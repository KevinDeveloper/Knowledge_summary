package com.opnext.domain.store;

import lombok.Data;

import java.net.URL;
import java.util.Map;

@Data
public class Resource {

    private Map<String, URL> resourceURL;

    public enum Type {
        ICON, SCREENSHOT, PACKAGE
    }
}
