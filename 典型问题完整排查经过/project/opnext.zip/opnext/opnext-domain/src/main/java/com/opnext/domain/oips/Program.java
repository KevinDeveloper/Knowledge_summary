package com.opnext.domain.oips;

import lombok.Data;
import java.util.List;

/**
 * 小节目
 */
@Data
public class Program {

	/**
	 * 节目编号
	 */
	private String id;

	/**
	 * 名称
	 */
	private String name;

	/**
	 * 播放时间
	 */
	private String playerTime;

	
	/**
	 * 背景音乐音量(0-100)
	 * */
	private int volume;

	/**
	 * 广告list
	 * */
	private List<Component> adList;
	
	/**
	 * 背景音乐List
	 * */
	private List<Component> musicList;

	/**
	 * 排序
	 */
	private int sort;

}
