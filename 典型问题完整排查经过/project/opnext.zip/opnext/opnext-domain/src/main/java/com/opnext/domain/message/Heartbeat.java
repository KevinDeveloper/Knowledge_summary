package com.opnext.domain.message;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Heartbeat{
    @POrder(1)
    private String sn;
    /**
     * 本次发送的消息确认序列号
     */
    @POrder(2)
    private long seq;
}
