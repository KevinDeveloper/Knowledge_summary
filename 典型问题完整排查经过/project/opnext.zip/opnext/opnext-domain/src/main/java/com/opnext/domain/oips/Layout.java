package com.opnext.domain.oips;

import lombok.Data;

@Data
public class Layout {
    private Type type;

    /**
     * type.FULL时不生效
     */
    private Pixel pixel;
    /**
     * type.FULL时不生效
     */
    private Position position = Position.CENTER;


    @Data
    public static class Pixel {
        private int width;
        private int height;
    }

    public enum Position {
        TOP, BOTTOM, CENTER, LEFT, RIGHT, TOP_LEFT, TOP_RIGHT, TOP_CENTER, BOTTOM_LEFT, BOTTOM_RIGHT, BOTTOM_CENTER
    }

    public enum Type {
        //全屏
        FULL,
        //画中画
        PIP
    }
}
