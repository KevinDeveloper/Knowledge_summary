package com.opnext.domain;

import lombok.AllArgsConstructor;

/**
 * @author wanglu
 */
@AllArgsConstructor
public enum DeviceAlarmType {
    /**
     * 温度过高
     */
    TEMPERATURE_TOO_HIGHT(1),
    /**
     * 摄像头损坏
     */
    CAMERA_BROKEN(2),
    /**
     * 存储预警
     */
    LACK_OF_STORAGE(3),
    /**
     * 设备离线
     */
    DEVICE_OFF_LINE(4),
    /**
     * 设备拆除告警
     */
    DEVICE_REMOVED(5);

    private int value;

    public int value(){
        return this.value;
    }
}
