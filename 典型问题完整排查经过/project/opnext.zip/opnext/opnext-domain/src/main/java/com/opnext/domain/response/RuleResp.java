package com.opnext.domain.response;

import com.opnext.domain.access.Rule;
import lombok.Data;

@Data
public abstract class RuleResp {
    private Rule rule;
}
