package com.opnext.domain;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

@Data
public class PersonInfo implements Serializable {
    /**
     * 服务端数据库ID
     */
    private String id;
    /**
     * 人员编号
     */
    private String no;
    /**
     * 人员姓名
     */
    private String name;
    /**
     * 人员年龄
     */
    private Integer age;
    /**
     * 租户ID
     */
    private long tenantId;
    /**
     * 组织ID
     */
    private int organizationId;
    /**
     * 手机号
     */
    private String phone;
    /**
     * 人脸图像
     */
    private Map<ResourceType, List<URL>> avatars;
    /**
     * 特征库ID
     */
    private String groupId;
    /**
     * 特征库名称
     */
    private String groupName;
    /**
     * 规则ID
     */
    private String ruleId;
    /**
     * 动态字段
     */
    private Map<String, String> variable;
    /**
     * IC卡号
     */
    private String icNumber;
    /**
     * 韦根号码
     */
    private String wgNumber;
    /**
     * 性别
     */
    private Sex sex;
    /**
     * 人员类型
     */
    private PersonType type;
    /**
     * 创建时间
     */
    private Long createTime;
    /**
     * 创建时间
     */
    private Long updateTime;
    /**
     * 身份证号
     */
    private String idCard;

    /**
     * 人员更新的版本号
     */
    private long version;

    /**
     * 人脸特征
     */
    private Map<ResourceType, List<Feature>> features;

}
