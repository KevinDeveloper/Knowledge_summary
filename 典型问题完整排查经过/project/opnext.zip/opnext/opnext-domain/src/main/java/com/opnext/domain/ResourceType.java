package com.opnext.domain;

public enum ResourceType {
    VISIBLE_LIGHT, NEAR_INFRARED
}
