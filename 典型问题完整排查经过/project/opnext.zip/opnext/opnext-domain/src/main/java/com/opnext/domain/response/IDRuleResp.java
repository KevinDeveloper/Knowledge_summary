package com.opnext.domain.response;

import com.opnext.domain.Pageable;
import com.opnext.domain.access.RulePerson;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.List;

@EqualsAndHashCode
@Data
@RequiredArgsConstructor
public class IDRuleResp implements Pageable {
    private String nextPage;
    private int ruleId;
    private List<RulePerson> rulePersonList;
    private SetupType setupType;
    private OperationType operationType;

    public enum SetupType {
        ORGNIZATION, PERSON
    }

    public enum OperationType{
        BIND,UNBIND
    }
}
