package com.opnext.domain.exception;

import com.opnext.domain.message.Report;
import lombok.Getter;

@Getter
public class ReportTypeIllegalException extends RuntimeException {
    private Report report;

    public ReportTypeIllegalException(Report report, String message) {
        super(message);
        this.report = report;
    }
}
