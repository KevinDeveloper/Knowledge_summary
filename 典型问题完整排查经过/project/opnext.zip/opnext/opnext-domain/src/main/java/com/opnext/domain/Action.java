package com.opnext.domain;

public enum Action {
    ALLOW, DENY
}
