package com.opnext.domain.message;

import java.lang.annotation.*;

/**
 * ProtoStuff 字段顺序
 * 服务端与终端交互的 domain 实体必须添加顺序且不能有重复值
 *
 * @author yeguangkun on 2018/8/17 上午11:24
 * @version 1.0
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.FIELD})
@Documented
public @interface POrder {
    int value() ;
}
