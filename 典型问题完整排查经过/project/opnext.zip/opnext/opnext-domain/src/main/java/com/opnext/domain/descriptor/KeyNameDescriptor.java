package com.opnext.domain.descriptor;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class KeyNameDescriptor extends Descriptor {
    private String keyName;
}
