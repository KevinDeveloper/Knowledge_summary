package com.opnext.domain;

import lombok.Data;

import java.io.Serializable;

/**
 * @author tianzc
 */
@Data
public class IdentifyCard implements Serializable {
    /**
     * 姓名
     */
    private String name;
    /**
     *  性别
     */
    private Sex sex;
    /**
     * 民族
     */
    private String nation;
    /**
     * 出生日期
     */
    private String birthday;
    /**
     * 住址
     */
    private String address;
    /**
     * 证件号码
     */
    private String idCard;
    /**
     * 签发机关
     */
    private String signOrg;
    /**
     * 签发日期
     */
    private String signBegin;
    /**
     * 有效期至
     */
    private String signEnd;
    /**
     * 国家代码
     */
    private String countryCode;
    /**
     * 出生地点
     */
    private String birthPlace;
    /**
     * 签发地点
     */
    private String issuePlace;
    /**
     * 身份证照片
     */
    private String imageUrl;
}
