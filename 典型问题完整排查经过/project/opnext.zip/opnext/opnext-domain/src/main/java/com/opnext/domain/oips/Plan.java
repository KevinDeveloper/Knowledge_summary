package com.opnext.domain.oips;

import lombok.Data;

import java.util.List;
import java.util.Map;
/**
 * 信发下发实体类
 * 播放计划（播放计划-->大节目-->屏幕-->小节目--->组件-->素材）
 */
@Data
public class Plan {

	/**
	 * 计划编号
	 */
	private String id;

	/**
	 * 计划名称
	 */
	private String name;

	/**
	 * 计划生效开始时间
	 */
	private Long startTime;

	/**
	 * 计划生效结束时间
	 */
	private Long stopTime;

	/*
	时间策略类型，cycle：时间段循环执行，
	timing：指定时间执行，now：立即执行，
	IntervalCycle:间隔循环执行, 4 mat 垫片，
	每个终端只能有1个垫片，如果发送了重复的垫片类型，可以直接覆盖，通常startTime，stopTime将失效
	 */
	public enum Type {
		CYCLE((byte) 0), TIMING((byte) 2), NOW((byte) 3), IINTERVALCYCLE((byte) 1), MAT((byte) 4);
		private byte value;

		private Type(byte value) {
			this.value = value;
		}

		public byte value() {
			return this.value;
		}
	}

	private Type type;

	/**
	 * 周期表达式
	 */
	private String cron;

	/**
	 * 是否插播：0 否 1 是
	 */
	private boolean intercut;

	private List<Screen> screenList;
}
