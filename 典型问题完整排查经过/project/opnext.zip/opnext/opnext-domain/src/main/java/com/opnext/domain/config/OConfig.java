package com.opnext.domain.config;
import com.opnext.domain.descriptor.VisibleDescriptor;
import lombok.Data;

@Data
public class OConfig<T> {
    private String key;
    private T value;
    private VisibleDescriptor descriptor;
}
