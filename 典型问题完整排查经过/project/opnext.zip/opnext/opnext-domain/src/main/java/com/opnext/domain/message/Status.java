package com.opnext.domain.message;

public enum  Status {
    /**
     * 消息创建到数据库
     */
    CREATED(10),

    /**
     * 塞入消息队列失败
     */
    QUEUE_FAIL(19),
    /**
     * 排队中
     */
    QUEUEING(20),

    /**
     * 发送中
     */
    SENDING(30),

    /**
     * 中断-终端失联、服务处理异常
     */
    SUSPEND(35),

    /**
     * 抵达
     */
    RECEIVED(40),

    /**
     * 已回调
     */
    CALLBACKED(50),

    /**
     * 反馈成功
     */
    SUCCESS(60),

    /**
     * 反馈失败
     */
    FAIL(61);

    private int code;

    Status(int code) {
        this.code = code;
    }

    public int getCode() {
        return this.code;
    }
}
