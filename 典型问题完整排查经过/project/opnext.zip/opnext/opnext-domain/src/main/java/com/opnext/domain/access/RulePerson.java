package com.opnext.domain.access;

import com.opnext.domain.PersonInfo;
import lombok.Data;

@Data
public class RulePerson {
    /**
     * 人员ID
     */
    private String personId;

    /**
     * 终端需要按此字段判断人员更新状态：
     * 如终端库中人员version与此version一致，则放弃更新人员信息；
     * 如不一致则检查info是否为空，如果不为空则用info中内容更新终端人员库，如为空则通过Rest接口更新终端人员库
     * 此Rest接口从获取服务列表接口中得到。
     */
    private long version;
    /**
     * 非必须字段，当按规则下发人员时，会出现此字段
     */
    private PersonInfo info;
}
