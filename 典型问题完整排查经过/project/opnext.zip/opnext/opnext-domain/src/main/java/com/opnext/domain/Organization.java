package com.opnext.domain;

import lombok.Data;

@Data
public class Organization {
    private int id;
    private long tenantId;
    private String name;
    private int parent;
}
