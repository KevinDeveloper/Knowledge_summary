package com.opnext.domain;

import lombok.Data;

import java.io.Serializable;

/**
 * @author tianzc
 */
@Data
public class DeviceInfo implements Serializable {
    private String sn;
    /**
     * 设备名称
     */
    private String name;
}
