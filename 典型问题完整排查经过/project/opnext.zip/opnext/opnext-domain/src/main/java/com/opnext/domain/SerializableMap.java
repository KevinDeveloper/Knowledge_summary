package com.opnext.domain;

import java.io.Serializable;
import java.util.HashMap;

/**
 *  序列化Map
 * @author tianzc
 */
public class SerializableMap<K,V> extends HashMap<K,V> implements Serializable {
}
