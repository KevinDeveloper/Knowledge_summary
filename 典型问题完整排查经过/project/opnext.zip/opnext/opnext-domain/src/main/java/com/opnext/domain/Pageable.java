package com.opnext.domain;

public interface Pageable {
    String getNextPage();
}
