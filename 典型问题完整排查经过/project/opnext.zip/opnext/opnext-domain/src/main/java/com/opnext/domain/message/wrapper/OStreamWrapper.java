package com.opnext.domain.message.wrapper;

import com.opnext.domain.message.*;
import lombok.Getter;
import lombok.Setter;

public class OStreamWrapper {
    @POrder(1)
    @Setter @Getter private Object entity;

    public boolean isHeartbeat() {
        return entity instanceof Heartbeat;
    }

    public Heartbeat getHeartbeat() {
        return (Heartbeat) entity;
    }

    public boolean isReport() {
        return entity instanceof Report;
    }

    public Report getReport() {
        return (Report) entity;
    }

    public boolean isCommand() {
        return entity instanceof Command;
    }

    public Command getCommand() {
        return (Command) entity;
    }

    public boolean isConfirm(){return entity instanceof Confirm; }

    public Confirm getConfirm() {return (Confirm) entity;}

    public static OStreamWrapper wrap(Object entity) {
        if(entity instanceof Heartbeat || entity instanceof Confirm ||
                entity instanceof Report || entity instanceof Command) {
            OStreamWrapper streamWrapper = new OStreamWrapper();
            streamWrapper.setEntity(entity);
            return streamWrapper;
        }
        throw new IllegalArgumentException("OStream Wrapper only wrap Command | Heartbeat | Report");
    }
}
