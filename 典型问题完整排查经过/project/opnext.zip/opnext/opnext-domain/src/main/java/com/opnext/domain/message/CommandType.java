package com.opnext.domain.message;


/**
 * 命令类型
 * 消息中心根据命令类型进行处理
 * 命令定义处理：http://wiki.opzoondev.com:8085/pages/viewpage.action?pageId=12124189
 *
 * @author yeguangkun on 2018/8/13 上午10:58
 * @version 1.0
 */
public enum CommandType {

    BLOCK_COMMAND("阻塞命令"),
    UNBLOCK_COMMAND("非阻塞命令"),
    WARNING_COMMAND("预警命令"),
    TIMING_COMMAND("定时命令"),
    CYCLE_COMMAND("周期命令")
    ;

    private String desc;

    CommandType(String desc) {
        this.desc = desc;
    }

}
