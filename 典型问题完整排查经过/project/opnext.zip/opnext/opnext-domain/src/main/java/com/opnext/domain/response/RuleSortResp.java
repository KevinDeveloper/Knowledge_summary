package com.opnext.domain.response;

import com.opnext.domain.Pageable;
import com.opnext.domain.access.Rule;
import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@RequiredArgsConstructor
public class RuleSortResp implements Pageable {
    private String nextPage;
    private List<Rule> ruleList;
    private String scriptContent;

    public String getNextPage() {
        return this.nextPage;
    }
}
