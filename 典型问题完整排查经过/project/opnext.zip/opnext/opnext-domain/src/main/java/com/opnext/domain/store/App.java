package com.opnext.domain.store;

import com.opnext.domain.Device;
import com.opnext.domain.I18n;
import lombok.Data;

import java.util.List;
import java.util.Map;

@Data
public class App {
    private int id;

    /**
     * 应用ID，不同的platform会产生同一个appId
     * @see #platform
     */
    private String appId;
    /**
     * 32位字符串，作为数据签名的KEY
     */
    private String secureKey;
    private Type type;
    private I18n<String, Info> info;
    private long createTime;
    private Platform platform;
    private String packageName;
    private String versionCode;
    private String versionName;
    private String latestVersion;
    private Long size;
    private Integer basis;
    /**
     * 解包后大小
     */
    private Long sizeUnzip;
    private long price;
    /**
     * 排序
     */
    private Integer rank;
    private String[] permissions;
    private long releaseDate;

    /**
     * type of resource URL
     * e.g.
     *  ICON, 64 -> http://xxx_64.png
     *  ICON, 128 -> http://xxx_128.png
     *  PACKAGE, 0 -> http://xxx.APK
     *           1200(versionCode) -> http://xxx_diff.APK（差分更新使用）
     */
    private Map<Resource.Type, Resource> resources;
    private Developer developer;
    private Channel channel = Channel.OPNEXT;
    private List<Device> supports;
    private List<String> categories;
    private Map<String, Object> extras;

    public enum Type {
        APP, ODSL, ROM, ZIP
    }

    public enum Platform {
        TERMINAL, SERVER
    }

    public enum Channel {
        OPNEXT
    }

    @Data
    public static class Info {
        private String name;
        private String nameIndex;
        private List<String> tags;
        private String description;
    }
}
