package com.opnext.domain.access;

import lombok.Data;

@Data
public class Range<T> {
    private T start;
    private T end;

    @Data
    public  class Day {
        private int year;
        private int mm;
        private int day;
    }

    @Data
    public class Time {
        private int hour;
        private int minute;
        private int second;
    }
}

