package com.opnext.domain.response;

import com.opnext.domain.Pageable;
import com.opnext.domain.PersonFeature;
import lombok.Data;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@RequiredArgsConstructor
public class FeatureResp implements Pageable {
    private String nextPage;
    private List<PersonFeature> personFeatureList;
}
