package com.opnext.domain.descriptor;

import com.opnext.domain.NameValuePair;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import java.util.List;

@Data
public class UI {
    public Type type;
    public List<NameValuePair> items;
    private Integer min;
    private Integer max;
    private Integer step;

    public enum Type {
        TEXT, PASSWORD, TOGGLE, RADIO, CHECKBOX, SELECT, SLIDEBAR, TEXTAREA
    }

}
