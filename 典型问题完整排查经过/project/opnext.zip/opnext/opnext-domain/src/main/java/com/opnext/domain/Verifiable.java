package com.opnext.domain;

import lombok.Data;

@Data
public abstract class Verifiable {
    private String beforeMethod;
    private String afterMethod;
    private String settingMethod;
}
