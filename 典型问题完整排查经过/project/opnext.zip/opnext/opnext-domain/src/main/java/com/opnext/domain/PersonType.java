package com.opnext.domain;

import lombok.AllArgsConstructor;

/**
 * @author tianzc
 */
@AllArgsConstructor
public enum PersonType {
    /**
     * 常客
     */
    FREQUENTER(0),
    /**
     * 访客
     */
    VISITOR(1);
    private int value;
    public int value(){
        return this.value;
    }
}
