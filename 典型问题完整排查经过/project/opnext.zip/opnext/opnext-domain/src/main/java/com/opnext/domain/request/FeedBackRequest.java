package com.opnext.domain.request;

import lombok.Data;

import java.util.List;

@Data
public class FeedBackRequest {
    private FeedBackStatus status;
    private List<FeedBackError> errorData;

    /**
     * @see com.opnext.domain.message.Status
     */
    public enum FeedBackStatus{
        /**
         * @see com.opnext.domain.message.Status.SUCCESS
         */
        SUCCESS(60),

        /**
         * @see com.opnext.domain.message.Status.FAIL
         */
        FAIL(61);

        private int code;
        private FeedBackStatus(int code) {
            this.code = code;
        }
    }

    @Data
    public static class FeedBackError {
        private String key;
        private String explain;
        private String content;
    }
}
