package com.opnext.domain.response;

import com.opnext.domain.access.Rule;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class ServiceRuleResp {
    private Rule rule;
}
