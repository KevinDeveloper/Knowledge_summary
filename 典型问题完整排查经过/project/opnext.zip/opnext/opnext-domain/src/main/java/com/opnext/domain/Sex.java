package com.opnext.domain;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * @author tianzc
 */
@AllArgsConstructor
public enum Sex {
    /**
     * 男
     */
    MALE((byte)0),
    /**
     * 女
     */
    FEMALE((byte)1);
//    /**
//     * 保密
//     */
//    SECRECY((byte)2);
    private Byte value;
    public Byte value(){
        return this.value;
    }
}
