package com.opnext.domain.response;

import com.opnext.domain.access.RulePerson;
import com.opnext.domain.message.Command;
import lombok.Data;

import java.util.List;

@Data
public class RulePersonResp {
    private String nextPage;
    private Command.CallBack errorCallback;
    private int ruleId;
    private List<RulePerson> rulePersonList;
    private IDRuleResp.OperationType operationType;
}
