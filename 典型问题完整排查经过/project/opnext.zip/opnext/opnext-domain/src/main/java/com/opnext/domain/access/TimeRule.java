package com.opnext.domain.access;

import com.opnext.domain.Action;
import lombok.Data;
import java.util.Calendar;
import java.util.List;
import java.util.Set;

@Data
public class TimeRule {

    /**
     * 名称
     */
    private String title;

    /**
     * 规则类型
     * 长期、自定义
     */
    private Type type;

    /**
     * 当type字段为CYCLE时此值为空
     * 当type字段为REGULAR时此值为日期时间段
     */
    private Range<Range.Day> dayRange;

    /**
     * 当dayRange生效时，不包含的日期，可不实现
     */
    private List<Range.Day> excludes;
    /**
     * 日期类型，与customDays联动
     * @see #customDays
     */
    private DayType dayType;

    /**
     * 当月dayType == EVERYDAY 时，此值为[1,2,3,4,5,6,7], 取值范围参考如下：
     *      @see Calendar.SUNDAY
     *      @see Calendar.MONDAY
     *      @see Calendar.TUESDAY
     *      @see Calendar.WEDNESDAY
     *      @see Calendar.THURSDAY
     *      @see Calendar.FRIDAY
     *      @see Calendar.SATURDAY
     * 当月dayType == WEEKDAY 时，此值为空
     * 当月dayType == CUSTOM 时，此值为周一至周日中的某几天
     */
    private Set<Integer> customDays;

    /**
     * 时间段
     */
    private Range<Range.Time> timeRange;

    private Action action;


    public enum DayType {
        //每天
        EVERYDAY,
        //工作日
        WEEKDAY,
        //自定义
        CUSTOM
    }
    public enum Type {
        //长期
        CYCLE,
        //定时
        TIMING
    }
}
