package com.opnext.domain.message;

import com.opnext.domain.OPNextConstant;
import com.opnext.domain.exception.ReportTypeIllegalException;
import lombok.*;

@Getter
@Setter
@Data
public class Report {
    private static final String EMPTY = "";
    private static final int MAX_TYPE_LENGTH = 32;
    @POrder(1)
    private String sn;
    @POrder(2)
    private String data;
    @POrder(3)
    private String appId = OPNextConstant.SELF_APP_ID;
    /**
     * 本次发送的消息确认序列号
     */
    @POrder(4)
    private long seq;

    /**
     * 所有Report会放到AMQP名为TerminalMarket的交换机中供人订阅
     * type字段是为了区分top
     * ic而制定的
     * 但由于是队列定位是消息市场，支持开放平台和第三方，所以不使用枚举类型限定
     * topic命名规则为，前缀+appId+type
     * type 格式为0-9A-Za-Z, 最长长度为32
     */
    @POrder(5)
    private String type;

    public Report() {}

    public Report(String sn, String data, String type) {
        this.sn = sn;
        this.data= data;
        this.type = type;
    }

    public Report(String sn, String data, String type, long seq) {
        this.sn = sn;
        this.data= data;
        this.type = type;
        this.seq = seq;
    }

    public void validateType() {
        if(null == type || EMPTY.equals(type)) {
            throw new ReportTypeIllegalException(this, "type must not be null");
        }
        for(int i = 0 ; i < type.length(); i ++) {
            if(i == MAX_TYPE_LENGTH) {
                throw new ReportTypeIllegalException(this, "type length must lt " + MAX_TYPE_LENGTH);
            }
            int ascii = (int)type.charAt(i);
            if(!((ascii >= '0' && ascii <= '9') ||
                (ascii >= 'A' && ascii <= 'Z') ||
                (ascii >= 'a' && ascii <= 'z') ||
                ascii == '.')
            ) {
                throw new ReportTypeIllegalException(this, "type format must be 0-9A-Za-Z.");
            }

        }
    }

}

