package com.opnext.domain.request;

import lombok.Data;

import java.util.List;

/**
 * @author tianzc
 */
@Data
public class CallBackRequest<T> {
    private List<T> errorDataList;
}
