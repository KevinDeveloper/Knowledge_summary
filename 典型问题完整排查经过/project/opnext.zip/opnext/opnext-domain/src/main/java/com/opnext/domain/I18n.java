package com.opnext.domain;

import java.util.LinkedHashMap;
import java.util.Locale;

public class I18n<String, T> extends LinkedHashMap<String, T> {

    public I18n<String, T> set(String locale, T content) {
        this.put(locale, content);
        return this;
    }
}
