package com.opnext.domain;

import lombok.Data;
import java.util.List;
import java.util.Map;

@Data
public class PersonFeature {
    private String personId;
    private Map<ResourceType, List<Feature>> features;
}
