package com.opnext.domain;

import lombok.Data;

@Data
public class NameValuePair {
    private String name;
    private String value;
}
