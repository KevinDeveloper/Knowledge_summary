package com.opnext.domain.store;

import lombok.Data;

@Data
public class Developer {
    private Integer id;
    private String name;
    private String website;
    private String description;
    private long registerTime;
}
