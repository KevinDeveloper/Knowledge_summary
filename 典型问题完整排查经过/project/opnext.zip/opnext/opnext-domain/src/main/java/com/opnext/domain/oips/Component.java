package com.opnext.domain.oips;

import lombok.Data;

import java.net.URI;
import java.util.List;

/**
 * 组件类
 */
@Data
public class Component {

	public enum Type {
		PICTURE((byte)3), VIDEO((byte)4), MUSIC((byte)0), HTML5((byte)1);
		private byte value;
		private Type(byte value){
			this.value=value;
		}
		public byte value(){
			return this.value;
		}
	}

	private Type type;


	/**
	 * 起始时间
	 */
	private Integer startTime;
	/**
	 * 结束时间
	 */
	private Integer endTime;

	private URI uri;
	/**
	 *组件编号（素材编号）
	 */
	private String id;
	/**
	 * 组件名称(素材名称）
	 */
	private String name;
}
