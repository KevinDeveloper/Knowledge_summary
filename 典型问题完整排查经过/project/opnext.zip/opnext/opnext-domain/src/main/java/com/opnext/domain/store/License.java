package com.opnext.domain.store;

import lombok.Data;

@Data
public class License {
    private String sn;
    private String urlPath;
}
