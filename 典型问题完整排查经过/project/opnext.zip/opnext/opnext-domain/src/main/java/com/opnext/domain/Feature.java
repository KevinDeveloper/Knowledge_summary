package com.opnext.domain;

import lombok.Data;

@Data
public class Feature {
    private String imageURL;
    private String base64Vectors;
}
