package com.opnext.domain.response;

import com.opnext.domain.I18n;
import com.opnext.domain.Pageable;
import com.opnext.domain.PersonInfo;
import com.opnext.domain.descriptor.KeyNameDescriptor;
import com.opnext.domain.message.Command;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

@Data
@RequiredArgsConstructor
public class PersonResp implements Pageable {
    private String nextPage;
    private Command.CallBack errorCallback;
    private List<PersonInfo> personInfoList;
    private I18n<String, List<KeyNameDescriptor>> descriptor;

}
