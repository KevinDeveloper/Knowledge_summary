package com.opnext.domain.oips;

import lombok.Data;
import java.util.List;

/**
 * 屏幕类
 */
@Data
public class Screen {

	private String id;
	private String name;
	private Layout layout;
	private List<Program> program;
}
