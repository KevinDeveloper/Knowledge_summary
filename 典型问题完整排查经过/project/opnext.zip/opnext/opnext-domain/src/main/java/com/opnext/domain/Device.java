package com.opnext.domain;

import java.util.List;

public enum Device {

}
