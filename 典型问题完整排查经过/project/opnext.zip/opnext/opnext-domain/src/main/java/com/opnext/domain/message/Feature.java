package com.opnext.domain.message;


import lombok.Data;

/**
 * 命令特征信息
 *
 * @author yeguangkun on 2018/8/13 下午1:30
 * @version 1.0
 */
@Data
public class Feature {

    /**
     * 阻塞集合名称
     */
    private String blockName;

    /**
     * 命令类型
     */
    private CommandType type;

    /**
     * 存活时间
     */
    private long liveTime;

    /**
     * 定时发送的时间时刻
     */
    private long timing;

    /**
     * 周期次数
     */
    private int cycleTime;

}
