package com.opnext.domain.message;

import com.opnext.domain.OPNextConstant;

public class ReportBuilder {
    public static Report commandReceived(Command command) {
        return new Report(command.getSn(),
                command.getRequestId(), OPNextConstant.REPORT_TYPE.STATUS.RECEIVED);
    }

    public static Report statusChange(String sn,
                                      String requestId, Status status) {
        return new Report(sn, requestId, "status." + status.name());
    }

    public static Report alert(String sn, String data) {
        return new Report(sn, data, OPNextConstant.REPORT_TYPE.TERMINAL_ALERT);
    }

}
