package com.opnext.domain;

import lombok.Data;

import java.util.List;

@Data
public class Response<T> {
    private long timestamp;
    private int status;
    private String message;
    private String path;
    private List<KeyError> errors;
    private T entity;

    @Data
    public static class KeyError {
        private String key;
        private String code;

        public KeyError(String key, String code) {
            this.key = key;
            this.code = code;
        }
    }
}
