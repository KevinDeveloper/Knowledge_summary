package com.opnext.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.net.URL;
import java.util.List;
import java.util.Map;

/**
 * @author tianzc
 */
@Data
public class AccessRecord {
    private String id;
    private DeviceInfo deviceInfo;
    private PersonInfo personInfo;
    /**
     *  证件信息（身份证、护照）
     */
    private IdentifyCard identifyCard;
    private String qrCode;
    private SerializableMap identifyInfo;
    private Long syncTime;
    /**
     * 识别结果
     */
    private ResultType resultType;
    /**
     * 验证失败原因
     */
    private RejectReason rejectReason;
    /**
     * 进出方式
     */
    private Type type;
    /**
     * 通行方式
     */
    private PassMode passMode;
    /**
     * 可见光打分
     */
    private String score;
    /**
     * 近红外打分
     */
    private String nirScore;
    /**
     * 照片地址
     * 可见光URL地址数组
     * 近红外URL地址数组
     * ResourceType枚举（可见光，近红外）
     */
    private Map<ResourceType, List<URL>> avatars;

    /**
     * 通行方式
     */
    @AllArgsConstructor
    public enum PassMode{
        /**
         * 人脸
         */
        FACE,
        /**
         * 人脸+身份证
         */
        FACE_AND_ID,
        /**
         * 人脸+护照
         */
        FACE_AND_PASSPORT,
        /**
         * 人脸+门禁卡
         */
        FACE_AND_GUARD,
        /**
         * 人脸+IC卡
         */
        FACE_AND_IC,
        /**
         * 二维码
         */
        QCODE,
        /**
         * 扫码枪
         */
        SCANNING_GUN
    }

    @AllArgsConstructor
    public enum ResultType {
        /**
         * 通过
         */
        TERMINAL_VALIDATION_PASS((byte)0),
        /**
         * 验证不通过
         */
        TERMINAL_VALIDATION_FAILURE((byte)1);
        private Byte value;
        public Byte value(){
            return this.value;
        }
    }

    @AllArgsConstructor
    public enum RejectReason {
        /**
         * 人脸比对不通过
         */
        FACIAL_COMPARISON_NOT_PASS((byte)0),
        /**
         * 黑名单拒绝通行
         */
        BLACKLIST_EXCEEDS_REFUSE((byte)1),
        /**
         * 人员规则
         */
        PERSONNAL_RULE_VALIDATION_FAILURE((byte)2),
        /**
         * 指纹验证失败
         */
        FINGERPRINT_VALIDATION_FAILURE((byte)3),
        /**
         * 无效认证
         */
        INVALID_VALIDATION((byte)4);
        private Byte value;
        public Byte value(){
            return this.value;
        }
    }

    @AllArgsConstructor
    public enum Type {
        IN_TYPE((byte)0),OUT_TYPE((byte)1);
        private Byte value;
        public Byte value(){
            return this.value;
        }
    }
}
