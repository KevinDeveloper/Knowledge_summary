package com.opnext.domain;

public class OPNextServerUtils {

    private final static String EMPTY = "";
    /**
     * 获取系统环境变量参数的工具类
     * @return OPNext.S uri
     */
    public static String getOPNextProperties(String key) {
        String uri = System.getProperty(key);
        if(null == uri || EMPTY.equals(uri)) {
            uri = System.getenv(key);
        }
        return uri;
    }
}
