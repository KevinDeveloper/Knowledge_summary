package com.opnext.domain.message;

import lombok.Data;

@Data
@SuppressWarnings({"WeakerAccess", "unused"})
public class Command {

    @POrder(1)
    private long timestamp;
    @POrder(2)
    private String workflowId;
    @POrder(3)
    private String commandId;
    @POrder(4)
    private String requestId;
    @POrder(5)
    private String sn;
    @POrder(6)
    private String appId;
    @POrder(7)
    private Code code;
    @POrder(8)
    private CallBack callBack;
    @POrder(9)
    private CallBack feedBack;
    @POrder(10)
    private String data;
    /**
     * 本次发送的消息确认序列号
     */
    @POrder(11)
    private long seq;

    @Data
    public static class CallBack {
        @POrder(1)
        private String url;
        @POrder(2)
        private Method method;
        @POrder(3)
        private String response;
        @POrder(4)
        private String request;
        @POrder(5)
        private boolean pageable;
    }

    public enum Method {
        GET, POST
    }
}
