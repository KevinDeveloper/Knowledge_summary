package com.opnext.domain.message;

/**
 * 消息类型
 *
 * @author yeguangkun on 2018/7/24 下午3:01
 * @version 1.0
 */
public enum MessageType {
    /** 命令信息 */
    COMMAND,
    /** 上报消息 */
    REPORT,
    /** 心跳信息 */
    HEARTBEAT,
    /** 确认信息 */
    CONFIRM;
}
