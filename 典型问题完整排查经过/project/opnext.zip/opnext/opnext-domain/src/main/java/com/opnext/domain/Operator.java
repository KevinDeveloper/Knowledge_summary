package com.opnext.domain;

import lombok.Data;

@Data
public class Operator {
    private String tenantId;
    private String admin;
    private Operator() {}

    public static Operator tenant(String tenantId) {
        Operator operator = new Operator();
        operator.tenantId = tenantId;
        return operator;
    }

    public Operator admin(String admin) {
        this.admin = admin;
        return this;
    }
}
