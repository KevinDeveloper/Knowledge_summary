package com.opnext.domain;

public interface OPNextConstant {
    String SELF_APP_ID = "00000";

    /**
     * FeedBackRequest
     */
    String COMMON_FEEDBACK_REQUEST_NAME = "FeedBackRequest";

    /*
     * 以下是 MQ 消息的 Exchange、RoutingKey、Queue 名称命名原则，
     *
     * Exchange:    以 '业务场景.' + 'exchange',
     *              eg: 终端命令下发 'terminal_command.' + 'exchange'
     * RoutingKey:  以 '业务场景.'  + '操作名.' + 'routing_key'
     *              eg: OStream 接受 MQ 命令："terminal_command." + "received." + "routing_key"
     * Queue:       以 '服务名.' + '业务场景.'  + '操作名.' + 'queue'
     *              eg: OStream 接受 MQ 命令：'ostream.' + "terminal_command." + "received." + "queue"
     *
     */
    /** 终端指令下发 Exchange*/
    String COMMAND_MESSAGE_EXCHANGE_NAME = "terminal_command.exchange";
    String COMMAND_MESSAGE_ROW_KEY = "";
    String REPORT_MARKET_EXCHANGE_NAME = "report.exchange";
    /** 人员识别记录推送 Exchange */
    String PERSON_ACCESS_RECORD_EXCHANGE_NAME = "person_access_record.exchange";
    /** O-Stream 推送在线设备 Exchange */
    String ONLINE_TERMINAL_SNS_EXCHANGE_NAME = "online_terminal_sns.exchange";

    /**
     * 私有云中有DNS服务情况下可使用此属性获取OPNext.S的地址
     */
    String OPNEXT_SERVER_URI = "https://server.opnext.com/";
    interface REPORT_TYPE {
        String TERMINAL_ALERT = "alert.terminal";
        interface STATUS {
            String RECEIVED = "status.RECEIVED";
        }
        interface ALERT {
            String OFF_LINE = "DEVICE_OFF_LINE";
            String NO_HEARTBEAT = "DEVICE_NO_HEARTBEAT";
            String RECOVERY = "DEVICE_RECOVERY";
        }
    }
}
