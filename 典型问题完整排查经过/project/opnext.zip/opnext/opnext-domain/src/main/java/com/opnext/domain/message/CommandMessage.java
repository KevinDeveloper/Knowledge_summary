package com.opnext.domain.message;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class CommandMessage<T> {
    private Command command;
    private Status status;
    private Time time = new Time();
    /**
     * 所属ID（租户ID）
     */
    private String tenantId;
    private String sn;
    private String operator;
    /**
     * highest is zero
     * @deprecated
     */
    private int priority = 0;
    private T data;


    @Data
    public static class Time {
        private long create;
        private long queue;
        private List<Long> send = new ArrayList<>();
        private long arrived;
        private long callback;
        private long feedback;

        public void addSendTime(long timestamp) {
            send.add(timestamp);
        }
    }
}
