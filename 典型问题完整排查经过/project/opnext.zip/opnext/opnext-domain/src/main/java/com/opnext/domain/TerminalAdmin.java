package com.opnext.domain;

import lombok.Data;

import java.net.URL;
import java.util.List;

@Data
public class TerminalAdmin {
    private Integer id;
    private String name;
    private List<URL> avatars;
    private String password;
}
