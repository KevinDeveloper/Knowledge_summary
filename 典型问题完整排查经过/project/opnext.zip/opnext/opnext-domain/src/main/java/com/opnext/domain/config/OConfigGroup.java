package com.opnext.domain.config;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class OConfigGroup implements Serializable {
    private String name;
    private List<OConfig> configList;
}
