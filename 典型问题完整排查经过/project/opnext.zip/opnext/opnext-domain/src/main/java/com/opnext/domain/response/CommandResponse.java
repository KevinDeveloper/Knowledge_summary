package com.opnext.domain.response;

import com.opnext.domain.OPNextConstant;
import com.opnext.domain.message.Command;
import lombok.Data;

@Data
public class CommandResponse<T> {
    private static final String FEED_BACK_REQUEST_NAME = "FeedBackRequest";
    private static final String FEED_BACK_URL_TEMPLATE =
            OPNextConstant.OPNEXT_SERVER_URI + "api/o-message/feedback/{workflowId}/{commandId}/{requestId}";

    private long timestamp;
    private int status;
    private String message;
    private T entity;
    private Command.CallBack feedBack;

    private CommandResponse() {
        this.feedBack = new Command.CallBack();
        this.feedBack.setUrl(FEED_BACK_URL_TEMPLATE);
        this.feedBack.setRequest(FEED_BACK_REQUEST_NAME);
    }

    /**
     * 调用CallbackURL成功时所使用的构造函数
     * @param entity 返回实体类，通常传入com.opnext.domain.response.**Resp即可
     */
    public CommandResponse(T entity) {
        this();
        this.setEntity(entity);
        this.status = 200;
        this.setTimestamp(System.currentTimeMillis());
    }

    public CommandResponse(T entity, String workflowId, String commandId, String requestId) {
        this(entity);
        this.feedBack.setUrl(OPNextConstant.OPNEXT_SERVER_URI+
                "api/o-message/feedback/" + workflowId + "/" + commandId + "/" + requestId);
        this.feedBack.setRequest(FEED_BACK_REQUEST_NAME);
    }

    public CommandResponse(T entity, String feedbackURL, String requestBodyName) {
        this(entity);
        this.feedBack = new Command.CallBack();
        this.feedBack.setUrl(feedbackURL);
        this.feedBack.setRequest(requestBodyName);
    }

    /**
     * 调用CallbackURL失败时所使用的构造函数
     * @param status 错误码，不允许传入200
     * @param message 错误信息，通常是国际化文件的key，但需要让终端了解key的含义
     */
    public CommandResponse(int status, String message) {
        if(200 == status) {
            throw new IllegalArgumentException("200 status can not access this constructor");
        }
        this.setStatus(status);
        this.setMessage(message);
        this.setTimestamp(System.currentTimeMillis());
    }

    public void setStatus(int status) {
        throw new IllegalArgumentException("please use constructor to set status");
    }
}
