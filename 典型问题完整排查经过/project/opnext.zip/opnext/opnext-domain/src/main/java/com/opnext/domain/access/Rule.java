package com.opnext.domain.access;

import lombok.Data;

import java.util.List;

@Data
public class Rule {
    /**
     * 服务端数据库ID
     */
    private int id;
    /**
     * 规则名称
     */
    private String name;
    /**
     * 规则描述
     */
    private String description;
    /**
     * 规则提示
     */
    private String prompt;
    /**
     * 可支持识别类型
     */
    private List<AccessType> type;
    /**
     * 时间规则
     */
    private List<TimeRule> timeRule;
    /**
     * 访问单有效期至
     */
    private Long validTill;
    /**
     * 是否为服务端规则
     */
    private Boolean isServiceRule;

    public enum AccessType {
        /**
         * 人脸
         */
        FACE,
        /**
         * 人脸+身份证
         */
        FACE_AND_ID,
        /**
         * 人脸+护照
         */
        FACE_AND_PASSPORT,
        /**
         * 人脸+门禁卡
         */
        FACE_AND_GUARD,
        /**
         * 人脸+IC卡
         */
        FACE_AND_IC,
        /**
         * 二维码
         */
        QCODE,
        /**
         * 扫码枪
         */
        SCANNING_GUN
    }
}
