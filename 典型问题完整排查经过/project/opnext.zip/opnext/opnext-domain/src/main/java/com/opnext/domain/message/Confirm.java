package com.opnext.domain.message;


import lombok.Data;

/**
 * 消息确认
 *
 * @author yeguangkun on 2018/7/24 下午2:55
 * @version 1.0
 */
@Data
public class Confirm {

    /**
     * SN 信息
     */
    @POrder(1)
    private String sn;

    /**
     * 确认 ID 号
     */
    @POrder(2)
    private long ackId;

    /**
     * 确认的消息类型
     */
    @POrder(3)
    private MessageType type;
}
