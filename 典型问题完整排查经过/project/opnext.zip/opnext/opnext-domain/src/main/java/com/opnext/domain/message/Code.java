package com.opnext.domain.message;

public enum Code {
    FETCH_DEVICE_INFO( 0),//获取终端配置信息
    OPEN_DOOR( 1),  //平台指令开门
    SYNC_DEVICE_INFO( 3),//平台指令同步配置信息
    DEVICE_REBOOT( 4),//平台指令重启
    DEVICE_RENAME(5),//平台指令重命名
    DEVICE_FACTORY_RESET(6),//平台指令恢复出厂设置
    DEVICE_UPGRADE_SOFT(7),//平台指令升级软件版本
    DEVICE_UPDATE_CONFIG(8),//平台指令修改配置信息
    SYNC_PERSON_INFO_FOR_RIGHT(9),//权限模板下发人员
    DEVICE_REMOVE_RECORD(10),//设备删除记录
    USER_SIGNATURE(11),//采集人脸特征
    STOP_SIGNATURE(12),//停止采集人脸特征
    DEVICE_DOWNLOAD(13),//平台指令下载升级包
    DEVICE_SETUP(14),//平台指令安装升级包
    DEVICE_GETPROGRESS(15),//平台指令获取下载/升级进度
    DEVICE_GETVERSION(16),//平台指令获取终端版本信息
    DEVICE_SET_ADMIN(17),//平台指令设置设备管理员信息
    DEVICE_GET_VOLUME(18),//平台指令获取设备容量信息
    DEVICE_STOPDOWNLOAD(19),//平台指令停止下载升级包
    DEVICE_EMPTY(20),//平台指令清空设备上所有数据
    DEVICE_PAUSEDOWNLOAD(21),//平台指令暂停下载升级包
    DEVICE_CONTINUEDOWNLOAD(22),//平台指令继续下载升级包
    DEVICE_CLEARUSER(23),//平台指令清空设备上所有数据不包括管理员
    DEVICE_GETBLACKLISTSTRATEGY(24),//平台通知终端获取黑名单策略
    DEVICE_UPLOADLOG(25),//平台通知终端上传日志
    DEVICE_DOWNLOAD_AD_ASYN(26),//平台通知终端现在广告信息

    /**
     * 1xx 应用操作
     */
    APP_ENABLE(100),//应用停用
    APP_DISABLE(101),//应用停用
    APP_UPDATE(102),//应用更新
    LICENSE_UPDATE(103),//授权更新

    /**
     * 2xx 配置操作
     */
    POST_CONFIG( 200),//发送终端配置信息
    GET_CONFIG( 201),//获取终端配置信息

    /**
     * 3xx 人员操作
     */
    GET_PERSON( 300),//获取人员信息并提取图片特征并保存
    DELETE_PERSON( 301),//删除人员信息
    GET_PERSON_INFO( 302),//仅获取人员信息

    /**
     * 4xx 设备操作
     */
    ACTION_ALLOW( 400), //行为允许（如：开门）
    ACTION_DENY( 401), //行为不允许
    REBOOT( 402), // 重启
    RESET( 403), // 恢复出厂
    OPEN_ALWAYS( 404),   //常开
    OPEN_CANCEL( 405),  //取消常开

    /**
     * 5xx 规则操作
     */
    GET_RULE( 500), //获取规则
    DELETE_RULE( 501), //删除规则
    GET_DYNAMIC_RULE( 502), //动态规则
    GET_RULE_SORT( 503), //获取规则顺序
    BIND_RULE( 504), //绑定规则
    UNBIND_RULE( 505), //解绑规则

    /**
     * 6xx 管理员操作
     */
    SYNC_ADMIN( 600), //同步管理员

    /**
     * 特征提取
     */
    GET_PIC_FOR_FEATURE( 700), //获取图片并提取特征
    GET_FEATURE_TO_SAVE( 701); //更新特征





    private int value;

    Code(int value) {
        this.value = value;
    }

    public int value() {
        return this.value;
    }
}
