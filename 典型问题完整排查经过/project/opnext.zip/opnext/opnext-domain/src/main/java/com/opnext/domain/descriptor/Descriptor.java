package com.opnext.domain.descriptor;

import com.opnext.domain.Verifiable;
import lombok.Data;

@Data
public class Descriptor extends Verifiable {
    private String explain;
    private boolean required;
    private boolean unique;
    private boolean readonly;
    private int limit;
}
