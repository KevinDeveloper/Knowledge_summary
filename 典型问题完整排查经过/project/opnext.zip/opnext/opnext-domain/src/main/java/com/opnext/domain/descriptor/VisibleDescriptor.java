package com.opnext.domain.descriptor;

import lombok.Data;

@Data
public class VisibleDescriptor extends Descriptor {
    private UI ui;
}
