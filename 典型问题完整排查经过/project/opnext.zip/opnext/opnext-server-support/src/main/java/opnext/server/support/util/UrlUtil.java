package opnext.server.support.util;

import lombok.experimental.UtilityClass;

import java.util.Objects;
import java.util.Optional;
import java.util.regex.Pattern;

/**
 * UrlUtil
 *
 * @author yeguangkun on 2018/10/9 上午9:43
 * @version 1.0
 */
@UtilityClass
public class UrlUtil {

    public static final String FTP_SCHEME = "ftp";
    public static final String FILE_SCHEME = "file";
    public static final String HTTP_SCHEME = "http";
    public static final String HTTPS_SCHEME = "https";

    /** 全路径 URL 匹配模式 */
    private static final Pattern ABSOLUTELY_PATTERN = Pattern.compile("^(http|https|ftp|file)\\://([a-zA-Z0-9\\.\\-]+(\\:[a-zA-Z0-9\\.&amp;%\\$\\-]+)*@)*((25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])|localhost|([a-zA-Z0-9\\-]+\\.)*[a-zA-Z0-9\\-]+\\.(com|edu|gov|int|mil|net|org|biz|arpa|info|name|pro|aero|coop|museum|[a-zA-Z]{2}))(\\:[0-9]+)*(/($|[a-zA-Z0-9\\.\\,\\?\\'\\\\\\+&amp;%\\$#\\=~_\\-]+))*$");
    /** Path Query Fragment 匹配模式 */
    private static final Pattern PATH_QUERY_FRAGMENT_PATTERN = Pattern.compile("^(/[^/][a-zA-Z0-9\\.\\,\\?\\'\\\\/\\+&amp;%\\$#\\=~_\\-@]*)*$");
    /** IPV4 匹配模式 */
    private static final Pattern IPV4_PATTERN = Pattern.compile("(?=(\\b|\\D))(((\\d{1,2})|(1\\d{1,2})|(2[0-4]\\d)|(25[0-5]))\\.){3}((\\d{1,2})|(1\\d{1,2})|(2[0-4]\\d)|(25[0-5]))(?=(\\b|\\D))\n");
    /** 协议域名匹配模式 */
    private static final Pattern SCHEME_HOST_PATTERN = Pattern.compile("^(http|https|ftp|file)\\://([a-zA-Z0-9\\.\\-]+(\\:[a-zA-Z0-9\\.&amp;%\\$\\-]+)*@)?((25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9])\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[1-9]|0)\\.(25[0-5]|2[0-4][0-9]|[0-1]{1}[0-9]{2}|[1-9]{1}[0-9]{1}|[0-9])|([a-zA-Z0-9\\-]+\\.)*[a-zA-Z0-9\\-]+\\.[a-zA-Z]{2,4})(\\:[0-9]+)?");

    /**
     * 判断是否为绝对 URL
     *
     * @param url  URL
     * @return     boolean
     */
    public static boolean isAbsolutely(final String url){
        if (Objects.isNull(url) || url.length() == 0) {
            return false;
        }

        return ABSOLUTELY_PATTERN.matcher(url).matches();

    }

    /**
     * 判断是否为相对 URL
     *
     * @param url  URL
     * @return     boolean
     */
    public static boolean isPathQueryFragment(final String url) {
        if (Objects.isNull(url) || url.length() == 0) {
            return false;
        }

        return PATH_QUERY_FRAGMENT_PATTERN.matcher(url).matches();
    }

    /**
     * 获取完整 URL
     *
     * @param scheme        协议
     * @param ip            IP
     * @param port          端口
     * @param relativeUrl   Path_Query_Fragment
     * @return              Optional Url
     */
    public static Optional<String> absolutely(final String scheme, final String ip,
                                              final int port, final String relativeUrl) {
        // 判断 scheme
        if (FTP_SCHEME.equals(scheme) || FILE_SCHEME.equals(scheme) || HTTP_SCHEME.equals(scheme) ||
                HTTPS_SCHEME.equals(scheme)) {
            if (Objects.nonNull(ip) && IPV4_PATTERN.matcher(ip).matches() && port > 0 && port < 65535) {
                return Optional.of(scheme + "://" + ip + ":" + port + (Objects.isNull(relativeUrl) ? "" : relativeUrl));
            }
        }

        return Optional.empty();
    }

    /**
     * 获取完整 URL
     *
     * @param scheme         协议
     * @param domain         域名
     * @param relativeUrl    Path_Query_Fragment
     * @return               Optional Url
     */
    public static Optional<String> absolutely(final String scheme, final String domain, final String relativeUrl) {
        // 判断 scheme
        if (FTP_SCHEME.equals(scheme) || FILE_SCHEME.equals(scheme) || HTTP_SCHEME.equals(scheme) ||
                HTTPS_SCHEME.equals(scheme)) {
            if (Objects.nonNull(domain) && domain.length() > 0) {
                return Optional.of(scheme + "://" + domain + (Objects.isNull(relativeUrl) ? "" : relativeUrl));
            }
        }

        return Optional.empty();
    }

    /**
     * 获取完整 URL
     *
     * @param schemeDomain         协议 域名
     * @param relativeUrl    Path_Query_Fragment
     * @return               Optional Url
     */
    public static Optional<String> absolutely(final String schemeDomain, final String relativeUrl) {
        // 判断 scheme
        if (Objects.nonNull(schemeDomain) && SCHEME_HOST_PATTERN.matcher(schemeDomain).find()) {
            if (schemeDomain.length() > 0) {
                return Optional.of(schemeDomain + (Objects.isNull(relativeUrl) ? "" : relativeUrl));
            }
        }
        return Optional.empty();
    }

    /**
     * 获取完整 URL
     *
     * @param scheme         协议
     * @param domain         域名
     * @param port           端口
     * @param relativeUrl    Path_Query_Fragment
     * @return               Optional Url
     */
    public static Optional<String> absolutelyOfDomainPort(final String scheme, final String domain,
                                                        final int port, final String relativeUrl) {
        // 判断 scheme
        if (FTP_SCHEME.equals(scheme) || FILE_SCHEME.equals(scheme) || HTTP_SCHEME.equals(scheme) ||
                HTTPS_SCHEME.equals(scheme)) {
            if (Objects.nonNull(domain) && domain.length() > 0 && port > 0 && port < 65535) {
                return Optional.of(scheme + "://" + domain + ":" + port + (Objects.isNull(relativeUrl) ? "" : relativeUrl));
            }
        }

        return Optional.empty();
    }

    /**
     * 获取 Url path query fragment
     *
     * @param absolutelyUrl   完整 URL
     * @return                Optional path_query_fragment
     */
    public static Optional<String> urlPathQueryFragment(final String absolutelyUrl) {
        if (Objects.nonNull(absolutelyUrl) && absolutelyUrl.length() > 0) {
            if (isPathQueryFragment(absolutelyUrl)) {
                return Optional.of(absolutelyUrl);
            }

            String relativeUrl = SCHEME_HOST_PATTERN.matcher(absolutelyUrl).replaceAll("");
            if (Objects.isNull(relativeUrl) || relativeUrl.length() == 0) {
                relativeUrl = "/";
            }
            if (!relativeUrl.startsWith("/")) {
                relativeUrl = "/" + relativeUrl;
            }

            return Optional.of(relativeUrl);
        }

        return Optional.empty();
    }

    /**
     * 得到实际保存地址
     *
     * @param urlPath    未处理的地址
     * @param isRelative 是否为相对地址的开关
     * @return
     */
    public Optional<String> getStorePath(final String schemeAndHost, String urlPath, final boolean isRelative) {
        Optional<String> optional = Optional.ofNullable(urlPath);
        if (Objects.nonNull(urlPath) && urlPath.length() != 0) {
            //开始保存相对路径
            if (isRelative) {
                if (UrlUtil.isAbsolutely(urlPath)) {
                    optional = UrlUtil.urlPathQueryFragment(urlPath);
                }
            } else {
                //保存绝对路径
                if (!UrlUtil.isAbsolutely(urlPath)) {
                    optional = UrlUtil.absolutely(schemeAndHost, urlPath);
                }
            }
        }

        return optional;
    }

    /**
     * 给界面返回的全地址
     *
     * @param urlPath       实际保存地址
     * @param schemeAndHost 协议 ip
     * @return
     */
    public Optional<String> getShowPath(final String schemeAndHost, String urlPath) {
        Optional<String> optional = Optional.ofNullable(urlPath);
        if (Objects.nonNull(urlPath) && urlPath.length() != 0) {
            //返回全路径
            if (!UrlUtil.isAbsolutely(urlPath)) {
                optional = UrlUtil.absolutely(schemeAndHost, urlPath);
            }
        }
        return optional;
    }

}
