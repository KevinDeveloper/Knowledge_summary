package opnext.server.support.advise;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.TypeMismatchException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClientResponseException;

import javax.servlet.http.HttpServletRequest;

/**
 * @author David on 17/3/14.
 */
@ControllerAdvice(annotations = { RestController.class})
public class CommonExceptionSupport {
    private static final Logger LOGGER = LoggerFactory.getLogger(CommonExceptionSupport.class);

    @ExceptionHandler({Exception.class})
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public CommonResponse handleCommonException(HttpServletRequest request) {
        return CommonResponse.ErrorResponse.error(request.getServletPath(), HttpStatus.INTERNAL_SERVER_ERROR);
    }


    @ExceptionHandler({TypeMismatchException.class})
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public CommonResponse handleTypeMismatchException(HttpServletRequest request) {
        return CommonResponse.ErrorResponse.error(request.getServletPath(), HttpStatus.BAD_REQUEST.value(),
                "TypeMismatch");
    }

    @ExceptionHandler({HttpMediaTypeNotSupportedException.class})
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public CommonResponse handleMediaTypeNotSupportException(HttpServletRequest request) {
        return CommonResponse.ErrorResponse.error(request.getServletPath(), HttpStatus.BAD_REQUEST.value(),
                "HttpMediaTypeNotSupported");
    }

    @ExceptionHandler({MissingServletRequestParameterException.class})
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public CommonResponse handleHttpMissingRequestParams(HttpServletRequest request) {
        if(LOGGER.isDebugEnabled()) {
            LOGGER.debug("MissingServletRequestParameterException query:[{}]", request.getQueryString());
        }
        return CommonResponse.ErrorResponse.error(request.getServletPath(), HttpStatus.BAD_REQUEST.value(),
                "MissingServletRequestParameter");
    }

    @ExceptionHandler({HttpRequestMethodNotSupportedException.class})
    @ResponseStatus(HttpStatus.METHOD_NOT_ALLOWED)
    public CommonResponse handleHttpMethodNotSupport(HttpServletRequest request) {
        return CommonResponse.ErrorResponse.error(request.getServletPath(), HttpStatus.METHOD_NOT_ALLOWED.value(),
                "HttpRequestMethodNotSupported");
    }

    @ExceptionHandler({HttpMessageNotReadableException.class})
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public CommonResponse handleHttpMessageNotReadable(HttpServletRequest request) {
        return CommonResponse.ErrorResponse.error(request.getServletPath(), HttpStatus.BAD_REQUEST.value(),
                "HttpMessageNotReadable");
    }

    @ExceptionHandler({MethodArgumentNotValidException.class})
    @ResponseBody
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public CommonResponse handleMethodArgsException(HttpServletRequest request, MethodArgumentNotValidException ex) {
        return CommonResponse.ErrorResponse.error(request.getServletPath(), HttpStatus.BAD_REQUEST, ex.getBindingResult());
    }

    @SuppressWarnings("unchecked")
    @ExceptionHandler({RestClientResponseException.class})
    @ResponseBody
    public ResponseEntity<String> handleRestClientResponseException(HttpServletRequest request, RestClientResponseException ex) {
        LOGGER.error("RestClientResponseException error, path:{}, {}", request.getServletPath(), ex.getMessage());
        return new ResponseEntity(ex.getResponseBodyAsString(), ex.getResponseHeaders(), HttpStatus.valueOf(ex.getRawStatusCode()));
    }

}
