package opnext.server.support.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

public interface SingleDomainValidator<T> extends Validator {

    void valid(T t, Errors error);

    default boolean supports(Class<?> clazz) {
        return true;
    }

    default void validate(Object bean, Errors errors) {
        if(!errors.hasErrors()) {
            //noinspection unchecked
            this.valid((T) bean, errors);
        }
    }

}
