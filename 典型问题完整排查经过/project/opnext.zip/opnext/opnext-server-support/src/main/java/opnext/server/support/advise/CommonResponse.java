package opnext.server.support.advise;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Data
@SuppressWarnings("WeakerAccess")
public class CommonResponse<T> {
    private static Logger LOGGER = LoggerFactory.getLogger(CommonResponse.class);
    private long timestamp;
    private int status;
    private int code = 0;
    private String message;
    private String path;
    private T entity;

    public static <T> CommonResponse ok(T entity) {
        CommonResponse commonResponse = new CommonResponse();
        commonResponse.entity = entity;
        commonResponse.timestamp = System.currentTimeMillis();
        commonResponse.status = HttpStatus.OK.value();
        return commonResponse;
    }

    public static class ErrorResponse extends CommonResponse {
        @Setter
        @Getter
        private List<KeyError> errors;

        public static ErrorResponse error(String path) {
            return error(path, (String) null);
        }

        public static ErrorResponse error(String path, String message) {
            return error(path, HttpStatus.BAD_REQUEST.value(), message, null);
        }

        public static ErrorResponse error(String path, Errors errors) {
            return error(path, HttpStatus.BAD_REQUEST, errors);
        }

        public static ErrorResponse error(String path, HttpStatus status) {
            return error(path, status, null);
        }

        public static ErrorResponse error(String path, HttpStatus status, Errors errors) {
            return error(path, status.value(), status.getReasonPhrase(), errors);
        }

        public static ErrorResponse error(String path, int status, String message) {
            return error(path, status, message, null);
        }

        public static ErrorResponse error(String path, int status, String message, Errors errors) {
            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setTimestamp(System.currentTimeMillis());
            errorResponse.setPath(path);
            errorResponse.setStatus(status);
            errorResponse.setMessage(message);
            if (Objects.nonNull(errors)) {
                errorResponse.setErrors(coverToBeanError(errors));
            }
            LOGGER.debug("error response created: {}", errorResponse);
            return errorResponse;
        }

        private static List<KeyError> coverToBeanError(Errors errors) {
            return errors.getAllErrors().stream().map(error -> new KeyError(error instanceof FieldError ? ((FieldError) error).getField() : error.getObjectName(),
                    error.getCode())).collect(Collectors.toList());
        }

        @Data
        public static class KeyError {
            private String key;
            private String code;

            public KeyError(String key, String code) {
                this.key = key;
                this.code = code;
            }
        }
    }
}
