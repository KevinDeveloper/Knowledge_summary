package com.opnext.server.ostream.codec;

import com.opnext.domain.message.wrapper.OStreamWrapper;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.codec.MessageToByteEncoder;
import io.netty.handler.codec.MessageToMessageDecoder;
import io.protostuff.LinkedBuffer;
import io.protostuff.ProtostuffIOUtil;
import io.protostuff.runtime.RuntimeSchema;
import java.util.List;

public class OStreamCodec {
    private static final RuntimeSchema<OStreamWrapper> entitySchema =
            RuntimeSchema.createFrom(OStreamWrapper.class);
    public static class Decoder extends MessageToMessageDecoder<ByteBuf> {

        @Override
        protected void decode(ChannelHandlerContext ctx, ByteBuf msg, List<Object> out) throws Exception {
            int length = msg.readableBytes();
            byte[] array = new byte[length];
            msg.readBytes(array);
            OStreamWrapper message = entitySchema.newMessage();
            ProtostuffIOUtil.mergeFrom(array, message, entitySchema);
            out.add(message);
        }
    }

    public static class Encoder extends MessageToByteEncoder<OStreamWrapper> {
        @Override
        protected void encode(ChannelHandlerContext ctx, OStreamWrapper msg, ByteBuf out) throws Exception {
            LinkedBuffer buffer = LinkedBuffer.allocate(2048);
            //noinspection unchecked
            byte[] array = ProtostuffIOUtil.toByteArray(msg, entitySchema, buffer);
            out.writeBytes(array);
        }

    }
}
