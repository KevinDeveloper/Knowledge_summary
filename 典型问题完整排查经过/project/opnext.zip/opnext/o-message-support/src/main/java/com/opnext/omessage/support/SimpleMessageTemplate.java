package com.opnext.omessage.support;

import com.opnext.domain.OPNextConstant;
import com.opnext.domain.Operator;
import com.opnext.domain.TerminalAdmin;
import com.opnext.domain.access.Rule;
import com.opnext.domain.config.OConfigGroup;
import com.opnext.domain.message.Code;
import com.opnext.domain.message.Command;
import com.opnext.domain.request.FeedBackRequest;
import com.opnext.domain.store.App;
import com.opnext.domain.store.License;

import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


@SuppressWarnings({"unused", "WeakerAccess", "unchecked"})
public class SimpleMessageTemplate implements MessageTemplate{
    private static final Command.CallBack DEFAULT_FEEDBACK_BUILDER = CallBackBuilder.ready().method(Command.Method.POST).
        request(FeedBackRequest.class.getSimpleName()).url(
            OPNextConstant.OPNEXT_SERVER_URI + "api/o-message/feedback/{workflowId}/{commandId}/{requestId}"
        ).build();
    private Operator operator;
    private Set<String> deviceList;
    private MessageContext messageContext;
    private String appId;

    public static SimpleMessageTemplate operator(String tenantId, String admin) {
        SimpleMessageTemplate template = new SimpleMessageTemplate();
        template.operator = Operator.tenant(tenantId).admin(admin);
        template.appId = OPNextConstant.SELF_APP_ID;
        return template;
    }

    public SimpleMessageTemplate scope(Set<String> deviceList) {
        this.deviceList = deviceList;
        return this;
    }

    public SimpleMessageTemplate scope(String... deviceSN) {
        return scope(new HashSet<>(Arrays.asList(deviceSN)));
    }

    public SimpleMessageTemplate appId(String appId) {
        this.appId = appId;
        return this;
    }

    private void ready(Code code) {
        if(null == operator) {
            throw new NullPointerException("operator must be set!");
        }
        if(null == deviceList || deviceList.isEmpty()) {
            throw new NullPointerException("device sn list must be set!");
        }
        MessageContext messageContext = new MessageContext();
        messageContext.setCode(code);
        messageContext.setAppId(this.appId);
        messageContext.setOperator(operator);
        messageContext.setSnList(deviceList);
//        messageContext.setFeedBack(DEFAULT_FEEDBACK_BUILDER);
        this.messageContext = messageContext;
    }
    
    @Override
    public MessageContext appEnable(String appId) {
        ready(Code.APP_ENABLE);
        this.messageContext.setAppId(appId);
        return this.messageContext;
    }

    @Override
    public MessageContext appDisable(String appId) {
        ready(Code.APP_DISABLE);
        this.messageContext.setAppId(appId);
        return this.messageContext;
    }

    @Override
    public MessageContext appUpdate(App app) {
        ready(Code.APP_UPDATE);
        messageContext.setCallBack(CallBackBuilder.ready()
                .method(Command.Method.GET).response("APP").build());
        messageContext.setData(app);
        return this.messageContext;
    }

    @Override
    public MessageContext postConfig(URL postConfigURL) {
        return postConfig(postConfigURL.toString());
    }

    @Override
    public MessageContext postConfig(String postConfigURL) {
        ready(Code.POST_CONFIG);
        messageContext.setCallBack(CallBackBuilder.ready().url(postConfigURL)
                .method(Command.Method.POST).request("List<OConfigGroup>").build());
        return this.messageContext;
    }

    @Override
    public MessageContext getConfig(List<OConfigGroup> configGroups) {
        ready(Code.GET_CONFIG);
        messageContext.setCallBack(CallBackBuilder.ready()
                .method(Command.Method.GET).response("List<OConfigGroup>").build());
        messageContext.setData(configGroups);
        return this.messageContext;
    }

    @Override
    public MessageContext getConfig(OConfigGroup configGroup) {
        ready(Code.GET_CONFIG);
        messageContext.setCallBack(CallBackBuilder.ready()
                .method(Command.Method.GET).response("String").build());
        messageContext.setData(configGroup);
        return this.messageContext;
    }

    @Override
    public MessageContext getPerson(URL changedPersonURL) {
        return getPerson(changedPersonURL.toString());
    }

    @Override
    public MessageContext deletePerson(URL deletedPersonURL) {
        return deletePerson(deletedPersonURL.toString());
    }

    @Override
    public MessageContext getPersonInfo(URL changedPersonURL) {
        return getPersonInfo(changedPersonURL.toString());
    }

    @Override
    public MessageContext getPerson(String changedPersonURL) {
        ready(Code.GET_PERSON);
        messageContext.setCallBack(CallBackBuilder.ready().url(changedPersonURL)
                .method(Command.Method.GET).response("PersonResp").build());
        return this.messageContext;
    }

    @Override
    public MessageContext deletePerson(String deletedPersonURL) {
        ready(Code.DELETE_PERSON);
        messageContext.setCallBack(CallBackBuilder.ready().url(deletedPersonURL)
                .method(Command.Method.GET).response("PersonResp").build());
        return this.messageContext;
    }

    @Override
    public MessageContext getPersonInfo(String changedPersonURL) {
        ready(Code.GET_PERSON_INFO);
        messageContext.setCallBack(CallBackBuilder.ready().url(changedPersonURL)
                .method(Command.Method.GET).response("PersonResp").build());
        return this.messageContext;
    }

    @Override
    public MessageContext actionAllow() {
        ready(Code.ACTION_ALLOW);
        return this.messageContext;
    }

    @Override
    public MessageContext actionDeny() {
        ready(Code.ACTION_DENY);
        return this.messageContext;
    }

    @Override
    public MessageContext reboot() {
        ready(Code.REBOOT);
        return this.messageContext;
    }

    @Override
    public MessageContext reset() {
        ready(Code.RESET);
        return this.messageContext;
    }

    @Override
    public MessageContext openAlways() {
        ready(Code.OPEN_ALWAYS);
        return this.messageContext;
    }

    @Override
    public MessageContext openCancel() {
        ready(Code.OPEN_CANCEL);
        return this.messageContext;
    }

    @Override
    public MessageContext getRule(List<Rule> changedRuleList) {
        ready(Code.GET_RULE);
        messageContext.setCallBack(CallBackBuilder.ready()
                .method(Command.Method.GET).response("List<Rule>").build());
        messageContext.setData(changedRuleList);
        return this.messageContext;
    }

    @Override
    public MessageContext deleteRule(List<Integer> deletedRuleList) {
        ready(Code.DELETE_RULE);
        messageContext.setCallBack(CallBackBuilder.ready()
                .method(Command.Method.GET).response("List<Rule>").build());
        messageContext.setData(deletedRuleList);
        return this.messageContext;
    }

    @Override
    public MessageContext bindRule(URL url) {
        return bindRule(url.toString());
    }

    @Override
    public MessageContext unbindRule(URL url) {
        return unbindRule(url.toString());
    }

    @Override
    public MessageContext bindRule(String url) {
        ready(Code.BIND_RULE);
        messageContext.setCallBack(CallBackBuilder.ready().url(url)
                .method(Command.Method.GET).response("IDRuleResp").build());
        return this.messageContext;
    }

    @Override
    public MessageContext unbindRule(String url) {
        ready(Code.UNBIND_RULE);
        messageContext.setCallBack(CallBackBuilder.ready().url(url)
                .method(Command.Method.GET).response("Admin").build());
        return this.messageContext;
    }

    @Override
    public MessageContext licenseUpdate(License license) {
        ready(Code.LICENSE_UPDATE);
        messageContext.setCallBack(CallBackBuilder.ready()
                .method(Command.Method.GET).response("License").build());
        messageContext.setData(license);
        return this.messageContext;
    }

    @Override
    public MessageContext syncAdmin(URL allAdminURL) {
        return syncAdmin(allAdminURL.toString());
    }

    @Override
    public MessageContext syncAdmin(String allAdminURL) {
        ready(Code.SYNC_ADMIN);
        messageContext.setCallBack(CallBackBuilder.ready().url(allAdminURL)
                .method(Command.Method.GET).response("Admin").build());
        return this.messageContext;
    }

    public MessageContext syncAdmin(List<TerminalAdmin> adminList) {
        ready(Code.SYNC_ADMIN);
        messageContext.setCallBack(CallBackBuilder.ready()
                .method(Command.Method.GET).response("List<TerminalAdmin>").build());
        messageContext.setData(adminList);
        return this.messageContext;
    }

    @Override
    public MessageContext getPicForFeature(URL getPicURL, URL postFeatureURL) {
        return getPicForFeature(getPicURL.toString(),postFeatureURL.toString());
    }

    @Override
    public MessageContext getPicForFeature(String getPicURL, String postFeatureURL) {
        ready(Code.GET_PIC_FOR_FEATURE);
        messageContext.setCallBack(CallBackBuilder.ready().url(getPicURL)
                .method(Command.Method.GET).response("FeatureResp").build());
        messageContext.setFeedBack(CallBackBuilder.ready().url(postFeatureURL)
                .method(Command.Method.POST).response("List<PersonFeature>").build());
        return this.messageContext;
    }

    @Override
    public MessageContext getFeatureToSave(URL getFeatureURL) {
        return getFeatureToSave(getFeatureURL.toString());
    }

    @Override
    public MessageContext getFeatureToSave(String getFeatureURL) {
        ready(Code.GET_FEATURE_TO_SAVE);
        messageContext.setCallBack(CallBackBuilder.ready().url(getFeatureURL)
                .method(Command.Method.GET).response("FeatureResp").build());
        return this.messageContext;
    }

}
