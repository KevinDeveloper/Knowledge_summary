package com.opnext.omessage.support;

import com.opnext.domain.message.Command;

public class CallBackBuilder {
    private CallBackBuilder() {}
    private Command.CallBack callBack = new Command.CallBack();

    public static CallBackBuilder ready() {
        return new CallBackBuilder();
    }

    public CallBackBuilder url(String url) {
        this.callBack.setUrl(url);
        return this;
    }

    public CallBackBuilder method(Command.Method method) {
        this.callBack.setMethod(method);
        return this;
    }

    public CallBackBuilder response(String response) {
        this.callBack.setResponse(response);
        return this;
    }

    public CallBackBuilder request(String request) {
        this.callBack.setRequest(request);
        return this;
    }

    public CallBackBuilder pageable(boolean pageable) {
        this.callBack.setPageable(pageable);
        return this;
    }

    public Command.CallBack build() {
        return this.callBack;
    }
}
