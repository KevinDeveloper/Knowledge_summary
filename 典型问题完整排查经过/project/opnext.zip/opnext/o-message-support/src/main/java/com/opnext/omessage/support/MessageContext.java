package com.opnext.omessage.support;

import com.opnext.domain.Operator;
import com.opnext.domain.message.Code;
import com.opnext.domain.message.Command;
import com.opnext.domain.message.Feature;
import lombok.Data;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Data
public class MessageContext<T> {
    private Code code;
    private String appId;
    private Set<String> snList = new HashSet<>();
    private Command.CallBack callBack;
    private Command.CallBack feedBack;
    private Operator operator;
    /** 命令特性 */
    private Feature feature;
    private T data;
}
