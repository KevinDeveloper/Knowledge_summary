package com.opnext.omessage.support;

import com.alibaba.fastjson.JSONObject;
import com.opnext.domain.access.Rule;
import com.opnext.domain.config.OConfigGroup;
import com.opnext.domain.store.App;
import com.opnext.domain.store.License;

import java.net.URL;
import java.util.List;

@SuppressWarnings("unused")
public interface MessageTemplate {

    MessageContext appEnable(String appId);

    MessageContext appDisable(String appId);

    MessageContext appUpdate(App app);

    MessageContext postConfig(URL postConfigURL);

    MessageContext postConfig(String postConfigURL);

    MessageContext getConfig(List<OConfigGroup> configGroups);

    /**
     * 配置下发终端，OConfigGroup
     * @param configGroup
     * @return
     */
    MessageContext getConfig(OConfigGroup configGroup);

    MessageContext getPerson(URL changedPersonURL);

    MessageContext deletePerson(URL deletedPersonURL);

    MessageContext getPersonInfo(URL changedPersonURL);

    MessageContext getPerson(String changedPersonURL);

    MessageContext deletePerson(String deletedPersonURL);

    MessageContext getPersonInfo(String changedPersonURL);

    MessageContext actionAllow();

    MessageContext actionDeny();

    MessageContext reboot();

    MessageContext reset();

    MessageContext openAlways();

    MessageContext openCancel();

    MessageContext getRule(List<Rule> changedRuleList);

    MessageContext deleteRule(List<Integer> deletedRuleList);

    MessageContext bindRule(URL url);

    MessageContext unbindRule(URL url);

    MessageContext bindRule(String url);

    MessageContext unbindRule(String url);

    MessageContext licenseUpdate(License license);

    MessageContext syncAdmin(URL allAdminURL);
    MessageContext syncAdmin(String allAdminURL);

    MessageContext getPicForFeature(URL getPicURL, URL postFeatureURL);
    MessageContext getPicForFeature(String getPicURL, String postFeatureURL);

    MessageContext getFeatureToSave(URL getFeatureURL);
    MessageContext getFeatureToSave(String getFeatureURL);

}
