package com.opnext.license;


import com.google.common.base.Joiner;
import com.google.common.base.Splitter;
import com.google.common.collect.Maps;
import com.opnext.domain.store.App;
import com.opnext.license.dto.LicenseBase;
import lombok.extern.slf4j.Slf4j;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * license工具类，生成license具体内容
 *
 * @author js
 */
@Slf4j
public class LicenseUtil {
    public static final String TEMP_DIRC_PATH = "keypair";

    public static HashMap<String, Object> createLicense(LicenseBase licenseBase, List<App> appList) throws Exception {
        BufferedWriter bw = null;
        HashMap<String, Object> hashMap = Maps.newHashMap();
        StringBuffer stringBuffer = new StringBuffer();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd");

        licenseBase.setDate(simpleDateFormat.format(new Date()));
        licenseBase.setCertificate(RSAUtil.getFileToString(RSAUtil.LICENSE_CRT_PATH));

        stringBuffer.append(licenseBase.getMagic())
                .append("\n")
                .append("======start company info======\n")
                .append(licenseBase.getCompany())
                .append("\n")
                .append("======end company info======\n" + "======start SN======\n")
                .append(Joiner.on("\n").skipNulls().join(Splitter.on(",").omitEmptyStrings().splitToList(licenseBase.getSn())))
                .append("\n")
                .append("======end SN======\n" + "======start switch======\n")
                .append(licenseBase.getWitch())
                .append("\n")
                .append("======end switch======\n" + "======start app======\n")
                .append(Joiner.on("\n").skipNulls().join(
                        appList.stream().map(app -> {
                            return app.getPackageName();
                        }).collect(Collectors.toList())))
                .append("\n")
                .append("======end app======\n" + "======start sign date======\n")
                .append(licenseBase.getDate())
                .append("\n")
                .append("======end sign date======");
        String signStr = RSAUtil.testSign(stringBuffer.toString());
        stringBuffer.append("\n======start signature======\n")
                .append(signStr)
                .append("\n")
                .append("======end signature======\n")
                .append(licenseBase.getCertificate());
        String uuid = UUID.randomUUID().toString().replaceAll("-", "");
        String tempPath = MyPath.getHomePath() + File.separator + TEMP_DIRC_PATH + File.separator + uuid + File.separator;
        File file = new File(tempPath, licenseBase.getSn() + ".dat");
        File fileParent = file.getParentFile();
        if (!fileParent.exists()) {
            fileParent.mkdirs();
        }
        if (!file.exists()) {
            file.createNewFile();
        }
        FileOutputStream writerStream = new FileOutputStream(file);
        bw = new BufferedWriter(new OutputStreamWriter(writerStream, "UTF-8"));
        bw.write(stringBuffer.toString());
        bw.close();
        hashMap.put("file", file);
        return hashMap;
    }

}
