package com.opnext.license.dto;

import com.opnext.domain.store.App;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

/**
 * license参数对象，生成license使用
 *
 * @author js
 */
@Slf4j
@Data
@Builder
public class LicenseParam {
    List<App> appList;
    List<String> snList;
    DeviceLicenseBase deviceLicenseBase;
    @Tolerate
    public LicenseParam(){}
}
