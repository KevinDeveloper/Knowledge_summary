package com.opnext.license.dto;

import lombok.Data;

import java.net.URL;
import java.util.List;

/**
 * 上传mgdb license实体类
 *
 * @author js
 */
@Data
public class License {

    private Integer id;
    private String sn;
    private List<String> packageName;
    private URL path;
    private long createTime;
}
