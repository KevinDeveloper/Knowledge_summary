package com.opnext.license.dto;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

/**
 * license实体类
 *
 * @author js
 */
@Data
@Builder
public class LicenseBase {

    private String magic;
    private String company;
    private String sn;
    private String witch;
    private String app;
    private String date;
    private String signature;
    private String certificate;
    @Tolerate
    public LicenseBase(){}

}
