package com.opnext.license.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * 读取配置文件license配置
 *
 * @author wanglu
 */
@Component
@Data
@ConfigurationProperties(prefix = "license")
public class LicenseProperties {

    /**
     * 租户标识
     */
    private String magic;

    /**
     * 公司名称
     */
    private String company;

    /**
     * 最大人数标识
     */
    private String witch;
}
