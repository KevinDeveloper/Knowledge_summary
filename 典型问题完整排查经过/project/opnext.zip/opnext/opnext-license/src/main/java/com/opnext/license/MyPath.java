package com.opnext.license;

import org.springframework.boot.ApplicationHome;

/**
 * 获取当前项目地址
 *
 * @author wanglu
 */
public class MyPath {

    public static String getHomePath() {

        ApplicationHome home = new ApplicationHome();
        String path = home.getDir().getAbsolutePath();
        return path;
    }
}