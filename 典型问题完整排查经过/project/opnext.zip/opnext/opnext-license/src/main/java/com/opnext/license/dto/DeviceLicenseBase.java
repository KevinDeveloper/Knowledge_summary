package com.opnext.license.dto;


import lombok.Data;


/**
 * 设备license配置表
 *
 * @author js
 */
@Data
public class DeviceLicenseBase {

    private Integer id;

    /**
     * 设备SN
     */
    private String sn;

    /**
     * 租户id
     */
    private Integer tenantId;

    /**
     * 租户
     */
    transient private String tenantName;

    /**
     * 应用id
     */
    transient private String appId;

    /**
     * 最大人数
     */
    private Integer maxNumber;

    /**
     * 生成方式
     */
    private Integer obtainTheWay;

    /**
     * 授权
     */
    private Integer authorization;

    /**
     * 服务端地址
     */
    private String serviceAddress;

    /**
     * 基本应用有效期时间
     */
    private Long validTime;

    private Long createTime;

    private Long updateTime;


}
