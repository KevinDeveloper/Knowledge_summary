package com.opnext.license.dto;

import lombok.Data;

import java.io.File;

/**
 * 设备license对象
 *
 * @author js
 */
@Data
public class DeviceLicenseFile {
    String sn;
    File file;
}
