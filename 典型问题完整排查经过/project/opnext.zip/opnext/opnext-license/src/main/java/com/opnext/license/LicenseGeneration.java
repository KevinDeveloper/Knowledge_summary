package com.opnext.license;

import com.google.common.collect.Lists;
import com.opnext.domain.store.App;
import com.opnext.license.conf.LicenseProperties;
import com.opnext.license.dto.DeviceLicenseFile;
import com.opnext.license.dto.LicenseBase;
import com.opnext.license.dto.LicenseParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.HashMap;
import java.util.List;

/**
 * 生成license业务类
 *
 * @author wanglu
 */
@Slf4j
@Component
public class LicenseGeneration {
    private static LicenseProperties licenseProperties;

    @Autowired
    public void setLicenseProperties(LicenseProperties licenseProperties) {
        LicenseGeneration.licenseProperties = licenseProperties;
    }

    /**
     * 使用本接口前提，配置文件中
     * 1、在resources中，必须存在文件 /keypair/license.crt， /keypair/license.key， /keypair/license.pubkey
     * 2、配置文件中预定义三项：license.magic/license.company/license.witch
     *
     * @param licenseParam
     * @return
     */
    public static List<DeviceLicenseFile> createLicense(LicenseParam licenseParam) throws Exception {
        List<DeviceLicenseFile> list = Lists.newArrayList();
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(licenseProperties.getWitch());
        stringBuilder.replace(15, 18, licenseParam.getDeviceLicenseBase().getMaxNumber() + "");

        for (String snId : licenseParam.getSnList()){
            LicenseBase licensebase = new LicenseBase();
            licensebase.setMagic(licenseProperties.getMagic().trim());
            licensebase.setCompany(licenseProperties.getCompany().trim() + ":" + licenseParam.getDeviceLicenseBase().getTenantName().trim());
            licensebase.setSn(snId.trim());
            licensebase.setWitch(stringBuilder.toString().trim());
            HashMap<String, Object> hashMap = null;
            hashMap = LicenseUtil.createLicense(licensebase, licenseParam.getAppList());
            File file = (File) hashMap.get("file");
            DeviceLicenseFile deviceLicenseFile = new DeviceLicenseFile();
            deviceLicenseFile.setSn(snId.trim());
            deviceLicenseFile.setFile(file);
            list.add(deviceLicenseFile);
        }
        return list;
    }

    /**
     * 创建单个license文件
     *
     * @param apps
     * @param deviceSn
     * @return
     */
    public static DeviceLicenseFile createDeviceLicense(List<App> apps, String deviceSn) throws Exception {
        LicenseBase licensebase = new LicenseBase();
        licensebase.setMagic(licenseProperties.getMagic());
        licensebase.setCompany(licenseProperties.getCompany());
        licensebase.setSn(deviceSn);
        licensebase.setWitch(licenseProperties.getWitch());

        HashMap<String, Object> hashMap = LicenseUtil.createLicense(licensebase, apps);
        File file = (File) hashMap.get("file");

        DeviceLicenseFile deviceLicenseFile = new DeviceLicenseFile();
        deviceLicenseFile.setSn(deviceSn);
        deviceLicenseFile.setFile(file);

        return deviceLicenseFile;
    }
}
