package com.opnext.server.store.common.mongo.dao.license.impl;

import com.opnext.domain.store.App;
import com.opnext.server.store.common.domain.license.LicenseBase;
import com.opnext.server.store.common.mongo.dao.license.LicenseManagerRepository;
import com.opnext.server.store.common.util.SeqInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

/**
 * 操作mongodb中的license实现
 *
 * @author js
 */
@Component
@Service
public class LicenseManagerRepositoryImpl implements LicenseManagerRepository {

    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * 根据sn删除对象
     *
     * @param sn
     */
    @Override
    public void deleteLicenseBySn(String sn) {
        Query query = new Query(Criteria.where("sn").is(sn));
        mongoTemplate.remove(query, LicenseBase.class);
    }

    /**
     * 保存license对象
     *
     * @param license
     */
    @Override
    public void saveLicense(LicenseBase license) {
        mongoTemplate.save(license);
    }

    /**
     * 保存license对象
     *
     * @param licenseBaseList
     */
    @Override
    public void saveLicense(List<LicenseBase> licenseBaseList) {
        mongoTemplate.insertAll(licenseBaseList);
    }

    /**
     * 自增id
     *
     * @return
     */
    @Override
    public int findLicenseNextId() {
        Query query = new Query(Criteria.where("collName").is("License"));
        Update update = new Update();
        update.inc("seqId", 1);
        FindAndModifyOptions options = new FindAndModifyOptions();
        options.upsert(true);
        options.returnNew(true);
        SeqInfo seq = mongoTemplate.findAndModify(query, update, options, SeqInfo.class);
        return seq.getSeqId();
    }

    /**
     * 根据id查询License
     *
     * @param id
     * @return
     */
    @Override
    public LicenseBase findLicenseByDeviceLicenseId(Integer id) {
        Query query = new Query(Criteria.where("deviceLicenseId").is(id));
        return mongoTemplate.findOne(query, LicenseBase.class);
    }

    /**
     * 根据deviceLicenseIds查询数据
     * @param ids
     * @return
     */
    @Override
    public List<LicenseBase> findLicenseByDeviceLicenseIds(Collection ids) {
        Criteria criteria = new Criteria();
        criteria.and("deviceLicenseId").in(ids);
        Query query = new Query(criteria);
        return mongoTemplate.find(query, LicenseBase.class);
    }

}
