package com.opnext.server.store.common.util;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

/**
 * 获取mongodb下一个id
 *
 * @author js
 */
@Data
@Document(collection = "sequence")
public class SeqInfo {

    /**
     * 主键
     */
    @Id
    private String id;
    /**
     * 集合名称
     */
    @Field
    private String collName;
    /**
     * 序列值
     */
    @Field
    private int seqId;


}  