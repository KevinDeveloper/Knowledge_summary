package com.opnext.server.store.common.util;

import lombok.Data;
import org.springframework.http.HttpStatus;

/**
 * 远程调用返回EntityResponse
 *
 * @author js
 */
@Data
public class EntityResponse {

    private long timestamp;
    private int status;
    private String message;
    private String path;
    private int code;
    private Object entity;

    public static EntityResponse entity(Object entity) {
        return entity("", entity);
    }

    public static EntityResponse entity(String path) {
        return entity(path, new Object());
    }

    public static EntityResponse entity(String path, Object entity) {
        return entity(path, HttpStatus.OK, entity);
    }

    public static EntityResponse entity(String path, HttpStatus status) {
        return entity(path, status, new Object());
    }

    public static EntityResponse entity(String path, HttpStatus status, Object entity) {
        return entity(path, status.value(), status.getReasonPhrase(), entity);
    }

    public static EntityResponse entity(String path, int status, String message) {
        return entity(path, status, message, new Object());
    }

    public static EntityResponse entity(String path, int status, String message, Object entity) {
        EntityResponse entityResponse = new EntityResponse();
        entityResponse.setTimestamp(System.currentTimeMillis());
        entityResponse.setPath(path);
        entityResponse.setStatus(status);
        entityResponse.setMessage(message);
        entityResponse.setEntity(entity);
        return entityResponse;
    }
}