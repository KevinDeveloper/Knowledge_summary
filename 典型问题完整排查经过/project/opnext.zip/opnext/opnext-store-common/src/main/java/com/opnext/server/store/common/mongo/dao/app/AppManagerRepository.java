package com.opnext.server.store.common.mongo.dao.app;

import com.opnext.domain.store.App;

import java.util.Collection;
import java.util.List;

/**
 * 操作mongodb库中的app
 *
 * @author js
 */
public interface AppManagerRepository {

    /**
     * 保存APP
     *
     * @param app
     */
    void saveApp(App app);

    /**
     * 根据APP列表
     *
     * @param type
     * @return
     */
    List<App> findAppList(String type);

    /**
     * license文件中用的app
     * @return
     */
    List<App> findAppListLicense();

    /**
     * 根据ids查询APP列表
     *
     * @param ids
     * @return
     */
    List<App> findAppListByids(Collection ids);

    /**
     * 根据ID查询APP
     *
     * @param id
     * @return
     */
    App findAppById(int id);

    /**
     * 根据app查询APP
     *
     * @param app
     * @return
     */
    List<App> findAppByApp(App app);

    /**
     * 根据APP下一个id
     *
     * @return
     */
    int findAppNextId();

    /**
     * 根据ID删除APP
     *
     * @param id
     */
    void deleteAppById(int id);

    /**
     * 删除多个apk
     *
     * @param ids
     */
    void deleteAppByIds(Integer[] ids);

    /**
     * 根据包名删除app
     *
     * @param pack
     */
    void deleteAppByPackage(String pack);

    /**
     * 自增id
     *
     * @return
     */
    int findLicenseNextId();


    /**
     * 根据包名查找list
     *
     * @param packageName
     * @return
     */
    List<App> findAppListByPackageName(String packageName);


    /**
     * 根据包名查找app
     *
     * @param packageName
     * @return app
     */
    App findAppByPackageName(String packageName);

    /**
     * 根据设备sn删除License
     *
     * @param sns
     */
    void deleteLicenseBySns(Collection sns);

}
