package com.opnext.server.store.common.util;

import org.springframework.boot.ApplicationHome;

/**
 * 获取jar包路径
 *
 * @author wanglu
 */
public class MyPath {

    public static String getHomePath() {
        ApplicationHome home = new ApplicationHome();
        return home.getDir().getAbsolutePath();
    }
}