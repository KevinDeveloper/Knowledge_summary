package com.opnext.server.store.common.mongo.dao.license;

import com.opnext.server.store.common.domain.license.LicenseBase;

import java.util.Collection;
import java.util.List;

/**
 * 操作mongodb中的license
 *
 * @author js
 */
public interface LicenseManagerRepository {

    /**
     * 根据sn删除对象
     *
     * @param sn
     */
    void deleteLicenseBySn(String sn);

    /**
     * 保存License对象
     *
     * @param licen
     */
    void saveLicense(LicenseBase licen);

    /**
     * 保存License对象
     *
     * @param licenseBaseList
     */
    void saveLicense(List<LicenseBase> licenseBaseList);

    /**
     * 自增id
     *
     * @return
     */
    int findLicenseNextId();

    /**
     * 根据id查询License
     *
     * @param id
     * @return
     */
    LicenseBase findLicenseByDeviceLicenseId(Integer id);

    /**
     * 根据ids查询License
     *
     * @param ids
     * @return
     */
    List<LicenseBase> findLicenseByDeviceLicenseIds(Collection ids);
}
