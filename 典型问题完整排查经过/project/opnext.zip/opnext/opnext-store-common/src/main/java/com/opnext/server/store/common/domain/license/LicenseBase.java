package com.opnext.server.store.common.domain.license;

import lombok.Data;

import java.net.URL;
import java.util.List;

/**
 * 本地license实体类
 *
 * @author js
 */
@Data
public class LicenseBase {

    private Integer id;
    private String sn;
    private List<String> packageName;
    private URL path;
    private long createTime;
    private Integer deviceLicenseId;
}
