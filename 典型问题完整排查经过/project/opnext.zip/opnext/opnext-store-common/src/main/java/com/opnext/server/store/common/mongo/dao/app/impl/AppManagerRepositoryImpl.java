package com.opnext.server.store.common.mongo.dao.app.impl;

import com.opnext.domain.store.App;

import com.opnext.server.store.common.domain.license.LicenseBase;
import com.opnext.server.store.common.mongo.dao.app.AppManagerRepository;
import com.opnext.server.store.common.util.SeqInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.FindAndModifyOptions;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.*;

/**
 * 操作mongodb库中的app实现类
 *
 * @author js
 */
@Component
@Service
public class AppManagerRepositoryImpl implements AppManagerRepository {

    @Autowired
    private MongoTemplate mongoTemplate;

    /**
     * 保存APP
     *
     * @param app
     */
    @Override
    public void saveApp(App app) {
        mongoTemplate.save(app);
    }

    /**
     * 查询APP列表
     *
     * @param type
     * @return
     */
    @Override
    public List<App> findAppList(String type) {
        Criteria criteria = new Criteria();
        if(!StringUtils.isEmpty(type)){
            criteria.and("type").is(type);
        }
        Query query = new Query(criteria);
        query.with(new Sort(new Sort.Order(Sort.Direction.DESC,"createTime")));
        return mongoTemplate.find(query,App.class);
    }

    /**
     * License文件中用的app
     * @return
     */
    @Override
    public List<App> findAppListLicense() {
        Criteria criteria = new Criteria();
        criteria.and("type").is("APP").and("latestVersion").is("true").and("basis").is(0);
        Query query = new Query(criteria);
        return mongoTemplate.find(query,App.class);
    }

    /**
     * 根据ID查询APP
     *
     * @param id
     * @return
     */
    @Override
    public App findAppById(int id) {
        Query query = new Query(Criteria.where("id").is(id));
        return mongoTemplate.findOne(query, App.class);
    }

    /**
     * 根据ID删除APP
     *
     * @param id
     */
    @Override
    public void deleteAppById(int id) {
        Query query = new Query(Criteria.where("id").is(id));
        mongoTemplate.remove(query, App.class);
    }

    /**
     * 删除多个apk
     *
     * @param ids
     */
    @Override
    public void deleteAppByIds(Integer[] ids) {
        Query query = new Query(Criteria.where("id").in(ids));
        mongoTemplate.remove(query, App.class);
    }

    /**
     * 根据包名删除app
     *
     * @param pack
     */
    @Override
    public void deleteAppByPackage(String pack) {
        Query query = new Query(Criteria.where("packageName").is(pack));
        mongoTemplate.remove(query, App.class);
    }

    /**
     * 根据ids查询APP列表
     *
     * @param ids
     */
    @Override
    public List<App> findAppListByids(Collection ids) {
        Criteria criteria = new Criteria();
        criteria.and("id").in(ids);
        Query query = new Query(criteria);
        return mongoTemplate.find(query, App.class);
    }

    /**
     * 获取下一下id
     *
     * @return
     */
    @Override
    public int findAppNextId() {
        Query query = new Query(Criteria.where("collName").is("App"));
        Update update = new Update();
        update.inc("seqId", 1);
        FindAndModifyOptions options = new FindAndModifyOptions();
        options.upsert(true);
        options.returnNew(true);
        SeqInfo seq = mongoTemplate.findAndModify(query, update, options, SeqInfo.class);
        return seq.getSeqId();
    }

    /**
     * 根据app中的条件查找app
     *
     * @param app
     * @return
     */
    @Override
    public List<App> findAppByApp(App app) {
        Criteria criteria = new Criteria();
        if (app.getVersionName() != null) {
            criteria.and("versionName").is(app.getVersionName());
        }
        if (app.getPackageName() != null) {
            criteria.and("packageName").is(app.getPackageName());
        }
        Query query = new Query(criteria);
        return mongoTemplate.find(query, App.class);
    }

    /**
     * 自增id
     *
     * @return
     */
    @Override
    public int findLicenseNextId() {
        Query query = new Query(Criteria.where("collName").is("License"));
        Update update = new Update();
        update.inc("seqId", 1);
        FindAndModifyOptions options = new FindAndModifyOptions();
        options.upsert(true);
        options.returnNew(true);
        SeqInfo seq = mongoTemplate.findAndModify(query, update, options, SeqInfo.class);
        return seq.getSeqId();
    }


    /**
     * 根据包名查找list
     *
     * @param packageName
     * @return
     */
    @Override
    public List<App> findAppListByPackageName(String packageName) {
        Criteria criteria = new Criteria();
        criteria.and("packageName").is(packageName);
        Query query = new Query(criteria);
        return mongoTemplate.find(query, App.class);
    }

    /**
     * @param packageName
     * @return
     */
    @Override
    public App findAppByPackageName(String packageName) {
        Query query = new Query(Criteria.where("packageName").is(packageName).and("latestVersion").is("true"));
        return mongoTemplate.findOne(query, App.class);
    }

    @Override
    public void deleteLicenseBySns(Collection sns) {
        Criteria criteria = new Criteria();
        criteria.and("sn").in(sns).and("obtainTheWay").is(0);
        Query query = new Query(criteria);
        mongoTemplate.remove(query,LicenseBase.class);
    }

}
