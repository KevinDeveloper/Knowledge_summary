package com.opnext.oservice.repository.authority;

import com.opnext.oservice.domain.authority.role.RoleModule;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @author wanglu
 */

public interface RoleModuleRepository extends PagingAndSortingRepository<RoleModule, Long>,
        QueryDslPredicateExecutor<RoleModule> {
    /**
     * 通过角色id查询全部角色模块表
     * @param roleId
     * @return
     */
    List<RoleModule> findAllByRoleId(long roleId);

    /**
     * 通过roleId删除所有模块关联
     * @param roleId
     */
    void deleteAllByRoleId(long roleId);
}
