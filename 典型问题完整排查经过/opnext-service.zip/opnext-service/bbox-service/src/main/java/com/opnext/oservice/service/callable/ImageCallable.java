package com.opnext.oservice.service.callable;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.oservice.domain.MultipartFileResp;
import com.opnext.oservice.service.ImageHandler;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;

/**
 * @author tianzc
 */
@Slf4j
public class ImageCallable implements Callable<Map<String, MultipartFileResp>> {

    List<File> fileList;

    ImageHandler imageHandler;

    CountDownLatch countDownLatch;
    OserviceOperator oserviceOperator;

    public ImageCallable(List<File> fileList, ImageHandler imageHandler, CountDownLatch countDownLatch,OserviceOperator oserviceOperator){

        this.fileList = fileList;
        this.imageHandler = imageHandler;
        this.countDownLatch = countDownLatch;
        this.oserviceOperator = oserviceOperator;
        if (Objects.nonNull(oserviceOperator)) {
            Messages.setLocale(oserviceOperator.getCurLocale());
        }
    }
    /**
     * Computes a result, or throws an exception if unable to do so.
     *
     * @return computed result
     * @throws Exception if unable to compute a result
     */
    @Override
    public Map<String, MultipartFileResp> call() throws Exception {
        Map<String, MultipartFileResp> map = handleImageFile();
        synchronized (ImageCallable.class) {
            countDownLatch.countDown();
            return map;
        }
    }

    private Map<String, MultipartFileResp> handleImageFile(){
        Map<String, MultipartFileResp> map = new HashMap<>();
        int size = fileList.size();
        for (int i = 0; i < size; i++ ) {
            try {
                Map<String, MultipartFileResp> mapResp = imageHandler.checkAndCutAndUploadImage(fileList.get(i),oserviceOperator);
                map.putAll(mapResp);
            } catch (Exception e) {
                log.error("File数据-调用图片处理方法异常：{}",e.getMessage());
                String msg = e.getMessage();
                if (StringUtils.isBlank(msg)) {
                    msg = "imageFile.exception";
                }
                String fileName = fileList.get(i).getName();
                MultipartFileResp fileResp = MultipartFileResp.builder()
                        .flag(false).message(msg).fileName(fileName).build();
                map.put(fileName, fileResp);
                log.error("调用图片处理方法异常：{}",e.getMessage());
            }
        }
        return map;
    }
}
