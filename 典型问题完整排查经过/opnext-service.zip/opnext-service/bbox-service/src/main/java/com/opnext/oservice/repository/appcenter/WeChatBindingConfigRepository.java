package com.opnext.oservice.repository.appcenter;

import com.opnext.oservice.domain.appcenter.WeChatBindingConfig;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @author wanglu
 */
public interface WeChatBindingConfigRepository  extends PagingAndSortingRepository<WeChatBindingConfig, Integer>,
        QueryDslPredicateExecutor<WeChatBindingConfig>{
    /**
     * 通过type查询默认的"微信绑定选项"
     * @param type
     * @return
     */
    List<WeChatBindingConfig> findAllByType(String type);

    /**
     * 通过type查询默认的"微信绑定选项"（值非0的）
     * @param type
     * @param configValue
     * @return
     */
    List<WeChatBindingConfig> findAllByTypeAndConfigValueNot(String type,String configValue);
    /**
     * 通过type和needFlag查询"微信绑定选项"
     * @param type
     * @param needFlag
     * @return
     */
    List<WeChatBindingConfig> findAllByTypeAndNeedFlag(String type,WeChatBindingConfig.NeedFlag needFlag);
}
