package com.opnext.oservice.controller.appcenter;

import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.conf.WeChatProperties;
import com.opnext.oservice.domain.tenant.TenantWechat;
import com.opnext.oservice.service.base.BaseRedisService;
import com.opnext.oservice.service.tenant.TenantWechatService;
import com.opnext.oservice.util.RestClient;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import me.chanjar.weixin.common.api.WxConsts;
import me.chanjar.weixin.mp.bean.result.WxMpUser;
import me.chanjar.weixin.open.bean.result.WxOpenAuthorizerInfoResult;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UriComponentsBuilder;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URI;
import java.util.Date;
import java.util.Objects;

/**
 * @author lixiuwen
 */
@Slf4j
@RestController
@RequestMapping("/wechat/callback")
public class WeChatController {
    @Autowired
    RestClient restClient;

    @Autowired
    BaseRedisService redisService;

    @Autowired
    WeChatProperties wechatProperties;

    @Autowired
    TenantWechatService tenantWechatService;

    @ApiIgnore
    @Transactional(rollbackFor = Exception.class, noRollbackForClassName = "CommonException")
    @ApiOperation(value = "获取授权码信息")
    @GetMapping("/authcode")
    public void setAuthCode(HttpServletResponse resp,
                            @RequestParam("auth_code") String authCode,
                            @RequestParam("tenantId") Long tenantId) throws IOException {
        log.info("进入“获取授权码信息”接口,authCode:{}", authCode);
        if (StringUtils.isBlank(authCode)) {
            log.info("预授权码为空");
            return;
        }
        String url = String.format("%s%s?authCode=%s&callback=%s",
                wechatProperties.getHost(),
                wechatProperties.getWechatAuthUrl(),
                authCode,
                wechatProperties.getSaasHost() + "/wechat/callback/msg");
        WxOpenAuthorizerInfoResult authorizerInfoResult = restClient.doGet(url, WxOpenAuthorizerInfoResult.class);
        if (Objects.isNull(authorizerInfoResult)) {
            log.info("预授信息为空");
            return;
        }
        String appId = authorizerInfoResult.getAuthorizationInfo().getAuthorizerAppid();
        TenantWechat tenantWechat = new TenantWechat(tenantId, appId, new Date());
        tenantWechatService.save(tenantWechat);
        tenantWechatService.deleteByAppIdAndTenantIdIsNot(appId, tenantId);
        String redisKey = tenantId + "_authCallBackUrl";
        String callback = null;
        if (redisService.hasKey(redisKey)) {
            Object obj=redisService.get(redisKey);
            if(Objects.nonNull(obj)){
                callback = String.valueOf(obj);
            }
            redisService.deleteKey(redisKey);
        }
        if (StringUtils.isBlank(callback)) {
            URI uri = UriComponentsBuilder.fromUriString(wechatProperties.getSaasHost()).build().toUri();
            callback = uri.getScheme() + "://" + uri.getHost();
        }
        log.info("授权完成，重定向到前端.url:{}", callback);
        resp.sendRedirect(callback);
    }


    @ApiIgnore
    @Transactional(rollbackFor = Exception.class)
    @ApiOperation(value = "公众号取消授权或用户取消关注事件")
    @GetMapping("/msg")
    public void setAuthCode(@RequestParam("infoType") String infoType,
                            @RequestParam("appId") String appId,
                            @RequestParam(value = "openId", required = false) String openId) {
        log.info("进入“公众号取消授权或用户取消关注”接口,infoType:{},appId:{},openId:{}", infoType, appId, openId);
        if (StringUtils.isBlank(infoType)) {
            log.info("信息类型为空");
            return;
        }
        if (StringUtils.isBlank(appId)) {
            log.info("微信APPID为空");
            return;
        }
        if (WxConsts.EventType.UNSUBSCRIBE.equals(infoType)) {
            if (StringUtils.isBlank(openId)) {
                log.info("openId为空");
            }
            //用户取消关注暂不处理
        } else if ("unauthorized".equals(infoType)) {
            //公众号取消授权删除关联表对应数据
            tenantWechatService.deleteByAppId(appId);
        }
    }

    @ApiIgnore
    @ApiOperation(value = "获取微信用户网页授权地址")
    @GetMapping("/user/auth")
    public CommonResponse geUserAuth(@RequestParam("appId") String appId,
                                     @RequestParam("callback") String callback) {
        log.info("进入“转发微信用户网页授权”接口,appId:{},callback:{}", appId, callback);
        String url = String.format("%s%s?appId=%s&callback=%s", wechatProperties.getHost(), wechatProperties.getUserAuthUrl(), appId, callback);
        log.info("转发地址：{}", url);
        return CommonResponse.ok(url);
    }

    @ApiOperation(value = "获取微信用户信息")
    @GetMapping("/user/info")
    public WxMpUser getUserInfo(@RequestParam("appId") String appId, @RequestParam("code") String code) {
        log.info("进入“获取微信用户信息”接口,appId:{},code:{}", appId, code);
        String url = String.format("%s%s?appId=%s&code=%s", wechatProperties.getHost(), wechatProperties.getUserInfoUrl(), appId, code);
        return restClient.doGet(url, WxMpUser.class);
    }

}
