package com.opnext.oservice.service.organization;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.organization.OrgVo;
import com.opnext.oservice.domain.organization.Organization;

import java.util.List;
import java.util.Map;

/**
 * @ClassName: OrganizationService
 * @Description:
 * @Author: Kevin
 * @Date: 2018/5/10 16:06
 */
public interface OrganizationService {


    /**
     * 租户注册时初始化根组织
     *
     * @param tenantId
     * @param operatorId
     * @param orgName
     * @throws Exception
     */
    void initRootOrgInTenant(Long tenantId, Long operatorId, String orgName) throws Exception;

    /**
     * 保存组织
     *
     * @param organization
     * @throws Exception
     */
    void saveOrg(Organization organization) throws Exception;


    /**
     *  更新组织
     * @param orgId
     * @param organization
     * @throws Exception
     */
    void updateOrgById(Integer orgId, Organization organization) throws Exception;

    /**
     * 删除组织
     *
     * @param ids
     * @throws Exception
     */
    void deleteOrgByIds(Integer[] ids) throws Exception;

    /**
     * 平级返回全部组织
     *
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    List<OrgVo> listAllOrg(OserviceOperator oserviceOperator) throws Exception;

    /**
     * 返回一颗组织树
     *
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    OrgVo orgNode(OserviceOperator oserviceOperator) throws Exception;

    /**
     * 通过租户id 和组织名查询组织
     *
     * @param tenantId
     * @param name
     * @return
     * @throws Exception
     */
    Organization findOrgByTenantIdAndName(Long tenantId, String name) throws Exception;

    /**
     * 判断组织名是否在租户中存在
     *
     * @param tenantId
     * @param name
     * @return
     * @throws Exception
     */
    boolean isExistOrgNameInTenantId(Long tenantId, String name) throws Exception;

    /**
     * 根据组织id返回组织
     *
     * @param tenantId
     * @param orgId
     * @return
     * @throws Exception
     */
    Organization findOrgInTenantIdById(Long tenantId, Integer orgId) throws Exception;

    /**
     * 查询特定组织id下的名称组织id
     *
     * @param parentId
     * @param orgName
     * @return
     * @throws Exception
     */
    List<OrgVo> listOrgByParentId(Integer parentId, String orgName) throws Exception;

    /**
     * 操作权限检查，判断是否为saas类用户
     *
     * @param oserviceOperator
     * @throws Exception
     */
    void checkOperator(OserviceOperator oserviceOperator) throws Exception;

    /**
     * 根据租户返回第三方其他组织
     *
     * @param tenantId
     * @return
     * @throws Exception
     */
    Organization getOtherOrgByTenantId(long tenantId) throws Exception;

    /**
     * 根据租户id返回根组织
     *
     * @param tenantId
     * @return
     * @throws Exception
     */
    Organization getRootOrgByTenantId(long tenantId) throws Exception;

    /**
     * 根据租户id获取所有
     * @param tenantId
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    Map<Integer, String> getOrgMap(long tenantId, OserviceOperator oserviceOperator) throws Exception;


    /**
     * 删除该组织和它下面的子组织 ，以及所有组织包括的人员
     * @param oserviceOperator
     * @param orgId
     */
    void deleteOrgDirect(OserviceOperator oserviceOperator, Integer orgId) throws Exception;


    /**
     * 删除删除该组织和它下面的子组织， 并移动所有组织下面的人员到目标组织
     * @param oserviceOperator
     * @param orgId
     * @param targetOrgId
     */
    void deleteOrgMove(OserviceOperator oserviceOperator, Integer orgId, Integer targetOrgId) throws Exception;

}
