package com.opnext.oservice.domain.authority.role;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

import javax.persistence.*;

/**
 * @author wanglu
 */
@Entity
@Table(name = "role_module")
@Data
@Builder
public class RoleModule {
    @Tolerate
    RoleModule(){}
    @Id
    @GeneratedValue
    private Long id;
    @Column(name="role_id")
    private Long roleId;

    @Column(name="module_id")
    private Integer moduleId;

}
