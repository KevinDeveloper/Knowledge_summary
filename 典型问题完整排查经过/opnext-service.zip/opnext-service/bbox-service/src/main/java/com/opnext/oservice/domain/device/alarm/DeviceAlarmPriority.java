package com.opnext.oservice.domain.device.alarm;
/**
 * @author wanglu
 */
public enum DeviceAlarmPriority {
    //一级
    ONE((byte)0),
    //二级
    TWO((byte)1);

    private byte value;

    DeviceAlarmPriority(byte value) {
        this.value = value;
    }

    public byte value() {
        return this.value;
    }
}
