package com.opnext.oservice.dto.account;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;
/**
 * @author wanglu
 */
@Data
@Builder
public class AccountDTO {
    private String loginName;
    private String password;
    /**
     * 0停用，1启用
     */
    private String email;
    private String phone;
    @Tolerate
    public AccountDTO(){}
}
