package com.opnext.oservice.service.authority.impl;

import com.opnext.oservice.domain.authority.role.QModule;
import com.opnext.oservice.domain.authority.role.QResource;
import com.opnext.oservice.dto.authority.role.ResourceDTO;
import com.opnext.oservice.service.authority.ResourceService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author wanglu
 * @date 2018/07/19
 */
@Service
@Slf4j
public class ResourceServiceImpl implements ResourceService {
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Override
    public ResourceDTO findApiResource(Predicate predicate) {
        QModule qModule = QModule.module;
        QResource qresource =QResource.resource;
        ResourceDTO resourceDTO = jpaQueryFactory.select(Projections.bean(
                ResourceDTO.class,
                qresource.id.as("resourceId"),
                qresource.name.as("resourceName"),
                qresource.method.as("method"),
                qModule.id.as("moduleId"),
                qModule.name.as("moduleName")))
                .from(qresource)
                .leftJoin(qModule).on(qModule.id.eq(qresource.moduleId))
                .where(predicate).fetchOne();
        return resourceDTO;
    }
}
