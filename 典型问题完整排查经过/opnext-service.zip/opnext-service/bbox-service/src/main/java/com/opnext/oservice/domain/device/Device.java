package com.opnext.oservice.domain.device;

import com.opnext.oservice.domain.converter.DeviceTypeConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * @Title: 设备类
 * @Description: --
 * @author tianzc
 * @Date 下午4:46 18/5/7
 */
@Entity
@Data
@Table(name = "device")
@ApiModel(description="设备类")
@EntityListeners(AuditingEntityListener.class)
public class Device {
    @Id
    @GeneratedValue
    @ApiModelProperty(value="id")
    private Integer id;
    /**
     * 设备名称
     */
    @ApiModelProperty(value="设备名称")
    private String name;
    /**
     * 设备SN
     */
    @ApiModelProperty(value="设备SN")
    private String sn;
    /**
     * 设备类型
     */
    @ApiModelProperty(value="设备类型")
    @Convert(converter = DeviceTypeConverter.class)
    private DeviceType type;

    /**
     * 设备状态
     */
    @ApiModelProperty(value="设备状态")
    private DeviceStatus status;
    /**
     * 设备组id
     */
    @ApiModelProperty(value="设备组id")
    @Column(name="group_id")
    private Integer groupId;

    @ApiModelProperty(value="设备组")
    @Column(name="group_name")
    private String groupName;

    @ApiModelProperty(value="版本号")
    @Column(name = "version")
    private String version;
    /**
     * 创建时间
     */
    @ApiModelProperty(value="创建时间")
    @Column(name="create_time")
    @CreatedDate
    private Date createTime;
    /**
     * 更新时间
     */
    @ApiModelProperty(value="更新时间")
    @Column(name="update_time")
    @LastModifiedDate
    private Date updateTime;
    /**
     * 表示外建：所属租户
     */
    @ApiModelProperty(value="租户id")
    @Column(name="tenant_id")
    private long tenantId;
    /**
     * 操作者id
     */
    @ApiModelProperty(value="操作者id")
    @Column(name = "operator_id")
    private Long operatorId;

    /**
     * 操作者账号
     */
    @ApiModelProperty(value="操作者")
    @Column(name = "operator_name")
    private String operatorName;

}
