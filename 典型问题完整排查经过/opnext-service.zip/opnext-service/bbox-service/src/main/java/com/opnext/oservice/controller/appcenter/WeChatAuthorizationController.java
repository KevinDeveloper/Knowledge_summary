package com.opnext.oservice.controller.appcenter;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.opnext.bboxsms.ShortMassageService;
import com.opnext.bboxsms.template.AuthCaptchaTemplate;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.conf.SelfProperties;
import com.opnext.bboxsupport.mail.MailEntity;
import com.opnext.bboxsupport.mail.MailSender;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.bboxsupport.util.RedisCommonKeyUtil;
import com.opnext.bboxsupport.util.RedisLifeTimeUtil;
import com.opnext.bboxsupport.validator.IsEmptyValidator;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.oservice.conf.WeChatProperties;
import com.opnext.oservice.domain.appcenter.WeChatBindingConfig;
import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.dto.appcenter.WeChatBindReqDTO;
import com.opnext.oservice.service.base.BaseRedisService;
import com.querydsl.core.types.Predicate;
import com.opnext.oservice.service.appcenter.WeChatAuthorizationService;
import com.opnext.oservice.service.person.PersonService;
import com.querydsl.core.types.dsl.BooleanExpression;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;
import java.util.*;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author wanglu
 */
@Slf4j
@RestController
@RequestMapping("/wechat/user")
public class WeChatAuthorizationController {
    public static final String NO_PERSON = "_0";
    @Autowired
    PersonService personService;
    @Autowired
    WeChatProperties weChatProperties;
    @Autowired
    WeChatAuthorizationService weChatAuthorizationService;
    @Autowired
    BaseRedisService redisService;
    @Autowired
    DefaultKaptcha defaultKaptcha;
    @Autowired
    ShortMassageService shortMassageService;
    @Autowired
    SelfProperties selfProperties;

    @ApiOperation(value = "跳转到绑定页面", notes = "如果openId绑定过则直接跳转绑定成功，否则进入信息录入页")
    @RequestMapping(value = "/_bind", method = RequestMethod.GET)
    public CommonResponse<String> redirectToBingPage(@RequestParam Long tenantId, @RequestParam String openId, @RequestParam String callbackUrl, HttpServletResponse response) throws Exception {
        //1、判断openId是否存在，如果存在重定向到callbackUrl?personId=
        Optional<String> personId = personService.getPersonIdByOpenId(openId, tenantId);
        if (personId.isPresent()) {
            String bindingFinishPage = callbackUrl + "?tenantId=" + tenantId + "&openId=" + openId + "&personId=" + personId.get();
            return CommonResponse.ok(bindingFinishPage);
        }
        //2、如果不存在，则redirect到上前台的与配置绑定页面,携带参数：tenantId、openId、callbackUrl
        String bindingPage = weChatProperties.getBindingPageUrl()
                + "?tenantId=" + tenantId
                + "&openId=" + openId
                + "&callbackUrl=" + URLEncoder.encode(callbackUrl, "UTF-8");
        return CommonResponse.ok(bindingPage);
    }

    @ApiOperation(value = "微信--用户解绑openId", notes = "用户解绑openId")
    @RequestMapping(value = "/_unbind", method = RequestMethod.DELETE)
    public void unBindOpenId(@RequestParam Long tenantId, @RequestParam String openId, @RequestParam String personId) throws Exception {
        Optional<Person> person = personService.getPersonByOpenId(openId, tenantId);
        if (person.isPresent()) {
            boolean personFlag = (person.map(u -> u.getId()).orElse(NO_PERSON)).equals(personId);
            if (personFlag) {
                //更新人员表，将openId改为null
                Person personObj = person.get();
                personObj.setOpenId(null);
                personService.updatePerson(personObj);
                return;
            }
            log.error("微信--用户解绑openId失败，openId={} 与personId={}不匹配", openId, personId);
            String code = selfProperties.getCode()+"902";
            throw new CommonException(400, "parameter.incorrect", null, Integer.parseInt(code));
        }
        log.error("微信--用户解绑openId失败，没有找到openId={} 绑定的人员",openId);
        String code = selfProperties.getCode()+"901";
        throw new CommonException(400, "parameter.incorrect", null, Integer.parseInt(code));
    }

    @ApiOperation(value = "微信接口，获取绑定输入项", notes = "微信接口，获取微信绑定输入项")
    @RequestMapping(value = "/bind-config", method = RequestMethod.GET)
    public List<WeChatBindingConfig> getBindingConfig(@RequestParam Long tenantId) {
        List<WeChatBindingConfig> weChatBindingConfigDTOList = weChatAuthorizationService.getBindingConfig(tenantId, WeChatBindingConfigController.WECHAT_BINDING_CONFIG_KEY);
        return weChatBindingConfigDTOList;
    }

    @ApiOperation(value = "发送邮箱验证码", notes = "获取图形验证码")
    @RequestMapping(value = "/{openId}/email/captcha/_send", method = RequestMethod.POST)
    public void sendEmailCodeAddress(@PathVariable String openId, @Valid @RequestBody WeChatBindReqDTO reqDTO, BindingResult bindingResult) throws Exception {
        if (bindingResult.hasErrors()) {
            log.error("微信绑定授权--发送邮箱验证码失败,{}", bindingResult);
            throw new CommonException(400, "parameter.incorrect", bindingResult);
        }
        Person person ;
        try{
            person = personService.getPersonByNo(reqDTO.getNo(), reqDTO.getTenantId());
        }catch (CommonException e){
            throw new CommonException(400, "weChat.binding.user.number.not.fount");
        }
        if (StringUtils.isBlank(person.getMail())) {
            log.error("发送短信验证码失败，通过no查询的人员没有mail信息");
            throw new CommonException(400, "weChat.binding.email.not.found");
        }
        String mailAddress = person.getMail();
        //生成验证码
        int code = (int) ((Math.random() * 9 + 1) * 100000);
        log.info("测试使用验证码：" + code);
        //发送邮件
        MailEntity m = MailEntity.builder()
                .title(Messages.get("email.title.verify.email"))
                .content(Messages.get("mail.weChat.binding.validateCode", new String[]{code + ""}))
                .contentType(MailEntity.MailContentTypeEnum.HTML.getValue())
                .target(new ArrayList<String>() {{
                    add(mailAddress);
                }}).build();
        try {
            MailSender.send(m);
        } catch (Exception e) {
            log.error("微信绑定发送验证码失败，原因为：{}", e.getMessage());
            throw new CommonException(e.getMessage());
        }
        //验证码放到redis中
        String keyName = RedisCommonKeyUtil.WECHAT_BINDING_EMAIL_CODE + openId + "_" + reqDTO.getNo();
        redisService.setKey(keyName, code + "", RedisLifeTimeUtil.validateCodeTime());
    }

    @ApiOperation(value = "发送短信验证码", notes = "获取图形验证码")
    @RequestMapping(value = "/{openId}/mobile/captcha/_send", method = RequestMethod.POST)
    public void sendPhoneCodeAddress(@PathVariable String openId, @Valid @RequestBody WeChatBindReqDTO reqDTO, BindingResult bindingResult) throws Exception {
        if (bindingResult.hasErrors()) {
            log.error("微信绑定授权--发送短信验证码失败,{}", bindingResult);
            throw new CommonException(400, "parameter.incorrect", bindingResult);
        }
        Person person;
        try{
            person = personService.getPersonByNo(reqDTO.getNo(), reqDTO.getTenantId());
        }catch (CommonException e){
            throw new CommonException(400, "weChat.binding.user.number.not.fount");
        }
        if (StringUtils.isBlank(person.getPhone())) {
            log.error("发送短信验证码失败，通过no查询的人员没有phone信息");
            throw new CommonException(400, "weChat.binding.phone.not.found");
        }
        String phone = person.getPhone();
        //生成验证码
        int code = (int) ((Math.random() * 9 + 1) * 100000);
        log.info("测试使用验证码：" + code);
        //发送短信验证码
        AuthCaptchaTemplate template = new AuthCaptchaTemplate(phone,code+"");
        shortMassageService.send(template);
        //验证码放到redis中
        String keyName = RedisCommonKeyUtil.WECHAT_BINDING_PHONE_CODE + openId + "_" + reqDTO.getNo();
        redisService.setKey(keyName, code + "", RedisLifeTimeUtil.validateCodeTime());
    }

    @ApiOperation(value = "获取图形验证码", notes = "获取图形验证码")
    @RequestMapping(value = "/{openId}/captcha", method = RequestMethod.GET)
    public CommonResponse<String> getGraphicCodeAddress(@PathVariable String openId) throws Exception {
        ByteArrayOutputStream jpegOutputStream = new ByteArrayOutputStream();
        try {
            String createText = defaultKaptcha.createText();
            BufferedImage challenge = defaultKaptcha.createImage(createText);
            ImageIO.write(challenge, "jpg", jpegOutputStream);
            String base64Image = "data:image/jpeg;base64," + Base64.encodeBase64String(jpegOutputStream.toByteArray());

            //验证码放到redis中
            String keyName = RedisCommonKeyUtil.WECHAT_BINDING_GRAPHIC_CODE + openId;
            redisService.setKey(keyName, createText, RedisLifeTimeUtil.validateCodeTime());
            jpegOutputStream.close();
            return CommonResponse.ok(base64Image);
        } catch (Exception e) {
            log.error("openId={} 生成图形验证码失败,{}", openId, e.getMessage());
            throw new CommonException("weChat.captcha.build.error");
        }
    }

    @ApiOperation(value = "openId与员工绑定", notes = "openId与员工绑定")
    @RequestMapping(value = "/{openId}/_bind", method = RequestMethod.POST)
    public CommonResponse bindingConfirm(@PathVariable String openId, @RequestBody Map<String, String> bindingInfo) throws Exception {
        Long tenantId = Long.parseLong(bindingInfo.get("tenantId"));
        String callbackUrl = bindingInfo.get("callbackUrl");
        String no = bindingInfo.get("no");
        if (Objects.isNull(tenantId)) {
            throw new CommonException(400, "parameter.incorrect");
        }
        if (StringUtils.isBlank(callbackUrl)) {
            throw new CommonException(400, "parameter.incorrect");
        }
        //判断openId是否已经绑定过人员
        Optional<String> personIdOption = personService.getPersonIdByOpenId(openId, tenantId);
        if (personIdOption.isPresent()) {
            log.error("绑定失败，这个openId={}已经绑定过该租户{}下的人员{}", openId, tenantId, personIdOption.get());
            throw new CommonException(400, "weChat.binding.openId.used");
        }
        //验证必填项不缺失且格式正确
        FluentValidator fluentValidator = FluentValidator.checkAll().failOver();
        List<WeChatBindingConfig> configList = weChatAuthorizationService.getBindingItems(tenantId, WeChatBindingConfigController.WECHAT_BINDING_CONFIG_KEY);

        QPerson qPerson = QPerson.person;
        Predicate predicate = qPerson.tenantId.eq(tenantId);

        for (int i = 0; i < configList.size(); i++) {
            String configKey = configList.get(i).getConfigKey();
            //验证参数中是否缺失必填项，且必填项是否内容为空
            if (!bindingInfo.containsKey(configKey) || StringUtils.isBlank(bindingInfo.get(configKey))) {
                throw new CommonException(Messages.get("weChat.binding.item.cannot.null",new String[]{configKey}));
            }
            //详细校验字段格式
            String configValue = bindingInfo.get(configKey);
            switch (configKey) {
                case "no":
                    fluentValidator.on(configValue, new IsEmptyValidator("no"))
                            .on(configValue, new IsStringWithinLengthRangeValidator("no", 1, 20, true));
                    predicate = ((BooleanExpression) predicate).and(qPerson.no.eq(configValue));
                    break;
                case "name":
                    fluentValidator.on(configValue, new IsEmptyValidator("name"))
                            .on(configValue, new IsStringWithinLengthRangeValidator("name", 1, 64, true));
                    predicate = ((BooleanExpression) predicate).and(qPerson.name.eq(configValue));
                    break;
                case "idCard":
                    fluentValidator.on(configValue, new IsStringWithinLengthRangeValidator("idCard", 0, 20, true));
                    predicate = ((BooleanExpression) predicate).and(qPerson.idCard.eq(configValue));
                    break;
                case "emailCode":
                    fluentValidator.on(configValue, new IsEmptyValidator("emailCode"));
                    String key = RedisCommonKeyUtil.WECHAT_BINDING_EMAIL_CODE + openId + "_" + no;
                    checkValidateCode(key, configValue, "emailCode");
                    break;
                case "phoneCode":
                    fluentValidator.on(configValue, new IsEmptyValidator("phoneCode"));
                    String phoneKey=RedisCommonKeyUtil.WECHAT_BINDING_PHONE_CODE + openId+"_" + no;
                    checkValidateCode(phoneKey,configValue,"phoneCode");
                    break;
                case "password":
                    fluentValidator.on(configValue, new IsStringWithinLengthRangeValidator("password", 6, 20, true));
                    personService.checkPassword(no, configValue, tenantId);
                    break;
                case "graphicCode":
                    fluentValidator.on(configValue, new IsEmptyValidator("graphicCode"));
                    String keyName = RedisCommonKeyUtil.WECHAT_BINDING_GRAPHIC_CODE + openId;
                    checkValidateCode(keyName, configValue, "graphicCode");
                    break;
                default:
                    break;
            }
        }
        ComplexResult ret = fluentValidator.doValidate().result(toComplex());
        if (!ret.isSuccess()) {
            log.error("微信绑定异常{}", ret);
            throw new CommonException(400, "parameter.incorrect", ret);
        }

        //验证完成，所有项均正确，则设置人员绑定openId
        String personId = personService.updatePersonOpenId(predicate, openId);

        //redirect到callbackUrl页面,携带参数：tenantId、openId、personId
        String bindingPage = callbackUrl + "?tenantId=" + tenantId + "&openId=" + openId + "&personId=" + personId;
        return CommonResponse.ok(bindingPage);
    }

    public void checkValidateCode(String key, String code, String param) throws Exception {
        //校验验证码
        String redisCode = redisService.getValue(key);
        if (StringUtils.isBlank(redisCode)) {
            log.error("微信绑定{}校验失败，原因为：redis中该验证码已过期,{}",param,key);
            throw new CommonException("weChat.binding." + param + ".expired");
        }
        if (!redisCode.equals(code)) {
            log.error("微信绑定{}校验失败，原因为：验证码错误,{}",param,key);
            throw new CommonException("weChat.binding." + param + ".incorrect");
        }
        redisService.deleteKey(key);
    }
}
