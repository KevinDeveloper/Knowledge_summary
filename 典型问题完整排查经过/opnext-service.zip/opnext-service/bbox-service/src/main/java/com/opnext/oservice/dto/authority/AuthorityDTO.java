package com.opnext.oservice.dto.authority;

import com.opnext.oservice.domain.account.Account;
import com.opnext.oservice.domain.authority.role.Role;
import com.opnext.oservice.domain.tenant.Tenant;
import lombok.Data;

/**
 * @author wanglu
 */
@Data
public class AuthorityDTO extends Account {
    private Role role;
    private Tenant tenant;
    private Long accountId;
}
