package com.opnext.oservice.controller.person;

import com.alibaba.fastjson.JSONObject;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.person.PersonConfigVo;
import com.opnext.oservice.domain.person.PropertyRequest;
import com.opnext.oservice.service.person.PersonConfigService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Title:PersonConfigController
 * @Description: 人员动态字段
 * @author Kevin
 * @Date 下午5:05 18/5/7
 */
@Slf4j
@RestController
@RequestMapping("/api/person/config")
public class PersonConfigController {

    @Autowired
    private PersonConfigService personConfigService;


    @ApiOperation(value = "人员字段配置初始化", notes = "人员字段配置初始化")
    @RequestMapping(value = "/init", method = RequestMethod.POST)
    public void init() throws Exception {
        log.info("进入接口——人员字段配置初始化");
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long operatorId = oserviceOperator.getUserId();
        personConfigService.initPersonConfig(tenantId, operatorId);
    }

    @ApiOperation(value = "人员字段配置列表", notes = "获取当前人员字段配置列表")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public CommonResponse list() throws Exception {
        log.info("进入接口——人员字段配置列表");
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        List<PersonConfigVo> configs = personConfigService.personConfigList(tenantId);
        return CommonResponse.ok(configs);
    }

    @ApiOperation(value = "更新(新增)人员字段配置", notes = "更新当前人员字段配置列表，id不传为新增")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public void update(@RequestBody PropertyRequest propertyRequest) throws Exception {
        log.info("进入接口——更新人员字段配置，{}", JSONObject.toJSON(propertyRequest));
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long operatorId = oserviceOperator.getUserId();
        personConfigService.updatePersonConfig(tenantId, operatorId, propertyRequest);
    }

    @ApiOperation(value = "删除人员配置字段", notes = "删除人员配置字段")
    @RequestMapping(value = "", method = RequestMethod.DELETE)
    public void delete(@RequestBody Integer[] ids) throws Exception {
        log.info("进入接口——更新人员字段配置，{}", JSONObject.toJSON(ids));
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long operatorId = oserviceOperator.getUserId();
        personConfigService.deletePersonConfig(tenantId, operatorId, ids);
    }

}
