package com.opnext.oservice.repository.rule;

import com.opnext.oservice.domain.rule.RuleApplySync;
import com.opnext.oservice.repository.BaseRepository;
import org.springframework.data.domain.Page;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/31 17:03
 */
public interface RuleApplySyncRepository extends BaseRepository<RuleApplySync> {
    /**
     * 查询批次中第一个结果
     * @param commandId 批次ID
     * @return 第一个查询结果
     */
    RuleApplySync findFirstByCommandId(String commandId);
}
