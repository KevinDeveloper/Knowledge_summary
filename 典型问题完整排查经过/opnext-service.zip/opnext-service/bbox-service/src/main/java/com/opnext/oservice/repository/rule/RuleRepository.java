package com.opnext.oservice.repository.rule;

import com.opnext.oservice.domain.rule.Rule;
import com.opnext.oservice.domain.rule.RuleApply;
import com.opnext.oservice.repository.BaseRepository;
/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 14:03
 */
public interface RuleRepository extends BaseRepository<Rule> {

    /**
     * 根据id和租户id获取规则
     * @param id
     * @param tenantId
     * @return
     */
    Rule findRuleByIdAndTenantId(int id, long tenantId);

    /**
     * 根据姓名查询规则
     * @param name
     * @param tenantId
     * @return
     */
    Rule findRuleByNameAndTenantId(String name, long tenantId);
}
