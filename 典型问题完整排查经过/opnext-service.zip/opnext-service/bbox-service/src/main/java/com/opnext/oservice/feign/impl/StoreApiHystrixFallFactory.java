package com.opnext.oservice.feign.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.feign.StoreApiFeign;
import feign.FeignException;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

/**
 * @author tianzc
 */
@Slf4j
@Component(value = "storeApiHystrixFallFactory")
public class StoreApiHystrixFallFactory implements FallbackFactory<StoreApiFeign> {
    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public StoreApiFeign create(Throwable throwable) {
        log.info("store-api fallback; reason was: {}",throwable.getMessage());
        return new StoreApiFeign() {
            @Override
            public CommonResponse getLicense(String sn) throws Exception {
                return innerHandlerException(throwable, new Object());
            }

            public CommonResponse innerHandlerException(Throwable throwable,Object object) throws Exception{
                if (StringUtils.isBlank(throwable.getMessage())){
                    throw (Exception) throwable;
                }

                String errorMessage = throwable.getMessage().substring(throwable.getMessage().indexOf("\n")+1);
                CommonResponse.ErrorResponse errorResponse = objectMapper.readValue(errorMessage,CommonResponse.ErrorResponse.class);

                if (errorResponse.getStatus()>= HttpStatus.BAD_REQUEST.value() && errorResponse.getStatus()<HttpStatus.INTERNAL_SERVER_ERROR.value()) {

                    if (throwable instanceof FeignException){
                        throw (FeignException) throwable;
                    }else{
                        throw (Exception) throwable;
                    }
                }
                return CommonResponse.ok(object);
            }
        };
    }
}
