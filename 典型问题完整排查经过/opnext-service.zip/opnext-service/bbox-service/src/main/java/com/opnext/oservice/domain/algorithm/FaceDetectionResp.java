package com.opnext.oservice.domain.algorithm;

import lombok.Data;

import java.util.List;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 上午11:36 18/5/12
 */
@Data
public class FaceDetectionResp {
    private int faceNum;
    private int errorCode;
    private String errorMsg;
    private List<FaceResult> result;
    private int score;
}
