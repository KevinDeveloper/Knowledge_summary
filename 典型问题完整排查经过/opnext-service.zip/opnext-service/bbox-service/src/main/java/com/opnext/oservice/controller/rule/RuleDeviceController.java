package com.opnext.oservice.controller.rule;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.domain.device.DeviceStatus;
import com.opnext.oservice.domain.device.DeviceType;
import com.opnext.oservice.domain.device.QDevice;
import com.opnext.oservice.domain.rule.QRuleDevice;
import com.opnext.oservice.domain.rule.Rule;
import com.opnext.oservice.service.rule.RuleDeviceService;
import com.opnext.oservice.service.rule.RuleService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/25 13:10
 */
@Slf4j
@RestController
@Api(value="规则和设备接口",tags={"规则和设备接口"})
@RequestMapping("/api/rule/device")
public class RuleDeviceController {
    @Autowired
    private RuleService ruleService;
    @Autowired
    private RuleDeviceService ruleDeviceService;

    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "ruleId", value = "规则id"),
            @ApiImplicitParam( name = "deviceSns", value = "设备sn号数组")})
    @Transactional(rollbackFor = Exception.class)
    @ApiOperation(value = "下发设备", notes = "将规则下发到设备")
    @PostMapping("/issue/{ruleId}")
    public void issue(@RequestBody List<String> deviceSns, @PathVariable("ruleId") Integer ruleId) throws Exception {
        log.debug("进入到'下发设备'接口");
        if (deviceSns == null || deviceSns.size() == 0 || ruleId == null) {
            log.debug("参数为空");
            throw new CommonException("string.notEmpty");
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        if (OserviceOperator.UserType.COMMON.equals(oserviceOperator.getUserType())
                && CollectionUtils.isEmpty(oserviceOperator.getDeviceGroups())) {
            throw new CommonException("org.tenant.rule");
        }
        Long tenantId = oserviceOperator.getTenantId();
        Rule rule = ruleService.findRuleByIdAndTenantId(ruleId, tenantId);
        if (rule == null) {
            log.debug("规则不存在");
            throw new CommonException("DataNotFound");
        }
        List<String> oldDeviceSnList = ruleDeviceService.getSnsByRuleId(ruleId);
        List<String> addDeviceSns = new ArrayList<>(deviceSns);
        List<String> delDeviceSns = new ArrayList<>(oldDeviceSnList);
        addDeviceSns.removeAll(oldDeviceSnList);
        delDeviceSns.removeAll(deviceSns);
        if (!addDeviceSns.isEmpty()) {
            if (OserviceOperator.UserType.COMMON.equals(oserviceOperator.getUserType())) {
                if (CollectionUtils.isEmpty(oserviceOperator.getDeviceGroups())) {
                    throw new CommonException("org.tenant.rule");
                }
                List<Integer> groupIds = ruleDeviceService.getGroupIdsBySns(addDeviceSns, oserviceOperator.getTenantId());
                if (CollectionUtils.isEmpty(groupIds)) {
                    throw new CommonException("org.tenant.rule");
                }
                groupIds.removeAll(oserviceOperator.getDeviceGroups());
                if (CollectionUtils.isNotEmpty(groupIds)) {
                    throw new CommonException("org.tenant.rule");
                }
            }
            ruleDeviceService.addDeviceToRule(addDeviceSns, rule, oserviceOperator);
        }
        if (!delDeviceSns.isEmpty()) {
            ruleDeviceService.delDeviceFromRule(delDeviceSns, ruleId, oserviceOperator);
        }
    }

    @ApiOperation(value = "获取规则绑定的设备", notes = "获取规则绑定的设备")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "deviceName", value = "设备名称"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "deviceSn", value = "设备SN号"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "deviceGroupId", value = "设备组ID"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "deviceType", value = "设备类型"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "status", value = "设备联网状态"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "ruleId", value = "规则id"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码， 默认为0"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数，默认为10"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "offset", value = "偏移量"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "pageNumber", value = "页数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "pageSize", value = "每页大小"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，name,desc表示在按name倒序排列，不填默认按照updateTime倒序排列")
    })
    @GetMapping("/{ruleId}")
    public CommonResponse<Page<Device>> getDevice(@PathVariable("ruleId") Integer ruleId,
                                                 @RequestParam(required = false) String deviceName,
                                                 @RequestParam(required = false) String deviceSn,
                                                 @RequestParam(required = false) Integer deviceGroupId,
                                                 @RequestParam(required = false) DeviceType deviceType,
                                                 @RequestParam(required = false) DeviceStatus status,
                                                 @PageableDefault Pageable pageable) throws Exception {
        log.debug("进入到'获取规则绑定的设备'接口");
        if (ruleId == null) {
            log.debug("参数为空");
            throw new CommonException("string.notEmpty");
        }
        Long tenantId = OperatorContext.getOperator().getTenantId();
        QDevice qDevice = QDevice.device;
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        Predicate predicate = qRuleDevice.deviceId.eq(qDevice.id).and(qRuleDevice.ruleId.eq(ruleId)).and(qDevice.tenantId.eq(tenantId));
        if (StringUtils.isNotBlank(deviceName)) {
            predicate = ((BooleanExpression) predicate).and(qDevice.name.contains(deviceName));
        }
        if (StringUtils.isNotBlank(deviceSn)) {
            predicate = ((BooleanExpression) predicate).and(qDevice.sn.eq(deviceSn));
        }
        if (deviceGroupId != null) {
            if (deviceGroupId == -1) {
                predicate = ((BooleanExpression) predicate).and(qDevice.groupId.isNull());
            } else {
                predicate = ((BooleanExpression) predicate).and(qDevice.groupId.eq(deviceGroupId));
            }
        }
        if (deviceType != null) {
            predicate = ((BooleanExpression) predicate).and(qDevice.type.eq(deviceType));
        }
        if (status != null) {
            predicate = ((BooleanExpression) predicate).and(qDevice.status.eq(status));
        }
        return CommonResponse.ok(ruleDeviceService.getDevice(predicate, pageable));
    }

    @ApiIgnore
    @ApiOperation(value = "获取规则下绑定的所有设备ID")
    @GetMapping("/getDeviceIdByRuleId/{ruleId}")
    public List<Integer> getDeviceIdByRuleId(@PathVariable("ruleId") Integer ruleId) throws CommonException {
        log.debug("进入到'获取规则下绑定的所有设备ID'接口");
        if (ruleId == null) {
            log.debug("参数为空");
            throw new CommonException("string.notEmpty");
        }
        Long tenantId = OperatorContext.getOperator().getTenantId();
        return ruleDeviceService.getDeviceIdByRuleId(ruleId, tenantId);
    }

    @Transactional(rollbackFor = Exception.class)
    @ApiOperation(value = "设备移除规则", notes = "设备移除规则")
    @ApiImplicitParams({
    @ApiImplicitParam(paramType = "path", dataType = "String", name = "deviceSn", value = "设备sn号"),
    @ApiImplicitParam(paramType = "path", dataType = "int", name = "ruleId", value = "规则id")})
    @DeleteMapping("/{ruleId}/{deviceSn}")
    public void removeRule(@PathVariable("deviceSn") String deviceSn, @PathVariable("ruleId") Integer ruleId) throws Exception {
        log.debug("进入到'设备移除规则'接口");
        if (deviceSn == null || ruleId == null) {
            log.debug("参数为空");
            throw new CommonException("string.notEmpty");
        }
        List<String> deviceSns = new ArrayList<>();
        deviceSns.add(deviceSn);
        ruleDeviceService.delDeviceFromRule(deviceSns, ruleId, OperatorContext.getOperator());
    }

    @ApiIgnore
    @Transactional(rollbackFor = Exception.class)
    @ApiOperation(value = "设备批量移除规则", notes = "设备批量移除规则")
    @PostMapping("/batchDel/{ruleId}")
    public void batchRemove(@RequestBody List<String> deviceSns, @PathVariable("ruleId") int ruleId) throws Exception {
        log.debug("进入到'设备批量移除规则'接口");
        if (deviceSns == null || deviceSns.size() == 0) {
            log.debug("参数为空");
            throw new CommonException("string.notEmpty");
        }
        ruleDeviceService.delDeviceFromRule(deviceSns, ruleId, OperatorContext.getOperator());
    }

}
