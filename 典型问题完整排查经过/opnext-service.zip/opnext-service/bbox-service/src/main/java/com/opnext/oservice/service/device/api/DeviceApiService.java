package com.opnext.oservice.service.device.api;

import com.beebox.push.event.Event;
import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.domain.PersonInfo;
import com.opnext.domain.message.Command;
import com.opnext.domain.request.CallBackRequest;
import com.opnext.domain.request.FeedBackRequest;
import com.opnext.domain.response.AdminResp;
import com.opnext.domain.response.PersonResp;
import com.opnext.oservice.controller.device.api.DeviceApiController;
import com.opnext.oservice.domain.command.BusinessType;
import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.domain.device.ServerEntity;
import com.opnext.oservice.domain.person.OperationType;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午4:50 18/5/7
 */
public interface DeviceApiService {

    /**
     *
     * @param command
     * @param oserviceDevApiOperator
     * @param businessType
     * @return
     * @throws Exception
     */
    void errorCallback(Command command, OserviceDevApiOperator oserviceDevApiOperator, BusinessType businessType, CallBackRequest callBackRequest) throws Exception;

    /**
     *
     * @param command
     * @param businessType
     * @return
     * @throws Exception
     */
    void feedback(Command command, OserviceDevApiOperator oserviceDevApiOperator, BusinessType businessType, FeedBackRequest feedBackRequest) throws Exception;

    /**
     * 获取服务端版本
     * @return
     * @throws Exception
     */
    String getServerVersion() throws Exception;

    /**
     * 终端获取服务端的服务地址和API列表
     * @return
     * @throws Exception
     */
    ServerEntity getServer(String sn, RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 恢复出厂
     * @param sn
     * @throws Exception
     */
    Device restoreFactorySettings(String sn, String operatorType) throws Exception;

    /**
     * 设备激活
     * @param deviceActiveRequest
     * @return
     * @throws Exception
     */
    ServerEntity deviceActive(DeviceApiController.DeviceActiveRequest deviceActiveRequest,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 终端分页获取人员列表
     * @param pageable
     * @param operationType
     * @param syncVersion
     * @throws Exception
     * @return
     */
    PersonResp getPerson(Pageable pageable, OperationType operationType, Long syncVersion,String workflowId,String commandId, String requestId,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 根据id获取人员信息
     * @param ids
     * @param oserviceDevApiOperator
     * @return
     * @throws Exception
     */
    List<PersonInfo> getPersonList(String ids, String nos,OserviceDevApiOperator oserviceDevApiOperator,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 终端分页获取管理员列表
     * @param pageable
     * @param command
     * @throws Exception
     * @return
     */
    AdminResp getAdmin(Pageable pageable, OserviceDevApiOperator oserviceDevApiOperator, Command command,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 获取设备总条数
     * @param sn
     * @return
     */
    long getCountBySn(String sn) throws Exception;

    /**
     * 推送设备信息
     *
     * @param obj       信息
     * @param eventType 事件类型
     */
    void pushDeviceInfo(Object obj, Event.EventType eventType, Long tenantId) throws Exception;
}
