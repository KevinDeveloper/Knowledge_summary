package com.opnext.oservice.domain.visitor;

import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/21 18:03
 */
@Entity
@Table(name = "visitor_area_device")
@Data
@EntityListeners(AuditingEntityListener.class)
public class AreaDevice {
    /**
     * 主键ID
     */
    @Id
    @GeneratedValue
    private Integer id;

    /**
     * 区域ID
     */
    @Column(name = "area_id")
    private Integer areaId;

    /**
     * 设备ID
     */
    @Column(name = "device_id")
    private Integer deviceId;

    /**
     * 设备SN号
     */
    @Column(name = "device_sn")
    private String deviceSn;

    /**
     * 设备进出方向(0进，1出)
     */
    @Column(name = "device_direction")
    private Byte deviceDirection;

    /**
     * 所属租户ID
     */
    @Column(name = "tenant_id")
    private Long tenantId;

}

