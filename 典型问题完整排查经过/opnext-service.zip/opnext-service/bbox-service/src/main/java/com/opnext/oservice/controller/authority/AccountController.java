package com.opnext.oservice.controller.authority;

import com.alibaba.fastjson.JSONObject;
import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.mail.MailEntity;
import com.opnext.bboxsupport.mail.MailSender;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.bboxsupport.util.RedisCommonKeyUtil;
import com.opnext.bboxsupport.util.RedisLifeTimeUtil;
import com.opnext.bboxsupport.validator.HasEasySpecialCharValidator;
import com.opnext.bboxsupport.validator.IsEmailValidator;
import com.opnext.bboxsupport.validator.IsEmptyValidator;
import com.opnext.oservice.conf.AuthorizeProperties;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.account.Account;
import com.opnext.oservice.domain.tenant.Tenant;
import com.opnext.oservice.dto.PageParam;
import com.opnext.oservice.dto.authority.AuthorityDTO;
import com.opnext.oservice.service.account.AccountService;
import com.opnext.oservice.service.base.BaseRedisService;
import com.opnext.bboxsupport.util.RedirectHttpUtil;
import io.swagger.annotations.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.web.PageableDefault;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author wanglu
 */
@Api(value="账号管理",tags={"租户、账号信息管理"})
@Slf4j
@RestController
@RequestMapping("/api/account")
public class AccountController {
    @Autowired
    private AccountService accountService;
    @Autowired
    private BaseRedisService redisService;
    @Autowired
    private AuthorizeProperties authorizeProperties;

    @ApiOperation(value = "获取登陆者可见的账号列表", notes = "获取登陆者可见的账号列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如xxx,desc表示根据xxx字段倒叙排序")
    })
    @RequestMapping(value = "/",method = RequestMethod.GET)
    public Page<Account> getAccountList(@PageableDefault PageParam pageable)throws Exception{
        OserviceOperator oserviceOperator =OperatorContext.getOperator();
        return accountService.getAccountPage(Account.builder().tenantId(oserviceOperator.getTenantId()).build(),pageable);
    }

    @ApiOperation(value = "获取租户信息", notes = "获取租户信息")
    @RequestMapping(value = "/tenant",method = RequestMethod.GET)
    public Tenant getTenantInfo()throws Exception{
        OserviceOperator oserviceOperator =OperatorContext.getOperator();
        return accountService.getTenantById(oserviceOperator.getTenantId());
    }

    @ApiOperation(value = "获取登陆者账号详情", notes = "获取登陆者的详情")
    @RequestMapping(value = "/detail",method = RequestMethod.GET)
    public AuthorityDTO getAccountInfo()throws Exception{
        OserviceOperator oserviceOperator =OperatorContext.getOperator();
        Long accountId = oserviceOperator.getUserId();
        List<AuthorityDTO> accountList = accountService.getAuthorityAccountList(Account.builder().id(accountId).tenantId(oserviceOperator.getTenantId()).build());
        if (Objects.isNull(accountList) || accountList.isEmpty()){
            throw new CommonException(400,"tenant.account.notFount");
        }
        AuthorityDTO authorityDTO = accountList.get(0);
        Tenant tenant = accountService.getTenantById(oserviceOperator.getTenantId());
        authorityDTO.setTenant(tenant);
        return authorityDTO;
    }

    @ApiOperation(value = "修改电话号码", notes = "修改电话号码")
    @RequestMapping(value = "/phone",method = RequestMethod.POST)
    public void changePhone(@RequestBody String phone,BindingResult result)throws Exception{
        String telephone=null;
        try {
            telephone = JSONObject.parseObject(phone).getString("phone");
        }catch (Exception e){
            throw new CommonException(400,"parameter.incorrect");
        }

        if (telephone.length()>20){
            result.addError(new ObjectError("phone", "string.length.incorrect"));
            throw new CommonException(400,"parameter.incorrect",result);
        }
        if (StringUtils.isNotBlank(telephone)){
            //判断邮箱是否已经被使用
            Account account = Account.builder().phone(telephone).build();
            List<Account> accountList = accountService.getAccountList(account);
            if (accountList!=null && accountList.size()>0){
                OserviceOperator oserviceOperator = OperatorContext.getOperator();
                List<Account> accounts =  accountService.getAccountList(Account.builder().id(oserviceOperator.getUserId()).tenantId(oserviceOperator.getTenantId()).build());
                String accountPhone = accounts.get(0).getPhone();
                if (accountList.get(0).getPhone().equals(accountPhone)){
                    result.addError(new ObjectError("phone", "tenant.phone.change.old"));
                    throw new CommonException(400,"tenant.phone.change.old",result);
                }else {
                    result.addError(new ObjectError("phone", "tenant.phone.used"));
                    throw new CommonException(400,"tenant.phone.used",result);
                }
            }
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        accountService.modifyAccount(Account.builder().id(oserviceOperator.getUserId()).phone(telephone).build());
    }

    @ApiOperation(value = "修改邮箱：发送邮箱验证码", notes = "修改邮箱：发送邮箱验证码")
    @RequestMapping(value = "/email/validateCode",method = RequestMethod.POST)
    public void checkEmailValidateCode(@RequestBody String email)throws Exception{
        String mailAddress;
        try {
            mailAddress = JSONObject.parseObject(email).getString("email");
        }catch (Exception e){
            throw new CommonException(400,"parameter.incorrect");
        }
        //校验邮箱地址正确性
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(mailAddress, new IsEmptyValidator("email"))
                .on(mailAddress, new IsEmailValidator("email"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            throw new CommonException(400,"parameter.incorrect",ret);
        }

        //判断邮箱是否已经被使用
        Account account = Account.builder().email(mailAddress).build();
        List<Account> accountList = accountService.getAccountList(account);
        if (accountList!=null && accountList.size()>0){
            OserviceOperator oserviceOperator = OperatorContext.getOperator();
            List<Account> accounts =  accountService.getAccountList(Account.builder().id(oserviceOperator.getUserId()).tenantId(oserviceOperator.getTenantId()).build());
            String accountEmail = accounts.get(0).getEmail();
            if (accountList.get(0).getEmail().equals(accountEmail)){
                throw new CommonException(400,"tenant.email.change.old");
            }else {
                throw new CommonException(400,"tenant.email.used");
            }
        }
        //生成验证码
        int code = (int) ((Math.random() * 9 + 1) * 100000);
        //发送邮件
        String emailAddress = mailAddress;
        MailEntity m=MailEntity.builder()
                .title(Messages.get("email.title.verify.email"))
                .content(Messages.get("mail.register.validateCode",new String[]{code+""}))
                .contentType(MailEntity.MailContentTypeEnum.HTML.getValue())
                .target(new ArrayList<String>(){{
                    add(emailAddress);
                }}).build();
        try {
            MailSender.send(m);
        } catch (Exception e) {
            log.error("注册发送验证码失败，原因为：{}",e.getMessage());
            throw new CommonException(e.getMessage());
        }
        //验证码放到redis中
        String keyName = RedisCommonKeyUtil.CHANGE_EMAIL_CODE+ mailAddress;
        redisService.setKey(keyName,code+"",RedisLifeTimeUtil.validateCodeTime());
    }

    @ApiOperation(value = "修改邮箱", notes = "修改邮箱")
    @RequestMapping(value = "/email",method = RequestMethod.POST)
    public void changeEmailAddress(@RequestBody @Valid ChangeEmailRequest changeEmailRequest, BindingResult bindingResult) throws Exception{
        if(bindingResult.hasErrors()){
            log.error("修改邮箱 操作失败,{}",bindingResult);
            throw new CommonException(400,"parameter.incorrect",bindingResult);
        }
        String email = changeEmailRequest.getEmail();
        String emailCode = changeEmailRequest.getEmailCode();
        OserviceOperator oserviceOperator = OperatorContext.getOperator();

        //判断邮箱是否已经被使用
        Account account = Account.builder().email(email).build();
        List<Account> accountList = accountService.getAccountList(account);
        if (accountList!=null && accountList.size()>0){
            List<Account> accounts =  accountService.getAccountList(Account.builder().id(oserviceOperator.getUserId()).tenantId(oserviceOperator.getTenantId()).build());
            String accountEmail = accounts.get(0).getEmail();
            if (accountList.get(0).getEmail().equals(accountEmail)){
                bindingResult.addError(new ObjectError("email", "tenant.email.change.old") );
                throw new CommonException(400,"tenant.email.change.old",bindingResult);
            }else {
                bindingResult.addError(new ObjectError("email", "tenant.email.used") );
                throw new CommonException(400,"tenant.email.used",bindingResult);
            }
        }
        //校验邮箱验证码
        String key =RedisCommonKeyUtil.CHANGE_EMAIL_CODE + email;
        String code = redisService.getValue(key);
        if (StringUtils.isBlank(code) ) {
            log.error("修改邮箱失败，原因为：通过邮箱查询到code为空");
            bindingResult.addError(new ObjectError("emailCode", "email.validation.code.timeout") );
            throw new CommonException(400, "email.validation.code.timeout",bindingResult);
        }else if(!emailCode.equals(code)){
            log.error("修改邮箱失败，原因为：验证码或者邮箱输入错误");
            throw new CommonException(400, "email.validation.code.incorrect");
        }
        redisService.deleteKey(key);
        accountService.modifyAccount(Account.builder().id(oserviceOperator.getUserId()).email(email).build());
    }

    @ApiOperation(value = "修改密码", notes = "修改密码")
    @RequestMapping(value = "/password",method = RequestMethod.POST)
    public void changePassword(@RequestBody @Valid ChangePasswordRequest changePasswordRequest, BindingResult bindingResult) throws Exception{
        if(bindingResult.hasErrors()){
            log.error("修改密码 操作失败,{}",bindingResult);
            throw new CommonException(400,"parameter.incorrect",bindingResult);
        }

        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(changePasswordRequest.getPassword(), new HasEasySpecialCharValidator("password"))
                .on(changePasswordRequest.getNewPassword(), new HasEasySpecialCharValidator("newPassword"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("修改密码失败,参数有误，{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }

        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long id = oserviceOperator.getUserId();
        //判断密码是否是原密码
        Boolean flag = accountService.verifyPassword(Account.builder().id(id).password(changePasswordRequest.password).build());
        if (!flag){
            log.error("修改密码失败，原因为：初始密码错误");
            bindingResult.addError(new ObjectError("password", "tenant.password.old.incorrect") );
            throw new CommonException(400, "tenant.password.old.incorrect",bindingResult);
        }
        //修改密码
        accountService.modifyAccount(
                Account.builder().id(id)
                        .password(changePasswordRequest.newPassword).build());
    }

    @ApiOperation(value = "登出", notes = "登出")
    @RequestMapping(value = "/logout",method = RequestMethod.GET)
    public void logout(HttpServletRequest request,HttpServletResponse response) throws Exception {
        //退出登陆后，删除当前的id-role关系
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Long accountId= oserviceOperator.getUserId();
        if (Objects.nonNull(accountId)) {
            String accountIdStr = accountId+"";
            String roleIdStr = redisService.getValue(RedisCommonKeyUtil.ACCOUNT_ROLE+accountIdStr);
            if (StringUtils.isNotBlank(roleIdStr)) {
                redisService.deleteKey(RedisCommonKeyUtil.ACCOUNT_ROLE+ accountIdStr);
            }
        }

        Cookie cookie = null;
        Cookie[] cookies = request.getCookies();
        Cookie refreshCookie = null;
        if(cookies != null){
            for (Cookie ck : cookies) {
                if(ck.getName().equals(authorizeProperties.getAuthCookieName())){
                    cookie = ck;
                }
                if (ck.getName().equals(authorizeProperties.getAuthRefreshCookieName())){
                    refreshCookie=ck;
                }
            }
            if (cookie != null){
                cookie.setMaxAge(0);
                cookie.setPath("/");
                response.addCookie(cookie);
            }
            if (refreshCookie != null){
                refreshCookie.setMaxAge(0);
                refreshCookie.setPath("/");
                response.addCookie(refreshCookie);
            }
        }
        //登出，重定向到OAuth的登陆页
        String redirectUrl = RedirectHttpUtil.getScheme(request)+"://"+RedirectHttpUtil.getHost(request) + authorizeProperties.getLogoutUrl();
        response.sendRedirect(redirectUrl);
    }

    @Data
    static class ChangeEmailRequest{
        @Email(message = "tenant.register.email.validate")
        private String email;

        @NotEmpty(message="tenant.parameter.notEmpty")
        private String emailCode;
    }

    @Data
    static class ChangePasswordRequest{
        @NotEmpty(message="tenant.register.password.notEmpty")
        @Length(max=20, message = "tenant.register.password.length")
        private String password;

        @NotEmpty(message="tenant.register.password.notEmpty")
        @Length(max=20, message = "tenant.register.password.length")
        private String newPassword;
    }
}