package com.opnext.oservice.service.impl;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.QServerConfig;
import com.opnext.oservice.domain.ServerConfig;
import com.opnext.oservice.repository.device.server.ServerConfigRepository;
import com.opnext.oservice.service.ServerConfigService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;

/**
 * @author tianzc
 */
@Slf4j
@Service
public class ServerConfigServiceImpl implements ServerConfigService {

    @Autowired
    ServerConfigRepository serverConfigRepository;
    @Autowired
    JPAQueryFactory jpaQueryFactory;

    /**
     * 更新信息
     *
     * @param serverConfig
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(ServerConfig serverConfig) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        QServerConfig qServerConfig = QServerConfig.serverConfig;
        Predicate predicate = qServerConfig.tenantId.eq(oserviceOperator.getTenantId());
        predicate = ((BooleanExpression) predicate).and(qServerConfig.id.eq(serverConfig.getId()));
        // 获取要更新数据
        ServerConfig findConfig = serverConfigRepository.findOne(predicate);
        if (Objects.isNull(findConfig)) {
            log.info("更新数据不存在：{}", serverConfig);
            throw new CommonException("DataNotFound");
        }
        jpaQueryFactory.update(QServerConfig.serverConfig)
                .set(qServerConfig.configValue, serverConfig.getConfigValue())
                .where(predicate).execute();
    }

    /**
     * 获取配置
     *
     * @param key
     * @param type
     * @param tenantId
     * @return
     * @throws Exception
     */
    @Override
    public ServerConfig getConfig(String key, String type, Long tenantId) throws Exception {
        return null;
    }

    /**
     * 获取人员密码配置
     *
     * @param tenantId
     * @return
     * @throws Exception
     */
    @Override
    public ServerConfig getPersonPwdConfig(Long tenantId) throws Exception {
        QServerConfig qServerConfig = QServerConfig.serverConfig;
        Predicate predicate = qServerConfig.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(qServerConfig.type.eq(GlobleConfig.ServicePerson.type));
        predicate = ((BooleanExpression) predicate).and(qServerConfig.configKey.eq(GlobleConfig.ServicePerson.pwdKey));
        ServerConfig serverConfig = serverConfigRepository.findOne(predicate);
        if (Objects.isNull(serverConfig)) {
            serverConfig = new ServerConfig();
            serverConfig.setConfigKey(GlobleConfig.ServicePerson.pwdKey);
            serverConfig.setConfigValue(GlobleConfig.ServicePerson.commonPassword);
            serverConfig.setType(GlobleConfig.ServicePerson.type);
            serverConfig.setConfigType(GlobleConfig.ServicePerson.pwdKey);
            serverConfig.setTenantId(tenantId);
            serverConfig = serverConfigRepository.save(serverConfig);
        }
        return serverConfig;
    }
}
