package com.opnext.oservice.controller.appcenter;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.conf.WeChatProperties;
import com.opnext.oservice.util.RestClient;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import me.chanjar.weixin.mp.bean.template.WxMpTemplateMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: lixiuwen
 * @Date: 2018/8/2 14:48
 */
@Slf4j
@RestController
@RequestMapping("/api/wechat/send")
public class WechatSendController {
    @Autowired
    RestClient restClient;
    @Autowired
    WeChatProperties wechatProperties;

    @ApiOperation(value = "获取公众号jsticket")
    @GetMapping("/ticket")
    public CommonResponse sendJsTicket(@RequestParam("appId") String appId) {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        log.info("进入“获取公众号jsticket”接口,tenantId;{}", oserviceOperator.getTenantId());
        String url = String.format("%s%s/%s", wechatProperties.getHost(), wechatProperties.getJsTicketUrl(), appId);
        return CommonResponse.ok(restClient.doGet(url, String.class));
    }

    @ApiOperation(value = "发送模版消息")
    @PostMapping("/msg")
    public CommonResponse sendJsTicket(@RequestParam("appId") String appId, @RequestBody WxMpTemplateMessage message) {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        log.info("进入“发送模版消息”接口,tenantId;{}", oserviceOperator.getTenantId());
        String url = String.format("%s%s/%s", wechatProperties.getHost(), wechatProperties.getSendTemplateUrl(), appId);
        return CommonResponse.ok(restClient.doPost(url, message, String.class));
    }

}
