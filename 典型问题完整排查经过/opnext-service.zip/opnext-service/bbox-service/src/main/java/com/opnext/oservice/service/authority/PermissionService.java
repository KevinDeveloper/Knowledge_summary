package com.opnext.oservice.service.authority;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.authority.role.Resource;

import java.util.List;

/**
 * @author wanglu
 */
public interface PermissionService {
    /**
     * 通过角色id获取资源（API）列表
     * @param roleId
     * @return
     */
    List<Resource> getResourcesByRoleId(long roleId);

    /**
     * 通过角色id查询组织id列表
     * @param roleId
     * @return
     */
    List<Integer> getOrgIdListByRoleId(long roleId);

    /**
     * 通过角色id查询设备组id列表
     * @param roleId
     * @return
     */
    List<Integer> getDeviceGroupIdListByRoleId(long roleId);

    /**
     * 获取当前操作者的角色Id String
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    String getRoleStrByOperator(OserviceOperator oserviceOperator) throws Exception;

    /**
     * 初始化公共资源资源到redis中
     */
    void initPubResource();
}
