package com.opnext.oservice.domain;

import lombok.Builder;
import lombok.Data;

/**
 * @author tianzc
 */
@Data
@Builder
public class MultipartFileResp {
    /**
     * 上传成功失败标志
     */
    private boolean flag;
    /**
     * 文件访问地址
     */
    private String url;
    /**
     * 消息
     */
    private String message;
    /**
     * 上传文件原名称
     */
    private String fileName;
}
