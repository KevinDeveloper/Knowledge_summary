package com.opnext.oservice.util;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * @author tianzc
 */
public class JsonConvertor {

    private static ObjectMapper objectMapper = new ObjectMapper();

    public static <T> String beanToJson(T bean) throws Exception {
        return objectMapper.writeValueAsString(bean);
    }

    public static String mapToJson(Map map) throws Exception {
        return objectMapper.writeValueAsString(map);
    }

    public static String listToJson(List list) throws Exception{

        return objectMapper.writeValueAsString(list);
    }

    public static <T> T jsonToBean(String json, Class<T> beanClass) throws IOException {
        return objectMapper.readValue(json, beanClass);
    }

    public static <T> List<T> jsonToList(String json, Class<T> beanClass) throws IOException {
        return (List<T>)objectMapper.readValue(json, getCollectionType(List.class, beanClass));
    }

    public static Map jsonToMap(String json) throws IOException {
        return (Map)objectMapper.readValue(json, Map.class);
    }

    public static JavaType getCollectionType(Class<?> collectionClass, Class<?>... elementClasses) {
        return objectMapper.getTypeFactory().constructParametricType(collectionClass, elementClasses);
    }

}
