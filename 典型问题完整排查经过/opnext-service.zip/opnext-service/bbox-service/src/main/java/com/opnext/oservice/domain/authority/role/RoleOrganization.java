package com.opnext.oservice.domain.authority.role;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

import javax.persistence.*;

/**
 * @author wanglu
 */
@Entity
@Data
@Table(name = "role_organization")
@Builder
public class RoleOrganization {
    @Tolerate
    public RoleOrganization(){};
    @Id
    @GeneratedValue
    private Long id;

    @Column(name="role_id")
    private Long roleId;

    @Column(name="organization_id")
    private Integer organizationId;
}
