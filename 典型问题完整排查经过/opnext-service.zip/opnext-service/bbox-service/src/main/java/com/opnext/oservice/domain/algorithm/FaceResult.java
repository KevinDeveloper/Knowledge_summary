package com.opnext.oservice.domain.algorithm;

import com.opnext.bboximage.domain.algorithm.FaceLocation;
import lombok.Data;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午1:20 18/5/12
 */
@Data
public class FaceResult {
    private double confidence;
    private int width;
    private int height;
    private FaceLocation faceLocation;
    private Quality quality;
    private LeftEye leftEye;
    private RightEye rightEye;
}
