package com.opnext.oservice.domain.person;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @ClassName: PersonConfig
 * @Description: 人员管理字段配置类
 * @Author: Kevin
 * @Date: 2018/5/14 16:58
 */
@Data
public class PersonConfigVo implements Serializable {
    private Integer id;
    private String propertyName;
    @JsonIgnore
    private PropertyType propertyType;
    private PropertyRequire propertyRequire;
    private PropertyShow propertyShow;
    private PropertyEdit propertyEdit;
    /**
     * 国际化显示的文字
     */
    private String propertyTitle;

    /**
     * propertyType 转换为 JSON 字段
     * @return PropertyType 枚举 value 值
     */
    @JSONField(name = "propertyType", label = "propertyType")
    @JsonProperty(value = "propertyType")
    public int getPropertyTypeToJSONField(){
        return propertyType.value();
    }

    /**
     * propertyType 转换为 JSON 字段
     * @return PropertyType 枚举 value 值
     */
    @JSONField(name = "propertyType" , label = "propertyType")
    @JsonProperty(value = "propertyType")
    public void setPropertyTypeToJSONField(int value){
        propertyType = PropertyType.indexOfVal(value);
    }

    public boolean getPropertyRequire() {
        return propertyRequire.value();
    }

    public void setPropertyRequire(boolean isRequire) {
        propertyRequire = PropertyRequire.indexOfVal(isRequire);
    }

    public boolean getPropertyShow() {
        return propertyShow.value();
    }

    public void setPropertyShow(boolean isShow) {
        propertyShow = PropertyShow.indexOfVal(isShow);
    }

    public boolean getPropertyEdit() {
        return propertyEdit.value();
    }

    public void setPropertyEdit(boolean isEdit) {
        propertyEdit = PropertyEdit.indexOfVal(isEdit);
    }

}

