package com.opnext.oservice.repository;

import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface BaseRepository<T> extends PagingAndSortingRepository<T, Integer>,QueryDslPredicateExecutor<T>{

}
