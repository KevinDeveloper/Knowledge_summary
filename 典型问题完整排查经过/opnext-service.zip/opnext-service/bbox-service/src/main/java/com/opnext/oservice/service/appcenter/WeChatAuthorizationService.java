package com.opnext.oservice.service.appcenter;

import com.opnext.oservice.domain.ServerConfig;
import com.opnext.oservice.domain.appcenter.WeChatBindingConfig;

import java.util.List;

/**
 * @author wanglu
 */
public interface WeChatAuthorizationService {

    /**
     * 通过租户和类型获取"微信绑定选项"
     * @param tenantId
     * @param type
     * @return
     */
    List<WeChatBindingConfig> getBindingConfig(long tenantId, String type);

    /**
     * 设置微信绑定选项
     * @param tenantId
     * @param serverConfigs
     * @throws Exception
     */
    void setBindingConfig(long tenantId,List<ServerConfig> serverConfigs)throws Exception;

    /**
     * 查询微信绑定的输入项
     * @param tenantId
     * @param type
     * @return
     */
    List<WeChatBindingConfig> getBindingItems(long tenantId,String type);
}
