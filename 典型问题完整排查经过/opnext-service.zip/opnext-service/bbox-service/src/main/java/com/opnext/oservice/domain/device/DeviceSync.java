package com.opnext.oservice.domain.device;

import com.opnext.domain.config.OConfigGroup;
import lombok.Data;

import java.util.List;

/**
 * @author tianzc
 */
@Data
public class DeviceSync {
    private List<Integer> deviceIds;
    private List<String> snList;
    private OConfigGroup objConfig;

}
