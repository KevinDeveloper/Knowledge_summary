package com.opnext.oservice.service.device;

import com.opnext.oservice.domain.device.DeviceGroup;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:03 18/5/7
 */
public interface DeviceGroupService {

    /**
     * 分页获取设备组列表
     * @param pageable
     * @param name
     * @return
     * @throws Exception
     */
    Page getPage(Pageable pageable, String name) throws Exception;


    /**
     * 获取所有设备列表
     * @return
     * @throws Exception
     */
    List getAllList() throws Exception;

    /**
     * 根据id获取设备组
     * @param id
     * @return
     * @throws Exception
     */
    DeviceGroup getInfo(Integer id) throws Exception;

    /**
     * 保存设备组，并关联设备
     * @param deviceGroup
     * @throws Exception
     */
    DeviceGroup save(DeviceGroup deviceGroup) throws Exception;

    /**
     * 更新设备名称
     * @param deviceGroup
     * @throws Exception
     */
    void updateGroup(DeviceGroup deviceGroup) throws Exception;

    /**
     * 更新设备名称
     * @param groupNme
     * @param id
     * @throws Exception
     */
    void updateGroupName(Integer id, String groupNme) throws Exception;

    /**
     * 删除设备组，移除设备关联设备组
     * @param ids
     * @throws Exception
     */
    void delete(Integer[] ids) throws Exception;
}
