package com.opnext.oservice.domain.person;

import lombok.AllArgsConstructor;

/**
 * @ClassName: PropertyShow
 * @Description:是否显示：0不显示，1显示
 * @Author: Kevin
 * @Date: 2018/6/5 11:00
 */
@AllArgsConstructor
public enum PropertyShow {
    /**
     * 隐藏
     */
    hide(false),
    /**
     * 显示
     */
    show(true);
    private boolean value;

    public boolean value() {
        return this.value;
    }

    /**
     * 通过 val 值索引 PropertyType
     *
     * @param val val
     * @return PropertyType
     */
    public static PropertyShow indexOfVal(boolean val) {
        for (PropertyShow propertyShow : values()) {
            if (propertyShow.value == val) {
                return propertyShow;
            }
        }

        throw new IllegalArgumentException("param value " + val);
    }
}
