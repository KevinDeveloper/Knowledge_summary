package com.opnext.oservice.controller.common;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.service.common.InitializationService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author tianzc
 */
@Slf4j
@RestController
@RequestMapping("/api/init")
public class InitializationController {

    @Resource
    private InitializationService initService;

    /**
     * 创建租户时初始化添加识别记录mongo集合
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "", method = RequestMethod.POST)
    public CommonResponse init(String orgName) throws Exception {
        log.info("--注册初始化(超管角色，组织，识别记录集合，人员配置)接口");
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(orgName, new IsStringWithinLengthRangeValidator("orgName", 1, 64, true))
                .doValidate()
                .result(toComplex());
        if (!ret.isSuccess()) {
            log.info("初始化根组织异常， 参数错误， orgName={}", orgName);
            throw new CommonException(400, "parameter.incorrect", ret);
        }
        // 获取操作者信息
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        CommonResponse commonResponse = initService.init(oserviceOperator,orgName);
        return commonResponse;
    }

    /**
     * 创建租户时初始化添加识别记录mongo集合
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/accessrecord/collection/_create", method = RequestMethod.POST)
    public CommonResponse createAccessRecordCollection() throws Exception {
        // 获取操作者信息
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        CommonResponse commonResponse = initService.createAccessRecordCollection(oserviceOperator);
        return commonResponse;
    }
}
