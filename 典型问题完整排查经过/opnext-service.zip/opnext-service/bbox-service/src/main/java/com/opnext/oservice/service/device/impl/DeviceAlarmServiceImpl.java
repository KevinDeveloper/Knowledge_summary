package com.opnext.oservice.service.device.impl;

import com.opnext.oservice.domain.device.alarm.DeviceAlarm;
import com.opnext.oservice.domain.device.alarm.DeviceAlarmType;
import com.opnext.oservice.domain.device.alarm.QDeviceAlarm;
import com.opnext.oservice.repository.device.alarm.DeviceAlarmRepository;
import com.opnext.oservice.repository.device.alarm.DeviceAlarmTypeRepository;
import com.opnext.oservice.service.device.DeviceAlarmService;
import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * @author wanglu
 */
@Slf4j
@Service
public class DeviceAlarmServiceImpl implements DeviceAlarmService {
    @Autowired
    private DeviceAlarmTypeRepository deviceAlarmTypeRepository;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    private DeviceAlarmRepository deviceAlarmRepository;

    @Override
    public List<DeviceAlarmType> getAlarmTypeList() {
        return (List) deviceAlarmTypeRepository.findAll();
    }

    @Override
    public int countByReadStatusAndTenantId(boolean status, long tenantId) {
        return deviceAlarmRepository.countByReadStatusAndTenantId(false,tenantId);
    }

    @Override
    public void clearUnReadAlarm(long tenantId) {
        QDeviceAlarm deviceAlarm = QDeviceAlarm.deviceAlarm;
        int count = deviceAlarmRepository.countByReadStatusAndTenantId(false,tenantId);
        if (count>0){
            jpaQueryFactory.update(deviceAlarm).set(deviceAlarm.readStatus,true).where(deviceAlarm.tenantId.eq(tenantId)).execute();
        }
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public Page<DeviceAlarm> queryAlarmPagable(long tenantId,Predicate predicate, Pageable pageable) {
        QDeviceAlarm deviceAlarm = QDeviceAlarm.deviceAlarm;
        int count = deviceAlarmRepository.countByReadStatusAndTenantId(false,tenantId);
        if (count>0){
            jpaQueryFactory.update(deviceAlarm).set(deviceAlarm.readStatus,true).where(deviceAlarm.tenantId.eq(tenantId)).execute();
        }
        Page<DeviceAlarm> deviceAlarms = deviceAlarmRepository.findAll(predicate,pageable);
        return deviceAlarms;
    }

    @Override
    public DeviceAlarmType findDeviceAlarmTypeByName(String alarmType) {
        return deviceAlarmTypeRepository.findDeviceAlarmTypeByName(alarmType);
    }

    @Override
    public void saveDeviceAlarm(DeviceAlarm deviceAlarm) {
        deviceAlarmRepository.save(deviceAlarm);
    }

}
