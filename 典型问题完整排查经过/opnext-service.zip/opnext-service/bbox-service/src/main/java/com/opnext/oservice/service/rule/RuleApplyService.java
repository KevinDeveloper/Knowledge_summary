package com.opnext.oservice.service.rule;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.domain.response.IDRuleResp;
import com.opnext.oservice.domain.person.PersonVo;
import com.opnext.oservice.domain.rule.Rule;
import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 15:56
 */
public interface RuleApplyService {

    /**
     * 查询规则下人员信息
     *
     * @param predicate 查询条件
     * @param pageable  分页信息
     * @return
     */
    Page<PersonVo> getPersonByRuleId(Predicate predicate, Pageable pageable);

    /**
     * 根据规则ID获取人员ID
     *
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return
     */
    List<String> getPersonIdByRuleId(Integer ruleId, Long tenantId);

    /**
     * 根据规则ID获取人员所属的组织ID集合（去重）
     *
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return
     */
    List<Integer> getOrganizationIdByRuleId(Integer ruleId, Long tenantId);

    /**
     * 根据规则ID获取人员所属的组织ID集合（去重）
     *
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return
     */
    List<Integer> getPersonOrgIdByRuleId(Integer ruleId, Long tenantId);

    /**
     * 获取规则集合下人员的数量
     *
     * @param ruleIdList 规则集合
     * @return
     */
    Map<Integer, Long> getPersonCountMap(List<Integer> ruleIdList);

    /**
     * 添加规则应用信息
     * 先删除原有的应用信息，再添加新的应用信息
     *
     * @param rule             规则
     * @param oserviceOperator 当前操作人信息
     */
    void addRuleApply(Rule rule, OserviceOperator oserviceOperator);

    /**
     * 添加规则应用信息
     *
     * @param ruleId           规则ID
     * @param personIdList     应用规则的人员ID集合
     * @param oserviceOperator 当前操作人信息
     */
    void addRuleApplyWithPersonId(Integer ruleId, List<String> personIdList, OserviceOperator oserviceOperator);

    /**
     * 添加规则应用信息
     *
     * @param ruleId             规则ID
     * @param organizationIdList 应用规则的组织ID集合
     * @param oserviceOperator   当前操作人信息
     */
    void addRuleApplyWithOrganizationId(Integer ruleId, List<Integer> organizationIdList, OserviceOperator oserviceOperator);


    /**
     * 将人员移除规则
     *
     * @param ruleId           规则ID
     * @param personIds        需要移除规则的人员ID集合
     * @param oserviceOperator 当前操作人信息
     * @param deviceSnList     发送的设备SN列表
     * @throws Exception
     */
    void removePersonFromRule(Integer ruleId, List<String> personIds, OserviceOperator oserviceOperator, List<String> deviceSnList) throws Exception;

    /**
     * 向规则中添加人员
     *
     * @param ruleId           规则ID
     * @param personIds        需要添加到规则的人员ID集合
     * @param oserviceOperator 当前操作人信息
     * @param deviceSnList     发送的设备SN列表
     * @throws Exception
     */
    void addPersonToRule(Integer ruleId, List<String> personIds, OserviceOperator oserviceOperator, List<String> deviceSnList) throws Exception;

    /**
     * 将人员移除规则
     *
     * @param ruleId           规则ID
     * @param organizationIds  需要移除规则的组织ID集合
     * @param oserviceOperator 当前操作人信息
     * @param deviceSnList     发送的设备SN列表
     * @throws Exception
     */
    void removeOrgFromRule(Integer ruleId, List<Integer> organizationIds, OserviceOperator oserviceOperator, List<String> deviceSnList) throws Exception;

    /**
     * 向规则中添加人员
     *
     * @param ruleId           规则ID
     * @param organizationIds  需要添加到规则的组织ID集合
     * @param oserviceOperator 当前操作人信息
     * @param deviceSnList     发送的设备SN列表
     * @throws Exception
     */
    void addOrgToRule(Integer ruleId, List<Integer> organizationIds, OserviceOperator oserviceOperator, List<String> deviceSnList) throws Exception;

    /**
     * 向设备发送获取人员规则信息
     *
     * @param deviceSnList     设备SN集合
     * @param commandId        批次ID
     * @param operationType    操作类型
     * @param oserviceOperator 当前登录人信息
     * @throws Exception
     */
    void sendRuleApplyToDevice(List<String> deviceSnList, String commandId, IDRuleResp.OperationType operationType, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 删除人员时调用此接口
     *
     * @param personIdList 人员ID集合
     * @param tenantId     租户ID
     * @throws Exception
     */
    void whenDelPerson(List<String> personIdList, long tenantId) throws Exception;

    /**
     * 向组织添加人员
     *
     * @param personIdList     人员ID集合
     * @param organizationId   组织ID
     * @param oserviceOperator 当前操作人信息
     * @throws Exception
     */
    void whenAddOrg(List<String> personIdList, int organizationId, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 向组织添加人员
     *
     * @param mapOrgPersonId   组织ID和人员ID集合
     * @param oserviceOperator 当前操作人信息
     * @throws Exception
     */
    void whenAddOrg(Map<Integer, List<String>> mapOrgPersonId, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 删除规则中的组织
     *
     * @param organizationIdList 组织ID集合
     * @param oserviceOperator   当前操作人
     * @throws Exception
     */
    void whenDelOrg(List<Integer> organizationIdList, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 组织内人员变更
     *
     * @param personId         人员ID
     * @param orgId            原组织ID
     * @param targetOrdId      现组织ID
     * @param oserviceOperator 当前操作人
     * @throws Exception
     */
    void whenModifyOrg(String personId, Integer orgId, Integer targetOrdId, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 批量修改人员组织接口
     *
     * @param personIds        人员ids
     * @param orgId            原组织id
     * @param targetOrdId      新的目标组织
     * @param oserviceOperator 当前操作人
     * @throws Exception
     */
    void whenEditPersonOrg(List<String> personIds, Integer orgId, Integer targetOrdId, OserviceOperator oserviceOperator) throws Exception;


}
