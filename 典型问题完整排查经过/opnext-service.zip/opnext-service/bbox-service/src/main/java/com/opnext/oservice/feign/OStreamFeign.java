package com.opnext.oservice.feign;

import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.domain.device.ServerHost;
import com.opnext.oservice.feign.impl.OStreamHystrixFallFactory;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author tianzc
 */
@FeignClient(value = "o-stream", path = "/o-stream", fallbackFactory = OStreamHystrixFallFactory.class)
public interface OStreamFeign {

    /**
     *
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET, value = "/service/netty/address")
    CommonResponse<ServerHost> getNettyHost() throws Exception;

}
