package com.opnext.oservice.repository.authority;

import com.opnext.oservice.domain.authority.role.RoleDeviceGroup;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @author wanglu
 */

public interface RoleDeviceGroupRepository extends PagingAndSortingRepository<RoleDeviceGroup, Long>,
        QueryDslPredicateExecutor<RoleDeviceGroup> {
    /**
     * 通过roleId获取角色设备组关联
     * @param roleId
     * @return
     */
    List<RoleDeviceGroup> findAllByRoleId(long roleId);

    /**
     * 通过roleId删除所有设备组
     * @param roleId
     */
    void deleteAllByRoleId(long roleId);
}
