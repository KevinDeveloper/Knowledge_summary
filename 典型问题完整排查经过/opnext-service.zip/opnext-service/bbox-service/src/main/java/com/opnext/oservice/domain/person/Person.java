package com.opnext.oservice.domain.person;

import com.opnext.domain.PersonInfo;
import com.opnext.domain.PersonType;
import com.opnext.domain.ResourceType;
import com.opnext.domain.Sex;
import com.opnext.oservice.domain.converter.PersonAvatarsConverter;
import com.opnext.oservice.domain.converter.PersonVariableConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.beans.BeanUtils;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:05 18/5/7
 */
@Entity
@Data
@Table(name = "person")
@ApiModel(description="人员实体")
@EntityListeners(AuditingEntityListener.class)
public class Person {
    /**
     * 人员id
     */
    @Id
    @ApiModelProperty(value="id")
    private String id;
    /**
     * 人员名称
     */
    @ApiModelProperty(value="姓名")
    @Column(name = "name")
    private String name;
    /**
     * 人员编号
     */
    @ApiModelProperty(value="编号")
    @Column(name = "no")
    private String no;
    /**
     * 密码
     */
    @ApiModelProperty(value="密码")
    @Column(name = "password")
    private String password;
    /**
     * 人员性别
     */
    @Column(name = "sex")
    @ApiModelProperty(value="性别")
    private Sex sex;
    /**
     * 身份证号
     */
    @ApiModelProperty(value="身份证号")
    @Column(name = "id_card")
    private String idCard;
    /**
     * 手机号
     */
    @ApiModelProperty(value="手机号")
    @Column(name = "phone")
    private String phone;
    /**
     * 职务
     */
    @ApiModelProperty(value="职务")
    @Column(name = "position")
    private String position;
    /**
     * 邮箱
     */
    @Column(name = "mail")
    @ApiModelProperty(value="邮箱")
    private String mail;
    /**
     * IC卡号
     */
    @ApiModelProperty(value="ic卡号")
    @Column(name = "ic_number")
    private String icNumber;
    /**
     * 韦根号
     */
    @ApiModelProperty(value="韦根号")
    @Column(name = "wg_number")
    private String wgNumber;
    /**
     * 组织id
     */
    @ApiModelProperty(value="组织id")
    @Column(name = "organization_id")
    private Integer organizationId;
    /**
     * 规则id
     */
    @ApiModelProperty(value="规则id")
    @Column(name = "rule_id")
    private Integer ruleId;
    /**
     * 同步状态
     */
    @ApiModelProperty(value="同步状态")
    @Column(name = "sync_status")
    private SyncStatus syncStatus;
    /**
     * 同步版本号
     */
    @ApiModelProperty(value="同步版本号")
    @Column(name = "sync_version")
    private Long syncVersion;
    /**
     * 入职时间
     */
    @ApiModelProperty(value="入职时间")
    @Column(name = "hiredate")
    private Date hiredate;
    /**
     * 特征库id
     */
    @ApiModelProperty(value="特征库")
    @Column(name = "group_id")
    private String groupId;
    /**
     * 备注
     */
    @ApiModelProperty(value=" 备注")
    private String remark;
    @ApiModelProperty(value=" 创建时间")
    @Column(name="create_time")
    @CreatedDate
    private Date createTime;
    @ApiModelProperty(value="更新时间")
    @Column(name="update_time")
    @LastModifiedDate
    private Date updateTime;
    @ApiModelProperty(value="租户id")
    @Column(name = "tenant_id")
    private Long tenantId;
    /**
     * 操作者id
     */
    @ApiModelProperty(value="操作者id")
    @Column(name = "operator_id")
    private Long operatorId;
    /**
     * 操作账号
     */
    @ApiModelProperty(value="操作者")
    @Column(name = "operator_name")
    private String operatorName;
    @ApiModelProperty(value="应用id")
    @Column(name = "app_id")
    private String appId;
    @ApiModelProperty(value="开放id")
    @Column(name="open_id")
    private String openId;
    /**
     * 扩展字段map
     */
    @ApiModelProperty(value="扩展字段")
    @Column(name = "variable")
    @Convert(converter = PersonVariableConverter.class)
    private Map<String, String> variable;
    /**
     * 照片Map包含可见光，近红外
     */
    @Column(name = "avatars")
    @ApiModelProperty(value="照片")
    @Convert(converter = PersonAvatarsConverter.class)
    private Map<ResourceType, List<String>> avatars;
    /**
     * 人员类型
     */
    @ApiModelProperty(value="人员类型")
    @Column(name = "type")
    private PersonType type;

    public PersonInfo toPersonInfo(){
        PersonInfo personInfo = new PersonInfo();
        BeanUtils.copyProperties(this, personInfo);
        personInfo.setCreateTime(this.createTime.getTime());
        personInfo.setUpdateTime(this.updateTime.getTime());
        personInfo.setVersion(personInfo.getUpdateTime());
        return personInfo;
    }

}
