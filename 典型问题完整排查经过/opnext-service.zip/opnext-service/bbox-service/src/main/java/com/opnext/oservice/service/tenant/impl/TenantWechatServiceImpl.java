package com.opnext.oservice.service.tenant.impl;

import com.opnext.oservice.domain.tenant.TenantWechat;
import com.opnext.oservice.repository.tenant.TenantWechatRepository;
import com.opnext.oservice.service.tenant.TenantWechatService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @Author: lixiuwen
 * @Date: 2018/7/30 18:09
 */
@Slf4j
@Service
public class TenantWechatServiceImpl implements TenantWechatService {


    @Autowired
    private TenantWechatRepository tenantWechatRepository;

    /**
     * 根据AppId删除不是当前租户ID的数据
     * @param appId appId
     * @param tenantId 租户ID
     */
    @Override
    public void deleteByAppIdAndTenantIdIsNot(String appId, Long tenantId) {
        tenantWechatRepository.deleteByAppIdAndTenantIdIsNot(appId, tenantId);
    }

    /**
     * 根据APPID删除记录
     *
     * @param appId APPID
     */
    @Override
    public void deleteByAppId(String appId) {
        tenantWechatRepository.deleteByAppId(appId);
    }

    /**
     * 保存记录
     *
     * @param tenantWechat 数据
     */
    @Override
    public void save(TenantWechat tenantWechat) {
        tenantWechatRepository.save(tenantWechat);
    }

    /**
     * 根据租户ID查询记录
     *
     * @param tenantId 租户ID
     * @return查询结果
     */
    @Override
    public TenantWechat findByTenantId(Long tenantId) {
        return tenantWechatRepository.findOne(tenantId);
    }
}
