package com.opnext.oservice.service.device.impl;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.google.common.collect.Sets;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.validator.IsEmptyValidator;
import com.opnext.bboxsupport.validator.IsIntegerValidator;
import com.opnext.bboxsupport.validator.IsObjectEmptyValidator;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.domain.TerminalAdmin;
import com.opnext.domain.message.Command;
import com.opnext.omessage.support.CallBackBuilder;
import com.opnext.omessage.support.MessageContext;
import com.opnext.omessage.support.SimpleMessageTemplate;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.command.BusinessType;
import com.opnext.oservice.domain.device.DeviceAdmin;
import com.opnext.oservice.domain.device.DeviceAdminRel;
import com.opnext.oservice.domain.device.DeviceAdminVo;
import com.opnext.oservice.domain.device.QDevice;
import com.opnext.oservice.domain.device.QDeviceAdmin;
import com.opnext.oservice.domain.device.QDeviceAdminRel;
import com.opnext.oservice.domain.device.QDeviceAdminVo;
import com.opnext.oservice.domain.device.SearchDevice;
import com.opnext.oservice.dto.CommonFailedStatus;
import com.opnext.oservice.feign.OMessageFeign;
import com.opnext.oservice.repository.ComplicateQueryDao;
import com.opnext.oservice.repository.ComplicateQueryDslDao;
import com.opnext.oservice.repository.device.DeviceAdminRelRepository;
import com.opnext.oservice.repository.device.DeviceAdminRepository;
import com.opnext.oservice.service.device.DeviceAdminService;
import com.opnext.oservice.service.device.DeviceService;
import com.opnext.oservice.service.fastdfs.FastTmpFileManagerService;
import com.opnext.oservice.util.MD5Utils;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import opnext.server.support.util.UrlUtil;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午4:50 18/5/7
 */
@Slf4j
@Service
public class DeviceAdminServiceImpl implements DeviceAdminService {

    @Value("${server.context-path}")
    private String serverPath;
    @Resource
    private OMessageFeign oMessageFeign;
    @Autowired
    private DeviceAdminRepository adminRepository;
    @Autowired
    private DeviceAdminRelRepository adminRelRepository;
    @Autowired
    private ComplicateQueryDao complicateQueryDao;
    @Autowired
    private ComplicateQueryDslDao complicateQueryDslDao;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    private EntityManager entityManager;
    @Autowired
    private DeviceService deviceService;
    @Resource
    private FastTmpFileManagerService fastTmpFileManagerService;


    /**
     * 分页获取设备管理员列表
     *
     * @param pageable
     * @param name
     * @param phone
     * @return
     * @throws Exception
     */
    @Override
    public Page getPage(Pageable pageable, String name, String phone,RequestUrlPrefix urlPrefix) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QDeviceAdmin.deviceAdmin.tenantId.eq(tenantId);
        if (StringUtils.isNotBlank(name)){
            predicate = ((BooleanExpression) predicate).and(QDeviceAdmin.deviceAdmin.name.contains(name));
        }
        if (StringUtils.isNotBlank(phone)) {
            predicate = ((BooleanExpression) predicate).and(QDeviceAdmin.deviceAdmin.phone.eq(phone));
        }
        QDeviceAdmin qDeviceAdmin = QDeviceAdmin.deviceAdmin;
        QDeviceAdminRel qDeviceAdminRel = QDeviceAdminRel.deviceAdminRel;

        Page page = complicateQueryDao.find(
                jpaQueryFactory.select(QDeviceAdmin.deviceAdmin,QDeviceAdmin.deviceAdmin.id)
                        .from(QDeviceAdmin.deviceAdmin)
                        .where(predicate)
                        .orderBy(QDeviceAdmin.deviceAdmin.updateTime.desc())
                ,pageable,DeviceAdminVo.class);
        if (page.getTotalPages() > 0) {
            List<DeviceAdminVo> adminVoList = page.getContent();
            List<Integer> adminIdList = new ArrayList<>();
            for (DeviceAdminVo adminVo : adminVoList) {
                deviceAdminShowPath(adminVo.getAvatars(),urlPrefix);
                adminIdList.add(adminVo.getId());
            }

            // 设置返回字段
            LinkedList<Path> linkedList = new LinkedList<>();
            linkedList.add(QDeviceAdmin.deviceAdmin.id);
            linkedList.add(QDeviceAdminVo.deviceAdminVo.deviceCount);
            predicate = QDeviceAdminRel.deviceAdminRel.deviceAdminId.in(adminIdList);
//                    .and(QDevice.device.id.isNotNull());
            if (CollectionUtils.isEmpty(oserviceOperator.getDeviceGroups())) {
                if (OserviceOperator.UserType.COMMON.equals(oserviceOperator.getUserType())) {
                    return page;
                }
            } else {
                predicate = ((BooleanExpression) predicate).and(QDevice.device.groupId.in(oserviceOperator.getDeviceGroups()));
            }
            pageable = new PageRequest(0, pageable.getPageSize());
            Page devicePage = complicateQueryDslDao.find(
                    jpaQueryFactory.select(QDeviceAdminRel.deviceAdminRel.deviceAdminId,
                            QDeviceAdminRel.deviceAdminRel.deviceAdminId.count().as(QDeviceAdminVo.deviceAdminVo.deviceCount))
                            .from(QDeviceAdminRel.deviceAdminRel)
                            .leftJoin(QDevice.device)
                            .on(QDevice.device.id.eq(QDeviceAdminRel.deviceAdminRel.deviceId))
                            .where(predicate)
                            .groupBy(QDeviceAdminRel.deviceAdminRel.deviceAdminId)
                    ,pageable,DeviceAdminVo.class, linkedList);
            if (devicePage.getTotalPages() > 0) {
                handleData(adminVoList, devicePage.getContent());
            }
        }
        return page;
    }

    public List<String> deviceAdminShowPath(List<String> avatars, RequestUrlPrefix urlPrefix) {
        if (!CollectionUtils.isEmpty(avatars)) {
            avatars.replaceAll(urlPath -> {
                Optional<String> optional = UrlUtil.getShowPath(GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()), urlPath);
                if (optional.isPresent()) {
                    urlPath = optional.get();
                }
                return urlPath;
            });
        }
        return avatars;
    }
    /**
     * 根据id获取设备管理员
     *
     * @param id
     * @return
     * @throws Exception
     */
    @Override
    public DeviceAdmin getInfo(Integer id,RequestUrlPrefix urlPrefix) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QDeviceAdmin.deviceAdmin.id.eq(id);
        predicate = ((BooleanExpression) predicate).and(QDeviceAdmin.deviceAdmin.tenantId.eq(tenantId));
        DeviceAdmin deviceAdmin = adminRepository.findOne(predicate);
        if (Objects.nonNull(deviceAdmin)) {
            entityManager.unwrap(Session.class).evict(deviceAdmin);
            deviceAdminShowPath(deviceAdmin.getAvatars(),urlPrefix);
        }
        return deviceAdmin;
    }

    /**
     * @param deviceAdmin
     * @return
     */
    @Override
    public ComplexResult fluentValidator(DeviceAdmin deviceAdmin) throws Exception {
        ComplexResult ret = new ComplexResult();
        FluentValidator fluentValidator = FluentValidator.checkAll().failOver();
        fluentValidator.on(deviceAdmin.getName(), new IsEmptyValidator("name"))
                .on(deviceAdmin.getName(), new IsStringWithinLengthRangeValidator("name", 1, 64,true))
                .on(deviceAdmin.getPassword(), new IsEmptyValidator("password"))
                .on(deviceAdmin.getPassword(), new IsIntegerValidator("password"))
                .on(deviceAdmin.getPassword(), new IsStringWithinLengthRangeValidator("password",4,4))
                .on(deviceAdmin.getAvatars(), new IsObjectEmptyValidator<>("avatars"))
                .on(deviceAdmin.getPhone(), new IsStringWithinLengthRangeValidator("phone", 4, 64, true));
        if (!CollectionUtils.isEmpty(deviceAdmin.getAvatars())) {
            List<String> list = deviceAdmin.getAvatars();
            for (String s : list) {
                try {
                    URL url = new URL(s);
                } catch (Exception e) {
                    throw new CommonException("person.imageUrl.incorrect");
                }
            }
        }
        ret = fluentValidator.doValidate().result(toComplex());
        return ret;
    }

    /**
     * 保存设备管理员，并关联设备
     *
     * @param deviceAdmin
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public DeviceAdmin save(DeviceAdmin deviceAdmin,RequestUrlPrefix urlPrefix) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long operatorId = oserviceOperator.getUserId();
        deviceAdmin.setTenantId(tenantId);
        deviceAdmin.setOperatorId(operatorId);
        deviceAdmin.setOperatorName(oserviceOperator.getLoginName());
        deviceAdminStorePath(deviceAdmin.getAvatars(),urlPrefix);
        // 移除文件信息临时表数据
        deleteFid(deviceAdmin);
        DeviceAdmin resultAdmin = adminRepository.save(deviceAdmin);
        if (null != deviceAdmin.getDeviceIds() && deviceAdmin.getDeviceIds().length > 0) {
            List<DeviceAdminRel> adminRelList = new ArrayList<>();
            for (Integer deviceId : deviceAdmin.getDeviceIds()) {
                DeviceAdminRel deviceAdminRel = new DeviceAdminRel();
                deviceAdminRel.setDeviceId(deviceId);
                deviceAdminRel.setDeviceAdminId(resultAdmin.getId());
                deviceAdminRel.setTenantId(tenantId);
                adminRelList.add(deviceAdminRel);
            }
            // 设备与管理员关联信息入库
            adminRelRepository.save(adminRelList);
        }
        return resultAdmin;
    }

    public List<String> deviceAdminStorePath(List<String> avatars, RequestUrlPrefix urlPrefix) {
        if (!CollectionUtils.isEmpty(avatars)) {
            avatars.replaceAll(urlPath -> {
                Optional<String> optional = UrlUtil.getStorePath(GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()), urlPath, GlobleConfig.ServerConfig.urlStoreRelative);
                if (optional.isPresent()) {
                    urlPath = optional.get();
                }
                return urlPath;
            });
        }
        return avatars;
    }

    public void addFid(DeviceAdmin deviceAdmin, OserviceOperator oserviceOperator) throws Exception {
        List<String> fidList = deviceAdmin.getAvatars();
        if (!CollectionUtils.isEmpty(fidList)) {
            for (String s : fidList) {
                if (StringUtils.isNotBlank(s)) {
                    String fid = s.substring(s.lastIndexOf("/") + 1);
                    fastTmpFileManagerService.insertTempFile(fid, oserviceOperator);
                }
            }
        }
    }

    public void deleteFid(DeviceAdmin deviceAdmin) throws Exception {
        List<String> fidList = deviceAdmin.getAvatars();
        if (!CollectionUtils.isEmpty(fidList)) {
            for (String s : fidList) {
                if (StringUtils.isNotBlank(s)) {
                    String fid = s.substring(s.lastIndexOf("/") + 1);
                    fastTmpFileManagerService.updateTempFile(fid);
                }
            }
        }
    }

    /**
     * 更新设备管理员
     *
     * @param deviceAdmin
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void update(DeviceAdmin deviceAdmin,RequestUrlPrefix urlPrefix) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long operatorId = oserviceOperator.getUserId();
        QDeviceAdmin qDeviceAdmin = QDeviceAdmin.deviceAdmin;
        // 查询设备管理员
        Predicate predicate = qDeviceAdmin.id.eq(deviceAdmin.getId());
        predicate = ((BooleanExpression) predicate).and(qDeviceAdmin.tenantId.eq(tenantId));
        DeviceAdmin findAdmin = adminRepository.findOne(predicate);
        // 校验更新数据是否存在
        if (Objects.nonNull(findAdmin)) {

            boolean updateFlag = false;
            if (!deviceAdmin.getName().equals(findAdmin.getName())) {
                updateFlag = true;
            }
            if (!deviceAdmin.getPassword().equals(findAdmin.getPassword())) {
                updateFlag = true;
            }
            if (!(deviceAdmin.getAvatars().containsAll(findAdmin.getAvatars()) && findAdmin.getAvatars().containsAll(deviceAdmin.getAvatars()))) {
                updateFlag = true;
                deviceAdminStorePath(deviceAdmin.getAvatars(),urlPrefix);
            }
            boolean phoneFlag = (StringUtils.isNotBlank(deviceAdmin.getPhone()) && StringUtils.isNotBlank(findAdmin.getPhone()) && deviceAdmin.getPhone().equals(findAdmin.getPhone())) || (StringUtils.isBlank(deviceAdmin.getPhone()) && StringUtils.isBlank(findAdmin.getPhone()));
            if (!phoneFlag) {
                updateFlag = true;
            }
            if (updateFlag) {
                DeviceAdmin findAdminDTO = new DeviceAdmin();
                findAdminDTO.setAvatars(findAdmin.getAvatars());
                // 将更新数据fid插入到临时表
                addFid(findAdminDTO, oserviceOperator);
                // 移除文件信息临时表数据
                deleteFid(deviceAdmin);
                deviceAdmin.setCreateTime(findAdmin.getCreateTime());
                deviceAdmin.setUpdateTime(new Date());
                deviceAdmin.setOperatorId(operatorId);
                deviceAdmin.setOperatorName(oserviceOperator.getLoginName());
                deviceAdmin.setTenantId(findAdmin.getTenantId());
                adminRepository.save(deviceAdmin);
                /** 下发指令，通知设备更新设备管理员*/
                Predicate predicateDevice = QDeviceAdminRel.deviceAdminRel.deviceAdminId.eq(deviceAdmin.getId());
                predicateDevice = ((BooleanExpression) predicateDevice).and(QDeviceAdminRel.deviceAdminRel.tenantId.eq(tenantId));
                // 获取管理员关联设备sn
                List<String> snList = jpaQueryFactory.select(QDevice.device.sn)
                        .from(QDevice.device)
                        .leftJoin(QDeviceAdminRel.deviceAdminRel)
                        .on(QDevice.device.id.eq(QDeviceAdminRel.deviceAdminRel.deviceId))
                        .where(predicateDevice).fetch();
                // 调用下发管理员方法
                sendAdmin(oserviceOperator, snList);
            }

        } else {
            log.info("参数id：{}，无可更新有效数据", deviceAdmin.getId());
        }
    }

    /**
     * 下发管理员
     * @param oserviceOperator
     * @param snList
     */
    @Override
    public void sendAdminData(OserviceOperator oserviceOperator, List<String> snList) throws Exception{
        log.info("同步管理员参数snList：{}", snList);
        if (!CollectionUtils.isEmpty(snList)) {
            try {
                for (String sn : snList) {
                    // 校验sn是否为空
                    if (StringUtils.isNotBlank(sn)) {
                        Predicate predicate = QDevice.device.sn.eq(sn);
                        predicate = ((BooleanExpression) predicate).and(QDevice.device.tenantId.eq(oserviceOperator.getTenantId()));
                        // 获取管理员列表
                        List<DeviceAdmin> deviceAdminList = jpaQueryFactory.select(QDeviceAdmin.deviceAdmin)
                                .from(QDevice.device)
                                .leftJoin(QDeviceAdminRel.deviceAdminRel)
                                .on(QDevice.device.id.eq(QDeviceAdminRel.deviceAdminRel.deviceId))
                                .leftJoin(QDeviceAdmin.deviceAdmin)
                                .on(QDeviceAdminRel.deviceAdminRel.deviceAdminId.eq(QDeviceAdmin.deviceAdmin.id))
                                .where(predicate).fetch();
                        List<TerminalAdmin> adminList = new ArrayList<>();
                        TerminalAdmin terminalAdmin;
                        // 管理员列表转换
                        if (!CollectionUtils.isEmpty(deviceAdminList)) {
                            for (DeviceAdmin deviceAdmin : deviceAdminList) {
                                if (Objects.nonNull(deviceAdmin)) {
                                    terminalAdmin = new TerminalAdmin();
                                    BeanUtils.copyProperties(deviceAdmin, terminalAdmin);
                                    // 终端密码加密
                                    terminalAdmin.setPassword(MD5Utils.encrypt(terminalAdmin.getPassword()));
                                    adminList.add(terminalAdmin);
                                }
                            }
                        }

                        // 调用o-message下发指令
                        MessageContext context = SimpleMessageTemplate
                                .operator(String.valueOf(oserviceOperator.getTenantId()), oserviceOperator.getLoginName())
                                .scope(Sets.newHashSet(sn)).syncAdmin(adminList);
                        oMessageFeign.send(context);
                        log.info("设备sn：{}，下发管理员完成，管理员adminList：{}", sn, adminList);
                    }
                }
            } catch (Exception e) {
                log.info("调用下发管理员失败！原因：{}", e);
                throw new CommonException("device.admin.sync.exception");
            }
        } else {
            log.debug("设备关联管理员下发参数snList为空，不需要下发");
        }

    }

    /**
     * 下发管理员
     * @param oserviceOperator
     * @param snList
     */
    @Override
    public void sendAdmin(OserviceOperator oserviceOperator, List<String> snList) throws Exception{
        log.info("同步管理员参数snList：{}", snList);
        if (!CollectionUtils.isEmpty(snList)) {
            try {
                String terminalGatewayHost = "";
                String relativeUrl = "%s%s/api/devapi/callback/admin/{workflowId}/{commandId}/{requestId}";
                String strUrl = String.format(relativeUrl, terminalGatewayHost, serverPath);
                // 调用o-message下发指令
                MessageContext context = SimpleMessageTemplate
                        .operator(String.valueOf(oserviceOperator.getTenantId()), oserviceOperator.getLoginName())
                        .appId(oserviceOperator.getAppId())
                        .scope(Sets.newHashSet(snList)).syncAdmin(strUrl);
                String feedback = String.format("%s%s/api/devapi/feedback/{workflowId}/{commandId}/{requestId}/%s"
                        , terminalGatewayHost
                        , serverPath
                        , BusinessType.ADMIN);
                context.setFeedBack(CallBackBuilder.ready().url(feedback).method(Command.Method.POST).build());
                oMessageFeign.send(context);
                log.info("设备sn：{}，下发管理员完成，管理员adminList：{}", snList);

            } catch (Exception e) {
                log.info("调用下发管理员失败！原因：{}", e);
                throw new CommonException("device.admin.sync.exception");
            }
        } else {
            log.debug("设备关联管理员下发参数snList为空，不需要下发");
        }

    }

    /**
     * 更新设备管理员名称
     *
     * @param id
     * @param name
     * @throws Exception
     */
    @Override
    public void updateName(Integer id, String name) throws Exception {

    }

    /**
     * 删除设备管理员，移除设备关联设备管理员
     * 下发指令更新设备管理员
     *
     * @param ids
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delete(Integer[] ids) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        // 根据设备管理员id获取关联的设备
        Predicate predicate = QDeviceAdminRel.deviceAdminRel.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QDeviceAdminRel.deviceAdminRel.deviceAdminId.in(ids));
        predicate = ((BooleanExpression) predicate).and(QDevice.device.sn.isNotNull());
        List<String> snList = jpaQueryFactory
                .select(QDevice.device.sn)
                .from(QDevice.device)
                .rightJoin(QDeviceAdminRel.deviceAdminRel)
                .on(QDevice.device.id.eq(QDeviceAdminRel.deviceAdminRel.deviceId))
                .where(predicate).fetch();
        // 删除设备与管理员关联表
        try {
            predicate = QDeviceAdminRel.deviceAdminRel.tenantId.eq(tenantId);
            predicate = ((BooleanExpression) predicate).and(QDeviceAdminRel.deviceAdminRel.deviceAdminId.in(ids));
            jpaQueryFactory.delete(QDeviceAdminRel.deviceAdminRel)
                    .where(predicate).execute();
        } catch (Exception e) {
            log.error("设备管理员关联删除失败：{}", e);
            throw new CommonException(HttpStatus.BAD_REQUEST.value(), CommonFailedStatus.DATABASE_EXCEPTION.getMessage(), null,CommonFailedStatus.DATABASE_EXCEPTION.getValue());
        }
        // 删除设备管理员
        try {
            predicate = QDeviceAdmin.deviceAdmin.tenantId.eq(tenantId);
            predicate = ((BooleanExpression) predicate).and(QDeviceAdmin.deviceAdmin.id.in(ids));
            jpaQueryFactory.delete(QDeviceAdmin.deviceAdmin)
                    .where(predicate)
                    .execute();
        } catch (Exception e) {
            log.error("设备管理员删除失败：{}", e);
            throw new CommonException("mysql.database.exception");
        }
        /** 下发指令，通知设备更新设备管理员*/
        // 调用下发管理员方法
        sendAdmin(oserviceOperator, snList);
    }

    /**
     * @param pageable
     * @param sDevice
     * @param id       管理员id
     * @return
     * @throws Exception
     */
    @Override
    public Page getDevicePage(Pageable pageable, SearchDevice sDevice, Integer id) throws Exception {

        return null;
    }

    /**
     * 设备关联管理员
     * @param deviceIds
     * @param id
     * @throws Exception
     */
    @Override
    public void bindDevice(Integer[] deviceIds, Integer id) throws Exception {
        Integer[] adminIds = {id};
        deviceService.bindDeviceAdmin(deviceIds, adminIds);


    }

    /**
     * 移除设备管理员
     *
     * @param deviceIds
     * @throws Exception
     */
    @Transactional(rollbackFor = {Exception.class})
    @Override
    public void deleteDeviceAdmin(Integer[] deviceIds, Integer[] adminIds) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        /**
         * 下发指令，通知终端更新设备管理员
         */
        Predicate predicateDevice = QDeviceAdminRel.deviceAdminRel.deviceId.in(deviceIds);
        predicateDevice = ((BooleanExpression) predicateDevice).and(QDeviceAdminRel.deviceAdminRel.tenantId.eq(oserviceOperator.getTenantId()));
        List<String> snList = jpaQueryFactory.select(QDevice.device.sn)
                .from(QDevice.device)
                .leftJoin(QDeviceAdminRel.deviceAdminRel)
                .on(QDevice.device.id.eq(QDeviceAdminRel.deviceAdminRel.deviceId))
                .where(predicateDevice).groupBy(QDevice.device.sn).fetch();

        // 删除设备管理员关联关系
        Predicate predicate = QDeviceAdminRel.deviceAdminRel.tenantId.eq(oserviceOperator.getTenantId());
        predicate = ((BooleanExpression) predicate).and(QDeviceAdminRel.deviceAdminRel.deviceId.in(deviceIds));
        if (Objects.nonNull(adminIds)) {
            predicate = ((BooleanExpression) predicate).and(QDeviceAdminRel.deviceAdminRel.deviceAdminId.in(adminIds));
        }
        long count = jpaQueryFactory.delete(QDeviceAdminRel.deviceAdminRel)
                .where(predicate)
                .execute();
        // 调用下发管理员方法
        sendAdmin(oserviceOperator, snList);
    }

    /**
     * 处理设备组列表返回数据
     * @param adminVoList
     * @param deviceCountList
     * @return
     * @throws Exception
     */
    public List handleData(List<DeviceAdminVo> adminVoList, List<DeviceAdminVo> deviceCountList) throws Exception{
        for (DeviceAdminVo deviceAdminVo : adminVoList) {
            for (DeviceAdminVo adminVo : deviceCountList) {
                if (deviceAdminVo.getId().equals(adminVo.getId())) {
                    deviceAdminVo.setDeviceCount(adminVo.getDeviceCount());
                }
            }
        }
        return adminVoList;
    }
}
