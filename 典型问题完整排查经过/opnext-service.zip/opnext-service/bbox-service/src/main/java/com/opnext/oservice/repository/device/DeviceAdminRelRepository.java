package com.opnext.oservice.repository.device;

import com.opnext.oservice.domain.device.DeviceAdminRel;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @author tianzc
 *
 * @Title:
 * @Description:
 * @Date 下午5:11 18/5/15
 */
public interface DeviceAdminRelRepository extends PagingAndSortingRepository<DeviceAdminRel, Integer>, QueryDslPredicateExecutor<DeviceAdminRel> {

}
