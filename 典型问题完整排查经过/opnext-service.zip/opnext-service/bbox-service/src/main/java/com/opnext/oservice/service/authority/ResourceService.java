package com.opnext.oservice.service.authority;

import com.opnext.oservice.dto.authority.role.ResourceDTO;
import com.querydsl.core.types.Predicate;

/**
 * @author wanglu
 * @date 2018/07/19
 */
public interface ResourceService {

    /**
     * 根据条件查询API
     * @param predicate
     * @return
     */
    ResourceDTO findApiResource(Predicate predicate);
}
