package com.opnext.oservice.domain.rule;

import com.opnext.oservice.domain.rule.MultiKeys.RuleDeviceMultiKeysClass;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/25 13:10
 */
@Entity
@Table(name = "rule_device")
@Data
@EntityListeners(AuditingEntityListener.class)
@IdClass(RuleDeviceMultiKeysClass.class)
public class RuleDevice implements Serializable {
    private static final long serialVersionUID = 1L;
    /**
     * 规则ID
     */
    @Id
    @Column(name = "rule_id")
    private Integer ruleId;

    /**
     * 设备SN
     */
    @Id
    @Column(name = "device_sn")
    private String deviceSn;

    /**
     * 设备ID
     */
    @Column(name = "device_id")
    private Integer deviceId;

    /**
     * 应用ID
     */
    @Column(name = "app_id")
    private String appId;

    /**
     * 创建时间
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    @CreatedDate
    private Date createTime;

    /**
     * 创建人
     */
    @Column(name = "create_by")
    private String createBy;

    /**
     * 租户ID
     */
    @Column(name = "tenant_id")
    private Long tenantId;
}
