package com.opnext.oservice.repository.appcenter;

import com.opnext.oservice.domain.appcenter.Application;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

public interface ApplicationRepositry extends PagingAndSortingRepository<Application, Integer>,
        QueryDslPredicateExecutor<Application> {
    /**
     * 通过租户获取应用列表
     * @param tenantId
     * @return
     */
    List<Application> getAllByTenantId(long tenantId);

    /**
     * 通过id查询应用
     * @param id
     * @param tenantId
     * @return
     */
    Application getApplicationByIdAndTenantId(int id,long tenantId);

    /**
     * 通过appId获取应用列表
     * @param appId
     * @param tenantId
     * @return
     */
    List<Application> getApplicationsByAppIdAndTenantId(String appId,long tenantId);
}
