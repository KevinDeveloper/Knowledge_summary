package com.opnext.oservice.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "kaptcha")
@Data
public class KaptchaProperties {
    public String border;
    public String borderColor;
    public String fontColor;
    public String imageWidth;
    public String imageHeight;
    public String fontSize;
    public String charLength;
    public String fontNames;
}