package com.opnext.oservice.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author wanglu
 */
@Component
@Data
@ConfigurationProperties(prefix = "remote-rest.browser-client-center")
public class BrowserClientCenter {
    String forgetPasswordUrl;
}
