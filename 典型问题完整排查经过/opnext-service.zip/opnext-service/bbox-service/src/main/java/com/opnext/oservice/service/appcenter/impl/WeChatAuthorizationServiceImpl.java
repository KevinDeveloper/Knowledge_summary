package com.opnext.oservice.service.appcenter.impl;

import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.oservice.controller.appcenter.WeChatBindingConfigController;
import com.opnext.oservice.domain.QServerConfig;
import com.opnext.oservice.domain.ServerConfig;
import com.opnext.oservice.domain.appcenter.QWeChatBindingConfig;
import com.opnext.oservice.domain.appcenter.WeChatBindingConfig;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.repository.ComplicateQueryDao;
import com.opnext.oservice.repository.appcenter.WeChatBindingConfigRepository;
import com.opnext.oservice.repository.device.server.ServerConfigRepository;
import com.opnext.oservice.service.appcenter.WeChatAuthorizationService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.Projections;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author wanglu
 */
@Service
public class WeChatAuthorizationServiceImpl implements WeChatAuthorizationService {
    @Autowired
    ServerConfigRepository serverConfigRepository;
    @Autowired
    WeChatBindingConfigRepository weChatBindingConfigRepository;
    @Autowired
    ComplicateQueryDao complicateQueryDao;
    @Autowired
    JPAQueryFactory jpaQueryFactory;

    @Override
    public List<WeChatBindingConfig> getBindingConfig(long tenantId,String type){
        QServerConfig qServerConfig = QServerConfig.serverConfig;
        QWeChatBindingConfig qWeChatBindingConfig = QWeChatBindingConfig.weChatBindingConfig;
        Predicate predicate = qServerConfig.tenantId.eq(tenantId).and(qServerConfig.type.eq(type));

        List<WeChatBindingConfig> configDTOList = jpaQueryFactory.select(
                        Projections.bean(
                                WeChatBindingConfig.class,
                                qServerConfig.configKey,
                                qServerConfig.configValue,
                                qWeChatBindingConfig.sequence,
                                qWeChatBindingConfig.needFlag,
                                qWeChatBindingConfig.type
                        )
        ).from(qServerConfig).leftJoin(qWeChatBindingConfig).on(qServerConfig.configKey.eq(qWeChatBindingConfig.configKey))
                .where(predicate).fetch();
        if (CollectionUtils.isEmpty(configDTOList)){
            configDTOList = weChatBindingConfigRepository.findAllByType(type);
        }
        return configDTOList;
    }

    @Override
    @Transactional(rollbackFor=Exception.class)
    public void setBindingConfig(long tenantId,List<ServerConfig> serverConfigs)throws Exception {
        Map<String,String> configKeyList = new HashMap<>(serverConfigs.size());
        for (int s=0;s<serverConfigs.size();s++){
            configKeyList.put(serverConfigs.get(s).getConfigKey(),serverConfigs.get(s).getConfigValue());
            serverConfigs.get(s).setTenantId(tenantId);
        }

        //判断是否有修改，如果没有修改则返回；
        List<ServerConfig> srcConf1= serverConfigRepository.findAllByTenantIdAndType(tenantId, WeChatBindingConfigController.WECHAT_BINDING_CONFIG_KEY);
        List<ServerConfig> srcConf2 = serverConfigRepository.findAllByTenantIdAndType(tenantId, WeChatBindingConfigController.WECHAT_BINDING_PERIOD);
        srcConf1.addAll(srcConf2);

        if (srcConf1.size() == configKeyList.size()){
            boolean changFlag = false;
            for (int s =0;s<srcConf1.size();s++){
                String key = srcConf1.get(s).getConfigKey();
                if (!configKeyList.containsKey(key) || !srcConf1.get(s).getConfigValue().equals(configKeyList.get(key))){
                    changFlag=true;
                    break;
                }
            }
            if (!changFlag){
                return;
            }
        }

        //查询必填项，中need_flag=1的
        List<WeChatBindingConfig> weConfigs1 = weChatBindingConfigRepository.findAllByTypeAndNeedFlag(WeChatBindingConfigController.WECHAT_BINDING_CONFIG_KEY,WeChatBindingConfig.NeedFlag.REQUIRED);
        List<WeChatBindingConfig> weConfigs2 = weChatBindingConfigRepository.findAllByTypeAndNeedFlag(WeChatBindingConfigController.WECHAT_BINDING_PERIOD,WeChatBindingConfig.NeedFlag.REQUIRED);

        for (int i=0;i<weConfigs1.size();i++){
           String key = weConfigs1.get(i).getConfigKey();
           if (!configKeyList.containsKey(key) || "0".equals(configKeyList.get(key))){
               throw new CommonException(Messages.get("weChat.binding.item.cannot.null",new String[]{key}));
           }
        }
        for (int j=0;j<weConfigs2.size();j++){
            String key = weConfigs2.get(j).getConfigKey();
            if (!configKeyList.containsKey(key) || "0".equals(configKeyList.get(key))){
                throw new CommonException(Messages.get("weChat.binding.item.cannot.null",new String[]{key}));
            }
        }

        serverConfigRepository.deleteAllByTenantIdAndType(tenantId, WeChatBindingConfigController.WECHAT_BINDING_CONFIG_KEY);
        serverConfigRepository.deleteAllByTenantIdAndType(tenantId, WeChatBindingConfigController.WECHAT_BINDING_PERIOD);
        serverConfigRepository.save(serverConfigs);
        //清除该租户下所有人员的openId；
        jpaQueryFactory.update(QPerson.person)
                .set(QPerson.person.openId,"")
                .where(
                        QPerson.person.tenantId.eq(tenantId)
                                .and(QPerson.person.openId.isNotNull())
                                .and(QPerson.person.openId.isNotEmpty())
                ).execute();
    }

    @Override
    public List<WeChatBindingConfig> getBindingItems(long tenantId,String type){
        QServerConfig qServerConfig = QServerConfig.serverConfig;
        QWeChatBindingConfig qWeChatBindingConfig = QWeChatBindingConfig.weChatBindingConfig;
        Predicate predicate =
                qServerConfig.tenantId.eq(tenantId)
                .and(qServerConfig.type.eq(type))
                .and(qServerConfig.configValue.notEqualsIgnoreCase("0"));

        List<WeChatBindingConfig> configDTOList = jpaQueryFactory.select(
                Projections.bean(
                        WeChatBindingConfig.class,
                        qServerConfig.configKey,
                        qServerConfig.configValue,
                        qWeChatBindingConfig.sequence,
                        qWeChatBindingConfig.needFlag,
                        qWeChatBindingConfig.type
                )
        ).from(qServerConfig).leftJoin(qWeChatBindingConfig).on(qServerConfig.configKey.eq(qWeChatBindingConfig.configKey))
                .where(predicate).fetch();
        if (CollectionUtils.isEmpty(configDTOList)){
            configDTOList = weChatBindingConfigRepository.findAllByTypeAndConfigValueNot(type,"0");
        }
        return configDTOList;
    }
}
