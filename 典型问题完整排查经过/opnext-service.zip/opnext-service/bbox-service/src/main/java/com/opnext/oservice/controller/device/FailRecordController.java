package com.opnext.oservice.controller.device;

import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.domain.device.SFailRecord;
import com.opnext.oservice.service.device.FailRecordService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author tianzc
 */
@Slf4j
@RestController
@RequestMapping("/api/device/command/fail")
public class FailRecordController {

    @Resource
    private FailRecordService failRecordService;

    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=version,updateTime,asc&sort=name,desc")
    })
    @ApiOperation(value = "设备处理数据失败记录列表")
    @RequestMapping(value = "/record", method = RequestMethod.GET)
    public CommonResponse page(@PageableDefault Pageable pageable, SFailRecord sFailRecord) throws Exception{
        log.info("------获取设备处理数据失败记录分页参数：{}", pageable);
        Page page = failRecordService.getPage(pageable, sFailRecord);
        return CommonResponse.ok(page);
    }

    @ApiOperation(value = "设备处理数据失败记录列表")
    @RequestMapping(value = "/{commandId}/{deviceSn}", method = RequestMethod.GET)
    public CommonResponse getPage(@PageableDefault Pageable pageable, @PathVariable String commandId,@PathVariable String deviceSn) throws Exception{
        log.info("------获取设备处理数据失败记录分页参数：{}", pageable);
        SFailRecord sFailRecord = new SFailRecord();
        sFailRecord.setCommandId(commandId);
        sFailRecord.setDeviceSn(deviceSn);
        Page page = failRecordService.getPage(pageable, sFailRecord);
        return CommonResponse.ok(page);
    }
}
