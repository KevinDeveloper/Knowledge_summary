package com.opnext.oservice.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午4:38 18/5/14
 */

@RestController
public class HealthController {

    /**
     * 服务发现健康检查接口
     * @return
     *
     */
    @ApiIgnore()
    @RequestMapping(value = "/health",method = RequestMethod.GET)
    public String health(){
        return "health";
    }

}
