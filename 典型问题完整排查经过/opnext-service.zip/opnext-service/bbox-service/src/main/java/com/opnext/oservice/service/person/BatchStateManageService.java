package com.opnext.oservice.service.person;


import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.batch.BatchStateBean;
import com.opnext.bboxdomain.batch.BatchStateType;
import com.opnext.bboxdomain.batch.ExportResult;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.redis.RedisCacheUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @ClassName: BatchStateManageService
 * @Description: 人员批量导入状态管理类
 * @Author: Kevin
 * @Date: 2018/7/4 13:29
 */
@Slf4j
@Service
public class BatchStateManageService {

    @Autowired
    private RedisCacheUtil redisCacheUtil;

    /**
     * -1表示当前无租户批量导入
     */
    public static Long BATCH_PERSON_USER_EMPTY = -1L;

    /**
     * 批量导入状态值的key前缀
     */
    public static final String BATCH_PERSON_KEY_STATE = "batch_person_key_state";
    public static final String BATCH_PERSON_KEY_TOTAL = "batch_person_key_total";
    public static final String BATCH_PERSON_KEY_INDEX = "batch_person_key_index";
    public static final String BATCH_PERSON_KEY_USERID = "batch_person_key_userId";

    /**
     * 批量导出状态
     */
    public static final String EXPORT_PERSON_KEY_TENANTID_USERID = "export_person_key_tenantId_userId";


    /**
     * 进行中时间，超过这个时间认为任务失败（分钟）
     */
    public static int ASYNC_TASK_UNDERWAR_CACHE_TIME = 5;

    /**
     * 进行中的状态值key - 入库
     */
    public static final String BATCH_PERSON_KEY_UNDERWAY = "batch_person_key_underway";

    /**
     * 进行中的状态值key - 导出
     */
    public static final String EXPORT_PERSON_KEY_UNDERWAY = "export_person_key_underway";


       /**
     * 租户内key值唯一
     *
     * @param tenantId
     * @return
     */
    public static String getBatchPersonKey(long tenantId, String key) {
        return key + "_" + tenantId;
    }



    /**
     * 设置状态值
     *
     * @param tenantId
     * @param batchStateVal
     */
    public void setBatchState(long tenantId, BatchStateType batchStateVal) {
        String key = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_STATE);
        redisCacheUtil.setCacheObject(key, batchStateVal.value(), GlobleConfig.ServiceBatch.cacheTime, TimeUnit.HOURS);
    }


    /**
     * 获取当前批量导入状态 总状态
     *
     * @param tenantId
     * @return
     */
    public BatchStateBean getBatchStateBean(long tenantId) {
        BatchStateBean stateBean = new BatchStateBean();
        String keyState = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_STATE);
        String keyTotal = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_TOTAL);
        String keyIndex = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_INDEX);
        String keyUserId = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_USERID);

        if (!redisCacheUtil.exists(keyState) ||
                !redisCacheUtil.exists(keyTotal) ||
                !redisCacheUtil.exists(keyIndex) ||
                !redisCacheUtil.exists(keyIndex) ||
                !redisCacheUtil.exists(keyUserId)) {
            return stateBean;
        }
        List<String> keyList = new ArrayList<>();
        keyList.add(keyState);
        keyList.add(keyTotal);
        keyList.add(keyIndex);
        keyList.add(keyUserId);
        List<Object> valList = redisCacheUtil.multiGetCacheObject(keyList);
        if (!CollectionUtils.isEmpty(valList)) {
            switch (valList.size()) {
                //4~1 读取
                case 4:
                    stateBean.setUserId((Long.valueOf(String.valueOf(valList.get(3)))));
                    //3~1 读取
                case 3:
                    stateBean.setIndex((Integer) valList.get(2));
                    //2~1 读取
                case 2:
                    stateBean.setTotal((Integer) valList.get(1));
                    //1读取
                case 1:
                    stateBean.setBatchStateType((Integer) valList.get(0));
                default:

            }
        }
        return stateBean;
    }




    //============================导出

    public String getExportKey(String key, long tenantId, long userId) {
        StringBuilder sb = new StringBuilder(key);
        sb.append("_").append(tenantId).append("_").append(userId);
        return sb.toString();
    }

    /**
     * 设置导出 总状态
     *
     * @param tenantId
     * @param exportResult
     */
    public void setExportState(long tenantId, long userId, ExportResult exportResult) {
        String keyState = getExportKey(EXPORT_PERSON_KEY_TENANTID_USERID, tenantId, userId);
        redisCacheUtil.setCacheObject(keyState, exportResult, GlobleConfig.ServiceBatch.cacheTime, TimeUnit.HOURS);
    }


    /**
     * 设置导出 总状态，  开始加锁
     *
     * @param tenantId
     * @param userId
     */
    public ExportResult getExportState(long tenantId, long userId) {
        ExportResult exportResult = new ExportResult();
        String key = getExportKey(EXPORT_PERSON_KEY_TENANTID_USERID, tenantId, userId);
        if (!redisCacheUtil.exists(key)) {
            return exportResult;
        }
        exportResult = redisCacheUtil.getCacheObject(key);
        return exportResult;
    }

    /**
     * 判断任务是否超过5分钟，用于判断异步任务是否已经挂了
     *
     * @param tenantId
     * @return
     */

    public boolean isExistAsyncTaskKey(long tenantId, long userId, String keyType) {
        boolean result = false;
        String underWayKey = getExportKey(keyType, tenantId, userId);
        if (redisCacheUtil.exists(underWayKey)) {
            result = true;
        }
        return result;

    }

    /**
     * 更新存活时间
     *
     * @param tenantId
     */
    public void setUnderWay(long tenantId, String keyType) {
        String underWayKey = getBatchPersonKey(tenantId, keyType);
        redisCacheUtil.setCacheObject(underWayKey, underWayKey + "_" + System.currentTimeMillis(), ASYNC_TASK_UNDERWAR_CACHE_TIME, TimeUnit.MINUTES);

    }

    /**
     * 更新异步导出的存活时间，用户唯一
     * @param tenantId
     * @param userId
     * @param keyType
     */
    public void setUnderWayExport(long tenantId, long userId, String keyType) {
        String underWayKey = getExportKey(keyType, tenantId, userId);
        redisCacheUtil.setCacheObject(underWayKey, underWayKey + "_" + System.currentTimeMillis(), ASYNC_TASK_UNDERWAR_CACHE_TIME, TimeUnit.MINUTES);

    }


    /**
     * 生成批量导出的用户空间
     *
     * @param oserviceOperator
     * @return
     */
    public String getExportUserRotPath(OserviceOperator oserviceOperator) {
        return "export_temp" + File.separator + oserviceOperator.getTenantId() + "_" + oserviceOperator.getUserId() + "_export";
    }
}
