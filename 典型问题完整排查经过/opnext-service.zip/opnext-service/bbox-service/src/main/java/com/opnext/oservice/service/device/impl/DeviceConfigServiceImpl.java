package com.opnext.oservice.service.device.impl;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.mongodb.WriteResult;
import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.bboxsupport.validator.IsUniqueValidator;
import com.opnext.domain.config.OConfig;
import com.opnext.domain.config.OConfigGroup;
import com.opnext.domain.message.Command;
import com.opnext.domain.request.FeedBackRequest;
import com.opnext.omessage.support.MessageContext;
import com.opnext.omessage.support.SimpleMessageTemplate;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.device.DeviceConfig;
import com.opnext.oservice.domain.device.DeviceSync;
import com.opnext.oservice.domain.device.QDeviceConfig;
import com.opnext.oservice.domain.device.SearchDeviceConfig;
import com.opnext.oservice.dto.CommonFailedStatus;
import com.opnext.oservice.feign.OMessageFeign;
import com.opnext.oservice.repository.device.DeviceConfigDao;
import com.opnext.oservice.repository.device.DeviceConfigRepository;
import com.opnext.oservice.service.base.BaseRedisService;
import com.opnext.oservice.service.device.DeviceConfigService;
import com.opnext.oservice.service.person.PersonService;
import com.opnext.oservice.util.HandleDeviceConfig;
import com.opnext.oservice.util.JsonConvertor;
import com.opnext.oservice.util.UUIDUtil;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午5:03 18/5/7
 */ 
@Slf4j
@Service
public class DeviceConfigServiceImpl implements DeviceConfigService {

    @Autowired
    DeviceConfigRepository deviceConfigRepository;
    @Resource
    DeviceConfigDao deviceConfigDao;
    @Autowired
    PersonService personService;


    @Autowired
    BaseRedisService redisService;
    @Resource
    OMessageFeign oMessageFeign;

    /**
     * 激活设备后下发指令，终端上传配置
     * 1、处理配置，只保留人脸识别配置
     * 2、配置入库（mongodb）
     * @param oConfigGroup
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void configCallback(Command command,OConfigGroup oConfigGroup) throws Exception {
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        // 判断是否已存在基础配置
        Predicate predicate = QDeviceConfig.deviceConfig.tenantId.eq(oserviceDevApiOperator.getTenantId());
        predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.serviceType.eq(DeviceConfig.ServiceType.BASE.name()));
        long count = deviceConfigRepository.count(predicate);
        FeedBackRequest.FeedBackStatus feedBackStatus = FeedBackRequest.FeedBackStatus.SUCCESS;
        // 激活时不存在基础配置，新增基础配置；新增默认识别库配置
        if (count == 0) {
            // 处理数据，只保留人脸识别配置
            // 数据格式化，嵌套
            OConfig oConfigParam = HandleDeviceConfig.encapsulationObject(oConfigGroup);
            String str = JsonConvertor.beanToJson(oConfigParam);
            OConfig oConfigDefaultParam = JsonConvertor.jsonToBean(str, OConfig.class);
            // 需要保留OConfig的key
            List<String> keyList = new ArrayList<>();
            keyList.add(GlobleConfig.TerminalConfigKey.qualityCheck);
            OConfig oConfig = HandleDeviceConfig.getTreeObject(GlobleConfig.TerminalConfigKey.profilesSelect,keyList, oConfigParam);
            if (Objects.isNull(oConfig)) {
                log.info("数据解析错误，缺少指定key：{}",GlobleConfig.TerminalConfigKey.profilesSelect);
                throw new CommonException("device.config.data.incorrect");
            }
//            oConfig = HandleDeviceConfig.removeConfig(GlobleConfig.TerminalConfigKey.bboxSettingRecognizeDbId, oConfig);
//            oConfig = HandleDeviceConfig.removeConfig(GlobleConfig.TerminalConfigKey.recognizeParamDb, oConfig);
            oConfig = HandleDeviceConfig.removeConfig(GlobleConfig.TerminalConfigKey.recognizeOneCompareMoreParam, oConfig);
            oConfigGroup = HandleDeviceConfig.getOConfigGroup(oConfig);

            OConfig defaultConfig = HandleDeviceConfig.getTreeObject(GlobleConfig.TerminalConfigKey.recognizeParamDbDefault, oConfigDefaultParam);
            if (Objects.isNull(defaultConfig)) {
                log.info("数据解析错误，缺少指定key：{}",GlobleConfig.TerminalConfigKey.recognizeParamDbDefault);
                throw new CommonException("device.config.data.incorrect");
            }
            OConfigGroup defaultGroup = HandleDeviceConfig.getOConfigGroup(defaultConfig);

            // 数据准备入库
            List<DeviceConfig> deviceConfigList = new ArrayList<>();
            DeviceConfig deviceConfig = new DeviceConfig();
            String uuId = UUIDUtil.uuid();
            deviceConfig.setId(uuId);
            deviceConfig.setName(GlobleConfig.TerminalConfigs.baseName);
            deviceConfig.setParamKey(GlobleConfig.TerminalConfigs.baseParamKey);
            // 设置配置类型
            deviceConfig.setServiceType(DeviceConfig.ServiceType.BASE.name());
            // 描述固定
            deviceConfig.setDescription(GlobleConfig.TerminalConfigs.baseDesc);
            deviceConfig.setSn(oserviceDevApiOperator.getSn());
            deviceConfig.setObjConfig(oConfigGroup);
            deviceConfig.setTenantId(oserviceDevApiOperator.getTenantId());
            // 设置版本号
            deviceConfig.setVersion(getCurrentTimeMillis());
            Long timestamp = System.currentTimeMillis();
            deviceConfig.setCreateTime(timestamp);
            deviceConfig.setUpdateTime(timestamp);
            // 基础配置添加到list
            deviceConfigList.add(deviceConfig);
            /** 新增默认识别库 */
            DeviceConfig deviceConfigDefault = new DeviceConfig();
            deviceConfigDefault.setId(UUIDUtil.uuid());
            deviceConfigDefault.setParamKey(GlobleConfig.TerminalConfigKey.recognizeParamDbDefault);
            deviceConfigDefault.setName(GlobleConfig.TerminalConfigs.groupName);
            // 设置配置类型
            deviceConfigDefault.setServiceType(DeviceConfig.ServiceType.GROUP.name());
            // 描述固定
            deviceConfigDefault.setDescription(GlobleConfig.TerminalConfigs.groupDesc);
            deviceConfigDefault.setSn(oserviceDevApiOperator.getSn());
            deviceConfigDefault.setObjConfig(defaultGroup);
            deviceConfigDefault.setTenantId(oserviceDevApiOperator.getTenantId());
            // 设置版本号
            deviceConfigDefault.setVersion(getCurrentTimeMillis());
            timestamp = System.currentTimeMillis();
            deviceConfigDefault.setCreateTime(timestamp);
            deviceConfigDefault.setUpdateTime(timestamp);
            deviceConfigList.add(deviceConfigDefault);
            try {
                deviceConfigRepository.save(deviceConfigList);
            } catch (DuplicateKeyException e) {
                log.error("-----------------Mongodb插入唯一索引异常：", e);
                throw new CommonException(HttpStatus.BAD_REQUEST.value(), CommonFailedStatus.DATABASE_INSERT_DUPLICATE_EXCEPTION.getMessage(),null,CommonFailedStatus.DATABASE_INSERT_DUPLICATE_EXCEPTION.getValue());
            } catch (Exception e) {
                log.error("配置信息入库异常：", e);
                // 设备激活上传上传配置处理失败
                feedBackStatus = FeedBackRequest.FeedBackStatus.FAIL;
            }
            log.info("设备激活配置上传完成，设备配置入库");
        } else {
            log.info("设备激活后上传配置已存在");
        }
        int callBackIndex = 5;
        do {
            try {
                //业务处理Callback数据的同时，需要调用消息中心的rest接口，来告诉消息中心此消息已回调成功
                oMessageFeign.callback(command.getWorkflowId(),command.getCommandId(),command.getRequestId());
                break;
            } catch (Exception e) {
                callBackIndex--;
                log.error("指令requestId：{},设备激活后上传配置callBack失败",command.getRequestId(), e);
            }
            Thread.sleep(5000);
        } while (callBackIndex > 0);
        int feedBackIndex = 5;
        do {
            try {
                FeedBackRequest feedBackRequest = new FeedBackRequest();
                feedBackRequest.setStatus(feedBackStatus);
                oMessageFeign.feedback(command.getWorkflowId(),command.getCommandId(), command.getRequestId(),feedBackRequest);
                break;
            } catch (Exception e) {
                feedBackIndex--;
                log.error("指令requestId：{}，设备激活后上传配置feedBack失败",command.getRequestId(), e);
            }
            Thread.sleep(5000);
        } while (feedBackIndex > 0);
    }

    @Override
    public void configCacheCallback(Command command,String redisKey, OConfigGroup oConfigGroup) throws Exception {
        //业务处理Callback数据的同时，需要调用消息中心的rest接口，来告诉消息中心此消息已回调成功
        oMessageFeign.callback(command.getWorkflowId(),command.getCommandId(), command.getRequestId());
        try {
            // 终端上传设备设置，保存到redis，数据有效期s，过期清空
            redisService.set(redisKey, oConfigGroup, GlobleConfig.TerminalConfigs.connectionRequestTimeout, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            log.error("指令requestId：{},上传配置存储redis缓存失败",command.getRequestId(), e);
            throw new CommonException("上传配置存储redis缓存异常");
        }
    }

    /**
     * 校验字段是否存在（唯一性）
     * @param name
     * @param tenantId
     * @return
     * @throws Exception
     */
    public long checkUniqueValidator(String id,String name, Long tenantId) throws Exception {
        Predicate predicate = QDeviceConfig.deviceConfig.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.name.eq(name));
        if (StringUtils.isNoneBlank(id)) {
            predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.id.ne(id));
        }
        long count = deviceConfigRepository.count(predicate);
        return count;
    }
    /**
     * 处理校验，抛出异常
     * @param name
     * @param tenantId
     * @throws Exception
     */
    public void fluentUniqueValidator(String id,String name, Long tenantId) throws Exception{
        if (StringUtils.isNoneBlank(name)) {
            ComplexResult ret = FluentValidator.checkAll()
                    .failFast()
                    .on(name, new IsUniqueValidator("name", "string.name.unique.incorrect",checkUniqueValidator(id, name, tenantId)))
                    .doValidate()
                    .result(toComplex());
            if (!ret.isSuccess()) {
                log.error("信息唯一性校验失败{}", ret);
                throw new CommonException(400, "parameter.incorrect", ret);
            }
        }
    }

    /**
     * 新增配置
     *
     * @param serviceType
     * @param deviceConfig
     * @param tenantId
     * @return
     * @throws Exception
     */
    @Override
    public DeviceConfig saveConfig(String serviceType, DeviceConfig deviceConfig, Long tenantId) throws Exception {
        return saveConfig( serviceType,  deviceConfig,  tenantId,  null);
    }

    /**
     * 新增配置
     *
     * @param serviceType
     * @param deviceConfig
     * @return
     */
    @Override
    public DeviceConfig saveConfig(String serviceType, DeviceConfig deviceConfig, Long tenantId, String sn) throws Exception {
        fluentUniqueValidator(null, deviceConfig.getName(), tenantId);

        Predicate predicate = QDeviceConfig.deviceConfig.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.serviceType.eq(serviceType));

        deviceConfig.setId(UUIDUtil.uuid());
        // 判断请求服务类型
        if (DeviceConfig.ServiceType.BASE.name().equals(serviceType)) {
            DeviceConfig fDeviceConfig = deviceConfigRepository.findOne(predicate);
            if (null == fDeviceConfig) {
                deviceConfig.setId(serviceType + "_" + UUIDUtil.uuid());
            }
        } else if (DeviceConfig.ServiceType.GROUP.name().equals(serviceType)) {
            Predicate predicateCount = QDeviceConfig.deviceConfig.tenantId.eq(tenantId);
            predicateCount = ((BooleanExpression) predicateCount).and(QDeviceConfig.deviceConfig.serviceType.eq(serviceType));
            long count = deviceConfigRepository.count(predicateCount);
            // 校验参数库个数是否小于等于10
            if (count >= 10) {
                log.info("------参数库配置达到最大值(10)限制");
                throw new CommonException("device.config.group.max");
            } else {
                predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.paramKey.eq(GlobleConfig.TerminalConfigKey.recognizeParamDbDefault));
                DeviceConfig fDeviceConfig = deviceConfigRepository.findOne(predicate);
                if (null != fDeviceConfig) {
                    OConfig oConfig = HandleDeviceConfig.encapsulationObject(fDeviceConfig.getObjConfig());
                    oConfig = HandleDeviceConfig.setOconfigGroupVals(GlobleConfig.TerminalConfigKey.recognizeParamDbDefault, oConfig, deviceConfig.getName());
                    oConfig = HandleDeviceConfig.setOconfigGroupKey(GlobleConfig.TerminalConfigKey.recognizeParamDbDefault, oConfig, deviceConfig.getId());
                    deviceConfig.setParamKey(deviceConfig.getId());
                    deviceConfig.setObjConfig((OConfigGroup) oConfig.getValue());
                } else {
                    log.info("--默认识别规则不存在");
                    throw new CommonException("device.default.config.not.found");
                }
            }
        } else {}

        deviceConfig.setServiceType(serviceType);
        // 时间戳
        deviceConfig.setVersion(getCurrentTimeMillis());
        long timestamp = System.currentTimeMillis();
        deviceConfig.setCreateTime(timestamp);
        deviceConfig.setUpdateTime(timestamp);
        deviceConfig.setSn(sn);
        deviceConfig.setTenantId(tenantId);

        return deviceConfigRepository.save(deviceConfig);
    }

    /**
     * 更新配置
     *
     * @param deviceConfig
     * @return
     * @throws Exception
     */
    @Override
    public DeviceConfig updateConfigName(DeviceConfig deviceConfig) throws Exception {
        return null;
    }

    /**
     * 获取时间戳
     * @return
     */
    public Long getCurrentTimeMillis() {
        Long timestramp = null;
        synchronized(this) {
            timestramp = System.currentTimeMillis();
        }
        return timestramp;
    }

    /**
     * 更新配置
     *
     * @param deviceConfig
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public DeviceConfig updateConfig(DeviceConfig deviceConfig) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        boolean existed = (StringUtils.isNoneBlank(deviceConfig.getServiceType()) && !(
                DeviceConfig.ServiceType.GROUP.name().equals(deviceConfig.getServiceType())
                        || DeviceConfig.ServiceType.BASE.name().equals(deviceConfig.getServiceType())));
        if (existed) {
            throw new CommonException("data.not.update");
        }
        if (StringUtils.isBlank(deviceConfig.getName()) && Objects.isNull(deviceConfig.getObjConfig())) {
            log.info("参数有误，name或objConfig不可为空");
            throw new CommonException("data.wrong");
        }

        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("id").is(deviceConfig.getId());
        criteria.and("tenantId").is(deviceConfig.getTenantId());
        criteria.and("serviceType").is(deviceConfig.getServiceType());
        query.addCriteria(criteria);
        DeviceConfig fDeviceConfig = deviceConfigDao.findOne(query);
        // 更新数据不存在
        if (null == fDeviceConfig) {
            throw new CommonException("DataNotFound");
        }
        // 基础配置，新增数据
        if (DeviceConfig.ServiceType.BASE.name().equals(deviceConfig.getServiceType())) {
            DeviceConfig submitConfig = new DeviceConfig();
            submitConfig.setId(UUIDUtil.uuid());
            if (Objects.isNull(deviceConfig.getObjConfig())) {
                throw new CommonException("data.wrong");
            }
            submitConfig.setName(fDeviceConfig.getName());
            submitConfig.setParamKey(UUIDUtil.uuid());
            submitConfig.setDescription(fDeviceConfig.getDescription());
            submitConfig.setObjConfig(deviceConfig.getObjConfig());
            // 获取时间戳
            submitConfig.setVersion(getCurrentTimeMillis());
            Long timestamp = System.currentTimeMillis();
            submitConfig.setCreateTime(timestamp);
            submitConfig.setUpdateTime(timestamp);
            submitConfig.setServiceType(DeviceConfig.ServiceType.BASE.name());
            submitConfig.setTenantId(oserviceOperator.getTenantId());
            deviceConfigRepository.save(submitConfig);
        } else if (DeviceConfig.ServiceType.GROUP.name().equals(deviceConfig.getServiceType())) {

            fluentUniqueValidator(deviceConfig.getId(), deviceConfig.getName(), oserviceOperator.getTenantId());
            Update update =new Update();
            if (Objects.isNull(deviceConfig.getObjConfig())) {
                deviceConfig.setObjConfig(fDeviceConfig.getObjConfig());
            }
            // 修改配置名称，自定义库配置也修改
            if (StringUtils.isNoneBlank(deviceConfig.getName())) {
                ComplexResult ret  = FluentValidator.checkAll()
                        .failOver()
                        .on(deviceConfig.getName(), new IsStringWithinLengthRangeValidator("name", 1,64,true))
                        .on(deviceConfig.getDescription(), new IsStringWithinLengthRangeValidator("description", 0,64,true))
                        .doValidate()
                        .result(toComplex());
                if(!ret.isSuccess()){
                    log.error("新增设置参数异常{}",ret);
                    throw new CommonException(400,"parameter.incorrect",ret);
                }
                // 默认库名称不可修改，判断不为默认库修改配置中名称
                if (!GlobleConfig.TerminalConfigs.groupName.equals(fDeviceConfig.getName())) {
                    OConfig oConfig = HandleDeviceConfig.encapsulationObject(deviceConfig.getObjConfig());
                    oConfig = HandleDeviceConfig.setOconfigGroupVals(deviceConfig.getId(),oConfig, deviceConfig.getName());
                    deviceConfig.setObjConfig((OConfigGroup) oConfig.getValue());
                    update.set("name", deviceConfig.getName());
                }
            }
            if (!GlobleConfig.TerminalConfigs.groupDesc.equals(fDeviceConfig.getDescription())) {
                update.set("description", deviceConfig.getDescription());
            }
            update.set("objConfig", deviceConfig.getObjConfig());
            long timestamp = System.currentTimeMillis();
            update.set("updateTime", timestamp);
            WriteResult result = deviceConfigDao.update(query, update);
            if (result.getN() == 0) {
                throw new CommonException("data.not.update");
            }
        }
        return null;
    }

    /**
     * 删除配置
     *
     * @param id
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(String serviceType, String id) throws Exception {
        if (Objects.nonNull(serviceType) && !DeviceConfig.ServiceType.GROUP.name().equals(serviceType)) {
            throw new CommonException("data.not.delete");
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("id").is(id);
        criteria.and("tenantId").is(oserviceOperator.getTenantId());
        criteria.and("serviceType").is(serviceType);
        query.addCriteria(criteria);
        if (DeviceConfig.ServiceType.GROUP.name().equals(serviceType)) {
            DeviceConfig deviceConfig = deviceConfigDao.findOne(query);
            if (Objects.isNull(deviceConfig)) {
                throw new CommonException("DataNotFound");
            }
            try {
                // 更新人员识别参数
                personService.deleteGroupByTenantIdAndGroupId(deviceConfig.getParamKey(), oserviceOperator.getTenantId());
            } catch (Exception e) {
                log.error("删除人员关联参数库id失败");
                throw new CommonException("data.delete.exception");
            }
        }

        WriteResult writeResult = deviceConfigDao.remove(query);
        // 获取租户id
        int conut = writeResult.getN();
        if (conut == 0) {
            log.error("根据参数无有效数据删除");
            throw new CommonException("DataNotFound");
        }
    }

    /**
     * 根据传入条件查询设备配置或
     *
     * @param type
     * @return
     */
    @Override
    public List<DeviceConfig> findList(String type) {
        return null;
    }

    /**
     * 根据传入条件查询设备配置或
     * @param sDeviceConfig
     * @return
     * @throws Exception
     */
    @Override
    public List<DeviceConfig> listConfig(SearchDeviceConfig sDeviceConfig) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        String serviceType = sDeviceConfig.getServiceType();
        Long version = sDeviceConfig.getVersion();
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("tenantId").is(tenantId);
        criteria.and("serviceType").is(serviceType);
        query.addCriteria(criteria);
        if(null != version){
            criteria.and("version").is(version);
        }
        if (DeviceConfig.ServiceType.BASE.name().equals(serviceType)) {
            query.with(new Sort(Sort.Direction.DESC,"version"));
            query.limit(1);
        } else if (DeviceConfig.ServiceType.GROUP.name().equals(serviceType)){
            query.with(new Sort(Sort.Direction.ASC,"version"));
        }else {
            query.with(new Sort(Sort.Direction.DESC,"createTime"));
        }
        List<DeviceConfig> deviceConfigList = deviceConfigRepository.findAll(query);
        // 初始化数据 第一条国际化翻译
        if (!CollectionUtils.isEmpty(deviceConfigList)) {
            if (Objects.nonNull(deviceConfigList.get(0))) {
                deviceConfigList.get(0).setName(Messages.get(deviceConfigList.get(0).getName()));
                deviceConfigList.get(0).setDescription(Messages.get(deviceConfigList.get(0).getDescription()));
            }
        }
        return deviceConfigList;
    }

    /**
     * 根据租户id获取参数库
     * @param tenantId
     * @return
     * @throws Exception
     */
    @Override
    public List<DeviceConfig> getGroupListByTenantId(Long tenantId) throws Exception{
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("tenantId").is(tenantId);
        criteria.and("serviceType").is(DeviceConfig.ServiceType.GROUP.name());
        query.addCriteria(criteria);
        query.with(new Sort(Sort.Direction.ASC,"version"));
        List<DeviceConfig> deviceConfigList = deviceConfigDao.find(query);
        return deviceConfigList;
    }


    /**
     * 同步基础设置
     * @param deviceSync
     * @throws Exception
     */
    @Override
    public void syncConfig(DeviceSync deviceSync) throws Exception {
        // 获取操作者信息
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        OConfigGroup oConfigGroup;
        // 不为空直接下发配置，保存终端当前配置
        if (Objects.nonNull(deviceSync.getObjConfig())) {
            // 移除设备关于设备
            OConfig oConfig = HandleDeviceConfig.encapsulationObject(deviceSync.getObjConfig());
            oConfig = HandleDeviceConfig.removeConfig(GlobleConfig.TerminalConfigKey.aboutDevice,oConfig);
            oConfigGroup = HandleDeviceConfig.getOConfigGroup(oConfig);
        } else {
            // 为空配置管理下发，在数据库获取配置
            oConfigGroup = getOConfigGroup();
            // 数据整合
        }

        List<DeviceConfig> deviceConfigList = new ArrayList<>();
        List<String> snList = deviceSync.getSnList();
        DeviceConfig saveConfig;

        String batchName = DeviceConfig.ServiceType.BASE.name() +"_"+ DeviceConfig.ServiceType.SN.name();
        for (String sn : snList) {
            saveConfig = new DeviceConfig();
            saveConfig.setId(UUIDUtil.uuid());
            saveConfig.setName(batchName);
            saveConfig.setParamKey(UUIDUtil.uuid());
            saveConfig.setObjConfig(oConfigGroup);
            saveConfig.setSn(sn);
            saveConfig.setServiceType(DeviceConfig.ServiceType.SN.name());
            saveConfig.setVersion(getCurrentTimeMillis());
            long timestamp = System.currentTimeMillis();
            saveConfig.setCreateTime(timestamp);
            saveConfig.setUpdateTime(timestamp);
            saveConfig.setTenantId(oserviceOperator.getTenantId());
            deviceConfigList.add(saveConfig);
        }
        // 保存设备下发配置信息
        deviceConfigRepository.save(deviceConfigList);
        log.debug("下发配置信息oConfigGroup：{}", oConfigGroup);
        sendConfigToMessage(oserviceOperator, deviceSync.getSnList(), oConfigGroup);
    }


    /**
     * 获取租户基础配置
     * @return
     * @throws Exception
     */
    private OConfigGroup getOConfigGroup() throws Exception {
        OConfigGroup oConfigGroup;
        // 为空配置管理下发，在数据库获取配置
        SearchDeviceConfig sDeviceConfig = new SearchDeviceConfig();
        sDeviceConfig.setServiceType(DeviceConfig.ServiceType.BASE.name());
        // 获取基础设置
        List<DeviceConfig> baseList = listConfig(sDeviceConfig);
        if (null != baseList && baseList.size() > 0) {
            oConfigGroup = baseList.get(0).getObjConfig();
        } else {
            log.info("------无配置信息，无法同步");
            throw new CommonException("device.config.not.found");
        }
        OConfig oConfig = HandleDeviceConfig.encapsulationObject(oConfigGroup);
        List<OConfig> oConfigList = new ArrayList<>();
        // 获取特征库列表
        sDeviceConfig.setServiceType(DeviceConfig.ServiceType.GROUP.name());
        List<DeviceConfig> groupList = listConfig(sDeviceConfig);
        OConfig oConfigParam = null;
        if (null != groupList && groupList.size() > 0) {
            for (DeviceConfig deviceConfig : groupList) {
                OConfig config = HandleDeviceConfig.encapsulationObject(deviceConfig.getObjConfig());
                oConfigParam = config;
                // 获取新增的参数库的参数
                OConfig configParam = HandleDeviceConfig.getOConfig(deviceConfig.getId(), config);
                // 获取默认参数库参数
                if (Objects.isNull(configParam)) {
                    config = HandleDeviceConfig.getOConfig(GlobleConfig.TerminalConfigKey.recognizeParamDbDefault, config);
                    oConfigList.add(config);
                } else {
                    oConfigList.add(configParam);
                }

            }
        } else {
            log.info("------无配置信息，无法同步");
            throw new CommonException("device.config.not.found");
        }
        // 修改参数库列表，返回参数库
        OConfig dbOConfig = HandleDeviceConfig.getOConfig(GlobleConfig.TerminalConfigKey.recognizeParamDb, oConfigParam, oConfigList);
        List<String> keyList = new ArrayList<>();
        keyList.add(GlobleConfig.TerminalConfigKey.qualityCheck);
        keyList.add(GlobleConfig.TerminalConfigKey.bboxSettingMatchlevel);
        oConfig = HandleDeviceConfig.getTreeObject(GlobleConfig.TerminalConfigKey.cumstomProfilesParamSettings, keyList, oConfig, Lists.newArrayList(dbOConfig), true);
        oConfigGroup = HandleDeviceConfig.getOConfigGroup(oConfig);
        return oConfigGroup;
    }
    @Override
    public DeviceConfig getConfig(String serviceType, String id, Long tenantId) throws Exception{
        try {
            DeviceConfig deviceConfig = deviceConfigRepository.findByIdAndServiceTypeAndTenantId(id, serviceType, tenantId);
            if (null == deviceConfig) {
                log.error("没有找到相应数据");
                throw new CommonException("DataNotFound");
            }
            return deviceConfig;
        } catch (Exception e) {
            log.error("mongodb数据库异常：{}", e);
            throw new CommonException(HttpStatus.BAD_REQUEST.value(), CommonFailedStatus.DATABASE_EXCEPTION.getMessage(), null,CommonFailedStatus.DATABASE_EXCEPTION.getValue());
        }
    }

    /**
     * 根据id获取单个配置
     *
     * @param name
     * @param tenantId
     * @return
     * @throws Exception
     */
    @Override
    public DeviceConfig getConfig(String name, Long tenantId) throws Exception {
        Predicate predicate = QDeviceConfig.deviceConfig.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.name.eq(name));
        predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.serviceType.eq(DeviceConfig.ServiceType.GROUP.name()));
        return deviceConfigRepository.findOne(predicate);
    }

    /**
     * 根据id获取单个配置
     *
     * @param id
     * @param tenantId
     * @return
     * @throws Exception
     */
    @Override
    public DeviceConfig getConfigById(String id, Long tenantId) throws Exception {
        Predicate predicate = QDeviceConfig.deviceConfig.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.id.eq(id));
        predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.serviceType.eq(DeviceConfig.ServiceType.GROUP.name()));
        return deviceConfigRepository.findOne(predicate);
    }


    /**
     * 根据id获取单个配置
     *
     * @param paramKey
     * @param tenantId
     * @return
     * @throws Exception
     */
    @Override
    public DeviceConfig getConfigByParamKey(String paramKey, Long tenantId) throws Exception {
        Predicate predicate = QDeviceConfig.deviceConfig.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.paramKey.eq(paramKey));
        predicate = ((BooleanExpression) predicate).and(QDeviceConfig.deviceConfig.serviceType.eq(DeviceConfig.ServiceType.GROUP.name()));
        return deviceConfigRepository.findOne(predicate);
    }

    /**
     * 根据sn获取单个配置
     *
     * @param serviceType
     * @return
     * @throws Exception
     */
    @Override
    public DeviceConfig getSNConfig(String serviceType) throws Exception {
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        String sn = oserviceDevApiOperator.getSn();
        long tenantId = oserviceDevApiOperator.getTenantId();
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("serviceType").is(serviceType);
        criteria.and("sn").is(sn);
        criteria.and("tenantId").is(tenantId);
        query.with(new Sort(Sort.Direction.DESC,"version"));
        query.limit(1);
        query.addCriteria(criteria);
        List<DeviceConfig> list = deviceConfigDao.find(query);
        DeviceConfig deviceConfig = null;
        if (!CollectionUtils.isEmpty(list)) {
            deviceConfig = list.get(0);
        } else {
            log.error("没有找到相应数据");
            throw new CommonException("DataNotFound");
        }
        return deviceConfig;
    }

    @Override
    public void sendConfigToMessage(OserviceOperator oserviceOperator, List<String> snList, OConfigGroup oConfigGroup) throws Exception {
        MessageContext context = SimpleMessageTemplate
                .operator(String.valueOf(oserviceOperator.getTenantId()), oserviceOperator.getLoginName())
                .appId(oserviceOperator.getAppId())
                .scope(Sets.newHashSet(snList)).getConfig(oConfigGroup);
        oMessageFeign.send(context);
    }

}
