package com.opnext.oservice.service.fastdfs.impl;

import com.google.common.util.concurrent.RateLimiter;
import com.op.server.dfs.client.DfsClient;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.oservice.domain.fastdfs.FastdfsTmpFile;
import com.opnext.oservice.domain.fastdfs.QFastdfsTmpFile;
import com.opnext.oservice.redis.RedisCacheUtil;
import com.opnext.oservice.repository.fastdfs.FastdfsTmpFileRepository;
import com.opnext.oservice.service.fastdfs.FastTmpFileManagerService;
import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import java.io.File;
import java.util.Base64;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

/**
 * @ClassName: FastTmpFileManagerServiceImpl
 * @Description: 临时文件管理类
 * @Author: Kevin
 * @Date: 2018/8/28 16:16
 */
@Slf4j
@Service
public class FastTmpFileManagerServiceImpl implements FastTmpFileManagerService {


    /**
     * 临时文件默认过期时间 3天
     */
    private int defaultExpireTime = 3;

    /**
     * 分布式锁key值
     */
    private final String fastTmpFileExpireKey = "fastTmpFileExpireKey";


    /**
     * 分布式锁超期时间(30s)
     */
    private long jedisKeyExpireTime = 30000;

    @Autowired
    private DfsClient dfsClient;

    @Autowired
    private JPAQueryFactory jpaQueryFactory;

    @Autowired
    private FastdfsTmpFileRepository fastdfsTmpFileRepository;

    @Autowired
    private RedisCacheUtil redisCacheUtil;


    /**
     * 上传文件并保存到临时表
     *
     * @param file     file
     * @param operator 操作人
     * @return 返回fileId, base64编码后的
     * @throws Exception
     */
    @Override
    public Optional<String> uploadFile(File file, OserviceOperator operator) throws Exception {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, defaultExpireTime);
        return uploadFile(file, calendar.getTime(), operator);
    }

    /**
     * 上传文件并保存到临时表
     *
     * @param file     file
     * @param operator 操作人
     * @param fileName 文件名
     * @return 返回fileId, base64编码后的
     * @throws Exception
     */
    @Override
    public Optional<String> uploadFileWithOriginalName(File file, String fileName, OserviceOperator operator) throws Exception {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, defaultExpireTime);
        return uploadFileWithOriginalName(file, fileName, calendar.getTime(), operator);
    }

    /**
     * 上传文件并保存到临时表
     *
     * @param file       file
     * @param expireDate 过期时间
     * @param operator   操作人
     * @return
     * @throws Exception
     */
    @Override
    public Optional<String> uploadFile(File file, Date expireDate, OserviceOperator operator) throws Exception {
        if (Objects.isNull(file) || Objects.isNull(expireDate)) {
            log.error("上传文件为空, 或过期日期为空");
            throw new CommonException("上传文件为空, 或过期日期为空");
        }
        String fileId = dfsClient.upload(file);
        if (StringUtils.isNoneBlank(fileId)) {
            fileId = Base64.getEncoder().encodeToString(fileId.getBytes());
            boolean result = insertTempFile(fileId, expireDate, operator);
            if (!result) {
                dfsClient.delete(fileId);
                // 文件删除返回fileId置为空
                fileId = null;
            }
        }else {
            throw new CommonException("文件上传返回 fileId 为空");
        }
        return Optional.ofNullable(fileId);
    }

    /**
     * 上传文件并保存到临时表
     *
     * @param file       file
     * @param expireDate 过期时间
     * @param operator   操作人
     * @param fileName   文件名
     * @return 返回fileId, base64编码后的
     * @throws Exception
     */
    @Override
    public Optional<String> uploadFileWithOriginalName(File file, String fileName, Date expireDate, OserviceOperator operator) throws Exception {
        if (Objects.isNull(file) || Objects.isNull(expireDate) || StringUtils.isBlank(fileName)) {
            log.error("上传文件为空, 或过期日期为空, 或文件名称为空");
            throw new CommonException();
        }
        String fileId = dfsClient.uploadWithOriginalName(file, fileName);
        if (StringUtils.isNoneBlank(fileId)) {
            fileId = Base64.getEncoder().encodeToString(fileId.getBytes());
            boolean result = insertTempFile(fileId, expireDate, operator);
            if (!result) {
                dfsClient.delete(fileId);
                fileId = null;
            }
        } else {
            throw new CommonException("文件上传返回 fileId 为空");
        }
        return Optional.ofNullable(fileId);
    }


    /**
     * 过期文件入库
     *
     * @param fileId
     * @param operator
     * @throws Exception
     */
    @Override
    public boolean insertTempFile(String fileId, OserviceOperator operator) throws Exception {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, defaultExpireTime);
        return insertTempFile(fileId, calendar.getTime(), operator);
    }

    /**
     * 文件上传记录入库
     *
     * @param fileId     fileId
     * @param expireDate 过期时间
     * @param operator   操作人
     */
    @Override
    public boolean insertTempFile(String fileId, Date expireDate, OserviceOperator operator) throws Exception {
        boolean result = false;
        try {
            if (StringUtils.isBlank(fileId)) {
                log.error("文件上传失败，获取fileId为空");
                return result;
            }
            FastdfsTmpFile fastdfsTmpFile = new FastdfsTmpFile();
            fastdfsTmpFile.setFileId(fileId);
            fastdfsTmpFile.setCreateTime(new Date());
            fastdfsTmpFile.setExpireTime(expireDate);
            fastdfsTmpFile.setTenantId(operator.getTenantId());
            fastdfsTmpFile.setUserId(operator.getUserId());
            fastdfsTmpFileRepository.save(fastdfsTmpFile);
            result = true;
        } catch (Exception e) {
            log.error("文件上传失败，保存临时文件记录异常", e);
        }
        return result;

    }

    /**
     * 更新临时表
     *
     * @param fileId
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updateTempFile(String fileId) throws Exception {
        if (StringUtils.isBlank(fileId)) {
            log.error("待更新文件为空");
            throw new CommonException();
        }
        Predicate predicate = QFastdfsTmpFile.fastdfsTmpFile.fileId.eq(fileId);
        jpaQueryFactory.delete(QFastdfsTmpFile.fastdfsTmpFile).where(predicate).execute();
        return true;
    }

    /**
     * 更新临时表(批量处理)
     *
     * @param fileIdList
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public boolean updateTempFile(List<String> fileIdList) throws Exception {
        if (CollectionUtils.isEmpty(fileIdList)) {
            log.error("待更新文件为空");
            throw new CommonException();
        }
        Predicate predicate = QFastdfsTmpFile.fastdfsTmpFile.fileId.in(fileIdList);
        jpaQueryFactory.delete(QFastdfsTmpFile.fastdfsTmpFile).where(predicate).execute();
        return true;
    }

    /**
     * 手动调用 删除文件
     *
     * @param fileId
     * @return
     * @throws Exception
     */
    @Override
    public boolean deleteFile(String fileId) throws Exception {
        boolean result = false;
        try {
            if (StringUtils.isNotBlank(fileId)) {
                fileId = new String(Base64.getDecoder().decode(fileId));
            }
            dfsClient.delete(fileId);
            result = true;
        } catch (Exception e) {
            log.error("删除文件失败", e);
            throw new CommonException();
        }
        return result;
    }

    /**
     * 删除文件记录
     *
     * @param fileId
     * @return
     * @throws Exception
     */
    @Override
    public boolean deleteTempFile(String fileId) throws Exception {
        if (StringUtils.isBlank(fileId)) {
            log.error("待更新文件为空");
            throw new CommonException();
        }
        fastdfsTmpFileRepository.deleteByFileId(fileId);
        return true;
    }

    /**
     * 定时删除临时表中过期的文件， 每天定时删除。
     *
     * @throws Exception
     */
    @Scheduled(cron = "0 30 3 * * ?")
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteExpireFile() {
        redisCacheUtil.handleDistributedLock(fastTmpFileExpireKey, jedisKeyExpireTime, TimeUnit.MILLISECONDS);
        StopWatch stopWatch = new StopWatch();
        try {
            stopWatch.start("获取redis分布式锁");
            long curTime = System.currentTimeMillis();
            boolean keyResult = redisCacheUtil.setIfAbsentCacheObject(fastTmpFileExpireKey, curTime);
            if (!keyResult) {
                log.info("没有获取到分布式锁，不执行定时删除文件临时表过期文件任务");
                return;
            }
            stopWatch.stop();
            log.info("获取到分布式锁，执行定时删除文件临时表过期文件任务");
            stopWatch.start("删除过期文件 - 查询数据库");
            //查询出所有的过期的fileId
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.DATE, 0 - defaultExpireTime);
            Predicate predicate = QFastdfsTmpFile.fastdfsTmpFile.expireTime.before(calendar.getTime());
            List<String> fileIdList = jpaQueryFactory.select(QFastdfsTmpFile.fastdfsTmpFile.fileId).from(QFastdfsTmpFile.fastdfsTmpFile).where(predicate).fetch();
            stopWatch.stop();
            if (CollectionUtils.isEmpty(fileIdList)) {
                log.info("临时表中过期文件数量为空");
            } else {
                stopWatch.start("删除过期文件 - 循环删除, listSize=" + fileIdList.size());
                //向fastdfs删除文件
                //对文件的批量删除操作进行流速控制
                RateLimiter limiter = RateLimiter.create(16);
                fileIdList.forEach(fileId -> {
                    try {
                        limiter.acquire();
                        deleteFile(fileId);
                        updateTempFile(fileId);
                    } catch (Exception e) {
                        log.error("定时删除文件异常，fileId={}", fileId, e);
                    }
                });
                stopWatch.stop();
            }
            stopWatch.start("释放分布式锁");
            Long cacheTime = redisCacheUtil.getCacheObject(fastTmpFileExpireKey);
            if (Objects.nonNull(cacheTime) && curTime == cacheTime) {
                redisCacheUtil.delete(fastTmpFileExpireKey);
            }
            stopWatch.stop();
            log.info("定时删除临时表中过期的文件,操作成功 , 耗时统计={}", stopWatch.prettyPrint());
        } catch (Exception e) {
            log.error("定时删除临时文件异常，e={}", e);
        }

    }

}
