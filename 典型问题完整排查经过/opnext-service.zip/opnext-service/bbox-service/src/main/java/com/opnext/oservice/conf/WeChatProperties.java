package com.opnext.oservice.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author wanglu
 */
@Component
@Data
@ConfigurationProperties(prefix = "remote-rest.wechat")
public class WeChatProperties {
    /**
     * 绑定员工界面地址
     */
    private String bindingPageUrl;
    /**
     * 微信第三方平台主机地址
     */
    private String host;
    /**
     * SaaS地址
     */
    private String saasHost;
    /**
     * 微信公众号入口地址
     */
    private String wechatLoginUrl;
    /**
     * 获取第三方平台授权码地址
     */
    private String wechatAuthCodeUrl;
    /**
     * 根据授权码获取授权信息地址
     */
    private String wechatAuthUrl;
    /**
     * 用户网页授权地址
     */
    private String userAuthUrl;
    /**
     * 获取用户信息地址
     */
    private String userInfoUrl;
    /**
     * 发送模版消息地址
     */
    private String sendTemplateUrl;
    /**
     * 获取jsticket地址
     */
    private String jsTicketUrl;
}
