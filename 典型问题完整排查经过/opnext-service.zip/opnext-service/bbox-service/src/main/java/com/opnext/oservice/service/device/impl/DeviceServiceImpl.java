package com.opnext.oservice.service.device.impl;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.domain.config.OConfig;
import com.opnext.domain.config.OConfigGroup;
import com.opnext.domain.message.Code;
import com.opnext.domain.message.CommandType;
import com.opnext.domain.message.Feature;
import com.opnext.domain.request.FeedBackRequest;
import com.opnext.omessage.support.MessageContext;
import com.opnext.omessage.support.SimpleMessageTemplate;
import com.opnext.oservice.conf.Constant;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.domain.device.DeviceAdminRel;
import com.opnext.oservice.domain.device.DeviceConfig;
import com.opnext.oservice.domain.device.DeviceStatus;
import com.opnext.oservice.domain.device.DeviceSync;
import com.opnext.oservice.domain.device.DeviceVo;
import com.opnext.oservice.domain.device.QDevice;
import com.opnext.oservice.domain.device.QDeviceAdmin;
import com.opnext.oservice.domain.device.QDeviceAdminRel;
import com.opnext.oservice.domain.device.QTenantActiveCode;
import com.opnext.oservice.domain.device.SearchDevice;
import com.opnext.oservice.domain.device.TenantActiveCode;
import com.opnext.oservice.dto.CommonFailedStatus;
import com.opnext.oservice.feign.OMessageFeign;
import com.opnext.oservice.repository.ComplicateQueryDao;
import com.opnext.oservice.repository.device.DeviceAdminRelRepository;
import com.opnext.oservice.repository.device.DeviceConfigDao;
import com.opnext.oservice.repository.device.DeviceConfigRepository;
import com.opnext.oservice.repository.device.DeviceRepository;
import com.opnext.oservice.repository.device.TenantActiveCodeRepository;
import com.opnext.oservice.service.base.BaseRedisService;
import com.opnext.oservice.service.device.DeviceAdminService;
import com.opnext.oservice.service.device.DeviceConfigService;
import com.opnext.oservice.service.device.DeviceService;
import com.opnext.oservice.util.HandleDeviceConfig;
import com.opnext.oservice.util.RadixUtil;
import com.opnext.oservice.util.UUIDUtil;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:04 18/5/7
 */
@Slf4j
@Service
public class DeviceServiceImpl implements DeviceService {
    @Value("${server.context-path}")
    private String serverPath;

    @Autowired
    private DeviceRepository deviceRepository;
    @Autowired
    private DeviceAdminRelRepository adminRelRepository;
    @Autowired
    private ComplicateQueryDao complicateQueryDao;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    private TenantActiveCodeRepository activeCodeRepository;
    @Resource
    private OMessageFeign oMessageFeign;
    @Autowired
    DeviceConfigService deviceConfigService;
    @Autowired
    private DeviceAdminService adminService;
    @Autowired
    DeviceConfigRepository deviceConfigRepository;
    @Resource
    DeviceConfigDao deviceConfigDao;
    @Autowired
    BaseRedisService redisService;


    /**
     * 根据sn获取设备所属租户
     *
     * @param sn
     * @return
     */
    @Override
    public Device getDevice(String sn) {
        Predicate predicate = QDevice.device.sn.eq(sn);
        Device device = deviceRepository.findOne(predicate);
        return device;
    }

    /**
     * 根据sn获取设备所属租户
     *
     * @param sn
     * @return
     */
    @Override
    public Long getTenantId(String sn) {
        Predicate predicate = QDevice.device.sn.eq(sn);
        Device device = deviceRepository.findOne(predicate);
        if (Objects.nonNull(device)) {
            return device.getTenantId();
        }
        return null;
    }

    /**
     * 获取设备列表
     *
     * @param pageable
     * @param sDevice
     * @return
     */
    @Override
    public Page getDevicePage(Pageable pageable, SearchDevice sDevice) throws Exception{
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = null;
        if (Objects.nonNull(tenantId)) {
            predicate = QDevice.device.tenantId.eq(oserviceOperator.getTenantId());
        }

        if (StringUtils.isNotBlank(sDevice.getName())) {
            predicate = (predicate == null ? QDevice.device.name.contains(sDevice.getName()) :
                    ((BooleanExpression) predicate).and(QDevice.device.name.contains(sDevice.getName())));
        }

        if (StringUtils.isNotBlank(sDevice.getSn())) {
            predicate = (predicate == null ? QDevice.device.sn.eq(sDevice.getSn()) :
                    ((BooleanExpression) predicate).and(QDevice.device.sn.contains(sDevice.getSn())));
        }

        if (null != sDevice.getType() && StringUtils.isNotBlank(sDevice.getType().value())) {
            predicate = (predicate == null ? QDevice.device.type.eq(sDevice.getType()) :
                    ((BooleanExpression) predicate).and(QDevice.device.type.eq(sDevice.getType())));
        }
        if (null != sDevice.getStatus()) {
            predicate = (predicate == null ? QDevice.device.status.eq(sDevice.getStatus()) :
                    ((BooleanExpression) predicate).and(QDevice.device.status.eq(sDevice.getStatus())));
        }

        if (CollectionUtils.isEmpty(oserviceOperator.getDeviceGroups())) {
            if (OserviceOperator.UserType.COMMON.equals(oserviceOperator.getUserType())) {
                Page page = new PageImpl(new ArrayList<>(), pageable, 0);
                return page;
            } else {
                if (null != sDevice.getGroupId()) {
                    if (-1 == sDevice.getGroupId()) {
                        predicate = (predicate == null ? QDevice.device.groupId.isNull() :
                                ((BooleanExpression) predicate).and(QDevice.device.groupId.isNull()));
                    } else {
                        predicate = (predicate == null ? QDevice.device.groupId.eq(sDevice.getGroupId()) :
                                ((BooleanExpression) predicate).and(QDevice.device.groupId.eq(sDevice.getGroupId())));
                    }
                }
            }
        } else {
            if (null != sDevice.getGroupId()) {
                if (-1 == sDevice.getGroupId()) {
                    predicate = (predicate == null ? QDevice.device.groupId.isNull() :
                            ((BooleanExpression) predicate).and(QDevice.device.groupId.isNull()));
                } else {
                    predicate = (predicate == null ? QDevice.device.groupId.eq(sDevice.getGroupId()) :
                            ((BooleanExpression) predicate).and(QDevice.device.groupId.eq(sDevice.getGroupId())));
                }
            } else {
                predicate = (predicate == null ? QDevice.device.groupId.in(oserviceOperator.getDeviceGroups()) :
                        ((BooleanExpression) predicate).and(QDevice.device.groupId.in(oserviceOperator.getDeviceGroups())));
            }
        }


        JPAQuery<Tuple> jpaQuery = jpaQueryFactory.select(QDevice.device,QDevice.device.id)
                .from(QDevice.device);

//         通过设备管理员id获取设备id列表，为查询设别列表添加筛选条件
        if (Objects.nonNull(sDevice.getDeviceAdminId()) || StringUtils.isNoneBlank(sDevice.getDeviceAdminName())) {

            if (Objects.nonNull(sDevice.getDeviceAdminId())) {
                predicate = (predicate == null ? QDeviceAdminRel.deviceAdminRel.deviceAdminId.eq(sDevice.getDeviceAdminId()) :
                        ((BooleanExpression) predicate).and(QDeviceAdminRel.deviceAdminRel.deviceAdminId.eq(sDevice.getDeviceAdminId())));
            }
            if (StringUtils.isNoneBlank(sDevice.getDeviceAdminName())) {
                predicate = (predicate == null ? QDeviceAdmin.deviceAdmin.name.eq(sDevice.getDeviceAdminName()) :
                        ((BooleanExpression) predicate).and(QDeviceAdmin.deviceAdmin.name.eq(sDevice.getDeviceAdminName())));
            }
            boolean existed = (Objects.nonNull(sDevice.getDeviceAdminId()) || StringUtils.isNotBlank(sDevice.getDeviceAdminName()));
            jpaQuery.leftJoin(QDeviceAdminRel.deviceAdminRel)
                    .on(QDevice.device.id.eq(QDeviceAdminRel.deviceAdminRel.deviceId))
                    .leftJoin(QDeviceAdmin.deviceAdmin)
                    .on(QDeviceAdmin.deviceAdmin.id.eq(QDeviceAdminRel.deviceAdminRel.deviceAdminId));
        }

        jpaQuery.where(predicate)
                .orderBy(QDevice.device.status.asc(),QDevice.device.updateTime.desc());
        // 根据查询条件获取设备分页
        Page<DeviceVo> page = complicateQueryDao.find(jpaQuery,
                pageable, DeviceVo.class);
        if (!CollectionUtils.isEmpty(page.getContent())) {
            // 根据设备列表，处理设备管理员名称拼接
            handleDeviceAdminName(page, sDevice.getDeviceAdminId());
        }
        return page;
    }

    /**
     * 根据是否有设备组获取设备列表
     *
     * @return
     * @throws Exception
     */
    @Override
    public List listByGroupFlag(Integer groupId) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QDevice.device.tenantId.eq(tenantId);
        if (Objects.nonNull(groupId)) {
            predicate = ((BooleanExpression) predicate).and(QDevice.device.groupId.eq(groupId));
        } else {
            predicate = ((BooleanExpression) predicate).and(QDevice.device.groupId.isNull());
        }
        List<Device> deviceList = jpaQueryFactory.selectFrom(QDevice.device)
                .where(predicate).fetch();
        return deviceList;
    }

    public void handleDeviceAdminName(Page<DeviceVo> page, Integer adminid) throws Exception {
        List<DeviceVo> list = page.getContent();
        List<Integer> idList = new ArrayList<>();
        for (DeviceVo deviceVo : list) {
            idList.add(deviceVo.getId());
        }
        // 查询设备管理员
        List<Map<String, Object>> listMap = jpaQueryFactory.select(QDevice.device.id, QDeviceAdmin.deviceAdmin.name, QDeviceAdmin.deviceAdmin.id)
                .from(QDevice.device)
                .leftJoin(QDeviceAdminRel.deviceAdminRel)
                .on(QDevice.device.id.eq(QDeviceAdminRel.deviceAdminRel.deviceId))
                .leftJoin(QDeviceAdmin.deviceAdmin)
                .on(QDeviceAdmin.deviceAdmin.id.eq(QDeviceAdminRel.deviceAdminRel.deviceAdminId))
                .where(QDevice.device.id.in(idList).and(QDeviceAdmin.deviceAdmin.name.isNotNull()))
                .orderBy(QDevice.device.id.desc())
                .fetch().stream().
                map(tuple -> {
                    Map<String, Object> map = new LinkedHashMap<>();
                    map.put("id", tuple.get(QDevice.device.id));
                    map.put("adminName", tuple.get(QDeviceAdmin.deviceAdmin.name));
                    map.put("adminId", tuple.get(QDeviceAdmin.deviceAdmin.id));
                    return map;
                }).collect(Collectors.toList());

        int id = 0;
        String adminName = "";
        Map<Integer, String> idAdminName = new LinkedHashMap<>();
        Map<Integer, Integer> adminIdMap = new LinkedHashMap<>();
        for (int i = 0; i < listMap.size(); i++) {
            int mapId = (int) listMap.get(i).get("id");
            String mapAdminName = (String) listMap.get(i).get("adminName");
            int mapAdminId = (int) listMap.get(i).get("adminId");
            if (i == 0) {
                id = mapId;
                adminName = mapAdminName;
            } else {
                if (id == mapId) {
                    adminName += "," + mapAdminName;
                } else {
                    id = mapId;
                    adminName = mapAdminName;
                }
            }
            if (Objects.nonNull(adminid) && mapAdminId == adminid){
                adminIdMap.put(id, mapAdminId);
            }
            idAdminName.put(id, adminName);
        }
        // 给返回数据赋值
        for (DeviceVo deviceVo : list) {
            deviceVo.setAdminName(idAdminName.get(deviceVo.getId()));
            deviceVo.setAdminId(adminIdMap.get(deviceVo.getId()));
        }
    }

    /**
     * 根据租户获取设备激活码
     *
     * @return
     * @throws Exception
     */
    @Override
    public TenantActiveCode getActiveCode() throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QTenantActiveCode.tenantActiveCode.tenantId.eq(tenantId);
        TenantActiveCode activeCode = activeCodeRepository.findOne(predicate);
        if (null == activeCode) {
            log.info("设备激活码不存在");
            // 不存在创建激活码
            TenantActiveCode tenantActiveCode = new TenantActiveCode();
            tenantActiveCode.setActiveCode(RadixUtil.randomPlainUUID());
            tenantActiveCode.setTenantId(tenantId);
            activeCode = activeCodeRepository.save(tenantActiveCode);
        }
        // 设置激活地址
        activeCode.setUrl(GlobleConfig.ServerUrl.terminalGatewayHost);
        return activeCode;
    }

    /**
     * 设备单次开门
     *
     * @param sn
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public CommonResponse doorSingleOpen(String sn, OserviceOperator oserviceOperator) throws Exception {
        Long tenantId = oserviceOperator.getTenantId();
        // 判断设备是否属于该租户 设备组
        QDevice qDevice = QDevice.device;
        Predicate predicate = qDevice.sn.eq(sn);
        if (Objects.nonNull(tenantId)) {
            predicate = ((BooleanExpression) predicate).and(qDevice.tenantId.eq(tenantId));
        }
        Device device = deviceRepository.findOne(predicate);
        if (Objects.isNull(device)) {
            throw new CommonException("parameter.incorrect");
        } else {
            if (device.getStatus().equals(DeviceStatus.DEVICE_OFF_LINE)) {
                throw new CommonException("device.offLine.command.send.failed");
            } else {
                // 下发指令
                sendCommand(Sets.newHashSet(sn), oserviceOperator, Code.ACTION_ALLOW);
            }
        }
        return CommonResponse.ok(new HashMap<>());
    }

    public List<Device> checkData(Set<String> snSet, OserviceOperator oserviceOperator, Code type) throws Exception {
        Long tenantId = oserviceOperator.getTenantId();
        QDevice qDevice = QDevice.device;
        Predicate predicate = qDevice.sn.in(snSet);
        if (Objects.nonNull(tenantId)) {
            predicate = ((BooleanExpression) predicate).and(qDevice.tenantId.eq(tenantId));
        }
        List<Device> deviceList = (List<Device>) deviceRepository.findAll(predicate);
        if (CollectionUtils.isEmpty(deviceList)) {
            log.error("==存在不属于该租户的设备:{}", snSet);
            throw new CommonException("parameter.incorrect");
        } else {
            if ( deviceList.size() < snSet.size()){
                deviceList.forEach(device -> snSet.remove(device.getSn()));
                log.error("==存在不属于该租户的设备:{}",snSet);
                throw new CommonException("parameter.incorrect");
            }
        }
        // 校验联网状态,生成断网错误信息
        BindingResult errorList = new BeanPropertyBindingResult(null,"Device");
        deviceList.forEach(device -> {
            if (DeviceStatus.DEVICE_OFF_LINE.equals(device.getStatus())) {
                // 移除已断网设备sn
                snSet.remove(device.getSn());
                errorList.addError(new ObjectError(device.getSn(),device.getName()));
            }
        });
        // 下发指令
        sendCommand(snSet, oserviceOperator, type);
        if (!CollectionUtils.isEmpty(errorList.getAllErrors())) {
            if (errorList.getAllErrors().size() < deviceList.size()) {
                throw new CommonException(HttpStatus.BAD_REQUEST.value(),"device.offLine.part.command.send.failed",errorList);
            } else {
                throw new CommonException("device.offLine.all.command.send.failed");
            }
        }
        return deviceList;
    }

    public void sendCommand(Set<String> snSet, OserviceOperator oserviceOperator, Code type) throws Exception {
        if (CollectionUtils.isEmpty(snSet)) {
            return;
        }
        try {
            SimpleMessageTemplate messageTemplate = SimpleMessageTemplate
                    .operator(String.valueOf(oserviceOperator.getTenantId()), oserviceOperator.getLoginName())
                    .appId(oserviceOperator.getAppId())
                    .scope(snSet);
            MessageContext context;
            switch (type) {
                // 设备单次开门
                case ACTION_ALLOW :
                    context = messageTemplate.actionAllow();
                    break;
                // 设备常开
                case OPEN_ALWAYS :
                    context = messageTemplate.openAlways();
                    break;
                // 取消设备常开
                case OPEN_CANCEL:
                    context = messageTemplate.openCancel();
                    break;
                // 设备重启
                case REBOOT:
                    context = messageTemplate.reboot();
                    break;
                default:
                    log.error("==没有找到对应的下发类型");
                    throw new CommonException("TypeMismatch");
            }
            // 设置命令类型，非阻塞
            Feature feature = new Feature();
            feature.setType(CommandType.UNBLOCK_COMMAND);
            context.setFeature(feature);
            oMessageFeign.send(context);
        } catch (Exception e) {
            log.error("==操作：{}，设备：{}, 调用OMessage失败",type.name(), snSet);
            throw new CommonException("oMessage.command.send.failed");
        }

    }

    /**
     * 重启设备
     *
     * @param snSet
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public CommonResponse rebootDevice(Set<String> snSet, OserviceOperator oserviceOperator) throws Exception {
        // 判断设备是否属于该租户 设备组
        checkData(snSet,oserviceOperator, Code.REBOOT);
        return CommonResponse.ok(new HashMap<>());
    }

    /**
     * 设备常开
     *
     * @param snSet
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public CommonResponse doorOpenAlways(Set<String> snSet, OserviceOperator oserviceOperator) throws Exception {
        // 判断设备是否属于该租户 设备组
        checkData(snSet,oserviceOperator, Code.OPEN_ALWAYS);
        return CommonResponse.ok(new HashMap<>());
    }

    /**
     * 设备取消常开
     *
     * @param snSet
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public CommonResponse doorOpenCancel(Set<String> snSet, OserviceOperator oserviceOperator) throws Exception {
        // 判断设备是否属于该租户 设备组
        checkData(snSet,oserviceOperator, Code.OPEN_CANCEL);
        return CommonResponse.ok(new HashMap<>());
    }

    /**
     * 根据租户刷新设备激活码
     *
     * @return
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public TenantActiveCode refreshActiveCode(Integer id) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        TenantActiveCode activeCode = null;
        String code =  RadixUtil.randomPlainUUID();
        do {
            Predicate predicate = QTenantActiveCode.tenantActiveCode.tenantId.eq(tenantId);
            predicate = ((BooleanExpression) predicate).and(QTenantActiveCode.tenantActiveCode.activeCode.eq(code));
            activeCode = activeCodeRepository.findOne(predicate);
        } while(Objects.nonNull(activeCode));

        // 更新激活码
        long count = jpaQueryFactory.update(QTenantActiveCode.tenantActiveCode)
                .set(QTenantActiveCode.tenantActiveCode.activeCode, code)
                .where(QTenantActiveCode.tenantActiveCode.id.eq(id))
                .execute();
        TenantActiveCode tenantActiveCode = null;
        if (count > 0) {
            tenantActiveCode = new TenantActiveCode();
            tenantActiveCode.setId(id);
            tenantActiveCode.setActiveCode(code);
            // 设置激活地址
            tenantActiveCode.setUrl(GlobleConfig.ServerUrl.terminalGatewayHost);
        } else {
            throw new CommonException("DataNotFound");
        }
        return tenantActiveCode;
    }



    /**
     * 关联设备管理员
     *
     * @param deviceIds
     * @param adminIds
     * @throws Exception
     */
    @Override
    public void bindDeviceAdmin(Integer[] deviceIds, Integer[] adminIds) throws Exception {
        log.info("设备绑定管理员，adminIds：{}，deviceIds：{}",adminIds, deviceIds);
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        QDevice qDevice = QDevice.device;
        QDeviceAdminRel qDeviceAdminRel = QDeviceAdminRel.deviceAdminRel;
        // 校验接口提交数据--防止已被删除设备进行数据关联
        List<Integer> adminIdList = checkAdminIdRemoveInvalid(Lists.newArrayList(adminIds), oserviceOperator);
        if (CollectionUtils.isEmpty(adminIdList)) {
            log.error("-------关联管理员id：{} 不存在", adminIds);
            throw new CommonException("data.warning");
        }

        List<Integer> checkDeviceIdList = checkDeviceIdRemoveInvalid(Lists.newArrayList(deviceIds), oserviceOperator);
        if (CollectionUtils.isEmpty(checkDeviceIdList)) {
            log.error("------不存在将要关联的设备id：{}", deviceIds);
        } else {
            // 获取设备关联管理员个数
            List<Map<String, Object>> findList = jpaQueryFactory.select(qDevice.id, QDevice.device.name,qDevice.sn, qDeviceAdminRel.deviceId.count())
                    .from(QDeviceAdminRel.deviceAdminRel)
                    .leftJoin(QDevice.device)
                    .on(qDevice.id.eq(qDeviceAdminRel.deviceId))
                    .where(qDeviceAdminRel.deviceId.in(checkDeviceIdList))
                    .groupBy(qDeviceAdminRel.deviceId)
                    .fetch().stream().map(
                            tuple -> {
                                Map<String, Object> map = new LinkedHashMap<>();
                                map.put("id", tuple.get(qDevice.id));
                                map.put("name", tuple.get(qDevice.name));
                                map.put("sn", tuple.get(qDevice.sn));
                                map.put("count", tuple.get(qDeviceAdminRel.deviceId.count()));
                                return map;
                            }
                    ).collect(Collectors.toList());
            // 判断设备关联管理员是否超限
            StringBuilder sBuilder = new StringBuilder();
            for (Map<String, Object> map : findList) {
                if ((Long) map.get("count") >= 10) {
//                    String deviceName = (String) map.get("name");
                    String sn = (String) map.get("sn");
                    if (sBuilder.length() > 0) {
                        sBuilder.append(",").append(sn);
                    } else {
                        sBuilder.append(sn);
                    }
                }
            }
            String errorMessage;
            String errorMsgKey = "device.admin.outOf.limit";
            try{
                errorMessage = Messages.get(errorMsgKey);
            }catch(Exception e){
                errorMessage = errorMsgKey;
            }

            if (sBuilder.length() > 0) {
                sBuilder.append("等");
                log.info("设备：{} {}", sBuilder.toString(), "超过关联最多管理员个数（10）");
                throw new CommonException(HttpStatus.BAD_REQUEST.value(), sBuilder.toString() + errorMessage);
            }
            // 获取本次提交已存在的数据
            Predicate predicate = qDeviceAdminRel.deviceAdminId.in(adminIds);
            predicate = ((BooleanExpression) predicate).and(qDeviceAdminRel.deviceId.in(checkDeviceIdList));
            List<Integer> deviceAdminRelList = jpaQueryFactory.select(qDeviceAdminRel.deviceId)
                    .from(qDeviceAdminRel)
                    .where(predicate)
                    .fetch();
            List<Integer> sendDeviceIdList = Lists.newArrayList(checkDeviceIdList);
            checkDeviceIdList.removeAll(deviceAdminRelList);
            // 在设备与管理员表中插入关联关系
            List<DeviceAdminRel> relList = new ArrayList<>();
            for (int i = 0; i < checkDeviceIdList.size(); i++) {
                for (int j = 0; j < adminIds.length; j++) {
                    DeviceAdminRel rel = new DeviceAdminRel();
                    rel.setTenantId(oserviceOperator.getTenantId());
                    rel.setDeviceId(checkDeviceIdList.get(i));
                    rel.setDeviceAdminId(adminIds[j]);
                    relList.add(rel);
                }
            }
            // 保存设备与管理员关联关系
            adminRelRepository.save(relList);
            Predicate predicateSn = QDevice.device.tenantId.eq(oserviceOperator.getTenantId());
            predicateSn = ((BooleanExpression) predicateSn).and(QDevice.device.id.in(sendDeviceIdList));
            List<String> snList = jpaQueryFactory.select(QDevice.device.sn)
                    .from(QDevice.device).where(predicateSn).fetch();
            /** 调用下发接口 */
            adminService.sendAdmin(oserviceOperator, snList);
        }
    }

    /**
     * 移除无效数据（设备id）
     * @param deviceIdList 设备id列表
     * @param oserviceOperator 操作者信息
     * @return
     * @throws Exception
     */
    public List<Integer> checkDeviceIdRemoveInvalid(List<Integer> deviceIdList, OserviceOperator oserviceOperator) throws Exception{
        log.info("------deviceIdList参数：{}", deviceIdList);
        QDevice qDevice = QDevice.device;
        List<Integer> checkDeviceIdList;
        if (CollectionUtils.isEmpty(deviceIdList)) {
            throw new CommonException("object.notEmpty");
        } else {
            checkDeviceIdList = jpaQueryFactory.select(qDevice.id)
                    .from(qDevice)
                    .where(qDevice.id.in(deviceIdList).and(qDevice.tenantId.eq(oserviceOperator.getTenantId())))
                    .fetch();
            if (!CollectionUtils.isEmpty(checkDeviceIdList) && deviceIdList.removeAll(checkDeviceIdList)) {
                log.warn("------存在已删除设备id：{}", deviceIdList);
            }
        }
        return checkDeviceIdList;
    }

    /**
     * 删除无效管理员id
     * @param adminIdList 管理员id
     * @param oserviceOperator 操作者信息
     * @return
     * @throws Exception
     */
    public List<Integer> checkAdminIdRemoveInvalid(List<Integer> adminIdList, OserviceOperator oserviceOperator) throws Exception{
        log.info("------adminIdList参数：{}", adminIdList);
        QDeviceAdmin qDeviceAdmin = QDeviceAdmin.deviceAdmin;
        List<Integer> checkAdminIdList;
        if (CollectionUtils.isEmpty(adminIdList)) {
            throw new CommonException("object.notEmpty");
        } else {
            checkAdminIdList = jpaQueryFactory.select(qDeviceAdmin.id)
                    .from(qDeviceAdmin)
                    .where(qDeviceAdmin.id.in(adminIdList).and(qDeviceAdmin.tenantId.eq(oserviceOperator.getTenantId())))
                    .fetch();
            if (!CollectionUtils.isEmpty(checkAdminIdList) && adminIdList.removeAll(checkAdminIdList)) {
                log.warn("------存在已删除管理员id：{}", adminIdList);
            }
        }
        return checkAdminIdList;
    }

    /**
     * 移除设备组
     *
     * @param deviceIds
     * @throws Exception
     */
    @Transactional(rollbackFor = {Exception.class})
    @Override
    public void deleteDeviceGroup(Integer[] deviceIds) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Predicate predicate = QDevice.device.id.in(deviceIds);
        predicate = ((BooleanExpression) predicate).and(QDevice.device.tenantId.eq(oserviceOperator.getTenantId()));
        try {
            long count = jpaQueryFactory.update(QDevice.device)
                    .setNull(QDevice.device.groupId)
                    .setNull(QDevice.device.groupName)
                    .where(predicate)
                    .execute();
        } catch (Exception e) {
            log.info("数据库操作异常：{}", e);
            throw new CommonException(HttpStatus.BAD_REQUEST.value(), CommonFailedStatus.DATABASE_EXCEPTION.getMessage(), null,CommonFailedStatus.DATABASE_EXCEPTION.getValue());
        }
    }

    /**
     * 获取设备设置
     *  1、下发指令，终端通过回调上传设备配置
     *  2、等待终端上传配置（超时时间：5000ms）
     *  3、返回终端上传设备设置
     * @param sn
     * @throws Exception
     */
    @Override
    public OConfigGroup getDeviceConfig(String sn) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        String redisKey =Constant.CONFIG_REDIS_PATTERN_KEY + UUIDUtil.uuid();
        log.info("设备获取终端设置redisKey：{}", redisKey);
        // 下发指令
        String terminalGatewayHost = "";
        String strUrl = String.format("%s%s/api/devapi/callback/config/cache/{workflowId}/{commandId}/{requestId}?redisKey=%s",
                terminalGatewayHost, serverPath, redisKey);
        MessageContext context = SimpleMessageTemplate
                    .operator(String.valueOf(oserviceOperator.getTenantId()), oserviceOperator.getLoginName())
                    .appId(oserviceOperator.getAppId())
                    .scope(Sets.newHashSet(sn)).postConfig(strUrl);
        List<String> requestIdList = oMessageFeign.send(context);
        // 从redis获取设备配置
        long startTime = System.currentTimeMillis();
        long endTime;
        OConfigGroup oConfigGroup;
        do {
            Thread.sleep(100);
            oConfigGroup = (OConfigGroup) redisService.get(redisKey);
            endTime = System.currentTimeMillis();
            if (Objects.nonNull(oConfigGroup)) {
                log.info("获取终端配置耗时(ms)：{}", endTime -startTime);
                break;
            }
            //时间差小于5000ms继续执行
        } while ((endTime - startTime) < GlobleConfig.TerminalConfigs.connectionRequestTimeout);
        FeedBackRequest.FeedBackStatus feedBackStatus = FeedBackRequest.FeedBackStatus.SUCCESS;
        String requestId = "";
        try {
            if (Objects.nonNull(oConfigGroup)) {
                return oConfigGroup;
            } else {
                log.info("获取设备配置超时，无数据");
                feedBackStatus = FeedBackRequest.FeedBackStatus.FAIL;
                throw new CommonException("terminal.response.config.timeout");
            }
        } finally {
            try {
                if (CollectionUtils.isEmpty(requestIdList)) {
                    log.error("oMessage指令发送异常，requestId返回为空");
                } else {
                    requestId = requestIdList.get(0);
                    String commandId = requestId.split("-")[1];
                    FeedBackRequest feedBackRequest = new FeedBackRequest();
                    feedBackRequest.setStatus(feedBackStatus);
                    oMessageFeign.feedback("", commandId, requestId, feedBackRequest);
                }
            } catch (Exception e) {
                log.error("指令requestId：{}，feedBack结果反馈调用失败:", requestId, e);
            }
        }
    }

    /**
     * 更新设备
     * 更新数据库设备名称
     * @param sn
     * @param deviceSync
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateDeviceConfig(String sn, DeviceSync deviceSync) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        OConfigGroup oConfigGroup = deviceSync.getObjConfig();
        // 处理提交数据
        OConfig oConfig = HandleDeviceConfig.encapsulationObject(oConfigGroup);
        oConfig = HandleDeviceConfig.getOConfig(GlobleConfig.TerminalConfigKey.bboxSettingDeviceName, oConfig);

        // 解析oConfig获取设备名称
        if (Objects.isNull(oConfig)) {
            log.error("--------获取设备名称异常，oConfig is null");
            throw new CommonException("data.wrong");
        }
        String deviceName = (String) oConfig.getValue();
        // 设备名称不为空，校验是否包含特殊字符
        if (StringUtils.isNotBlank(deviceName)) {
            ComplexResult ret  = FluentValidator.checkAll()
                    .failFast()
                    .on(deviceName, new IsStringWithinLengthRangeValidator("deviceName",0,64,true))
                    .doValidate()
                    .result(toComplex());
            if(!ret.isSuccess()){
                log.error("设备名称参数异常{}",ret);
                throw new CommonException(400,"parameter.incorrect",ret);
            }
        }
        // 更新数据库设备名称
        Predicate predicate = QDevice.device.sn.eq(sn);
        predicate = ((BooleanExpression) predicate).and(QDevice.device.tenantId.eq(oserviceOperator.getTenantId()));
        jpaQueryFactory.update(QDevice.device)
                .set(QDevice.device.name, deviceName)
                .where(predicate).execute();
        DeviceConfig deviceConfig = new DeviceConfig();
        deviceConfig.setId(UUIDUtil.uuid());
        deviceConfig.setSn(sn);
        deviceConfig.setParamKey(UUIDUtil.uuid());
        deviceConfig.setObjConfig(deviceSync.getObjConfig());
        deviceConfig.setTenantId(oserviceOperator.getTenantId());
        Long timestamp = System.currentTimeMillis();
        deviceConfig.setVersion(timestamp);
        deviceConfig.setCreateTime(timestamp);
        deviceConfig.setUpdateTime(timestamp);
        deviceConfig.setServiceType(DeviceConfig.ServiceType.SN.name());
        deviceConfigRepository.save(deviceConfig);
        // 调用message下发指令
        deviceConfigService.sendConfigToMessage(oserviceOperator, Lists.newArrayList(sn) ,oConfigGroup);
    }
}

