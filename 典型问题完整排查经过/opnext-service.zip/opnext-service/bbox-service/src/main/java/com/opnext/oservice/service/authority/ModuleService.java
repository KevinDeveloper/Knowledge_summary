package com.opnext.oservice.service.authority;

import com.opnext.oservice.domain.authority.role.Module;
import com.opnext.oservice.dto.authority.role.ModuleDTO;

import java.util.List;

/**
 * @author wanglu
 */
public interface ModuleService {
    /**
     * 获取全部菜单，用于角色编辑时选择权限
     * @return
     */
    List<ModuleDTO> getAllModule();

    /**
     * 获取主功能列表（用于日志查询时选择主功能）
     * @return
     * @throws Exception
     */
    List<Module> getMainFunction() throws Exception;

    /**
     * 通过角色获取菜单列表
     * @param roleId
     * @return
     */
    List<ModuleDTO> findModuleListByRoleId(long roleId);
}
