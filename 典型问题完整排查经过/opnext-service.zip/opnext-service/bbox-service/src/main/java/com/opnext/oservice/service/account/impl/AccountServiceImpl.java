package com.opnext.oservice.service.account.impl;

import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.controller.authority.AuthorizationController;
import com.opnext.oservice.domain.account.Account;
import com.opnext.oservice.domain.tenant.Tenant;
import com.opnext.oservice.dto.PageFeign;
import com.opnext.oservice.dto.authority.AuthorityDTO;
import com.opnext.oservice.feign.UserCenterFeign;
import com.opnext.oservice.service.account.AccountService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author wanglu
 */
@Service(value = "accountService")
@Slf4j
public class AccountServiceImpl implements AccountService {

    @Resource
    private UserCenterFeign userCenter;

    @Override
    public Page<Account> getAccountPage(Object... urlVariables)throws Exception {
        CommonResponse<PageFeign<Account>> pageFeign = userCenter.getAccountPage(urlVariables);
        if (pageFeign.getEntity() instanceof Page){
            return (Page<Account>)pageFeign.getEntity();
        }
        Page<Account> accountPage = PageFeign.localPageToSpringPage(pageFeign.getEntity());
        return accountPage;
    }

    @Override
    public Boolean verifyPassword(Account account)throws Exception{
        CommonResponse<Boolean> entityResponse = userCenter.verifyPassword(account);
        return entityResponse.getEntity();
    }

    @Override
    public List<AuthorityDTO> getAuthorityAccountList(Object... urlVariables)throws Exception {
        CommonResponse<PageFeign<AuthorityDTO>> entityResponse = userCenter.getAuthorityAccountPage(urlVariables);
        return entityResponse.getEntity().getContent();
    }

    @Override
    public List<Account> getAccountList(Object... urlVariables)throws Exception {
        CommonResponse<PageFeign<Account>> entityResponse =userCenter.getAccountPage(urlVariables);
        return entityResponse.getEntity().getContent();
    }

    @Override
    public Account addAccount(Account account) throws Exception{
        CommonResponse<Account> entityResponse =userCenter.addAccount(account);
        return entityResponse.getEntity();
    }

    @Override
    public ResponseEntity modifyAccount(Account account)throws Exception{
        CommonResponse entityResponse =userCenter.modifyAccount(account);
        return ResponseEntity.ok(entityResponse);
    }

    @Override
    public List<Long> changeAccountStatus(AuthorizationController.ChangeAccountStatusParam changeAccountStatusParam)throws Exception{
        CommonResponse<List<Long>> entityResponse =userCenter.changeAccountStatus(changeAccountStatusParam);
        return entityResponse.getEntity();
    }

    @Override
    public ResponseEntity deleteAccount(Map paramMap) throws Exception{
        CommonResponse entityResponse =userCenter.deleteAccount(paramMap);
        return ResponseEntity.ok(entityResponse);
    }

    @Override
    public Tenant getTenantById(long id) throws Exception{
        CommonResponse<Tenant> entityResponse = userCenter.getTenantById(id);
        return entityResponse.getEntity();
    }
}
