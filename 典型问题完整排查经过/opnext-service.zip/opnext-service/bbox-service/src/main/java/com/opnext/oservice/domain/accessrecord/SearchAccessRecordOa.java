package com.opnext.oservice.domain.accessrecord;

import lombok.Data;

/**
 * @author tianzc
 */
@Data
public class SearchAccessRecordOa {

    private boolean regexName = false;
    private String name;
    private boolean regexPersonNo = false;
    private String personNo;
    private Long startTime;
    private Long endTime;
    private String sn;
    private String resultType;


}
