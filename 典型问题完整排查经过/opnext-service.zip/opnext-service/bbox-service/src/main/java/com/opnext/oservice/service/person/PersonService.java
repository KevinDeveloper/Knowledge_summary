package com.opnext.oservice.service.person;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.beebox.push.event.Event;
import com.opnext.bboxdomain.batch.BatchResult;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.domain.PersonType;
import com.opnext.oservice.domain.MultipartFileResp;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.organization.Organization;
import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.domain.person.PersonConfigVo;
import com.opnext.oservice.domain.person.PersonPropertysSetType;
import com.opnext.oservice.domain.person.PersonVo;
import com.opnext.oservice.dto.person.PersonProjection;
import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午5:05 18/5/7
 */
public interface PersonService {

    /**
     * 根据id获取人员信息
     *
     * @param id
     * @return
     */
    Person getOne(String id,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 分页获取人员列表
     *
     * @param pageable
     * @param name
     * @return
     * @throws Exception
     */
    Page getPage(Pageable pageable, String name, String no, Integer organizationId, RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 分页获取人员列表（list）
     *
     * @param pageable
     * @param organizationId
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    List<PersonProjection> getList(Pageable pageable, Integer organizationId, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 根据组织id获取组织下人员个数
     * @param organizationId
     * @return
     * @throws Exception
     */
    List<Map<String,Long>> getPersonCountByOrgId(Integer[] organizationId, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 批量保存人员信息
     *
     * @param personList
     * @throws Exception
     */
    List<Person> batchSave(List<Person> personList, PersonType personType,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * @param person
     * @param hasExtends 是否校验扩展字段
     * @return
     */
    ComplexResult fluentValidatorPerson(Person person, boolean hasExtends) throws Exception;

    /**
     * 保存人员信息
     *
     * @param person
     * @throws Exception
     */
    Person save(Person person,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 更新人员信息
     *
     * @param person
     * @throws Exception
     */
    void update(Person person,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 根据id删除人员
     *
     * @param id
     * @throws Exception
     */
    void delete(String id) throws Exception;

    /**
     * 根据租户id和参数库id修改为空
     *
     * @param groupId
     * @param tenantId
     * @return
     */
    long deleteGroupByTenantIdAndGroupId(String groupId, Long tenantId) throws Exception;

    /**
     * 批量删除人员
     *
     * @param ids
     * @throws Exception
     */
    void delete(String[] ids) throws Exception;




    /**
     * 返回当前租户下某个字段的全部集合
     *
     * @param tenantId
     * @return
     * @throws Exception
     */
    Set<String> getAllPropertysInTenantId(long tenantId, PersonPropertysSetType propertysSetType) throws Exception;


    /**
     * 根据动态字段转换下载模板
     *
     * @param configs
     * @return
     */
    List<PersonConfigVo> formatPersonConfig(List<PersonConfigVo> configs);


    /**
     * 获取需要导出的人员
     *
     * @param tenantId
     * @param name
     * @param no
     * @param organizationId
     * @return
     * @throws Exception
     */
    List<PersonVo> getExportPersons(long tenantId, String name, String no, Integer organizationId) throws Exception;

    /**
     * 导出人员并保存到excel
     *
     * @param personVos
     * @param personConfigVos
     * @param fileExcelPath
     * @throws Exception
     */
    void exportAndSaveExcelPersons(List<PersonVo> personVos, List<PersonConfigVo> personConfigVos, String fileExcelPath) throws Exception;


    /**
     * 下载并压缩待导出的人员图片
     *
     * @param personVos
     * @param avatarsDirPath
     * @param allAvatarsZipPath
     * @throws Exception
     */
    void downloadAndZipPersonAvatars(List<PersonVo> personVos, String avatarsDirPath, String allAvatarsZipPath) throws Exception;

    /**
     * 获取已经格式转换后的人员字段配置列表
     *
     * @param tenantId
     * @return
     * @throws Exception
     */
    List<PersonConfigVo> getFormatPersonConfigs(long tenantId) throws Exception;


    /**
     * 根据组织ids 下是否有人员, 《=0 表示没有，》0 表示有
     *
     * @param tenantId
     * @param orgIdList
     * @return
     * @throws Exception
     */
    int getPersonByOrgIds(long tenantId, List<Integer> orgIdList) throws Exception;

    //===========================================批量导入

    /**
     * 批量导入 - 解析数据，导入结果，预览
     *
     * @param pageable
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    Page batchImportDataPage(Pageable pageable, OserviceOperator oserviceOperator, RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 批量导入 - 解析数据, 入库
     *
     * @param oserviceOperator
     * @throws Exception
     */
    void batchImportDataInsert(OserviceOperator oserviceOperator, RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 将某行数据转换成person实体
     *
     * @param rowDataMap
     * @param configs
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    PersonVo getPersonByExcelRowMap(Map<Integer, String> rowDataMap, List<PersonConfigVo> configs, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 获取人员的照片检测结果
     *
     * @param personVo
     * @param imgFileResultMap
     * @return
     * @throws Exception
     */
    PersonVo getPersonVoWithAvatorFile(PersonVo personVo, Map<String, MultipartFileResp> imgFileResultMap) throws Exception;


    /**
     * 综合格式校验
     *
     * @param personVo
     * @return
     */
    PersonVo checkValidatorPersonVo(PersonVo personVo);

    /**
     * 检测人员属性唯一性
     *
     * @param personVo
     * @param defaultPwd
     * @param configs
     * @param rootOrg
     * @param orgNameForIdMap
     * @param groupNameForIdMap
     * @param setNo
     * @return
     */
    PersonVo checkUniquePersonVo(PersonVo personVo, String defaultPwd, List<PersonConfigVo> configs, Organization rootOrg, Map<String, Integer> orgNameForIdMap, Map<String, String> groupNameForIdMap, Set<String> setNo);

    /**
     * 统计人员批量插入情况
     *
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    BatchResult batchAddResultCount(OserviceOperator oserviceOperator) throws Exception;


    /**
     * 获取需要导出的人员数量
     * @param tenantId
     * @param name
     * @param no
     * @param organizationId
     * @return
     * @throws Exception
     */
    long getExportPersonsCount(long tenantId, String name, String no, Integer organizationId) throws Exception;

    /**
     * 根据openId查询人员id
     * @param openId
     * @param tenantId
     * @return
     * @throws Exception
     */
    Optional<String> getPersonIdByOpenId(String openId, long tenantId) throws Exception;

    /**
     * 根据openId查询人员对象
     * @param openId
     * @param tenantId
     * @return
     * @throws Exception
     */
    Optional<Person> getPersonByOpenId(String openId, long tenantId) throws Exception;
    /**
     * 通过人员编号查询人员详情
     * @param predicate
     * @param openId
     * @return
     * @throws Exception
     */
    String updatePersonOpenId(Predicate predicate, String openId) throws Exception;

    /**
     * 修改人员信息
     * @param person
     * @throws Exception
     */
    void updatePerson(Person person) throws Exception;

    /**
     * 通过编号获取人员详情
     * @param no
     * @param tenantId
     * @return
     * @throws Exception
     */
    Person getPersonByNo(String no,long tenantId) throws Exception;

    /**
     * 通过no和密码验证用户是否存在
     * @param no
     * @param password
     * @param tenantId
     * @return
     * @throws Exception
     */
    Person checkPassword(String no,String password,long tenantId) throws Exception;

    /**
     * 推送人员
     *
     * @param obj       人员信息
     * @param eventType 事件类型
     */
    void pushPerson(Object obj, Event.EventType eventType, Long tenantId) throws Exception;
}
