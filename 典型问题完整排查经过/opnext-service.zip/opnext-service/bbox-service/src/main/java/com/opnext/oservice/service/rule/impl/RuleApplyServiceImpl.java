package com.opnext.oservice.service.rule.impl;

import com.google.common.collect.Sets;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.domain.PersonType;
import com.opnext.domain.message.Command;
import com.opnext.domain.response.IDRuleResp;
import com.opnext.omessage.support.CallBackBuilder;
import com.opnext.omessage.support.MessageContext;
import com.opnext.omessage.support.SimpleMessageTemplate;
import com.opnext.oservice.domain.command.BusinessType;
import com.opnext.oservice.domain.organization.QOrganization;
import com.opnext.oservice.domain.person.PersonVo;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.domain.person.QPersonVo;
import com.opnext.oservice.domain.rule.OrgPerson;
import com.opnext.oservice.domain.rule.QRuleApply;
import com.opnext.oservice.domain.rule.Rule;
import com.opnext.oservice.feign.OMessageFeign;
import com.opnext.oservice.repository.ComplicateQueryDslDao;
import com.opnext.oservice.service.rule.RuleApplyService;
import com.opnext.oservice.service.rule.RuleApplySyncService;
import com.opnext.oservice.service.rule.RuleDeviceService;
import com.opnext.oservice.service.rule.RuleService;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.*;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 15:57
 */
@Service
@Slf4j
public class RuleApplyServiceImpl implements RuleApplyService {
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    private ComplicateQueryDslDao complicateQueryDslDao;
    @Autowired
    private RuleService ruleService;
    @Autowired
    private RuleApplySyncService ruleApplySyncService;
    @Autowired
    private RuleDeviceService ruleDeviceService;
    @Resource
    private OMessageFeign oMessageFeign;
    @Value("${server.context-path}")
    private String serverPath;
    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 查询规则下人员信息
     *
     * @param predicate 查询条件
     * @param pageable  分页信息
     * @return
     */
    @Override
    public Page<PersonVo> getPersonByRuleId(Predicate predicate, Pageable pageable) {
        QPerson qPerson = QPerson.person;
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        QOrganization qOrganization = QOrganization.organization;
        predicate = ((BooleanExpression) predicate).and(qPerson.organizationId.eq(qOrganization.id));
        LinkedList<Path> linkedList = new LinkedList<>();
        linkedList.add(qPerson);
        linkedList.add(QPersonVo.personVo.organization);
        return complicateQueryDslDao.find(jpaQueryFactory
                        .select(qPerson, qOrganization.name.as(QPersonVo.personVo.organization))
                        .from(qPerson, qRuleApply, qOrganization)
                        .where(predicate)
                        .orderBy(qPerson.no.desc())
                , pageable, PersonVo.class, linkedList);
    }

    /**
     * 根据规则ID获取人员ID集合
     *
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return
     */
    @Override
    public List<String> getPersonIdByRuleId(Integer ruleId, Long tenantId) {
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        return jpaQueryFactory.select(qRuleApply.personId)
                .from(qRuleApply)
                .where(qRuleApply.ruleId.eq(ruleId).and(qRuleApply.tenantId.eq(tenantId)))
                .fetch();
    }

    /**
     * 根据规则ID获取组织ID集合
     *
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return
     */
    @Override
    public List<Integer> getOrganizationIdByRuleId(Integer ruleId, Long tenantId) {
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        return jpaQueryFactory.select(qRuleApply.organizationId)
                .from(qRuleApply)
                .where(qRuleApply.ruleId.eq(ruleId).and(qRuleApply.tenantId.eq(tenantId)))
                .fetch();
    }

    /**
     * 根据规则ID获取人员所属的组织ID集合（去重）
     *
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return
     */
    @Override
    public List<Integer> getPersonOrgIdByRuleId(Integer ruleId, Long tenantId) {
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        QPerson qPerson = QPerson.person;
        return jpaQueryFactory.selectDistinct(qPerson.organizationId)
                .from(qRuleApply, qPerson)
                .where(qRuleApply.personId.eq(qPerson.id).and(qRuleApply.ruleId.eq(ruleId)).and(qRuleApply.tenantId.eq(tenantId)))
                .fetch();
    }

    /**
     * 获取规则集合下人员的数量
     *
     * @param ruleIdList 规则集合
     * @return
     */
    @Override
    public Map<Integer, Long> getPersonCountMap(List<Integer> ruleIdList) {
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        List<Tuple> tuplesPersonCount = jpaQueryFactory
                .select(qRuleApply.ruleId, qRuleApply.personId.count())
                .from(qRuleApply)
                .where(qRuleApply.ruleId.in(ruleIdList).and(qRuleApply.personId.isNotNull()))
                .groupBy(qRuleApply.ruleId)
                .fetch();
        Map<Integer, Long> personCountMap = new HashMap<>(tuplesPersonCount.size());
        tuplesPersonCount.forEach(tuple -> personCountMap.put(tuple.get(qRuleApply.ruleId), tuple.get(1, Long.class)));

        //查询组织规则的人员数量
        QPerson qPerson = QPerson.person;
        List<Tuple> tuplesOrgPersonCount = jpaQueryFactory
                .select(qRuleApply.ruleId, qPerson.id.count())
                .from(qRuleApply, qPerson)
                .where(qRuleApply.ruleId.in(ruleIdList)
                        .and(qRuleApply.organizationId.isNotNull())
                        .and(qRuleApply.organizationId.eq(qPerson.organizationId))
                        .and(qPerson.type.eq(PersonType.FREQUENTER)))
                .groupBy(qRuleApply.ruleId)
                .fetch();
        tuplesOrgPersonCount.forEach(tuple -> personCountMap.put(tuple.get(qRuleApply.ruleId), tuple.get(1, Long.class)));
        return personCountMap;
    }


    /**
     * 添加规则应用信息
     *
     * @param rule             规则
     * @param oserviceOperator 当前操作人信息
     */
    @Override
    public void addRuleApply(Rule rule, OserviceOperator oserviceOperator) {
        if (rule.getType() == Rule.RuleType.PERSON.ordinal()) {
            if (CollectionUtils.isNotEmpty(rule.getOrganizationIds())) {
                List<String> personList = ruleService.orgIdToPersonId(rule.getOrganizationIds(), oserviceOperator.getTenantId());
                rule.getPersonIds().removeAll(personList);
                rule.getPersonIds().addAll(personList);
            }
            addRuleApplyWithPersonId(rule.getId(), rule.getPersonIds(), oserviceOperator);
        } else if (rule.getType() == Rule.RuleType.ORGNIZATION.ordinal()) {
            addRuleApplyWithOrganizationId(rule.getId(), rule.getOrganizationIds(), oserviceOperator);
        }
    }

    /**
     * 添加规则应用信息
     *
     * @param ruleId           规则ID
     * @param personIdList     应用规则的人员ID集合
     * @param oserviceOperator 当前操作人信息
     */
    @Override
    public void addRuleApplyWithPersonId(Integer ruleId, List<String> personIdList, OserviceOperator oserviceOperator) {
        StringBuilder sbSQLValue = new StringBuilder();
        String strInsertSQL = "insert into rule_apply (app_id, create_by, create_time, tenant_id, person_id, rule_id) values ";
        if (CollectionUtils.isNotEmpty(personIdList)) {
            for (int i = 0; i < personIdList.size(); i++) {
                sbSQLValue.append(String.format(",('%s', %d,NOW(), %d, '%s', %d)",
                        oserviceOperator.getAppId(),
                        oserviceOperator.getUserId(),
                        oserviceOperator.getTenantId(),
                        personIdList.get(i),
                        ruleId));
                if (i > 0 && i % 100 == 0) {
                    entityManager.createNativeQuery(strInsertSQL + sbSQLValue.toString().substring(1)).executeUpdate();
                    sbSQLValue = new StringBuilder();
                }
            }
            if (StringUtils.isNotBlank(sbSQLValue.toString())) {
                entityManager.createNativeQuery(strInsertSQL + sbSQLValue.toString().substring(1)).executeUpdate();
            }
        }
    }

    /**
     * 添加规则应用信息
     *
     * @param ruleId             规则ID
     * @param organizationIdList 应用规则的组织ID集合
     * @param oserviceOperator   当前操作人信息
     */
    @Override
    public void addRuleApplyWithOrganizationId(Integer ruleId, List<Integer> organizationIdList, OserviceOperator oserviceOperator) {
        StringBuilder sbSQLValue = new StringBuilder();
        String strInsertSQL = "insert into rule_apply (app_id, create_by, create_time, tenant_id, organization_id, rule_id) values ";
        if (CollectionUtils.isNotEmpty(organizationIdList)) {
            for (int i = 0; i < organizationIdList.size(); i++) {
                sbSQLValue.append(String.format(",('%s', %d,NOW(), %d, '%s', %d)",
                        oserviceOperator.getAppId(),
                        oserviceOperator.getUserId(),
                        oserviceOperator.getTenantId(),
                        organizationIdList.get(i),
                        ruleId));
                if (i > 0 && i % 100 == 0) {
                    entityManager.createNativeQuery(strInsertSQL + sbSQLValue.toString().substring(1)).executeUpdate();
                    sbSQLValue = new StringBuilder();
                }
            }
            if (StringUtils.isNotBlank(sbSQLValue.toString())) {
                entityManager.createNativeQuery(strInsertSQL + sbSQLValue.toString().substring(1)).executeUpdate();
            }
        }
    }

    /**
     * 从规则中移除人员
     *
     * @param ruleId           规则ID
     * @param personIds        需要移除人员ID集合
     * @param oserviceOperator 当前操作人信息
     * @param deviceSnList     发送的设备SN列表
     * @throws Exception
     */
    @Override
    public void removePersonFromRule(Integer ruleId, List<String> personIds, OserviceOperator oserviceOperator, List<String> deviceSnList) throws Exception {
        if (CollectionUtils.isEmpty(personIds)) {
            return;
        }
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        long lResult = jpaQueryFactory.delete(qRuleApply)
                .where(qRuleApply.personId.in(personIds)
                        .and(qRuleApply.personId.isNotNull())
                        .and(qRuleApply.ruleId.eq(ruleId))
                        .and(qRuleApply.tenantId.eq(oserviceOperator.getTenantId()))).execute();
        log.info(String.format("批量移除人员规则，人员数：%d，执行成功数：%d", personIds.size(), lResult));
        if (CollectionUtils.isEmpty(deviceSnList)) {
            return;
        }
        String commandId = ruleApplySyncService.insertApplySync(ruleId, IDRuleResp.OperationType.UNBIND, personIds);
        sendRuleApplyToDevice(deviceSnList, commandId, IDRuleResp.OperationType.UNBIND, oserviceOperator);
    }

    /**
     * 向规则中添加人员
     *
     * @param ruleId           规则ID
     * @param personIds        需要添加到规则的人员ID集合
     * @param oserviceOperator 当前操作人信息
     * @param deviceSnList     发送的设备SN列表
     * @throws Exception
     */
    @Override
    public void addPersonToRule(Integer ruleId, List<String> personIds, OserviceOperator oserviceOperator, List<String> deviceSnList) throws Exception {
        if (CollectionUtils.isEmpty(personIds)) {
            return;
        }
        //添加规则应用信息
        addRuleApplyWithPersonId(ruleId, personIds, oserviceOperator);
        if (CollectionUtils.isEmpty(deviceSnList)) {
            return;
        }
        //添加到同步表
        String commandId = ruleApplySyncService.insertApplySync(ruleId, IDRuleResp.OperationType.BIND, personIds);
        sendRuleApplyToDevice(deviceSnList, commandId, IDRuleResp.OperationType.BIND, oserviceOperator);
    }

    /**
     * 将组织移除规则
     *
     * @param ruleId           规则ID
     * @param organizationIds  需要移除规则的组织ID集合
     * @param oserviceOperator 当前操作人信息
     * @param deviceSnList     发送的设备SN列表
     * @throws Exception
     */
    @Override
    public void removeOrgFromRule(Integer ruleId, List<Integer> organizationIds, OserviceOperator oserviceOperator, List<String> deviceSnList) throws Exception {
        if (CollectionUtils.isEmpty(organizationIds)) {
            return;
        }
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        long lResult = jpaQueryFactory.delete(qRuleApply)
                .where(qRuleApply.organizationId.in(organizationIds)
                        .and(qRuleApply.organizationId.isNotNull())
                        .and(qRuleApply.ruleId.eq(ruleId))
                        .and(qRuleApply.tenantId.eq(oserviceOperator.getTenantId())))
                .execute();
        log.info(String.format("批量移除组织规则，组织数：%d，执行成功数：%d", organizationIds.size(), lResult));
        if (CollectionUtils.isEmpty(deviceSnList)) {
            return;
        }
        List<String> personIdList = ruleService.orgIdToPersonId(organizationIds, oserviceOperator.getTenantId());
        if (CollectionUtils.isEmpty(personIdList)) {
            return;
        }
        String commandId = ruleApplySyncService.insertApplySync(ruleId, IDRuleResp.OperationType.UNBIND, personIdList);
        sendRuleApplyToDevice(deviceSnList, commandId, IDRuleResp.OperationType.UNBIND, oserviceOperator);
    }

    /**
     * 向规则中添加组织
     *
     * @param ruleId           规则ID
     * @param organizationIds  需要添加到规则的组织ID集合
     * @param oserviceOperator 当前操作人信息
     * @param deviceSnList     发送的设备SN列表
     * @throws Exception
     */
    @Override
    public void addOrgToRule(Integer ruleId, List<Integer> organizationIds, OserviceOperator oserviceOperator, List<String> deviceSnList) throws Exception {
        if (CollectionUtils.isEmpty(organizationIds)) {
            return;
        }
        //添加规则应用信息
        addRuleApplyWithOrganizationId(ruleId, organizationIds, oserviceOperator);
        if (CollectionUtils.isEmpty(deviceSnList)) {
            return;
        }
        List<String> personIdList = ruleService.orgIdToPersonId(organizationIds, oserviceOperator.getTenantId());
        if (CollectionUtils.isEmpty(personIdList)) {
            return;
        }
        //添加到同步表
        String commandId = ruleApplySyncService.insertApplySync(ruleId, IDRuleResp.OperationType.BIND, personIdList);
        sendRuleApplyToDevice(deviceSnList, commandId, IDRuleResp.OperationType.BIND, oserviceOperator);
    }

    /**
     * 向设备发送获取人员规则信息
     *
     * @param deviceSnList     设备SN集合
     * @param commandId        批次ID
     * @param operationType    操作类型
     * @param oserviceOperator 当前登录人信息
     */
    @Override
    public void sendRuleApplyToDevice(List<String> deviceSnList, String commandId, IDRuleResp.OperationType operationType, OserviceOperator oserviceOperator) throws Exception {
        if (StringUtils.isBlank(commandId)) {
            log.debug("commandId is null");
            return;
        }
        if (deviceSnList == null || deviceSnList.size() == 0) {
            log.debug("deviceSnList is null");
            return;
        }
        SimpleMessageTemplate template = SimpleMessageTemplate
                .operator(String.valueOf(oserviceOperator.getTenantId()), String.valueOf(oserviceOperator.getLoginName()))
                .appId(oserviceOperator.getAppId())
                .scope(Sets.newHashSet(deviceSnList));
        String terminalGatewayHost = "";
        String strCallBack = String.format("%s%s/api/devapi/getRulePersonIds/{workflowId}/{commandId}/{requestId}/%s?page=0"
                , terminalGatewayHost
                , serverPath
                , commandId);
        String strFeedBack = String.format("%s%s/api/devapi/feedback/{workflowId}/{commandId}/{requestId}/%s"
                , terminalGatewayHost
                , serverPath
                , BusinessType.PERSON);
        Command.CallBack feedBack = CallBackBuilder.ready().url(strFeedBack).method(Command.Method.POST).build();
        MessageContext context = null;
        if (operationType == IDRuleResp.OperationType.BIND) {
            context = template.bindRule(strCallBack);
        } else if (operationType == IDRuleResp.OperationType.UNBIND) {
            context = template.unbindRule(strCallBack);
        }
        if (context != null) {
            context.setFeedBack(feedBack);
            List<String> resultList = oMessageFeign.send(context);
            log.debug(operationType.name() + ",sendRule，Result:" + String.valueOf(resultList));
        }
    }

    /**
     * 删除人员时调用此接口
     *
     * @param personIdList 人员ID集合
     * @param tenantId     租户ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void whenDelPerson(List<String> personIdList, long tenantId) {
        log.info("删除人员whenDelPerson");
        if (CollectionUtils.isEmpty(personIdList)) {
            log.info("personIdList为空");
            return;
        }
        //删除规则人员关联表
        //指令下发由人员管理发送，此接口仅删除人员和规则的关联
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        jpaQueryFactory.delete(qRuleApply)
                .where(qRuleApply.personId.in(personIdList)
                        .and(qRuleApply.personId.isNotNull())
                        .and(qRuleApply.tenantId.eq(tenantId)))
                .execute();
    }

    /**
     * 向组织添加人员
     *
     * @param personIdList     人员ID集合
     * @param organizationId   组织ID
     * @param oserviceOperator 当前操作人信息
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void whenAddOrg(List<String> personIdList, int organizationId, OserviceOperator oserviceOperator) throws Exception {
        log.info("向组织添加人员whenAddOrg,orgId:{}", organizationId);
        addOrDelPerson(personIdList, organizationId, IDRuleResp.OperationType.BIND, oserviceOperator);
    }

    /**
     * 向组织添加人员
     *
     * @param mapOrgPersonId   组织ID和人员ID集合
     * @param oserviceOperator 当前操作人信息
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void whenAddOrg(Map<Integer, List<String>> mapOrgPersonId, OserviceOperator oserviceOperator) throws Exception {
        log.info("向组织添加人员whenAddOrg");
        if (MapUtils.isEmpty(mapOrgPersonId)) {
            return;
        }
        for (Map.Entry<Integer, List<String>> entry : mapOrgPersonId.entrySet()) {
            if (CollectionUtils.isEmpty(entry.getValue())) {
                continue;
            }
            addOrDelPerson(entry.getValue(), entry.getKey(), IDRuleResp.OperationType.BIND, oserviceOperator);
        }
    }

    /**
     * 删除规则中的组织
     *
     * @param organizationIdList 组织ID集合
     * @param oserviceOperator   当前操作人
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void whenDelOrg(List<Integer> organizationIdList, OserviceOperator oserviceOperator) throws Exception {
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        List<Integer> ruleIdList = jpaQueryFactory.selectDistinct(qRuleApply.ruleId)
                .from(qRuleApply)
                .where(qRuleApply.organizationId.in(organizationIdList)
                        .and(qRuleApply.organizationId.isNotNull())
                        .and(qRuleApply.tenantId.eq(oserviceOperator.getTenantId())))
                .fetch();
        if (CollectionUtils.isNotEmpty(ruleIdList)) {
            for (Integer ruleId : ruleIdList) {
                List<String> deviceSnList = ruleDeviceService.getSnsByRuleId(ruleId);
                if (CollectionUtils.isEmpty(deviceSnList)) {
                    continue;
                }
                removeOrgFromRule(ruleId, organizationIdList, oserviceOperator, deviceSnList);
            }
        }
        //删除规则和组织关联表
        jpaQueryFactory.delete(qRuleApply)
                .where(qRuleApply.organizationId.in(organizationIdList)
                        .and(qRuleApply.organizationId.isNotNull())
                        .and(qRuleApply.tenantId.eq(oserviceOperator.getTenantId())))
                .execute();
    }

    /**
     * 组织内人员变更
     *
     * @param personId         人员ID
     * @param orgId        原组织ID
     * @param targetOrdId          现组织ID
     * @param oserviceOperator 当前操作人
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void whenModifyOrg(String personId, Integer orgId, Integer targetOrdId, OserviceOperator oserviceOperator) throws Exception {
        List<String> personIds = new ArrayList<>();
        personIds.add(personId);
        whenEditPersonOrg(personIds,orgId,targetOrdId,oserviceOperator);
    }

    /**
     * 批量修改人员组织接口
     *
     * @param personIds        人员ids
     * @param orgId            原组织id
     * @param targetOrdId      新的目标组织
     * @param oserviceOperator 当前操作人
     * @throws Exception
     */
    @Override
    public void whenEditPersonOrg(List<String> personIds, Integer orgId, Integer targetOrdId, OserviceOperator oserviceOperator) throws Exception {
        if (Objects.isNull(orgId) || Objects.isNull(targetOrdId)) {
            return;
        }
        if (orgId.equals(targetOrdId)) {
            return;
        }
        if (CollectionUtils.isEmpty(personIds)) {
            return;
        }
        addOrDelPerson(personIds, orgId, IDRuleResp.OperationType.UNBIND, oserviceOperator);
        addOrDelPerson(personIds, targetOrdId, IDRuleResp.OperationType.BIND, oserviceOperator);
    }

    /**
     * 组织内人员添加或删除
     *
     * @param personIdList     人员集合ID
     * @param organizationId   组织ID
     * @param operationType    BIND 添加 ,UNBIND 删除;
     * @param oserviceOperator 当前操作人信息
     * @throws Exception
     */
    private void addOrDelPerson(List<String> personIdList, int organizationId, IDRuleResp.OperationType operationType, OserviceOperator oserviceOperator) throws Exception {
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        List<Integer> ruleIdList = jpaQueryFactory.selectDistinct(qRuleApply.ruleId)
                .from(qRuleApply)
                .where(qRuleApply.organizationId.eq(organizationId)
                        .and(qRuleApply.organizationId.isNotNull())
                        .and(qRuleApply.tenantId.eq(oserviceOperator.getTenantId())))
                .fetch();
        if (CollectionUtils.isEmpty(ruleIdList)) {
            return;
        }
        for (Integer ruleId : ruleIdList) {
            List<String> deviceSnList = ruleDeviceService.getSnsByRuleId(ruleId);
            if (CollectionUtils.isEmpty(deviceSnList)) {
                continue;
            }
            //添加到同步表
            String commandId = ruleApplySyncService.insertApplySync(ruleId, operationType, personIdList);
            sendRuleApplyToDevice(deviceSnList, commandId, operationType, oserviceOperator);
        }
    }

    /**
     * 根据人员ID集合查询按组织分组的人员ID
     *
     * @param personIdList 人员ID集合
     * @param tenantId     租户ID
     * @return
     */
    private List<OrgPerson> getOrgPersonIdList(List<String> personIdList, long tenantId) {
        if (CollectionUtils.isEmpty(personIdList)) {
            return null;
        }
        String sql = "SELECT organization_id,GROUP_CONCAT(id) as id FROM person WHERE id IN (:personIds) and tenant_id=:tenantId and type=0 GROUP BY organization_id";
        Query lQuery = entityManager.createNativeQuery(sql, OrgPerson.class).setParameter("personIds", personIdList).setParameter("tenantId", tenantId);
        return lQuery.getResultList();
    }

}
