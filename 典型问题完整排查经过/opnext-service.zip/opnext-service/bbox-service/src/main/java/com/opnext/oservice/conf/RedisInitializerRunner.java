package com.opnext.oservice.conf;

import com.opnext.bboxsupport.util.RedisCommonKeyUtil;
import com.opnext.oservice.domain.authority.role.Role;
import com.opnext.oservice.service.authority.RoleService;
import com.opnext.oservice.service.base.BaseRedisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;

import java.util.List;
import java.util.stream.Collectors;

public class RedisInitializerRunner implements ApplicationRunner {
    @Autowired
    BaseRedisService redisService;
    @Autowired
    RoleService roleService;

    @Override
    public void run(ApplicationArguments args) throws Exception {
        //pub_resources
        redisService.deleteKey(RedisCommonKeyUtil.PUB_RESOURCES);

        //roleResource_{roleId}
        List<Role> roleList = roleService.getRolesInAllTenant();
        List<String> roleIds = roleList.stream().map(role ->
                RedisCommonKeyUtil.ROLE_RESOURCE+role.getId()).collect(Collectors.toList());
        redisService.deleteByKeys(roleIds);
    }
}
