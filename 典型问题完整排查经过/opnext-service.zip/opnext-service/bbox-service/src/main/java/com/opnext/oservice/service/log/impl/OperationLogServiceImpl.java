package com.opnext.oservice.service.log.impl;

import com.opnext.oservice.domain.log.OperationLog;
import com.opnext.oservice.repository.log.OperationLogRepository;
import com.opnext.oservice.service.log.OperationLogService;
import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
/**
 * @author wanglu
 * @date 2018/07/19
 */
@Slf4j
@Service
public class OperationLogServiceImpl implements OperationLogService {
    @Autowired
    private OperationLogRepository operationLogRepository;
    @Override
    public Page<OperationLog> findAll(Predicate predicate, Pageable pageable) {
        return operationLogRepository.findAll(predicate,pageable);
    }

    @Override
    public void save(OperationLog operationLog) {
        operationLogRepository.save(operationLog);
    }

}
