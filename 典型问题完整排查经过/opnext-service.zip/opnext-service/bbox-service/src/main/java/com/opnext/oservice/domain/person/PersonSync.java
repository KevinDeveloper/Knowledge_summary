package com.opnext.oservice.domain.person;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * 人员同步类
 * @author tianzc
 */
@Data
@Entity
@Table(name = "person_sync")
public class PersonSync {
    @Id
    @GeneratedValue
    private Integer id;
    @Column(name = "no")
    private String no;
    @Column(name = "person_id")
    private String personId;

    @Column(name = "tenant_id")
    private Long tenantId;
    @Column(name = "sync_version")
    private Long syncVersion;
    @Column(name="create_time")
    @CreatedDate
    private Date createTime;
    @Column(name = "operator_id")
    private Long operatorId;
    @Column(name = "operator_name")
    private String operatorName;
    /**
     * 操作类型
     */
    @Column(name = "operation_type")
    private OperationType operationType;

}
