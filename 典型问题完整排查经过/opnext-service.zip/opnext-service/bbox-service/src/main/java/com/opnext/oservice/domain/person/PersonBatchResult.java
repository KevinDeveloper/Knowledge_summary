package com.opnext.oservice.domain.person;

import org.apache.commons.lang3.StringUtils;

/**
 * @ClassName: PersonBatchResult
 * @Description:
 * @Author: Kevin
 * @Date: 2018/6/5 13:17
 */
public interface PersonBatchResult {

    String BATCH_ADD_RESULT_KEY="batch_add_result_key";
    String BATCH_ADD_RESULT_SUCCESS="batch_add_result_success";
    String BATCH_ADD_RESULT_MAYFAIL="batch_add_result_may_fail";

    /**初始化扩展字段map的大小*/
    int PERSON_VARIABLE_MAP_SIZE_INIT = 16;
    /**单个导入数据的量*/
    int PERSON_BATCH_INSERT_SIZE = 200;
    /**批量导入缓存的时间（小时）*/
    int BATCH_ADD_PERSONVOS_EXIST_TIME_HOUR = 1;

    /**设置单次导出人员最大数量*/
    int EXPORT_PERSON_SIZE_MAX=5000;

    String SEX_MALE="male";
    String SEX_FEMALE="female";

    /**
     * 人员字段名
     */
    String PERSON_PROPERTY_NAME_SEX="sex";
    String PERSON_PROPERTY_NAME_HIRE_DATE ="hiredate";


    /**
     * 批量导入失败原因格式包装
     *
     * @param reason
     * @return
     */
    static String formatBatchAddResult(String reason) {
        String formatResult = "";
        if (StringUtils.isNotBlank(reason)) {
            formatResult = "[" + reason + "]";
        }
        return formatResult;
    }

}
