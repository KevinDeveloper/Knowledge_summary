package com.opnext.oservice;

import com.beebox.push.common.amqp.PushClient;
import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opnext.bboxsupport.advise.CommonExceptionSupport;
import com.opnext.domain.OPNextConstant;
import com.opnext.oservice.conf.RedisInitializerRunner;
import com.opnext.oservice.repository.ComplicateQueryDao;
import com.opnext.oservice.repository.ComplicateQueryDslDao;
import com.querydsl.jpa.impl.JPAQueryFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.FanoutExchange;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

import javax.persistence.EntityManager;

/**
 * @author wanglu
 */
@EnableJpaAuditing
@EnableDiscoveryClient
@EnableFeignClients
@EnableAsync
@EnableScheduling
@SpringBootApplication(scanBasePackages = {
        "com.opnext.oservice",
        "com.opnext.bboximage",
        "com.opnext.bboxsupport",
        "com.opnext.omessage.support",
        "com.opnext.bboxsms",
        "com.opnext.license"
})
public class OServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(OServiceApplication.class, args);
    }

    @Bean
    @SuppressWarnings("SpringJavaAutowiringInspection")
    JPAQueryFactory jpaQueryFactory(EntityManager entityManager) {
        return new JPAQueryFactory(entityManager);
    }

    @Bean
    ComplicateQueryDao complicateQueryDao() {
        return new ComplicateQueryDao() {
        };
    }

    @Bean
    ComplicateQueryDslDao complicateQueryDslDao() {
        return new ComplicateQueryDslDao() {
        };
    }

    @Bean
    CommonExceptionSupport commonExceptionAdvise() {
        return new CommonExceptionSupport();
    }

    @Bean
    public FanoutExchange defaultFanoutExchange() {
        return new FanoutExchange(OPNextConstant.PERSON_ACCESS_RECORD_EXCHANGE_NAME);
    }

    @Bean
    public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory) {
        RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory);

        // 使用Jackson2JsonRedisSerialize 替换默认序列化
        Jackson2JsonRedisSerializer jackson2JsonRedisSerializer = new Jackson2JsonRedisSerializer(Object.class);

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.setVisibility(PropertyAccessor.ALL, JsonAutoDetect.Visibility.ANY);
        objectMapper.enableDefaultTyping(ObjectMapper.DefaultTyping.NON_FINAL);

        jackson2JsonRedisSerializer.setObjectMapper(objectMapper);
        // 设置value的序列化规则和 key的序列化规则
        redisTemplate.setValueSerializer(jackson2JsonRedisSerializer);
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.afterPropertiesSet();
        return redisTemplate;
    }


    /**
     * 消息推送
     *
     * @param amqpTemplate mq模版
     * @return
     */
    @Bean
    public PushClient pushClient(AmqpTemplate amqpTemplate) {
        return new PushClient(amqpTemplate);
    }


    @Bean
    public RedisInitializerRunner initRedis(){
        return new RedisInitializerRunner();
    }
}
