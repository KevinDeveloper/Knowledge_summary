package com.opnext.oservice.conf;

import com.opnext.oservice.interceptor.PermissionHandlerInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * @author wanglu
 */
@Configuration
public class CommonWebConfig extends WebMvcConfigurerAdapter {

    @Bean
    public PermissionHandlerInterceptor permissionHandlerInterceptor(){
        return new PermissionHandlerInterceptor();
    }
    /**
     * 注册 拦截器
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(permissionHandlerInterceptor())
                .addPathPatterns("/api/**")
                .excludePathPatterns("/api/devapi/**","/api/error");
        super.addInterceptors(registry);
    }

}