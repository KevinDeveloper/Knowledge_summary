package com.opnext.oservice.repository.authority;

import com.opnext.oservice.domain.authority.role.ModuleResource;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @author wanglu
 */
public interface ModuleResourceRepository  extends PagingAndSortingRepository<ModuleResource, Integer>,
        QueryDslPredicateExecutor<ModuleResource> {
    /**
     * 通过模块id列表查询模块资源对象列表
     * @param moduleIdList
     * @return
     */
    List<ModuleResource> findAllByModuleIdIn(List<Integer> moduleIdList);
}