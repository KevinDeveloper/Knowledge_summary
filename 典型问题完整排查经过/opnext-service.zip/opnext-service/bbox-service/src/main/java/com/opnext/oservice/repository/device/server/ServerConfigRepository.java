package com.opnext.oservice.repository.device.server;

import com.opnext.oservice.domain.ServerConfig;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:07 18/5/7
 */
public interface ServerConfigRepository extends PagingAndSortingRepository<ServerConfig, String>, QueryDslPredicateExecutor<ServerConfig> {

    /**
     * 通过租户和类型删除配置记录
     * @param tenantId
     * @param type
     * @return
     */
    int deleteAllByTenantIdAndType(long tenantId,String type);

    /**
     * 根据租户ID和类型获取配置列表
     * @param tenantId
     * @param type
     * @return
     */
    List<ServerConfig> findAllByTenantIdAndType(long tenantId,String type);
}
