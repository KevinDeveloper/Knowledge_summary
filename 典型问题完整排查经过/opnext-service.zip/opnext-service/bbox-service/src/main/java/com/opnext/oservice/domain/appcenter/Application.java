package com.opnext.oservice.domain.appcenter;

import jdk.nashorn.internal.ir.annotations.Ignore;
import lombok.Data;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @author wanglu
 */
@Entity
@Table(name = "tenant_app")
@Data
public class Application {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Ignore
    Integer id;
    @NotEmpty(message="tenant.parameter.notEmpty")
    @Column(name="app_id")
    @Length(max=50, message = "string.length.incorrect")
    String appId;
    @Column(name="tenant_id")
    Long tenantId;
    @Column(name = "expired_date")
    Date expiredDate;
    @NotNull(message="tenant.parameter.notEmpty")
    @Column(name = "expired_date_type")
    ExpiredDateType expiredDateType;
    Status status;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="create_time")
    @CreatedDate
    Date createTime;
    @NotEmpty(message="tenant.parameter.notEmpty")
    @Length(max=50, message = "string.length.incorrect")
    String name;
    String icon;
    @NotEmpty(message="tenant.parameter.notEmpty")
    @Column(name = "index_url")
    String indexUrl;
    String version;
    Scope scope;


    public enum ExpiredDateType{
        /**
         * 有期限的
         */
        PERMANENT((byte) 0),
        /**
         * 永久有效
         */
        TIME_LIMITED((byte) 1);
        private byte value;
        ExpiredDateType(byte value) {
            this.value = value;
        }
        public byte value() {
            return this.value;
        }
    }
    public enum Status{
        /**
         * 停用状态
         */
        OFF((byte) 0),
        /**
         * 启用状态
         */
        ON((byte) 1);
        private byte value;
        Status(byte value) {
            this.value = value;
        }
        public byte value() {
            return this.value;
        }
    }
    enum Scope{
        /**
         * 拥有
         */
        PUBLIC((byte) 0),
        /**
         * 私有
         */
        PRIVATE((byte) 1);

        private byte value;
        Scope(byte value) {
            this.value = value;
        }
        public byte value() {
            return this.value;
        }
    }
}
