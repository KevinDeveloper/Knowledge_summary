package com.opnext.oservice.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.AuthServletException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.account.Account;
import com.opnext.oservice.dto.AccountFailedStatus;
import com.opnext.oservice.service.account.AccountService;
import com.opnext.oservice.util.AntPathRequestMatcher;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/**
 * @author wanglu
 */
@Slf4j
public class OperatorFilter implements Filter{
    private List<AntPathRequestMatcher> matchers = new ArrayList();
    private ObjectMapper objectMapper = new ObjectMapper();
    private AccountService accountService;
    private static final String APP_STORE = "0";

    @Override
    public void init(FilterConfig config) throws ServletException {
        String excludePath = this.getParameter(config, "excludes");
        if (excludePath != null && excludePath.length() > 0) {
            String[] paths = excludePath.split(",");
            String[] var4 = paths;
            int var5 = paths.length;

            for(int var6 = 0; var6 < var5; ++var6) {
                String path = var4[var6];
                this.matchers.add(new AntPathRequestMatcher(path));
            }
        }
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException,RuntimeException {
        this.doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
    }

    public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException,RuntimeException {
        boolean ignore = this.isExcludePath(request);
        if (ignore){
            chain.doFilter(request, response);
        }else{
            try{
                this.checkHeader(request);
            }catch(AuthServletException authEx){
                log.error("AuthServletException error, path:{}, {}", request.getServletPath(), authEx.getMessage());
                CommonResponse.ErrorResponse errorResponse =
                        CommonResponse.ErrorResponse.error(request.getServletPath(),authEx.getStatusCode(),authEx.getMessage(),null,authEx.getCode());
                response.setStatus(401);
                response.getWriter().write(objectMapper.writeValueAsString(errorResponse));
                OperatorContext.remove();
                return;
            }
            try {
                chain.doFilter(request, response);
            } catch (Exception var10) {
                response.sendError(500);
                OperatorContext.remove();
            }

        }
    }

    private void checkHeader(HttpServletRequest request) throws IOException,RuntimeException{
        //步骤1：检查是否有头部
        String jsonStr = request.getHeader("param");
        log.info("从header中取出参数 param,{}",jsonStr);
        if (StringUtils.isBlank(jsonStr)){
            throw new AuthServletException(401,AccountFailedStatus.HEADER_MISS.message,AccountFailedStatus.HEADER_MISS.value);
        }

        //步骤2：如果appId是0且user为空，则放入全局用户；如果app非0但user为空，则放入API用户
        OserviceOperator oserviceOperator = objectMapper.readValue(jsonStr,OserviceOperator.class);
        oserviceOperator.setUserType(OserviceOperator.UserType.COMMON);
        if (APP_STORE.equals(oserviceOperator.getAppId()) && Objects.isNull(oserviceOperator.getUserId())){
            oserviceOperator.setUserType(OserviceOperator.UserType.GLOBAL);
        }
        if (Objects.isNull(oserviceOperator.getUserId())){
            oserviceOperator.setUserType(OserviceOperator.UserType.API);
        }else {
            //步骤3：普通用户，查询账号是否存在；不存在抛出异常
            Account account;
            try {
                if (Objects.isNull(accountService)) {
                    BeanFactory factory = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getServletContext());
                    accountService = (AccountService) factory.getBean("accountService");
                }
                List<Account> accounts = accountService.getAccountList(Account.builder().id(oserviceOperator.getUserId()).tenantId(oserviceOperator.getTenantId()).build());
                account = accounts.get(0);
            }catch (Exception e){
                throw new AuthServletException(401,AccountFailedStatus.ACCOUNT_NOT_FOUND.message,AccountFailedStatus.ACCOUNT_NOT_FOUND.value);
            }
            //步骤4：普通用户，查看用户状态，如果是停用则抛出异常
            if (account.getStatus()==0){
                throw new AuthServletException(401,AccountFailedStatus.ACCOUNT_DISABLED.message,AccountFailedStatus.ACCOUNT_DISABLED.value);
            }
            if (account.getIsRoot()){
                oserviceOperator.setUserType(OserviceOperator.UserType.SUPER);
            }
            oserviceOperator.setLoginName(account.getLoginName());
        }
        //设置当前用户登录的语言环境
        oserviceOperator.setCurLocale(Messages.getLocale());
        OperatorContext.setOperator(oserviceOperator);
    }

    private boolean isExcludePath(HttpServletRequest request) {
        Iterator var2 = this.matchers.iterator();

        AntPathRequestMatcher matcher;
        do {
            if (!var2.hasNext()) {
                return false;
            }

            matcher = (AntPathRequestMatcher)var2.next();
        } while(!matcher.matches(request));

        return true;
    }

    private String getParameter(FilterConfig config, String param) {
        String value = config.getInitParameter(param);
        return value;
    }

    @Override
    public void destroy() {
        // do nothing
    }

}
