package com.opnext.oservice.dto.appcenter;

import lombok.Data;

/**
 * @author wanglu
 */
@Data
public class WeChatBindingConfigDTO {
    private String configKey;
    private String configValue;
    private Integer sequence;
    private Boolean needFlag;
    private String type;
}

