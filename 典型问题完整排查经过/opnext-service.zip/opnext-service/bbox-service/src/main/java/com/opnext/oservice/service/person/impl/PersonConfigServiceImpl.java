package com.opnext.oservice.service.person.impl;

import com.alibaba.fastjson.JSONObject;
import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.baidu.unbiz.fluentvalidator.util.CollectionUtil;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.oservice.domain.person.PersonConfig;
import com.opnext.oservice.domain.person.PersonConfigVo;
import com.opnext.oservice.domain.person.PropertyEdit;
import com.opnext.oservice.domain.person.PropertyRequest;
import com.opnext.oservice.domain.person.PropertyRequire;
import com.opnext.oservice.domain.person.PropertyShow;
import com.opnext.oservice.domain.person.PropertyType;
import com.opnext.oservice.domain.person.QPersonConfig;
import com.opnext.oservice.repository.person.PersonConfigRepository;
import com.opnext.oservice.service.person.PersonConfigService;
import com.opnext.oservice.util.UUIDUtil;
import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @ClassName: PersonConfigServiceImpl
 * @Description:
 * @Author: Kevin
 * @Date: 2018/5/18 15:07
 */
@Slf4j
@Service
public class PersonConfigServiceImpl implements PersonConfigService {

    @Autowired
    private PersonConfigRepository configRepostitory;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;

    @Autowired
    private EntityManager entityManager;

    @Value(value = "#{${personConfig.fixedPropertyNonEditable}}")
    private Set<String> fixedPropertyNonEditable;

    @Value(value = "#{${personConfig.fixedPropertyEditable}}")
    private Set<String> fixedPropertyEditable;

    @Value(value = "${personConfig.extendedPrefix}")
    private String extendedPrefix;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void initPersonConfig(Long tenantId, Long operatorId) throws Exception {
        if (Objects.isNull(tenantId) || Objects.isNull(operatorId)) {
            throw new CommonException("org.parameter.incorrect");
        }
        if (CollectionUtils.isEmpty(fixedPropertyNonEditable) &&
                CollectionUtils.isEmpty(fixedPropertyEditable)) {
            return;
        }
        QPersonConfig qPersonConfig = QPersonConfig.personConfig;
        Predicate predicate = qPersonConfig.tenantId.eq(tenantId);
        jpaQueryFactory.delete(qPersonConfig).where(predicate).execute();

        List<PersonConfig> configList = new ArrayList<>();
        PersonConfig personConfig = null;
        //初始化固定默认不可编辑字段
        Iterator<String> iterator = fixedPropertyNonEditable.iterator();
        while (iterator.hasNext()) {
            personConfig = new PersonConfig();
            String val = iterator.next();
            personConfig.setPropertyName(val);
            personConfig.setPropertyTitle(val);
            personConfig.setPropertyType(PropertyType.fixed);
            personConfig.setPropertyRequire(PropertyRequire.unRequire.value());
            personConfig.setPropertyShow(PropertyShow.show.value());
            personConfig.setPropertyEdit(PropertyEdit.nonEditable.value());
            personConfig.setTenantId(tenantId);
            personConfig.setOperatorId(operatorId);
            personConfig.setCreateTime(new Date());
            personConfig.setUpdateTime(new Date());
            configList.add(personConfig);
        }
        //初始化固定可编辑字段
        iterator = fixedPropertyEditable.iterator();
        while (iterator.hasNext()) {
            personConfig = new PersonConfig();
            String val = iterator.next();
            personConfig.setPropertyName(val);
            personConfig.setPropertyTitle(val);
            personConfig.setPropertyType(PropertyType.fixed);
            personConfig.setPropertyRequire(PropertyRequire.unRequire.value());
            personConfig.setPropertyShow(PropertyShow.show.value());
            personConfig.setPropertyEdit(PropertyEdit.editable.value());
            personConfig.setTenantId(tenantId);
            personConfig.setOperatorId(operatorId);
            personConfig.setCreateTime(new Date());
            personConfig.setUpdateTime(new Date());
            configList.add(personConfig);
        }
        configRepostitory.save(configList);
    }

    @Override
    public List<PersonConfigVo> personConfigList(Long tenantId) throws Exception {
        QPersonConfig qPersonConfig = QPersonConfig.personConfig;
        Predicate predicate = qPersonConfig.tenantId.eq(tenantId);
        List<PersonConfig> personConfigs = jpaQueryFactory.select(qPersonConfig).from(qPersonConfig).where(predicate).orderBy(qPersonConfig.id.asc()).fetch();
        personConfigs.stream().forEach(config -> {
            if (config.getPropertyType() == PropertyType.fixed) {
                config.setPropertyTitle(Messages.get(config.getPropertyName(), config.getPropertyName()));
            }
        });
        List<PersonConfigVo> personConfigVos = personConfigs.stream().map(config -> {
            PersonConfigVo personConfigVo = new PersonConfigVo();
            BeanUtils.copyProperties(config, personConfigVo);
            return personConfigVo;
        }).collect(Collectors.toList());

        return personConfigVos;
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updatePersonConfig(Long tenantId, Long operatorId, PropertyRequest propertyRequest) throws Exception {
        List<PersonConfig> configList = propertyRequest.getConfigs();
        if (Objects.isNull(tenantId) ||
                Objects.isNull(operatorId) ||
                CollectionUtil.isEmpty(configList)) {
            throw new CommonException("person.config.parameter.incorrect");
        }
        if (null != propertyRequest.getConfigs()) {
            deletePersonConfig(tenantId, operatorId, propertyRequest.getIds());
        }
        List<PersonConfigVo> curConfigs = personConfigList(tenantId);
        log.info("更新人员字段，已有字段列表 curConfigs={}", JSONObject.toJSONString(curConfigs));
        log.info("更新人员字段，待更新字段列表 configList={}", JSONObject.toJSONString(configList));
        checkValidator(configList, curConfigs);
        configList = configList.stream().map(config -> {
            config.setTenantId(tenantId);
            config.setOperatorId(operatorId);
            config.setUpdateTime(new Date());
            //动态字段
            if (config.getPropertyType() != PropertyType.fixed) {
                //动态字段都可编辑
                config.setPropertyEdit(PropertyEdit.editable.value());
            } else {
                config.setPropertyTitle(config.getPropertyName());
            }
            //新增
            if (Objects.isNull(config.getId())) {
                config.setCreateTime(new Date());

            }
            return config;
        }).collect(Collectors.toList());
        configRepostitory.save(configList);

    }

    private void checkValidator(List<PersonConfig> configList, List<PersonConfigVo> curConfigs) throws Exception {
        int flexbleCount = 0;

        // 名称集合
        Set<String> propertyTitlesSet = new HashSet<>();
        // name集合
        Set<String> propertyNameKeySet = new HashSet<>();
        Set<Integer> propertyIdsSet = new HashSet<>();
        // 固定字段id集合
        Set<Integer> fixedIdsSet = new HashSet<>();
        for (PersonConfigVo tempConfig : curConfigs) {
            propertyIdsSet.add(tempConfig.getId());
            propertyTitlesSet.add(tempConfig.getPropertyTitle());
            propertyNameKeySet.add(tempConfig.getPropertyName());
            if (PropertyType.fixed == tempConfig.getPropertyType()) {
                fixedIdsSet.add(tempConfig.getId());
            } else {
                flexbleCount++;
            }
        }
        PersonConfig temp = null;
        int size = configList.size();
        for (int i = 0; i < size; i++) {
            temp = configList.get(i);
            if (temp.getPropertyType() != PropertyType.fixed && temp.getPropertyType() != PropertyType.extended) {
                log.info("字段类型错误，propertyType={}", temp.getPropertyType());
                throw new CommonException("person.config.property.type.error");
            }
            if (Objects.isNull(temp.getId())) {
                if (temp.getPropertyType() == PropertyType.fixed) {
                    log.info("固定字段不能被添加", temp.getPropertyType());
                    throw new CommonException("person.config.property.type.fixed");
                }
            } else {
                if (temp.getPropertyType() == PropertyType.fixed && !fixedIdsSet.contains(temp.getId())) {
                    log.info("固定字段不能被添加, 添加的固定字段id不合法", temp.getPropertyType());
                    throw new CommonException("person.config.property.type.fixed");
                }
            }
            if (temp.getPropertyType() != PropertyType.fixed
                    && Objects.isNull(temp.getId())) {
                flexbleCount++;
                String tempName = extendedPrefix + flexbleCount;
                while (propertyNameKeySet.contains(tempName)) {
                    log.info("人员字段名key重复，tempName={}", tempName);
                    tempName = tempName + UUIDUtil.uuid();
                }
                temp.setPropertyName(tempName);
                configList.set(i, temp);
            }
            if (flexbleCount > 10) {
                log.info("动态字段数量超过10个");
                throw new CommonException("person.config.flexible.max");
            }
            if (StringUtils.isBlank(temp.getPropertyTitle())) {
                log.info("人员字段更新，字段名不能为空");
                throw new CommonException("person.config.property.empty");
            } else {
                if (Objects.isNull(temp.getId())) {
                    ComplexResult ret = FluentValidator.checkAll()
                            .failFast()
                            .on(temp.getPropertyTitle(), new IsStringWithinLengthRangeValidator("title", 1, 32, true))
                            .doValidate()
                            .result(toComplex());
                    if (!ret.isSuccess()) {
                        log.debug("参数长度格式错误");
                        throw new CommonException(400, "parameter.incorrect", ret);
                    } else if (propertyTitlesSet.contains(temp.getPropertyTitle())) {
                        log.info("字段名重复，{}", temp.getPropertyTitle());
                        throw new CommonException("person.config.property.repeat");
                    } else {
                        propertyTitlesSet.add(temp.getPropertyTitle());
                    }
                } else {
                    if (!propertyIdsSet.contains(temp.getId())) {
                        log.info("人员字段更新，传递参数字段id不合法，id不存在或重复，id={}", temp.getId());
                        throw new CommonException("person.config.parameter.incorrect.id");
                    } else {
                        propertyIdsSet.remove(temp.getId());
                    }
                }
            }

            //判断可编辑性，动态字段都可以编辑  - 待定
            if (temp.getPropertyType() == PropertyType.extended &&
                     temp.getPropertyEdit() != PropertyEdit.editable.value() ) {
                log.info("参数不合法，动态字段都可以编辑");
                throw new CommonException("person.config.flexable.editable");
            }

        }
        if (!CollectionUtils.isEmpty(propertyIdsSet)) {
            log.info("参数不合法，需要传递所有的字段配置, 多传传递了id:={}", JSONObject.toJSONString(propertyIdsSet));
            throw new CommonException("person.config.property.count");
        }


    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deletePersonConfig(Long tenantId, Long operatorId, Integer[] configIds) throws Exception {
        if (Objects.isNull(tenantId) || Objects.isNull(operatorId) || Objects.isNull(configIds)) {
            throw new CommonException("person.config.parameter.incorrect");
        }
        QPersonConfig qPersonConfig = QPersonConfig.personConfig;
        Predicate predicate = qPersonConfig.tenantId.eq(tenantId).and(qPersonConfig.id.in(configIds)).and(qPersonConfig.propertyType.eq(PropertyType.extended));
        jpaQueryFactory.delete(qPersonConfig).where(predicate).execute();
    }
}
