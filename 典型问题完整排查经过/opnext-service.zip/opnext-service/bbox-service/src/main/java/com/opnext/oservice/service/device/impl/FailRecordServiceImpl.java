package com.opnext.oservice.service.device.impl;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.command.CommandErrorInfo;
import com.opnext.oservice.domain.command.QCommandErrorInfo;
import com.opnext.oservice.domain.device.SFailRecord;
import com.opnext.oservice.repository.command.CommandErrorInfoRepository;
import com.opnext.oservice.service.device.FailRecordService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author tianzc
 */
@Slf4j
@Service
public class FailRecordServiceImpl implements FailRecordService {
    @Resource
    CommandErrorInfoRepository errorInfoRepository;
    /**
     * 获取设备处理失败记录
     *
     * @param pageable 分页参数：page 查询页，size 分页条数
     * @param sFailRecord 查询条件：commandId 指令id，deviceSn 设备sn
     * @return page 返回分页对象
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @Override
    public Page getPage(Pageable pageable, SFailRecord sFailRecord) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        List<Sort.Order> orderList = new ArrayList<>();
        orderList.add(new Sort.Order(Sort.Direction.DESC,"createTime"));
        if (Objects.nonNull(pageable.getSort())) {
            for (Sort.Order order : pageable.getSort()) {
                orderList.add(order);
            }
        }
        Sort sort = new Sort(orderList);
        pageable = new PageRequest(pageable.getPageNumber(),pageable.getPageSize(), sort);
        log.info("------重新组合排序后参数pageable：{}", pageable);
        QCommandErrorInfo qCommandErrorInfo = QCommandErrorInfo.commandErrorInfo;
        Predicate predicate = qCommandErrorInfo.tenantId.eq(oserviceOperator.getTenantId());
        if (StringUtils.isNotBlank(sFailRecord.getCommandId())) {
            predicate = ((BooleanExpression) predicate).and(qCommandErrorInfo.commandId.eq(sFailRecord.getCommandId()));
        }
        if (StringUtils.isNotBlank(sFailRecord.getDeviceSn())) {
            predicate = ((BooleanExpression) predicate).and(qCommandErrorInfo.deviceSn.eq(sFailRecord.getDeviceSn()));
        }
        Page<CommandErrorInfo> page = errorInfoRepository.findAll(predicate,pageable);
        return page;
    }
}
