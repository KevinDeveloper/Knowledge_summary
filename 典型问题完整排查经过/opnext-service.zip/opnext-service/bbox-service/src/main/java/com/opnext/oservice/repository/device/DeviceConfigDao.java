package com.opnext.oservice.repository.device;

import com.opnext.oservice.domain.device.DeviceConfig;
import com.opnext.oservice.repository.base.impl.BaseMongoDaoImpl;
import org.springframework.stereotype.Service;

/**
 * @author tianzc
 */
@Service
public class DeviceConfigDao extends BaseMongoDaoImpl<DeviceConfig> {
}
