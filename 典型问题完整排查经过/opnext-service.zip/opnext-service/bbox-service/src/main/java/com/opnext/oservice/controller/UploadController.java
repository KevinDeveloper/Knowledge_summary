package com.opnext.oservice.controller;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.context.CommonContext;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.MultipartFileResp;
import com.opnext.oservice.feign.OcfsFeign;
import com.opnext.oservice.service.UploadService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import springfox.documentation.annotations.ApiIgnore;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午3:10 18/5/9
 */
@Slf4j
@RestController
@RequestMapping("/api/upload")
@Api(value="照片上传接口",tags={"照片上传接口"})
public class UploadController {

    @Autowired
    UploadService uploadService;


    @ApiOperation(value = "单个照片上传", notes = "上传照片，返回裁剪后的照片地址")
    @RequestMapping(value = "/image",method = RequestMethod.POST, consumes = "multipart/*", headers = "content-type=multipart/form-data")
    @ResponseBody
    public CommonResponse<String> uploadImage(HttpServletRequest request, MultipartFile file) throws Exception {
        log.info("单文件上传");
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        Map<String, MultipartFile>  multipartFileMap = multipartRequest.getFileMap();
        String url = "";
        if (multipartFileMap.size() > 1) {
            throw new CommonException("imageFile.limit");
        } else if (multipartFileMap.size() > 0){
            RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
            for (Map.Entry<String, MultipartFile> entry : multipartFileMap.entrySet()) {
                Map<String, MultipartFileResp> map = uploadService.uploadImage(entry.getValue(), oserviceOperator,urlPrefix);
                MultipartFileResp fileResp = map.get(entry.getValue().getOriginalFilename());
                if (fileResp.isFlag()) {
                     url = fileResp.getUrl();
                } else {
                    throw new CommonException(fileResp.getMessage());
                }
            }
        } else {
            throw new CommonException("file.isEmpty");
        }
        return CommonResponse.ok(url);
    }

    @ApiIgnore()
    @ApiOperation(value = "批量上传照片", notes = "上传照片，返回裁剪后的照片地址")
    @RequestMapping(value = "/batchImage",method = RequestMethod.POST)
    @ResponseBody
    public CommonResponse batchUploadImage(HttpServletRequest request) throws Exception {
        log.info("批量上传文件 request");
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        Map<String, MultipartFile>  multipartFileMap = multipartRequest.getFileMap();
        List<MultipartFile> list = new ArrayList<>();
        for (Map.Entry<String, MultipartFile> entry : multipartFileMap.entrySet()) {
            list.add(entry.getValue());
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Map<String, MultipartFileResp> map = uploadService.batchUploadImage(list,oserviceOperator);
        return CommonResponse.ok(map);
    }

    @ApiIgnore
    @ApiOperation(value = "批量上传照片", notes = "上传照片，返回裁剪后的照片地址")
    @RequestMapping(value = "/batchUploadImageApi",method = RequestMethod.POST)
    @ResponseBody
    public CommonResponse batchUploadImageApi(List<MultipartFile> multipartFiles) throws Exception {
        log.info("批量上传文件 List<MultipartFile>");
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Map<String, MultipartFileResp> map = uploadService.batchUploadImage(multipartFiles, oserviceOperator);
        return CommonResponse.ok(map);
    }
}
