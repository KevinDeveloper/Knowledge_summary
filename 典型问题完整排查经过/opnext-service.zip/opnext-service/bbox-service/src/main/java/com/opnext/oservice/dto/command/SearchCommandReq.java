package com.opnext.oservice.dto.command;

import com.opnext.domain.message.Code;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

import java.util.Set;

/**
 * @author wanglu
 */
@Data
@Builder
public class SearchCommandReq {
    /**
     * 设备 SN 号
     */
    private Set<String> sns;
    /**
     * 命令类型
     */
    private Set<Code> code;

    private Set<String> tenantIds;
    /**
     * 命令发送开始时间
     */
    private Long startTime;
    /**
     * 命令发送结束时间
     */
    private Long endTime;

    /**
     * 页码
     */
    private Integer page;

    /**
     * 查询条数
     */
    private Integer size;

    /**
     * 排序规则
     */
    private String sort;
    @Tolerate
    public SearchCommandReq(){}
}
