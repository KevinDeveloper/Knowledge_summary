package com.opnext.oservice.repository.fastdfs;

import com.opnext.oservice.domain.fastdfs.FastdfsTmpFile;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

/**
 * @ClassName: fastdfs
 * @Description:
 * @Author: Kevin
 * @Date: 2018/8/28 16:05
 */
public interface FastdfsTmpFileRepository extends PagingAndSortingRepository<FastdfsTmpFile, Long>, QueryDslPredicateExecutor<FastdfsTmpFile> {

    @Transactional
    @Modifying
    @Query(value = "delete from fastdfs_temp_file  where file_id =:fileId", nativeQuery = true)
    void deleteByFileId(@Param(value = "fileId") String fileId);
}
