package com.opnext.oservice.domain.person;

import com.alibaba.fastjson.annotation.JSONField;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @ClassName: PersonConfig
 * @Description: 人员管理字段配置类
 * @Author: Kevin
 * @Date: 2018/5/14 16:58
 */
@Entity
@Data
@Table(name = "person_property_config")
public class PersonConfig implements Serializable {
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Integer id;
    @Column(name = "property_name")
    private String propertyName;

    @Column(name = "property_title")
    private String propertyTitle;

    @Column(name = "property_type")
    @JsonIgnore
    private PropertyType propertyType;

    @Column(name = "property_require")
    private PropertyRequire propertyRequire;
    @Column(name = "property_show")
    private PropertyShow propertyShow;
    @Column(name = "property_edit")
    private PropertyEdit propertyEdit;


    @Column(name = "tenant_id")
    private Long tenantId;
    @Column(name = "operator_id")
    private Long operatorId;
    @Column(name = "create_time")
    @CreatedDate
    private Date createTime;
    @Column(name = "update_time")
    @LastModifiedDate
    private Date updateTime;

    /**
     * propertyType 转换为 JSON 字段
     *
     * @return PropertyType 枚举 value 值
     */
    @JSONField(name = "propertyType", label = "propertyType")
    @JsonProperty(value = "propertyType")
    public int getPropertyTypeToJSONField() {
        return propertyType.value();
    }

    /**
     * propertyType 转换为 JSON 字段
     *
     * @return PropertyType 枚举 value 值
     */
    @JSONField(name = "propertyType", label = "propertyType")
    @JsonProperty(value = "propertyType")
    public void setPropertyTypeToJSONField(int value) {
        propertyType = PropertyType.indexOfVal(value);
    }


    public boolean getPropertyRequire() {
        return propertyRequire.value();
    }

    public void setPropertyRequire(boolean isRequire) {
        propertyRequire = PropertyRequire.indexOfVal(isRequire);
    }

    public boolean getPropertyShow() {
        return propertyShow.value();
    }

    public void setPropertyShow(boolean isShow) {
        propertyShow = PropertyShow.indexOfVal(isShow);
    }

    public boolean getPropertyEdit() {
        return propertyEdit.value();
    }

    public void setPropertyEdit(boolean isEdit) {
        propertyEdit = PropertyEdit.indexOfVal(isEdit);
    }

}

