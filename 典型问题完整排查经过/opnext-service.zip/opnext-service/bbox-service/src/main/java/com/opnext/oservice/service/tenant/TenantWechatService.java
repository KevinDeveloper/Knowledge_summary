package com.opnext.oservice.service.tenant;

import com.opnext.oservice.domain.tenant.TenantWechat;

/**
 * @Author: lixiuwen
 * @Date: 2018/7/30 18:07
 */
public interface TenantWechatService {
    /**
     * 根据APPID删除记录
     *
     * @param appId APPID
     */
    void deleteByAppId(String appId);

    /**
     * 根据AppId删除不是当前租户ID的数据
     * @param appId appId
     * @param tenantId 租户ID
     */
    void deleteByAppIdAndTenantIdIsNot(String appId, Long tenantId);
    /**
     * 保存记录
     *
     * @param tenantWechat 数据
     */
    void save(TenantWechat tenantWechat);

    /**
     * 根据租户ID查询记录
     *
     * @param tenantId 租户ID
     * @return查询结果
     */
    TenantWechat findByTenantId(Long tenantId);
}
