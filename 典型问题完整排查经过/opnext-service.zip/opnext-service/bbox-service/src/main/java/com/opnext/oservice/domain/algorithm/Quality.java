package com.opnext.oservice.domain.algorithm;

import lombok.Data;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午1:15 18/5/12
 */
@Data
public class Quality {
    private double regular;
    private double yaw;
    private double pitch;
    private double clearLevel;
    private double visLevel;
    private double glassLevel;
}
