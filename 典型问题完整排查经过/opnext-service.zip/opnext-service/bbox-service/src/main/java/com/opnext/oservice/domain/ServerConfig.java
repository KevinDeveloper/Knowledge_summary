package com.opnext.oservice.domain;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:06 18/5/7
 */
@Entity
@Data
@Table(name = "server_config")
public class ServerConfig {
    @Id
    @GeneratedValue
    private Integer id;
    /**
     * 配置键
     */
    @Column(name = "config_key")
    private String configKey;

    /**
     * 配置值
     */
    @Column(name = "config_value")
    private String configValue;

    /**
     * 配置分类
     * 命名规则：服务名_配置类型，如bbox_visitor_visitRecord
     * 最大长度：50
     */
    @Column(name = "type")
    private String type;

    /**
     * key_val 内部业务区分
     */
    @Column(name = "config_type")
    private String configType;

    /**
     * 租户ID
     */
    @Column(name = "tenant_id")
    private Long tenantId;
}
