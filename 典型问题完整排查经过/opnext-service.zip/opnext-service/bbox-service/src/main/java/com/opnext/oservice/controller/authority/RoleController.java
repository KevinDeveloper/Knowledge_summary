package com.opnext.oservice.controller.authority;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.validator.HasEasySpecialCharValidator;
import com.opnext.bboxsupport.validator.IsIntegerStringValidator;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.authority.role.*;
import com.opnext.oservice.dto.authority.role.RoleDetailDTO;
import com.opnext.oservice.service.authority.RoleService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.Objects;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author wanglu
 */
@Slf4j
@RestController
@RequestMapping("/api/role")
public class RoleController {
    @Autowired
    private RoleService roleService;

    @ApiOperation(value = "获取角色列表", notes = "获取角色列表(分页，包含超级管理员角色）")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=xxx desc表示根据xxx字段倒叙排序")
    })
    @RequestMapping(value = "/page",method = RequestMethod.GET)
    public Page<Role> getRoles(@PageableDefault Pageable pageable){
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        return roleService.findRolePage(pageable,tenantId);
    }

    @ApiOperation(value = "角色列表", notes = "获取角色列表(非分页，且不包含超级管理员角色)")
    @RequestMapping(value = "/",method = RequestMethod.GET)
    public List<Role> getRoles(){
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        return roleService.findAllRole(tenantId);
    }

    @ApiOperation(value = "获取角色关联的账号列表", notes = "获取角色关联的账号列表")
    @RequestMapping(value = "/{roleId}/accounts",method = RequestMethod.GET)
    public List<Long> getAccount(@PathVariable  String roleId) throws Exception {
        //参数校验
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(roleId,  new IsIntegerStringValidator("roleId"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("获取角色绑定的账号，roleId参数有误，{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        String suRoot= "0";
        if (suRoot.equals(roleId)){
            log.error("获取角色绑定的账号，不能查询超级管理员角色关联的账号");
            throw new CommonException(400,"role.superaccount.cannot.search");
        }
        long roleLong = Long.parseLong(roleId);
        return roleService.getAccountIdsByRoleId(roleLong);
    }

    @ApiOperation(value = "获取角色详情", notes = "获取角色详情")
    @RequestMapping(value = "/{roleId}",method = RequestMethod.GET)
    public RoleDetailDTO getRoleDetail(@PathVariable  String roleId) throws Exception{
        //参数校验
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(roleId,  new IsIntegerStringValidator("roleId"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("获取角色详情失败，roleId参数有误，{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        long roleLong = Long.parseLong(roleId);

        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        return roleService.getRoleDetail(roleLong,tenantId);
    }

    @ApiOperation(value = "新增角色", notes = "新增角色")
    @RequestMapping(value = "/",method = RequestMethod.POST)
    public void addRole(@RequestBody @Valid RoleDetailDTO roleDetailDTO, BindingResult bindingResult) throws Exception{
        //参数校验
        if (bindingResult.hasErrors()){
            log.error("新增角色失败,参数有误，{}",bindingResult);
            throw new CommonException(400,"parameter.incorrect",bindingResult);
        }

        //校验邮箱地址正确性
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(roleDetailDTO.getName(), new HasEasySpecialCharValidator("name"))
                .on(roleDetailDTO.getDescription(), new HasEasySpecialCharValidator("description"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            throw new CommonException(400,"parameter.incorrect",ret);
        }

        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long accountId = oserviceOperator.getUserId();

        List<Role> roles = roleService.findAllByNameAndTenantId(roleDetailDTO.getName(), tenantId);
        if (Objects.nonNull(roles) && !roles.isEmpty()){
            log.error("创建角色错误，角色名称已被占用");
            bindingResult.addError(new ObjectError("name", "name.used") );
            throw new CommonException(400, "name.used",bindingResult);
        }

        roleService.addRole(roleDetailDTO,accountId,tenantId);
    }

    @ApiOperation(value = "更新角色", notes = "更新角色")
    @RequestMapping(value = "/{roleId}",method = RequestMethod.POST)
    public void modifyRoleDetail(@PathVariable String roleId, @RequestBody @Valid RoleDetailDTO roleDetailDTO, BindingResult bindingResult) throws Exception{
        //参数校验
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(roleId,  new IsIntegerStringValidator("roleId"))
                .on(roleDetailDTO.getName(), new HasEasySpecialCharValidator("name"))
                .on(roleDetailDTO.getDescription(), new HasEasySpecialCharValidator("description"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("更新角色失败,参数有误，{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }

        if (bindingResult.hasErrors()){
            log.error("新增修改失败,参数有误，{}",bindingResult);
            throw new CommonException(400,"parameter.incorrect",bindingResult);
        }

        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long roleLong = Long.parseLong(roleId);
        List<Role> roles = roleService.findAllByNameAndTenantId(roleDetailDTO.getName(),tenantId);
        if (Objects.nonNull(roles)){
            if (roles.size()>1 || (roles.size()==1 && roles.get(0).getId()!=roleLong)){
                log.error("修改角色失败，角色名称已被占用");
                bindingResult.addError(new ObjectError("name", "name.used") );
                throw new CommonException(400, "name.used",bindingResult);
            }
        }

        roleService.modifyRole(roleLong,roleDetailDTO,tenantId);
    }

    @ApiOperation(value = "删除角色", notes = "删除角色")
    @RequestMapping(value = "/{roleId}",method = RequestMethod.DELETE)
    public void deleteRole(@PathVariable String roleId) throws Exception{
        //参数校验
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(roleId,  new IsIntegerStringValidator("roleId"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("删除角色失败,参数有误，{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        //判断如果是超级管理员，返回错误
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long roleLong = Long.parseLong(roleId);

        roleService.deleteRole(roleLong,tenantId);
    }

}
