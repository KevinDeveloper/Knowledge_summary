package com.opnext.oservice.domain.visitor;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/21 18:03
 */
@Entity
@Table(name = "visitor_area")
@Data
@EntityListeners(AuditingEntityListener.class)
public class Area{

    /**
     * 主键ID
     */
    @Id
    @GeneratedValue
    private Integer id;

    /**
     * 名称
     */
    @Column(name="name")
    private String name;

    /**
     * 描述
     */
    @Column(name="description")
    private String description;

    /**
     * 创建时间
     */
    @Column(name="create_time")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date createTime;

    /**
     * 创建人
     */
    @Column(name="create_by")
    private Long createBy;

    /**
     * 更新时间
     */
    @Column(name="update_time")
    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    private Date updateTime;

    /**
     * 租户ID
     */
    @Column(name="tenant_id")
    private Long tenantId;
}
