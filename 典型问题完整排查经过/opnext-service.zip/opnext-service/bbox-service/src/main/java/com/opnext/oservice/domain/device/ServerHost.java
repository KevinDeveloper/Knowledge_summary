package com.opnext.oservice.domain.device;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Title: 
 * @Description: 
 * @author tianzc
 * @Date 下午5:08 18/5/7
 */ 
@Data
@Entity
@Table(name = "server_host")
public class ServerHost {
    @Id
    private String name;
    private String ip;
    private Integer port;
}
