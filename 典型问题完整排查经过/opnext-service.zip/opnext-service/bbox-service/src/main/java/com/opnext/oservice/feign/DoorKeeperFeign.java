package com.opnext.oservice.feign;

import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.feign.impl.DoorKeeperHystrixFallFactory;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author tianzc
 */
@FeignClient(value = "door-keeper",fallbackFactory = DoorKeeperHystrixFallFactory.class)
public interface DoorKeeperFeign {

    /**
     * 获取设备秘钥
     * @param sn
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET, value = "/key")
    CommonResponse getSecureKey(@RequestParam("sn") String sn) throws Exception;
}
