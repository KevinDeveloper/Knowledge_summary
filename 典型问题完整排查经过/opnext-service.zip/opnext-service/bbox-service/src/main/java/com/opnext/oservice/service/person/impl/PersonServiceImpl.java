package com.opnext.oservice.service.person.impl;

import com.alibaba.fastjson.JSONObject;
import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.baidu.unbiz.fluentvalidator.ValidationError;
import com.beebox.push.common.amqp.PushClient;
import com.beebox.push.event.Event;
import com.beebox.push.event.EventBuilder;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.op.server.dfs.client.DfsClient;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.batch.BatchResult;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.bboxsupport.validator.IsEmptyValidator;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.bboxsupport.validator.IsUniqueValidator;
import com.opnext.domain.PersonType;
import com.opnext.domain.ResourceType;
import com.opnext.domain.Sex;
import com.opnext.oservice.conf.Constant;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.MultipartFileResp;
import com.opnext.oservice.domain.ServerConfig;
import com.opnext.oservice.domain.batch.BatchImportData;
import com.opnext.oservice.domain.batch.QBatchImportData;
import com.opnext.oservice.domain.device.DeviceConfig;
import com.opnext.oservice.domain.organization.OrgVo;
import com.opnext.oservice.domain.organization.Organization;
import com.opnext.oservice.domain.organization.QOrganization;
import com.opnext.oservice.domain.person.HistoryPerson;
import com.opnext.oservice.domain.person.OperationType;
import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.domain.person.PersonBatchResult;
import com.opnext.oservice.domain.person.PersonConfigVo;
import com.opnext.oservice.domain.person.PersonPropertysSetType;
import com.opnext.oservice.domain.person.PersonVo;
import com.opnext.oservice.domain.person.PropertyType;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.domain.person.QPersonVo;
import com.opnext.oservice.domain.person.SyncStatus;
import com.opnext.oservice.dto.CommonFailedStatus;
import com.opnext.oservice.dto.person.PersonProjection;
import com.opnext.oservice.repository.ComplicateQueryDslDao;
import com.opnext.oservice.repository.person.BatchImportRepository;
import com.opnext.oservice.repository.person.HistoryPersonRepository;
import com.opnext.oservice.repository.person.PersonRepository;
import com.opnext.oservice.service.AsyncService;
import com.opnext.oservice.service.ServerConfigService;
import com.opnext.oservice.service.device.DeviceConfigService;
import com.opnext.oservice.service.fastdfs.FastTmpFileManagerService;
import com.opnext.oservice.service.organization.OrganizationService;
import com.opnext.oservice.service.person.PersonConfigService;
import com.opnext.oservice.service.person.PersonService;
import com.opnext.oservice.service.rule.RuleApplyService;
import com.opnext.oservice.util.DateUtil;
import com.opnext.oservice.util.FileUrlPathHandle;
import com.opnext.oservice.util.FileUtil;
import com.opnext.oservice.util.JsonConvertor;
import com.opnext.oservice.util.ReflectHelperUtil;
import com.opnext.oservice.util.UUIDUtil;
import com.opnext.oservice.util.ZipUtil;
import com.opnext.oservice.util.excel.ExcelDataExportPerson;
import com.opnext.oservice.util.excel.ExcelExportPersonUtil;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQuery;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.csource.fastdfs.DownloadCallback;
import org.hibernate.Session;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Base64Utils;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午5:05 18/5/7
 */
@Slf4j
@Service
public class PersonServiceImpl implements PersonService {

    @Autowired
    private PersonRepository personRepository;
    @Autowired
    private HistoryPersonRepository historyPersonRepository;

    @Autowired
    private ComplicateQueryDslDao complicateQueryDslDao;

    @Autowired
    private JPAQueryFactory jpaQueryFactory;

    @Autowired
    private EntityManager entityManager;


    @Autowired
    private AsyncService asyncService;

    @Autowired
    private PersonConfigService personConfigService;

    @Autowired
    private OrganizationService organizationService;
    @Autowired
    private DeviceConfigService deviceConfigService;
    @Autowired
    private ServerConfigService serverConfigService;

    @Autowired
    private RuleApplyService ruleApplyService;

    @Lazy
    @Autowired
    private DfsClient dfsClient;

    @Autowired
    private BatchImportRepository batchImportRepository;

    @Resource
    private PushClient pushClient;
    @Resource
    private FastTmpFileManagerService fastTmpFileManagerService;

    /**
     * 根据id获取人员信息
     *
     * @param id
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public Person getOne(String id,RequestUrlPrefix urlPrefix) throws Exception {
        // 获取操作者信息
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QPerson.person.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QPerson.person.id.eq(id));
        Person person = personRepository.findOne(predicate);
        if (Objects.nonNull(person)) {
            entityManager.unwrap(Session.class).evict(person);
            // 人员图片地址调整
            Map<ResourceType, List<String>> avatars = FileUrlPathHandle.getShowAvatarsMap(person.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()));
            person.setAvatars(avatars);
        }
        return person;
    }

    /**
     * 分页获取人员列表
     *
     * @param pageable
     * @param name
     * @param no
     * @param organizationId
     * @return
     * @throws Exception
     */
    @Override
    public Page getPage(Pageable pageable, String name, String no, Integer organizationId,RequestUrlPrefix urlPrefix) throws Exception {
        // 获取操作者信息
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QPerson.person.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QPerson.person.type.eq(PersonType.FREQUENTER));
        Page<PersonVo> page;
        if (StringUtils.isNotBlank(name)) {
            predicate = ((BooleanExpression) predicate).and(QPerson.person.name.contains(name));
        }
        if (StringUtils.isNotBlank(no)) {
            predicate = ((BooleanExpression) predicate).and(QPerson.person.no.contains(no));
        }
        // 根据用户组织权限生成查询条件
        if (CollectionUtils.isEmpty(oserviceOperator.getOrganizations())) {
            if (OserviceOperator.UserType.COMMON.equals(oserviceOperator.getUserType())) {
                page = new PageImpl(new ArrayList(), pageable, 0);
                return page;
            } else {
                if (Objects.nonNull(organizationId)) {
                    predicate = ((BooleanExpression) predicate).and(QPerson.person.organizationId.eq(organizationId));
                }
            }
        } else {
            if (Objects.nonNull(organizationId)) {
                List<Integer> orgIdList = oserviceOperator.getOrganizations();
                if (orgIdList.contains(organizationId)) {
                    predicate = ((BooleanExpression) predicate).and(QPerson.person.organizationId.eq(organizationId));
                } else {
                    page = new PageImpl(new ArrayList(), pageable, 0);
                    return page;
                }
            } else {
                predicate = ((BooleanExpression) predicate).and(QPerson.person.organizationId.in(Sets.newHashSet(oserviceOperator.getOrganizations())));
            }
        }
        page = complicateQueryDslDao.find(
                jpaQueryFactory.select(QPerson.person, QPerson.person.id)
                        .from(QPerson.person).where(predicate)
                        .orderBy(QPerson.person.updateTime.desc(), QPerson.person.no.desc()),
                pageable, PersonVo.class);
        if (!CollectionUtils.isEmpty(page.getContent())) {
            Map<Integer, String> orgMap = organizationService.getOrgMap(tenantId, oserviceOperator);
            List<PersonVo> personVoList = page.getContent();
            personVoList.forEach(personVo -> {
                Map<ResourceType, List<String>> map = FileUrlPathHandle.getShowAvatarsMap(personVo.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()));
                personVo.setAvatars(map);
                if (!CollectionUtils.isEmpty(orgMap)) {
                    if (Objects.nonNull(personVo.getOrganizationId())) {
                        personVo.setOrganization(orgMap.get(personVo.getOrganizationId()));
                    }
                }
            });
        }
        return page;
    }

    /**
     * 分页获取人员列表（list）
     *
     * @param pageable
     * @param organizationId
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public List<PersonProjection> getList(Pageable pageable, Integer organizationId, OserviceOperator oserviceOperator) throws Exception {
        return personRepository.findByOrganizationId(PersonType.FREQUENTER.value(), organizationId, oserviceOperator.getTenantId(), pageable.getOffset(), pageable.getPageSize());
    }

    /**
     * 根据组织id获取组织下人员个数
     *
     * @param organizationId
     * @return
     * @throws Exception
     */
    @Override
    public List<Map<String, Long>> getPersonCountByOrgId(Integer[] organizationId, OserviceOperator oserviceOperator) throws Exception {
        List<Map<String, Long>> mapList = new ArrayList<>();
        QPerson qPerson = QPerson.person;
        Predicate predicate = qPerson.tenantId.eq(oserviceOperator.getTenantId());
        predicate = ((BooleanExpression) predicate).and(qPerson.type.eq(PersonType.FREQUENTER));
        // 校验用户组织权限
        if (CollectionUtils.isEmpty(oserviceOperator.getOrganizations())) {
            if (OserviceOperator.UserType.COMMON.equals(oserviceOperator.getUserType())) {
                return mapList;
            } else {
                if (Objects.nonNull(organizationId)) {
                    predicate = ((BooleanExpression) predicate).and(qPerson.organizationId.in(organizationId));
                }
            }
        } else {
            if (Objects.nonNull(organizationId)) {
                predicate = ((BooleanExpression) predicate).and(qPerson.organizationId.in(organizationId));
            } else {
                predicate = ((BooleanExpression) predicate).and(qPerson.organizationId.in(oserviceOperator.getOrganizations()));
            }
        }
        List<Tuple> list = jpaQueryFactory.select(qPerson.organizationId, qPerson.count())
                .from(qPerson).where(predicate).groupBy(qPerson.organizationId)
                .fetch();

        if (!CollectionUtils.isEmpty(list)) {
            mapList = list.stream().map(obj ->{
                    Map<String, Long> map = new HashMap<>();
                    map.put("organizationId",((Integer)obj.toArray()[0]).longValue());
                    map.put("count",(Long) obj.toArray()[1]);
                    return map;
                }
            ).collect(Collectors.toList());
        }
        return mapList;
    }

    /**
     * 批量接口
     * 1、限制批量最大条数
     * 2、逐条数据检验返回相应结果
     * 3、删除文件数据（fileId）
     */

    /**
     * 批量保存人员信息
     *
     * @param personList
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public List<Person> batchSave(List<Person> personList, PersonType personType,RequestUrlPrefix urlPrefix) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long syncVersion = System.currentTimeMillis();
        deleteFileId(personList);
        List<Person> list = savePerson(personList, syncVersion, personType, oserviceOperator,urlPrefix);
        return list;
    }

    public List<Person> savePerson(List<Person> personList, long syncVersion, PersonType personType, OserviceOperator oserviceOperator,RequestUrlPrefix urlPrefix) throws Exception {
        long tenantId = oserviceOperator.getTenantId();
        Long operatorId = oserviceOperator.getUserId();
        List<Person> rePersonList = new ArrayList<>();
        List<Person> list = new ArrayList<>();
        // 默认数据（默认密码，默认组织）
        Map<String, String> defaultMap = new HashMap<>();
        String pwdKey = "pwd";
        String orgIdKey = "orgId";
        String apiOrgIdKey = "apiOrgId";
        List<String> groupIdList = new ArrayList<>();
        List<Integer> organizationIdList = new ArrayList<>();
        int i = 0;
        for (Person person : personList) {
            person.setId(UUIDUtil.uuid());
            person.setSyncVersion(syncVersion);
            person.setTenantId(tenantId);
            person.setType(personType);
            person.setAppId(oserviceOperator.getAppId());
            if (PersonType.VISITOR.equals(personType)) {
                person.setNo(person.getId());
            }
            Map<ResourceType, List<String>> avatarsMap = FileUrlPathHandle.getStoreAvatarsMap(person.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()), GlobleConfig.ServerConfig.urlStoreRelative);
            person.setAvatars(avatarsMap);
            // 操作者信息
            person.setOperatorName(oserviceOperator.getLoginName());
            person.setOperatorId(operatorId);
            if (StringUtils.isBlank(person.getPassword())) {
                if (StringUtils.isNoneBlank(defaultMap.get(pwdKey))) {
                    person.setPassword(defaultMap.get(pwdKey));
                } else {
                    //人员密码设置
                    ServerConfig config = serverConfigService.getPersonPwdConfig(tenantId);
                    person.setPassword(config.getConfigValue());
                    defaultMap.put(pwdKey, config.getConfigValue());
                }
            }
            // 校验人员参数库
            if (Objects.nonNull(person.getGroupId())) {
                // 判断是否存在
                if (!groupIdList.contains(person.getGroupId())) {
                    DeviceConfig deviceConfig = deviceConfigService.getConfigByParamKey(person.getGroupId(), tenantId);
                    if (Objects.isNull(deviceConfig)) {
                        log.info("提交数据groupId不合法（不存在）");
                        throw new CommonException("person.groupId.incorrect");
                    } else {
                        groupIdList.add(deviceConfig.getParamKey());
                    }
                }
            }
            // 组织id校验
            Integer orgId = person.getOrganizationId();
            if (Objects.isNull(person.getOrganizationId())) {
                Organization organization = null;
                if (OserviceOperator.UserType.API.equals(oserviceOperator.getUserType())) {
                    // 判断默认数据中是否存在api组织
                    if (Objects.nonNull(defaultMap.get(apiOrgIdKey))) {
                        orgId = Integer.parseInt(defaultMap.get(apiOrgIdKey));
                    } else {
                        organization = organizationService.getOtherOrgByTenantId(tenantId);
                        if (Objects.isNull(organization)) {
                            log.info("获取api对应organization信息（不存在）");
                            throw new CommonException("person.organization.not.found");
                        } else {
                            defaultMap.put(apiOrgIdKey, String.valueOf(organization.getId()));
                            orgId = organization.getId();
                        }
                    }
                } else {
                    // 判断默认数据中是否存在root组织
                    if (Objects.nonNull(defaultMap.get(orgIdKey))) {
                        orgId = Integer.parseInt(defaultMap.get(orgIdKey));
                    } else {
                        organization = organizationService.getRootOrgByTenantId(tenantId);
                        if (Objects.isNull(organization)) {
                            log.info("获取root对应organization信息（不存在）");
                            throw new CommonException("person.organization.not.found");
                        } else {
                            defaultMap.put(orgIdKey, String.valueOf(organization.getId()));
                            orgId = organization.getId();
                        }
                    }
                }
            } else {
                // 判断是否存在数组中
                if (!organizationIdList.contains(person.getOrganizationId())) {
                    Organization organization = organizationService.findOrgInTenantIdById(tenantId, person.getOrganizationId());
                    if (Objects.isNull(organization)) {
                        log.info("提交数据organizationId不合法（不存在）");
                        throw new CommonException("person.organizationId.incorrect");
                    } else {
                        organizationIdList.add(organization.getId());
                    }
                }
            }
            person.setOrganizationId(orgId);
            list.add(person);
            if ((i + 1) % 100 == 0) {
                Iterable<Person> savePerson = personRepository.save(list);
                list = new ArrayList<>();
                rePersonList.addAll(Lists.newArrayList(savePerson));
            }
            i++;
        }
        if (list.size() > 0) {
            Iterable<Person> savePerson = personRepository.save(list);
            rePersonList.addAll(Lists.newArrayList(savePerson));
        }
        return rePersonList;
    }

    /**
     * 人员格式校验
     *
     * @return
     */
    @Override
    public ComplexResult fluentValidatorPerson(Person person, boolean hasExtends) throws Exception {
        ComplexResult ret = new ComplexResult();
        FluentValidator fluentValidator = FluentValidator.checkAll().failOver();
        fluentValidator.on(person.getNo(), new IsEmptyValidator("no"))
                .on(person.getNo(), new IsStringWithinLengthRangeValidator("no", 1, 32, true))
                .on(person.getName(), new IsEmptyValidator("name"))
                .on(person.getName(), new IsStringWithinLengthRangeValidator("name", 1, 64, true))
                .on(person.getPassword(), new IsStringWithinLengthRangeValidator("password", 6, 20, true))
                .on(person.getMail(), new IsStringWithinLengthRangeValidator("mail", 4, 64, true))
                .on(person.getPhone(), new IsStringWithinLengthRangeValidator("phone", 4, 64, true))
                .on(person.getIcNumber(), new IsStringWithinLengthRangeValidator("icNumber", 0, 32, true))
                .on(person.getWgNumber(), new IsStringWithinLengthRangeValidator("wgNumber", 0, 20, true))
                .on(person.getIdCard(), new IsStringWithinLengthRangeValidator("idCard", 0, 20, true))
//                .on(person.getHiredate(), new IsDateStringValidator("hiredate", DateUtil.DATE_FORMAT_YYYY_MM_DD))
                .on(person.getPosition(), new IsStringWithinLengthRangeValidator("position", 0, 64, true))
                .on(person.getRemark(), new IsStringWithinLengthRangeValidator("remark", 0, 256, true));
        Map<String, String> variable = person.getVariable();
        if (hasExtends && !CollectionUtils.isEmpty(variable)) {
            if (variable.size() > 10) {
                log.info("自定义字段个数超限；限制10个");
                throw new CommonException(400, "person.config.flexible.max");
            } else {
                for (Map.Entry<String, String> entry : variable.entrySet()) {
                    fluentValidator.on(entry.getValue(), new IsStringWithinLengthRangeValidator(entry.getKey(), 0, 32, true));
                }
            }
        }
        ret = fluentValidator.doValidate().result(toComplex());
        return ret;
    }

    /**
     * 校验人员字段是否存在（唯一性）
     * 常客使用
     *
     * @param person
     * @param tenantId
     * @param propertysSetType
     * @return
     * @throws Exception
     */
    public long checkUniqueValidatorPerson(Person person, Long tenantId, PersonPropertysSetType propertysSetType) throws Exception {
        long count = 0;
        QPerson qPerson = QPerson.person;
        Predicate predicate = qPerson.tenantId.eq(tenantId);
        // 常客使用
//        predicate = ((BooleanExpression) predicate).and(qPerson.type.eq(PersonType.FREQUENTER));
        // 人员id不为空，更新人员操作
        if (StringUtils.isNoneBlank(person.getId())) {
            predicate = ((BooleanExpression) predicate).and(qPerson.id.ne(person.getId()));
        }
        switch (propertysSetType) {
            case no:
                if (StringUtils.isNoneBlank(person.getNo())) {
                    predicate = ((BooleanExpression) predicate).and(qPerson.no.eq(person.getNo()));
                    count = jpaQueryFactory.select(qPerson.no).from(qPerson).where(predicate).fetchCount();
                    break;
                }
            case name:
                if (StringUtils.isNoneBlank(person.getName())) {
                    predicate = ((BooleanExpression) predicate).and(qPerson.name.eq(person.getName()));
                    count = jpaQueryFactory.select(qPerson.name).from(qPerson).where(predicate).fetchCount();
                    break;
                }
            case idCard:
                if (StringUtils.isNoneBlank(person.getIdCard())) {
                    predicate = ((BooleanExpression) predicate).and(qPerson.idCard.eq(person.getIdCard()));
                    count = jpaQueryFactory.select(qPerson.idCard).from(qPerson).where(predicate).fetchCount();
                    break;
                }
            default:
        }
        return count;
    }

    /**
     * 处理校验，抛出异常
     *
     * @param person
     * @param tenantId
     * @throws Exception
     */
    public void fluentUniqueValidatorPerson(Person person, Long tenantId) throws Exception {
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(person.getNo(), new IsUniqueValidator("no", "person.no.unique.incorrect", checkUniqueValidatorPerson(person, tenantId, PersonPropertysSetType.no)))
//                .on(person.getName(), new IsUniqueValidator("name" ,checkUniqueValidatorPerson(person,tenantId, PersonPropertysSetType.name)))
//                .on(person.getIdCard(), new IsUniqueValidator("idCard", "person.idCard.unique.incorrect", checkUniqueValidatorPerson(person, tenantId, PersonPropertysSetType.idCard)))
                .doValidate()
                .result(toComplex());
        if (!ret.isSuccess()) {
            log.error("人员信息唯一性校验失败{}", ret);
            throw new CommonException(400, "parameter.incorrect", ret);
        }
    }

    /**
     * 保存人员信息
     *
     * @param person
     * @throws Exception
     */
    @Override
    public Person save(Person person,RequestUrlPrefix urlPrefix) throws Exception {
        // 获取操作者对象
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        // 校验唯一性字段，直接抛出异常
        fluentUniqueValidatorPerson(person, oserviceOperator.getTenantId());
        // 同步版本号
        long syncVersion = System.currentTimeMillis();
        deleteFileId(person);
        List<Person> list = savePerson(Lists.newArrayList(person), syncVersion, PersonType.FREQUENTER, oserviceOperator,urlPrefix);
        if (!CollectionUtils.isEmpty(list)) {
            Person resultPerson = list.get(0);

            // 人员添加，根据组织同步到终端
            ruleApplyService.whenAddOrg(Lists.newArrayList(resultPerson.getId()), resultPerson.getOrganizationId(), oserviceOperator);
            Map<ResourceType, List<String>> avatarsMap = FileUrlPathHandle.getShowAvatarsMap(resultPerson.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()));
            resultPerson.setAvatars(avatarsMap);
            try {
                pushPerson(resultPerson, Event.EventType.PERSON_ADD, oserviceOperator.getTenantId());
            } catch (Exception e) {
                log.error("pushServer服务异常",e);
            }
            return resultPerson;
        } else {
            throw new CommonException(HttpStatus.INTERNAL_SERVER_ERROR.value(), CommonFailedStatus.DATABASE_EXCEPTION.getMessage(), null, CommonFailedStatus.DATABASE_EXCEPTION.getValue());
        }
    }


    /**
     * fid插入到临时表
     *
     * @param personList
     * @param oserviceOperator
     * @throws Exception
     */
    public void addFileId(List<Person> personList, OserviceOperator oserviceOperator) throws Exception {
        for (Person person : personList) {
            Map<ResourceType, List<String>> avatars = person.getAvatars();
            if (!CollectionUtils.isEmpty(avatars)) {
                for (List<String> fidList : avatars.values()) {
                    if (!CollectionUtils.isEmpty(fidList)) {
                        for (String s : fidList) {
                            if (StringUtils.isNotBlank(s)) {
                                String fid = s.substring(s.lastIndexOf("/") + 1);
                                fastTmpFileManagerService.insertTempFile(fid, oserviceOperator);
                            }
                        }
                    }
                }
            }
        }
    }

    /**
     * 删除临时表数据
     *
     * @param person
     * @throws Exception
     */
    public void deleteFileId(Person person) throws Exception {
        Map<ResourceType, List<String>> avatars = person.getAvatars();
        if (!CollectionUtils.isEmpty(avatars)) {
            for (List<String> fidList : avatars.values()) {
                if (!CollectionUtils.isEmpty(fidList)) {
                    for (String s : fidList) {
                        String fid = s.substring(s.lastIndexOf("/") + 1);
                        fastTmpFileManagerService.updateTempFile(fid);
                    }
                }
            }
        }

    }

    /**
     * 删除临时表数据
     *
     * @param personList
     * @throws Exception
     */
    public void deleteFileId(List<Person> personList) throws Exception {
        List<String> fileIdList = new ArrayList<>();
        for (Person person : personList) {
            Map<ResourceType, List<String>> avatars = person.getAvatars();
            if (!CollectionUtils.isEmpty(avatars)) {
                for (List<String> fidList : avatars.values()) {
                    if (!CollectionUtils.isEmpty(fidList)) {
                        for (String s : fidList) {
                            if (StringUtils.isNotBlank(s)) {
                                String fid = s.substring(s.lastIndexOf("/") + 1);
                                fileIdList.add(fid);
                            }
                        }
                    }
                }
            }
        }
        // 检验不为空
        if (!CollectionUtils.isEmpty(fileIdList)) {
            fastTmpFileManagerService.updateTempFile(fileIdList);
        }

    }

    public void pushPersons(List<Person> personList,Long tenantId) throws Exception {
        //推送人员
        if (!CollectionUtils.isEmpty(personList)) {
            personList.forEach(person -> {
                try {
                    pushPerson(person, Event.EventType.PERSON_ADD,tenantId);
                } catch (Exception e) {
                    log.error("推送人员失败", e);
                }
            });
        }
    }

    /**
     * 更新人员信息
     *
     * @param person
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void update(Person person,RequestUrlPrefix urlPrefix) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        // 校验唯一性字段，直接抛出异常
        fluentUniqueValidatorPerson(person, tenantId);
        Predicate predicate = QPerson.person.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QPerson.person.id.eq(person.getId()));
        // 获取人员信息，校验人员信息是否修改
        Person fPerson = personRepository.findOne(predicate);
        entityManager.unwrap(Session.class).evict(fPerson);
        List pathList = new ArrayList();
        List<Object> valueList = new ArrayList<>();
        if (!person.getName().equals(fPerson.getName())) {
            pathList.add(QPerson.person.name);
            valueList.add(person.getName());
        }
//        if (!person.getNo().equals(fPerson.getNo())) {
//            // 设置人员编号
//            pathList.add(QPerson.person.no);
//            valueList.add(person.getNo());
//        }
        // 图片判断，特殊处理
        if (!CollectionUtils.isEmpty(person.getAvatars())) {
            Map<ResourceType, List<String>> avatarsMap = FileUrlPathHandle.getStoreAvatarsMap(person.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()), GlobleConfig.ServerConfig.urlStoreRelative);
            pathList.add(QPerson.person.avatars);
            valueList.add(avatarsMap);
        }
        // 扩展字段
        boolean existed = ((!CollectionUtils.isEmpty(person.getVariable()) && !CollectionUtils.isEmpty(fPerson.getVariable()) && !person.getVariable().toString().equals(fPerson.getVariable().toString())) || !(CollectionUtils.isEmpty(person.getVariable()) && CollectionUtils.isEmpty(fPerson.getVariable())));
        if (existed) {
            pathList.add(QPerson.person.variable);
            valueList.add(person.getVariable());
        }
        // 判断分库（组）id
        if (StringUtils.isNoneBlank(person.getGroupId()) && !person.getGroupId().equals(fPerson.getGroupId())) {
            DeviceConfig deviceConfig = deviceConfigService.getConfigByParamKey(person.getGroupId(), tenantId);
            if (Objects.isNull(deviceConfig)) {
                log.info("提交数据groupId不合法（不存在）");
                throw new CommonException("person.groupId.incorrect");
            }
            pathList.add(QPerson.person.groupId);
            valueList.add(person.getGroupId());
        }
        int orgId = fPerson.getOrganizationId();
        // 判断组织id
        if (Objects.nonNull(person.getOrganizationId()) && !person.getOrganizationId().equals(fPerson.getOrganizationId())) {
            orgId = person.getOrganizationId();
            pathList.add(QPerson.person.organizationId);
            valueList.add(person.getOrganizationId());
        }
        // 判断性别
        if (Objects.nonNull(person.getSex()) && !person.getSex().equals(fPerson.getSex())) {
            pathList.add(QPerson.person.sex);
            valueList.add(person.getSex());
        }
        if (equalsPermitNull(person.getIdCard(), fPerson.getIdCard())) {
            pathList.add(QPerson.person.idCard);
            valueList.add(person.getIdCard());
        }
        if (equalsPermitNull(person.getMail(), fPerson.getMail())) {
            pathList.add(QPerson.person.mail);
            valueList.add(person.getMail());
        }
        if (Objects.nonNull(person.getHiredate())) {
            pathList.add(QPerson.person.hiredate);
            valueList.add(person.getHiredate());
        }
        if (equalsPermitNull(person.getRemark(), fPerson.getRemark())) {
            pathList.add(QPerson.person.remark);
            valueList.add(person.getRemark());
        }
        if (equalsPermitNull(person.getPhone(), fPerson.getPhone())) {
            pathList.add(QPerson.person.phone);
            valueList.add(person.getPhone());
        }
        if (equalsPermitNull(person.getPosition(), fPerson.getPosition())) {
            pathList.add(QPerson.person.position);
            valueList.add(person.getPosition());
        }
        if (equalsPermitNull(person.getIcNumber(), fPerson.getIcNumber())) {
            pathList.add(QPerson.person.icNumber);
            valueList.add(person.getIcNumber());
        }
        if (equalsPermitNull(person.getWgNumber(), fPerson.getWgNumber())) {
            pathList.add(QPerson.person.wgNumber);
            valueList.add(person.getWgNumber());
        }
        if (StringUtils.isNoneBlank(person.getPassword())) {
            if (!person.getPassword().equals(fPerson.getPassword())) {
                pathList.add(QPerson.person.password);
                valueList.add(person.getPassword());
            }
        } else {
            ServerConfig config = serverConfigService.getPersonPwdConfig(tenantId);
            pathList.add(QPerson.person.password);
            valueList.add(config.getConfigValue());
        }
        if (!CollectionUtils.isEmpty(valueList)) {
            addFileId(Lists.newArrayList(fPerson), oserviceOperator);
            // 删除文件临时表文件数据
            deleteFileId(person);
            long count = jpaQueryFactory.update(QPerson.person)
                    .set(pathList, valueList)
                    .set(QPerson.person.updateTime, new Date())
                    .where(predicate).execute();
            if (count > 0) {
                try {
                    if (fPerson.getOrganizationId() == orgId) {
                        asyncService.syncPerson(person, OperationType.UPDATE, oserviceOperator);
                    } else {
                        ruleApplyService.whenModifyOrg(fPerson.getId(), fPerson.getOrganizationId(), orgId, oserviceOperator);
                    }
                } catch (Exception e) {
                    log.error("更新操作，同步人员信息出现异常 updatePerson：{}", person, e);
                    throw new CommonException("person.sync.exception");
                }
                try {
                    pushPerson(person, Event.EventType.PERSON_UPDATE, oserviceOperator.getTenantId());
                } catch (Exception e) {
                    log.error("pushServer服务异常",e);
                }
            } else {
                log.info("没有可以更新的数据！");
            }
        } else {
            log.info("数据信息没有修改，不进行数据更新操作！");
        }
    }

    /**
     * 数据比较
     *
     * @param source
     * @param target
     * @return
     */
    public Boolean equalsPermitNull(String source, String target) {
        boolean flag = ((StringUtils.isNoneBlank(source) && StringUtils.isNoneBlank(target) && source.equals(target)) || (StringUtils.isBlank(source) && StringUtils.isBlank(target)));
        return !flag;
    }


    /**
     * 根据id删除人员
     *
     * @param id
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(String id) throws Exception {
        String[] ids = {id};
        delete(ids);
    }

    /**
     * 根据租户id和参数库id修改为空
     *
     * @param groupId
     * @param tenantId
     * @return
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public long deleteGroupByTenantIdAndGroupId(String groupId, Long tenantId) throws Exception {
        QPerson qPerson = QPerson.person;
        Predicate predicate = qPerson.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(qPerson.groupId.eq(groupId));
        long count = jpaQueryFactory.update(qPerson)
                .setNull(qPerson.groupId)
                .where(predicate)
                .execute();
        log.info("设置人员参数库完成");
        return count;
    }

    /**
     * 批量删除人员
     * 删除，待完善tianzc
     *
     * @param ids
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void delete(String[] ids) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QPerson.person.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QPerson.person.id.in(ids));
        Sort sort = new Sort(Sort.Direction.ASC, "id");
        Pageable pageable = new PageRequest(0, Constant.PERSON_PAGEABLE_SIZE, sort);
        List<HistoryPerson> historyPersonList = new ArrayList<>();
        HistoryPerson historyPerson = new HistoryPerson();
        List<Person> personSyncList = new ArrayList<>();
        // 获取要删除人员
        Page<Person> page;
        do {
            page = personRepository.findAll(predicate, pageable);
            pageable = new PageRequest(page.getNumber() + 1, page.getSize(), sort);
            if (page.getNumberOfElements() > 0) {
                int i = 0;
                List<Person> personList = page.getContent();
                for (Person person : personList) {
                    entityManager.unwrap(Session.class).evict(person);
                    BeanUtils.copyProperties(person, historyPerson);
                    historyPerson.setOperatorId(oserviceOperator.getUserId());
                    historyPerson.setOperatorName(oserviceOperator.getLoginName());
                    historyPerson.setUpdateTime(new Date());
                    historyPersonList.add(historyPerson);
                    if ((i + 1) % Constant.BATCH_INSERT_SIZE == 0) {
                        historyPersonRepository.save(historyPersonList);
                        historyPersonList = new ArrayList<>();
                    }
                    i++;
                }
                if (!CollectionUtils.isEmpty(historyPersonList)) {
                    historyPersonRepository.save(historyPersonList);
                    historyPersonList = new ArrayList<>();
                }
                personSyncList.addAll(personList);
            }
            // 批量入库
        } while (!page.isLast());
        // 逻辑删除人员信息
        long count = jpaQueryFactory.delete(QPerson.person).where(predicate).execute();
        if (count > 0) {
            try {
                asyncService.syncPerson(personSyncList, OperationType.DELETE, oserviceOperator);
            } catch (Exception e) {
                log.error("删除人员操作，同步人员信息出现异常 ids：{}", ids, e);
                throw new CommonException("person.sync.exception");
            }
            ruleApplyService.whenDelPerson(Lists.newArrayList(ids), oserviceOperator.getTenantId());
            try {
                // 推送
                pushPerson(ids, Event.EventType.PERSON_DELETE, oserviceOperator.getTenantId());
            } catch (Exception e) {
                log.error("pushServer服务异常",e);
            }
            log.info("人员删除完成！");
        } else {
            log.info("没有可以删除的数据！");
        }
    }


    private String formatPropertyName(String propertyName) {
        //组织做特殊处理
        if ("organizationId".equals(propertyName)) {
            propertyName = "organization";
        } else if ("avatars".equals(propertyName)) {
            propertyName = "avatarName";
        } else if ("groupId".equals(propertyName)) {
            propertyName = "groupName";
        }
        return propertyName;
    }


    /**
     * 批量导入处理特殊字段
     *
     * @param propertyName
     * @param tempPropertyVal
     * @return
     */
    private Object getPersonVoPropertyValue(PersonVo personVo, String propertyName, String tempPropertyVal) {
        Object propertyValue = tempPropertyVal;
        switch (propertyName) {
            case "sex":
                if (StringUtils.isNotBlank(tempPropertyVal)) {
                    if (PersonBatchResult.SEX_MALE.equals(tempPropertyVal.toLowerCase())) {
                        propertyValue = Sex.MALE;
                    } else if (PersonBatchResult.SEX_FEMALE.equals(tempPropertyVal.toLowerCase())) {
                        propertyValue = Sex.FEMALE;
                    } else {
                        propertyValue = null;
                        personVo.setSexTitle(tempPropertyVal);
                    }
                } else {
                    propertyValue = null;
                    personVo.setSexTitle(tempPropertyVal);
                }
                break;
            case "hiredate":
                propertyValue = DateUtil.parseStrToDate(tempPropertyVal, DateUtil.DATE_FORMAT_YYYY_MM_DD);
                if (Objects.isNull(propertyValue) && StringUtils.isNotBlank(tempPropertyVal)) {
                    personVo.setHireDateTitle(tempPropertyVal);
                }
                break;
            default:

        }
        return propertyValue;

    }

    @Override
    public PersonVo checkValidatorPersonVo(PersonVo personVo) {
        StringBuilder sbResult = new StringBuilder(personVo.getBatchAddResult());
        //唯一性校验， 和 默认密码 需要在入库之前处理
        //综合格式校验
        Person person = new Person();
        BeanUtils.copyProperties(personVo, person);
        try {
            //基础字段校验
            ComplexResult complexResult = fluentValidatorPerson(person, false);
            if (!complexResult.isSuccess()) {
                log.error("新建人员参数异常{}", complexResult);
                List<ValidationError> validationErrors = complexResult.getErrors();
                for (ValidationError error : validationErrors) {
                    String errorFieldCode = error.getField();
                    String errorMsgCode = error.getErrorMsg();
                    sbResult.append("[")
                            .append(Messages.getDefaultEmpty(errorFieldCode))
                            .append(" ")
                            .append(Messages.get(errorMsgCode, errorMsgCode))
                            .append("]");
                }
            }
            //扩展字段校验
            Map<String, String> variable = person.getVariable();
            if (!CollectionUtils.isEmpty(variable)) {
                ComplexResult ret = null;
                ValidationError error = null;
                String errorFieldCode = null;
                String errorMsgCode = null;
                FluentValidator fluentValidator = FluentValidator.checkAll().failOver();
                for (Map.Entry<String, String> entry : variable.entrySet()) {
                    ret = new ComplexResult();
                    fluentValidator.on(entry.getValue(), new IsStringWithinLengthRangeValidator(entry.getKey(), 0, 32, true));
                    ret = fluentValidator.doValidate().result(toComplex());
                    if (!ret.isSuccess()) {
                        error = ret.getErrors().get(0);
                        errorFieldCode = error.getField();
                        errorMsgCode = error.getErrorMsg();
                        sbResult.append("[")
                                .append(Messages.getDefaultEmpty("person.flexible.excel"))
                                .append(" ")
                                .append(Messages.get(errorMsgCode, errorMsgCode))
                                .append("]");
                        break;
                    }
                }

            }

            // 校验入职日期
            if (Objects.isNull(personVo.getSex()) &&
                    StringUtils.isNotBlank(personVo.getSexTitle())) {
                sbResult.append(Messages.get("check.validator.sex"));
            }
            //校验性别
            if (Objects.isNull(personVo.getHiredate()) &&
                    StringUtils.isNotBlank(personVo.getHireDateTitle())) {
                sbResult.append(Messages.get("check.validator.hiredate"));
            }

        } catch (Exception e) {
            log.error("批量导入 ，检测格式异常，e={}", e);
        }
        personVo.setBatchAddResult(sbResult.toString());
        return personVo;
    }


    /**
     * 批量导入校验personvo的合法性
     *
     * @param personVo
     * @return
     */
    @Override
    public PersonVo checkUniquePersonVo(PersonVo personVo, String defaultPwd, List<PersonConfigVo> configs, Organization rootOrg, Map<String, Integer> orgNameForIdMap, Map<String, String> groupNameForIdMap, Set<String> setNo) {
        StringBuilder sbResult = new StringBuilder(personVo.getBatchAddResult());
        //检查orgnaeme
        if (StringUtils.isBlank(personVo.getOrganization())) {
            personVo.setOrganizationId(rootOrg.getId());
            personVo.setOrganization(rootOrg.getName());
        } else if (!orgNameForIdMap.containsKey(personVo.getOrganization())) {
            sbResult.append(Messages.getDefaultEmpty("check.unexist.org"));
        } else {
            int orgId = orgNameForIdMap.get(personVo.getOrganization());
            //判断是否在授权组织内
            if (orgId != -1) {
                personVo.setOrganizationId(orgId);
            } else {
                sbResult.append(Messages.getDefaultEmpty("check.unauth.org"));
            }
        }
        //检查参数库
        if (StringUtils.isBlank(personVo.getGroupName())) {
            personVo.setGroupId(null);
        } else if (!groupNameForIdMap.containsKey(personVo.getGroupName())) {
            sbResult.append(Messages.getDefaultEmpty("check.unexist.group"));
        } else {
            personVo.setGroupId(groupNameForIdMap.get(personVo.getGroupName()));
        }

        //最后检查no 的唯一性
        if (StringUtils.isNotBlank(personVo.getNo())) {
            if (setNo.contains(personVo.getNo())) {
                sbResult.append(Messages.getDefaultEmpty("check.unique.no"));
            } else if (StringUtils.isBlank(sbResult.toString())) {
                setNo.add(personVo.getNo());
            }
        }

        if (StringUtils.isBlank(sbResult.toString()) &&
                StringUtils.isBlank(personVo.getPassword())) {
            personVo.setPassword(defaultPwd);
        }
        personVo.setBatchAddResult(sbResult.toString());
        return personVo;
    }


    @Override
    public Set<String> getAllPropertysInTenantId(long tenantId, PersonPropertysSetType propertysSetType) throws Exception {
        List<String> propertyValList = new ArrayList<>();
        QPerson qPerson = QPerson.person;
        Predicate predicate = qPerson.tenantId.eq(tenantId);
        switch (propertysSetType) {
            case no:
                propertyValList = jpaQueryFactory.select(qPerson.no).from(qPerson).where(predicate).groupBy(qPerson.no).fetch();
                break;
            case name:
                propertyValList = jpaQueryFactory.select(qPerson.name).from(qPerson).where(predicate).groupBy(qPerson.name).fetch();
                break;
            case idCard:
                propertyValList = jpaQueryFactory.select(qPerson.idCard).from(qPerson).where(predicate).groupBy(qPerson.idCard).fetch();
                break;
            case orgName:
                Predicate predicateOrg = QOrganization.organization.tenantId.eq(tenantId);
                propertyValList = jpaQueryFactory.select(QOrganization.organization.name).from(QOrganization.organization).where(predicateOrg).groupBy(QOrganization.organization.name).fetch();
                break;
            default:
        }
        return new HashSet<>(propertyValList);
    }

    @Override
    public List<PersonConfigVo> formatPersonConfig(List<PersonConfigVo> configs) {
        if (CollectionUtils.isEmpty(configs)) {
            return configs;
        }
        configs.stream().forEach(config -> {
            if (StringUtils.isNotBlank(config.getPropertyName())) {
                switch (config.getPropertyName()) {
                    case "sex":
                        StringBuilder sbSexInfo = new StringBuilder(config.getPropertyTitle());
                        sbSexInfo.append("(");
                        sbSexInfo.append(Messages.getDefaultEmpty("sex.male"));
                        sbSexInfo.append("[").append(PersonBatchResult.SEX_MALE).append("]");
                        sbSexInfo.append(Messages.getDefaultEmpty("sex.female"));
                        sbSexInfo.append("[").append(PersonBatchResult.SEX_FEMALE).append("]");
                        sbSexInfo.append(")");
                        config.setPropertyTitle(sbSexInfo.toString());
                        break;
                    case "avatars":
                        config.setPropertyTitle(config.getPropertyTitle() + Messages.get("person.download.excel.avatar", ""));
                    case "organizationId":
                        config.setPropertyTitle(config.getPropertyTitle());
                        break;
                    case "hiredate":
                        config.setPropertyTitle(config.getPropertyTitle() + "(yyyy-MM-dd)");
                        break;
                    default:
                }

            }
        });
//        //过滤了参数库
//        configs = configs.stream().filter(config ->
//                !"groupId".equals(config.getPropertyName())).collect(Collectors.toList());
        return configs;
    }


    @Override
    public List<PersonConfigVo> getFormatPersonConfigs(long tenantId) throws Exception {
        List<PersonConfigVo> configs = personConfigService.personConfigList(tenantId);
        if (CollectionUtils.isEmpty(configs)) {
            log.error("租户tenandId={}获取人员字段为空", tenantId);
            configs = new ArrayList<>();
        }
        configs = formatPersonConfig(configs);
        return configs;
    }

    @Override
    public List<PersonVo> getExportPersons(long tenantId, String name, String no, Integer organizationId) throws Exception {
        Predicate predicate = QPerson.person.tenantId.eq(tenantId).and(QPerson.person.type.eq(PersonType.FREQUENTER));
        if (StringUtils.isNotBlank(name)) {
            predicate = ((BooleanExpression) predicate).and(QPerson.person.name.contains(name));
        }
        if (StringUtils.isNotBlank(no)) {
            predicate = ((BooleanExpression) predicate).and(QPerson.person.no.contains(no));
        }
        if (Objects.nonNull(organizationId)) {
            predicate = ((BooleanExpression) predicate).and(QPerson.person.organizationId.eq(organizationId));
        }
        // 设置返回字段
        LinkedList<Path> linkedList = new LinkedList<>();
        linkedList.add(QPerson.person);
        linkedList.add(QPersonVo.personVo.organization);

        List<Tuple> personList = jpaQueryFactory.select(QPerson.person, QOrganization.organization.name.as(QPersonVo.personVo.organization))
                .from(QPerson.person)
                .leftJoin(QOrganization.organization)
                .on(QOrganization.organization.id.eq(QPerson.person.organizationId))
                .where(predicate)
                .orderBy(QPerson.person.createTime.desc(), QPerson.person.no.desc()).fetch();

        List<PersonVo> personVos = new ArrayList<>();
        Map<String, String> personAvatarMap = new HashMap<>();
        Map<String, String> groupIdNameMap = getGroupIdNameMap(tenantId, "idKey");
        //查询出
        PersonVo personVo = null;
        Set<String> avatarNameSet = new HashSet<>();
        for (int i = 0; i < personList.size(); i++) {
            personVo = new PersonVo();
            BeanUtils.copyProperties(personList.get(i).toArray()[0], personVo);
            //处理组织id-与名称关系
            personVo.setOrganization(String.valueOf(personList.get(i).toArray()[1]));
            //处理照片名称
            String avatarPath = "";
            if (!CollectionUtils.isEmpty(personVo.getAvatars()) && !CollectionUtils.isEmpty(personVo.getAvatars().get(ResourceType.VISIBLE_LIGHT))
                    && !StringUtils.isEmpty(personVo.getAvatars().get(ResourceType.VISIBLE_LIGHT).get(0))) {
                avatarPath = personVo.getAvatars().get(ResourceType.VISIBLE_LIGHT).get(0);
                String avatarName = personVo.getName();
                while (avatarNameSet.contains(avatarName)) {
                    avatarName = avatarName + "_1";
                }
                personVo.setAvatarName(avatarName + ".jpg");
                avatarNameSet.add(avatarName);
            }
            personAvatarMap.put(personVo.getName(), avatarPath);
            //处理参数库id与名称
            personVo.setGroupName(groupIdNameMap.get(personVo.getGroupId()));

            personVos.add(personVo);
        }

        return personVos;
    }

    @Override
    public void exportAndSaveExcelPersons(List<PersonVo> personVos, List<PersonConfigVo> configs, String fileExcelPath) throws Exception {
        ExcelDataExportPerson data = ExcelDataExportPerson.builder().configs(configs).personVos(personVos).build();
        File fileExcel = ExcelExportPersonUtil.exportExcelForFile(fileExcelPath, data);
        if (null == fileExcel) {
            throw new CommonException("export.person.allFile.exception");
        }
    }

    @Override
    public void downloadAndZipPersonAvatars(List<PersonVo> personVos, String avatarsDirPath, String allAvatarsZipPath) throws Exception {
        //下载图片到文件夹中
        handlePersonAvatars(avatarsDirPath, personVos);
        //压缩头像-》allAvatarsZipPath
        ZipUtil.fileToZip(avatarsDirPath, allAvatarsZipPath);
        //删除图片文件夹
        FileUtil.deletefilesOrDir(avatarsDirPath);
    }


    private void handlePersonAvatars(String avatarDirName, List<PersonVo> personVos) throws Exception {
        File avatarDir = new File(avatarDirName);
        if (!avatarDir.exists()) {
            avatarDir.mkdirs();
        }
        PersonVo personVo = null;
        File file = null;
        for (int i = 0; i < personVos.size(); i++) {
            personVo = personVos.get(i);
            if (Objects.isNull(personVo) || StringUtils.isBlank(personVo.getAvatarName()) || CollectionUtils.isEmpty(personVo.getAvatars()) || CollectionUtils.isEmpty(personVo.getAvatars().get(ResourceType.VISIBLE_LIGHT))
                    || StringUtils.isBlank(personVo.getAvatars().get(ResourceType.VISIBLE_LIGHT).get(0))) {
                continue;
            }

            String avatarName = personVo.getAvatarName();
            String avatarPath = personVo.getAvatars().get(ResourceType.VISIBLE_LIGHT).get(0);
            avatarPath = avatarPath.replaceAll("\\\\", "/");
            String fileId = avatarPath.substring(avatarPath.lastIndexOf("/") + 1);
            fileId = new String(Base64Utils.decode(fileId.getBytes()));

            String targetFileSrc = avatarDirName + File.separator + avatarName;

            file = new File(targetFileSrc);
            if (!file.exists()) {
                file.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(targetFileSrc, true);
            try {
                boolean flag = dfsClient.download(fileId, new DownloadCallback() {
                    @Override
                    public int recv(long fileSize, byte[] bytes, int i) {
                        byte result = 0;
                        try {
                            if (i < fileSize) {
                                fout.write(bytes, 0, i);
                            }
                        } catch (Exception e) {
                            log.error("获取人员图片保存出现异常，avatarName={},targetSrc={} , e={}", avatarName, targetFileSrc, e);
                            //中止下载
                            result = -1;
                        }
                        return result;
                    }
                });
            } catch (Exception e) {
                log.error("人员图片下载异常，e={}", e);
            } finally {
                if (null != fout) {
                    fout.close();
                }
                log.info("人员图片下载完成");
            }

        }

    }

    @Override
    public int getPersonByOrgIds(long tenantId, List<Integer> orgIdList) throws Exception {
        int count = 0;
        Predicate predicate = QPerson.person.tenantId.eq(tenantId).and(QPerson.person.organizationId.in(orgIdList));
        List<Tuple> list = jpaQueryFactory.select(QPerson.person,
                QOrganization.organization.name.as(QPersonVo.personVo.organization))
                .from(QPerson.person)
                .leftJoin(QOrganization.organization)
                .on(QOrganization.organization.id.eq(QPerson.person.organizationId))
                .where(predicate)
                .orderBy(QPerson.person.updateTime.desc()).fetch();
        if (!CollectionUtils.isEmpty(list)) {
            count = list.size();
        }

        return count;
    }

    /**
     * 根据租户id查询出当前租户内的参数库
     *
     * @param tenantId
     * @param type     idKey 为id作为key, nameKey 表示 name作为key
     * @return
     */
    private Map<String, String> getGroupIdNameMap(long tenantId, String type) {
        String typeIdKey = "idKey";
        String typeNameKey = "nameKey";
        Map<String, String> groupIdNameMap = new HashMap<>(16);
        List<DeviceConfig> deviceConfigList = null;
        try {
            deviceConfigList = deviceConfigService.getGroupListByTenantId(Long.valueOf(tenantId));
        } catch (Exception e) {
            log.error("根据租户tenantId={} 获取参数库失败, e={}", tenantId, e);
        }
        log.info("根据租户tenantId={} 获取参数库list={}", tenantId, JSONObject.toJSONString(deviceConfigList));
        if (CollectionUtils.isEmpty(deviceConfigList) ||
                (!typeIdKey.equals(type) && !typeNameKey.equals(type))) {
            return groupIdNameMap;
        }
        deviceConfigList.forEach(deviceConfig -> {
            if (typeIdKey.equals(type)) {
                groupIdNameMap.put(deviceConfig.getParamKey(), deviceConfig.getName());
            } else if (typeNameKey.equals(type)) {
                groupIdNameMap.put(deviceConfig.getName(), deviceConfig.getParamKey());
            }
        });
        return groupIdNameMap;
    }

    /**
     * 根据租户id查询出当前租户内的组织
     * name作为key, id为value
     *
     * @param oserviceOperator
     * @return
     */
    private Map<String, Integer> getOrgNameForIdMap(OserviceOperator oserviceOperator) {
        Map<String, Integer> orgNameIdMap = new HashMap<>(32);
        List<OrgVo> orgVoList = new ArrayList<>();
        try {
            orgVoList = organizationService.listAllOrg(oserviceOperator);
        } catch (Exception e) {
            orgVoList = new ArrayList<>();
            log.error("获取租户内全部组织异常，{}", e);
        }
        if (CollectionUtils.isEmpty(orgVoList)) {
            return orgNameIdMap;
        }
        //区分operator帐号授权的组织， -1表示未授权
        orgVoList.forEach(orgVo -> {
            if (!orgVo.isDisabled()) {
                orgNameIdMap.put(orgVo.getName(), orgVo.getId());
            } else {
                orgNameIdMap.put(orgVo.getName(), -1);
            }
        });
        return orgNameIdMap;
    }

    //======================================批量

    @Override
    public Page batchImportDataPage(Pageable pageable, OserviceOperator oserviceOperator,  RequestUrlPrefix urlPrefix) throws Exception {
        long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QBatchImportData.batchImportData.tenantId.eq(tenantId);
        JPAQuery<BatchImportData> query = jpaQueryFactory.select(QBatchImportData.batchImportData)
                .from(QBatchImportData.batchImportData)
                .where(predicate)
                .orderBy(QBatchImportData.batchImportData.importResultFlag.asc(), QBatchImportData.batchImportData.order.asc());
        long startTime = System.currentTimeMillis();
        long count = query.fetchCount();
        List<BatchImportData> batchImportDatas = query.offset(pageable.getOffset()).limit(pageable.getPageSize()).fetch();
        log.info("上传文件解析数据预览分页， 数据库操作耗时={}", (System.currentTimeMillis() - startTime));
        if (CollectionUtils.isEmpty(batchImportDatas)) {
            return new PageImpl<>(Collections.emptyList(), pageable, count);
        }
        List<PersonConfigVo> configs = getFormatPersonConfigs(tenantId);
        List<PersonVo> personVoList = new ArrayList<>();
        batchImportDatas.forEach(batchImportData -> {
            Map<Integer, String> rowdatasMap = batchImportData.getRowdata();
            Map<String, MultipartFileResp> imgFileResultMap = batchImportData.getPicResp();
            if (!CollectionUtils.isEmpty(rowdatasMap)) {
                PersonVo personVo = null;
                //处理rowdatasMap 转换为person
                try {
                    personVo = getPersonByExcelRowMap(rowdatasMap, configs, oserviceOperator);
                    personVo = getPersonVoWithAvatorFile(personVo, imgFileResultMap);
                    //转换person 的照片地址为全地址
                    personVo.setAvatars(FileUrlPathHandle.getShowAvatarsMap(personVo.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme())));
                    personVo.setBatchAddResult(batchImportData.getImportResultText());
                    personVo.setImportResult(batchImportData.isImportResultFlag());
                } catch (Exception e) {
                    log.error("rowdatas转person 异常，rowdata={}", JSONObject.toJSONString(rowdatasMap));
                    log.error("rowdatas转person 异常，e={}", e);
                    personVo = null;
                }
                if (Objects.nonNull(personVo)) {
                    personVoList.add(personVo);
                }
            }
        });

        return new PageImpl<>(personVoList, pageable, count);
    }

    @Override
    public PersonVo getPersonByExcelRowMap(Map<Integer, String> rowDataMap, List<PersonConfigVo> configs, OserviceOperator oserviceOperator) throws Exception {
        PersonVo personVo = new PersonVo();
        Map<String, String> variable = new HashMap<>(PersonBatchResult.PERSON_VARIABLE_MAP_SIZE_INIT);
        int configCount = configs.size();
        for (int j = 0; j < configCount; j++) {
            if (rowDataMap.containsKey(j)) {
                PropertyType propertyType = configs.get(j).getPropertyType();
                String propertyName = configs.get(j).getPropertyName();
                if (PropertyType.fixed == propertyType) {
                    propertyName = formatPropertyName(propertyName);
                    String tempPropertyValue = rowDataMap.get(j);
                    Object propertyValue = getPersonVoPropertyValue(personVo, propertyName, tempPropertyValue);
                    //通过反射对 personVo实体进行属性赋值
                    ReflectHelperUtil.setClassFieldValue(personVo, propertyName, propertyValue, PersonVo.class);
                } else {
                    variable.put(propertyName, rowDataMap.get(j));
                }
            }
        }
        personVo.setVariable(variable);
        //---------------
        personVo.setId(UUIDUtil.uuid());
        personVo.setTenantId(oserviceOperator.getTenantId());
        personVo.setOperatorId(oserviceOperator.getUserId());
        // 同步版本号
        long syncVersion = System.currentTimeMillis();
        personVo.setSyncVersion(syncVersion);
        personVo.setSyncStatus(SyncStatus.DATA_DEFAULT);
        personVo.setGroupId(null);
        personVo.setType(PersonType.FREQUENTER);
        personVo.setCreateTime(new Date());
        personVo.setUpdateTime(new Date());
        return personVo;
    }


    @Override
    public void batchImportDataInsert(OserviceOperator oserviceOperator, RequestUrlPrefix urlPrefix) throws Exception {
        long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QBatchImportData.batchImportData.tenantId.eq(tenantId);
        JPAQuery<BatchImportData> query = jpaQueryFactory.select(QBatchImportData.batchImportData)
                .from(QBatchImportData.batchImportData)
                .where(predicate)
                .orderBy(QBatchImportData.batchImportData.order.asc());

        List<PersonConfigVo> configs = getFormatPersonConfigs(tenantId);
        ServerConfig personPwdConfig = serverConfigService.getPersonPwdConfig(tenantId);
        String personPwd = personPwdConfig.getConfigValue();
        Organization roogOrg = organizationService.getRootOrgByTenantId(tenantId);
        Map<String, Integer> orgNameForIdMap = getOrgNameForIdMap(oserviceOperator);
        Map<String, String> groupNameForIdMap = getGroupIdNameMap(tenantId, "nameKey");
        Set<String> setNo = getAllPropertysInTenantId(tenantId, PersonPropertysSetType.no);

        long count = query.fetchCount();
        int maxInsert = 500;
        log.info("批量导入数据入库处理, 总数据count={}, maxInsert={}", count, maxInsert);
        if (count > maxInsert) {
            int total = 0;
            while (total < count) {
                List<BatchImportData> batchImportDatas = query.offset(total).limit(maxInsert).fetch();
                batchResultForImportData(batchImportDatas, configs, oserviceOperator, personPwd, roogOrg, orgNameForIdMap, groupNameForIdMap, setNo, urlPrefix);
                log.info("total={}, batchImportDatas.size={}", total, batchImportDatas.size());
                total += batchImportDatas.size();
            }
        } else {
            List<BatchImportData> batchImportDatas = query.fetch();
            batchResultForImportData(batchImportDatas, configs, oserviceOperator, personPwd, roogOrg, orgNameForIdMap, groupNameForIdMap, setNo, urlPrefix);
        }

    }

    /**
     * 将解析的数据转换成personvo
     *
     * @param batchImportDatas
     * @return
     */
    private void batchResultForImportData(List<BatchImportData> batchImportDatas, List<PersonConfigVo> configs, OserviceOperator oserviceOperator, String personPwd, Organization roogOrg, Map<String, Integer> orgNameForIdMap, Map<String, String> groupNameForIdMap, Set<String> setNo, RequestUrlPrefix urlPrefix) throws Exception {
        if (CollectionUtils.isEmpty(batchImportDatas)) {
            return;
        }
        List<Person> personToInsertList = new ArrayList<>();
        PersonVo personVo = null;
        BatchImportData importData = null;
        Map<Integer, String> rowdatasMap = null;
        StringBuilder importResultText = null;
        Map<String, MultipartFileResp> imgFileResultMap = null;
        StopWatch stopWatch = new StopWatch();
        stopWatch.start("批量导入人员检测转换");
        for (int i = 0; i < batchImportDatas.size(); i++) {
            importData = batchImportDatas.get(i);
            //转换personvo
            rowdatasMap = importData.getRowdata();
            personVo = getPersonByExcelRowMap(rowdatasMap, configs, oserviceOperator);
            //检查照片
            imgFileResultMap = importData.getPicResp();
            personVo = getPersonVoWithAvatorFile(personVo, imgFileResultMap);
            //格式合法性校验
            personVo = checkValidatorPersonVo(personVo);
            //唯一性检测
            personVo = checkUniquePersonVo(personVo, personPwd, configs, roogOrg, orgNameForIdMap, groupNameForIdMap, setNo);
            //可导入结果预检测
            importResultText = new StringBuilder(personVo.getBatchAddResult());
            if (StringUtils.isBlank(importResultText.toString())) {
                Person tempPerson = new Person();
                BeanUtils.copyProperties(personVo, tempPerson);
                try {
                    //删除imag临时表，图片永久保存
                    deleteFileId(tempPerson);
                    //转换person 的照片地址为全地址
                    tempPerson.setAvatars(FileUrlPathHandle.getStoreAvatarsMap(tempPerson.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()), GlobleConfig.ServerConfig.urlStoreRelative));
                    //合法人员入库
                    personRepository.save(tempPerson);
                    personToInsertList.add(tempPerson);
                    importResultText.append(Messages.getDefaultEmpty("person.batchAdd.success"));
                } catch (Exception e) {
                    log.error("批量导入，人员信息入库失败，tempPerson={}, e={}", tempPerson.toString(), e);
                    personVo.setImportResult(false);
                    importResultText.append(Messages.getDefaultEmpty("person.batchAdd.exception"));
                    importResultText.insert(0, Messages.getDefaultEmpty("person.batchAdd.failure"));
                }
            } else {
                personVo.setImportResult(false);
                importResultText.insert(0, Messages.getDefaultEmpty("person.batchAdd.failure"));
            }
            importData.setImportResultFlag(personVo.isImportResult());
            importData.setImportResultText(importResultText.toString());
            batchImportDatas.set(i, importData);
        }
        stopWatch.stop();
        stopWatch.start("批量导入人员入库,清空解析临时表");
        //删除imag临时表，图片永久保存
        //deleteFileId(personToInsertList);
        //合法人员入库
        //personRepository.save(personToInsertList);
        //更新中间表
        batchImportRepository.save(batchImportDatas);
        stopWatch.stop();
        //将人员添加到组织规则
        stopWatch.start("批量导入，添加人员到组织规则");
        try {
            addPersonToOrgRule(personToInsertList, oserviceOperator);
        } catch (Exception e) {
            log.error("批量导入，添加人员到组织规则异常", e);
        }
        stopWatch.stop();
        //批量导入人员推送功能 - 需求待定
//        stopWatch.start("批量导入，人员推送");
//        try {
//            pushPersons(personToInsertList);
//        } catch (Exception e) {
//            log.error("批量导入推送人员异常", e);
//        }
//        stopWatch.stop();
        log.info("批量导入人员数量={}, 耗时统计={}", batchImportDatas.size(), stopWatch.prettyPrint());

    }


    private void addPersonToOrgRule(List<Person> personList, OserviceOperator oserviceOperator) throws Exception {
        if (CollectionUtils.isEmpty(personList)) {
            log.info("批量导入，按组织规则下发，size=为空, tenantId={}, userID={}", oserviceOperator.getTenantId(), oserviceOperator.getUserId());
            return;
        }
        Map<Integer, List<String>> orgPersonIdMap = new HashMap<>();
        List<String> tempPersonIds = null;
        int size = personList.size();
        for (int i = 0; i < size; i++) {
            Integer orgId = personList.get(i).getOrganizationId();
            tempPersonIds = orgPersonIdMap.get(orgId);
            if (Objects.isNull(tempPersonIds)) {
                tempPersonIds = new ArrayList<>();
            }
            tempPersonIds.add(personList.get(i).getId());
            orgPersonIdMap.put(orgId, tempPersonIds);
        }
        //根据组织规则发送
        int count = 1;
        while (count <= 5) {
            try {
                ruleApplyService.whenAddOrg(orgPersonIdMap, oserviceOperator);
                log.info("批量导入，按组织规则下发，size={}, tenantId={}, userID={}", personList.size(), oserviceOperator.getTenantId(), oserviceOperator.getUserId());
                break;
            } catch (Exception e) {
                log.error("向组织规则中批量添加人异常", e);
            } finally {
                count++;
            }
        }

    }

    @Override
    public PersonVo getPersonVoWithAvatorFile(PersonVo personVo, Map<String, MultipartFileResp> imgFileResultMap) throws Exception {
        if (Objects.isNull(personVo)) {
            return personVo;
        }
        if (CollectionUtils.isEmpty(imgFileResultMap)) {
            imgFileResultMap = new HashMap<>();
        }
        //处理照片
        Map<ResourceType, List<String>> avatars = new HashMap<>();
        StringBuilder sbResult = new StringBuilder(personVo.getBatchAddResult());
        String avatarName = personVo.getAvatarName();
        //有照片名
        if (StringUtils.isNotBlank(avatarName)) {
            //照片不存在
            if (!imgFileResultMap.containsKey(avatarName)) {
                sbResult.append(Messages.getDefaultEmpty("check.empty.pic"));
            } else {
                //照片存在
                MultipartFileResp resp = imgFileResultMap.get(avatarName);
                if (Objects.isNull(resp)) {
                    //照片检测异常
                    sbResult.append(Messages.getDefaultEmpty("check.error.pic"));
                } else if (!resp.isFlag()) {
                    //照片检测失败
                    sbResult.append(PersonBatchResult.formatBatchAddResult(Messages.get(resp.getMessage())));
                } else {
                    //照片检测成功
                    List<String> imgUrl = new ArrayList<>();
                    imgUrl.add(resp.getUrl());
                    avatars.put(ResourceType.VISIBLE_LIGHT, imgUrl);
                }
            }
        }
        personVo.setBatchAddResult(sbResult.toString());
        personVo.setAvatars(avatars);

        return personVo;
    }

    @Override
    public BatchResult batchAddResultCount(OserviceOperator oserviceOperator) throws Exception {
        QBatchImportData qBatchImportData = QBatchImportData.batchImportData;
        Predicate predicate = qBatchImportData.tenantId.eq(oserviceOperator.getTenantId());
        Long total = jpaQueryFactory.select(qBatchImportData.id.count()).from(qBatchImportData).where(predicate).fetchOne();
        predicate = ((BooleanExpression) predicate).and(qBatchImportData.importResultFlag.eq(true));
        Long numSuccess = jpaQueryFactory.select(qBatchImportData.id.count()).from(qBatchImportData).where(predicate).fetchOne();
        long numFail = total - numSuccess;
        BatchResult batchResult = new BatchResult();
        batchResult.setTotal(total);
        batchResult.setNumSuccess(numSuccess);
        batchResult.setNumFail(numFail);
        return batchResult;
    }


    //==========================================导出人员
    @Override
    public long getExportPersonsCount(long tenantId, String name, String no, Integer organizationId) throws Exception {
        Predicate predicate = QPerson.person.tenantId.eq(tenantId).and(QPerson.person.type.eq(PersonType.FREQUENTER));
        if (StringUtils.isNotBlank(name)) {
            predicate = ((BooleanExpression) predicate).and(QPerson.person.name.contains(name));
        }
        if (StringUtils.isNotBlank(no)) {
            predicate = ((BooleanExpression) predicate).and(QPerson.person.no.contains(no));
        }
        if (Objects.nonNull(organizationId)) {
            predicate = ((BooleanExpression) predicate).and(QPerson.person.organizationId.eq(organizationId));
        }
        // 设置返回字段
        LinkedList<Path> linkedList = new LinkedList<>();
        linkedList.add(QPerson.person);
        linkedList.add(QPersonVo.personVo.organization);

        long count = jpaQueryFactory.select(QPerson.person.id.count())
                .from(QPerson.person)
                .where(predicate)
                .fetchOne();

        return count;
    }

    @Override
    public Optional<String> getPersonIdByOpenId(String openId, long tenantId) {
        Optional<Person> person = personRepository.findByOpenIdAndTenantId(openId, tenantId);
        return person.map(u -> u.getId());
    }

    @Override
    public Optional<Person> getPersonByOpenId(String openId, long tenantId) throws Exception {
        return personRepository.findByOpenIdAndTenantId(openId, tenantId);
    }

    @Override
    public String updatePersonOpenId(Predicate predicate, String openId) throws Exception {
        try {
            Person person = personRepository.findOne(predicate);
            if (Objects.nonNull(person)) {
                if (StringUtils.isNotBlank(person.getId())) {
                    person.setOpenId(openId);
                    personRepository.save(person);
                    return person.getId();
                }
            }
        }catch (Exception e){
            log.error("微信员工登陆接口，人员查询失败,",e);
        }
        throw new CommonException(400, "person.not.found");
    }

    @Override
    public void updatePerson(Person person) throws Exception {
        if (Objects.nonNull(person) && StringUtils.isNotBlank(person.getId())) {
            personRepository.save(person);
            return;
        }
        throw new CommonException(400, "person.not.found");
    }

    @Override
    public Person getPersonByNo(String no, long tenantId) throws Exception {
        Person person = personRepository.findByNoAndTenantId(no, tenantId);
        if (Objects.nonNull(person)) {
            if (StringUtils.isNotBlank(person.getId())) {
                return person;
            }
        }
        log.error("微信绑定异常，没有找到no对应的人员,no={}", no);
        throw new CommonException(400, "person.not.found.by.no");
    }

    @Override
    public Person checkPassword(String no, String password, long tenantId) throws Exception {
        Person person = personRepository.findByNoAndTenantId(no, tenantId);
        if (Objects.isNull(person) || StringUtils.isBlank(person.getId())) {
            throw new CommonException(400, "weChat.binding.user.number.not.fount");
        }
        if (StringUtils.isBlank(person.getPassword())) {
            throw new CommonException(400, "person.password.not.found");
        }
        if (!person.getPassword().equals(password)) {
            throw new CommonException(400, "person.password.incorrect");
        }
        return person;
    }

    /**
     * 推送人员
     *
     * @param obj       人员信息
     * @param eventType 事件类型
     */
    @Override
    public void pushPerson(Object obj, Event.EventType eventType, Long tenantId) throws Exception {
        //消息推送
        Event event = EventBuilder.newBuilder()
                .entity(JsonConvertor.beanToJson(obj))
                .timestamp(System.currentTimeMillis())
                .tenantId(String.valueOf(tenantId))
                .type(eventType).build();
        pushClient.send(event);
    }


}
