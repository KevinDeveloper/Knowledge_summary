package com.opnext.oservice.service.authority.impl;

import com.google.common.collect.Lists;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.bboxsupport.util.RedisCommonKeyUtil;
import com.opnext.bboxsupport.util.RedisLifeTimeUtil;
import com.opnext.oservice.domain.authority.AccountRole;
import com.opnext.oservice.domain.authority.role.*;
import com.opnext.oservice.dto.authority.role.RoleDetailDTO;
import com.opnext.oservice.repository.ComplicateQueryDao;
import com.opnext.oservice.repository.authority.*;
import com.opnext.oservice.service.authority.RoleService;
import com.opnext.oservice.service.base.BaseRedisService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author wanglu
 */
@Service
@Slf4j
public class RoleServiceImpl implements RoleService {
    @Autowired
    private AccountRoleRepository accountRoleRepository;
    @Autowired
    private RoleRepository roleRepository;
    @Autowired
    private RoleModuleRepository roleModuleRepository;
    @Autowired
    private RoleDeviceGroupRepository roleDeviceGroupRepository;
    @Autowired
    private RoleOrganizationRepository roleOrganizationRepository;
    @Autowired
    private ComplicateQueryDao complicateQueryDao;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    private BaseRedisService redisService;
    @Autowired
    private ModuleResourceRepository moduleResourceRepository;
    @Autowired
    private ResourceRepository resourceRepository;

    @Override
    public AccountRole getAccountRoleByAccountId(long accountId){
        AccountRole accountRole = accountRoleRepository.findByAccountId(accountId);
        return accountRole;
    }

    @Override
    public Page<Role> findRolePage(Pageable pageable,long tenantId){
        QRole qRole = QRole.role;
        Predicate predicate=qRole.tenantId.eq(tenantId).or(qRole.tenantId.isNull());
        Page<Role> page = roleRepository.findAll(predicate,pageable);

        page.getContent().forEach(role -> {
            if (role.getId()==0L){
                role.setName(Messages.get(role.getName()));
                role.setDescription(Messages.get(role.getDescription()));
            }
        });
        return page;
    }

    @Override
    public List<Role> findAllRole(long tenantId){
        return roleRepository.findAllByTenantIdAndIdIsNot(tenantId,0);
    }

    @Override
    public List<Long> getAccountIdsByRoleId(long roleId){
        List<AccountRole> accountRoles = accountRoleRepository.findAllByRoleId(roleId);
        List<Long> list = Lists.newArrayList();
        if (Objects.nonNull(accountRoles)){
            list = accountRoles.stream().map(accountRole -> { return accountRole.getAccountId();} ).collect(Collectors.toList());
        }
        return list;
    }

    @Override
    public RoleDetailDTO getRoleDetail(long roleId,long tenantId) throws Exception{
        //判断是不是超级管理员，如果是超级管理员，返回Type=super_admin,moduleIds=null,organizations=null,deviceGroups=null
        String suRoot= "0";
        QRole qRole = QRole.role;
        Predicate predicate=qRole.id.eq(roleId);
        if (!suRoot.equals(roleId+"")){
            predicate=((BooleanExpression) predicate).and(qRole.tenantId.eq(tenantId));
        }
        Role role = jpaQueryFactory.select(qRole).from(qRole).where(predicate).fetchOne();
        if (Objects.isNull(role)){
            //拒绝访问该资源，在tenantId下没有找到对一个的资源
            log.error("在tenantId {}下没有找到对一个的角色资源{}",tenantId,roleId);
            throw new CommonException(400,"parameter.incorrect");
        }
        if (role.getType().equals(Role.Type.DEFAULT)){
            return RoleDetailDTO.builder()
                    .id(roleId)
                    .name(role.getName())
                    .description(role.getDescription())
                    .type(role.getType())
                    .moduleIds(null)
                    .organizationIds(null)
                    .deviceGroupIds(null)
                    .build();
        }
        //查询role——module 全部modelId
        List<RoleModule> roleModules = roleModuleRepository.findAllByRoleId(roleId);
        List<Integer> moduleIds = roleModules.stream().map(roleModule -> { return roleModule.getModuleId();} ).collect(Collectors.toList());

        //查询role——organization 全部 organizationId
        List<RoleOrganization> roleOrganizations = roleOrganizationRepository.findAllByRoleId(roleId);
        List<Integer> organizationIds =roleOrganizations.stream().map(roleOrganization -> { return roleOrganization.getOrganizationId();} ).collect(Collectors.toList());

        //查询role——deviceGroup 全部deviceGroupId
        List<RoleDeviceGroup> roleDeviceGroups = roleDeviceGroupRepository.findAllByRoleId(roleId);
        List<Integer> deviceGroupIds =roleDeviceGroups.stream().map(roleDeviceGroup -> { return roleDeviceGroup.getDeviceGroupId();} ).collect(Collectors.toList());

        return RoleDetailDTO.builder()
                .id(roleId)
                .name(role.getName())
                .description(role.getDescription())
                .type(role.getType())
                .moduleIds(moduleIds)
                .organizationIds(organizationIds)
                .deviceGroupIds(deviceGroupIds)
                .build();
    }

    @Override
    @Transactional(rollbackFor=Exception.class)
    public void addRole(RoleDetailDTO roleDetailDTO,long accountId,long tenantId){
        if (Objects.isNull(roleDetailDTO.getModuleIds())){
            roleDetailDTO.setModuleIds(Lists.newArrayList());
        }
        if (Objects.isNull(roleDetailDTO.getOrganizationIds())){
            roleDetailDTO.setOrganizationIds(Lists.newArrayList());
        }
        if (Objects.isNull(roleDetailDTO.getDeviceGroupIds())){
            roleDetailDTO.setDeviceGroupIds(Lists.newArrayList());
        }
        // 获取当前操作人
        Role roleParam = new Role();
        BeanUtils.copyProperties(roleDetailDTO,roleParam);
        roleParam.setType(Role.Type.CREATED);
        roleParam.setCreatedBy(accountId);
        roleParam.setTenantId(tenantId);
        roleParam.setCreateTime(new Date());

        //新增role
        Role role = roleRepository.save(roleParam);

        //新增role——module
        List<RoleModule> roleModules = roleDetailDTO.getModuleIds().stream().map(moduleId -> {
            return RoleModule.builder().roleId(role.getId()).moduleId(moduleId).build();
        }).collect(Collectors.toList());
        roleModuleRepository.save(roleModules);

        //新增role——organization
        List<RoleOrganization> roleOrganizations = roleDetailDTO.getOrganizationIds().stream().map(organizationId -> {
            return RoleOrganization.builder().roleId(role.getId()).organizationId(organizationId).build();
        }).collect(Collectors.toList());
        roleOrganizationRepository.save(roleOrganizations);

        //新增role——deviceGroup
        List<RoleDeviceGroup> roleDeviceGroups = roleDetailDTO.getDeviceGroupIds().stream().map(deviceGroupId -> {
            return RoleDeviceGroup.builder().roleId(role.getId()).deviceGroupId(deviceGroupId).build();
        }).collect(Collectors.toList());
        roleDeviceGroupRepository.save(roleDeviceGroups);
    }

    @Override
    @Transactional(rollbackFor=Exception.class)
    public void modifyRole(long roleId,RoleDetailDTO roleDetailDTO,long tenantId) throws Exception{

        if (Objects.isNull(roleDetailDTO.getModuleIds())){
            roleDetailDTO.setModuleIds(Lists.newArrayList());
        }
        if (Objects.isNull(roleDetailDTO.getOrganizationIds())){
            roleDetailDTO.setOrganizationIds(Lists.newArrayList());
        }
        if (Objects.isNull(roleDetailDTO.getDeviceGroupIds())){
            roleDetailDTO.setDeviceGroupIds(Lists.newArrayList());
        }
        //判断如果是超级管理员，返回错误
        QRole qRole = QRole.role;
        Predicate predicate=qRole.tenantId.eq(tenantId).and(qRole.id.eq(roleId));
        Role role = complicateQueryDao.findOne(jpaQueryFactory.select(QRole.role,QRole.role).from(QRole.role).where(predicate),Role.class);
        if (Objects.isNull(role)){
            //拒绝访问该资源，在tenantId下没有找到对一个的资源
            log.error("在tenantId {}下没有找到对一个的角色资源{}",tenantId,roleId);
            return ;
        }
        if (role.getType().equals(Role.Type.DEFAULT)){
            log.error("角色{} 是超级管理员，因此不能被修改",roleId);
            throw new CommonException(400,"resource.conflict");
        }

        //更新role
        role.setName(roleDetailDTO.getName());
        role.setDescription(roleDetailDTO.getDescription());
        roleRepository.save(role);

        //删除role——module
        roleModuleRepository.deleteAllByRoleId(roleId);
        //更新role——module
        List<RoleModule> roleModules = roleDetailDTO.getModuleIds().stream().map(moduleId -> {
            return RoleModule.builder().roleId(role.getId()).moduleId(moduleId).build();
        }).collect(Collectors.toList());
        roleModuleRepository.save(roleModules);

        //删除role——organization
        roleOrganizationRepository.deleteAllByRoleId(roleId);
        //更新role——organization
        List<RoleOrganization> roleOrganizations = roleDetailDTO.getOrganizationIds().stream().map(organizationId -> {
            return RoleOrganization.builder().roleId(role.getId()).organizationId(organizationId).build();
        }).collect(Collectors.toList());
        roleOrganizationRepository.save(roleOrganizations);

        //删除role——deviceGroup
        roleDeviceGroupRepository.deleteAllByRoleId(roleId);
        //更新role——deviceGroup
        List<RoleDeviceGroup> roleDeviceGroups = roleDetailDTO.getDeviceGroupIds().stream().map(deviceGroupId -> {
            return RoleDeviceGroup.builder().roleId(role.getId()).deviceGroupId(deviceGroupId).build();
        }).collect(Collectors.toList());
        roleDeviceGroupRepository.save(roleDeviceGroups);

        List<ModuleResource> moduleResources = moduleResourceRepository.findAllByModuleIdIn(roleDetailDTO.getModuleIds());
        List<Integer> resourceIds = moduleResources.stream().map(moduleResource -> { return moduleResource.getResourceId(); }).distinct().collect(Collectors.toList());
        List<Resource> resources = resourceRepository.findDistinctByIdInOrScope(resourceIds,Resource.Scope.All);

        String roleResourceKey = RedisCommonKeyUtil.ROLE_RESOURCE+role.getId();
        String roleOrgKey = RedisCommonKeyUtil.ROLE_ORG+role.getId();
        String roleDevKey = RedisCommonKeyUtil.ROLE_DEV+role.getId();

        if (redisService.hasKey(roleResourceKey)){
            redisService.deleteKey(roleResourceKey);
            if (resources.size()>0){
                redisService.setListValue(roleResourceKey,resources);
                redisService.setLifeTime(roleResourceKey,RedisLifeTimeUtil.roleRightTime());
            }
        }
        if (redisService.hasKey(roleOrgKey)){
            redisService.deleteKey(roleOrgKey);
            if (CollectionUtils.isEmpty(roleDetailDTO.getOrganizationIds())) {
                redisService.setListValue(roleOrgKey, roleDetailDTO.getOrganizationIds());
                redisService.setLifeTime(roleOrgKey,RedisLifeTimeUtil.roleRightTime());
            }
        }
        if (redisService.hasKey(roleDevKey)){
            redisService.deleteKey(roleDevKey);
            if (CollectionUtils.isEmpty(roleDetailDTO.getDeviceGroupIds())) {
                redisService.setListValue(roleDevKey, roleDetailDTO.getDeviceGroupIds());
                redisService.setLifeTime(roleDevKey,RedisLifeTimeUtil.roleRightTime());
            }
        }
    }

    @Override
    @Transactional(rollbackFor=Exception.class)
    public void deleteRole(long roleId,long tenantId) throws Exception{
        QRole qRole = QRole.role;
        Predicate predicate=qRole.tenantId.eq(tenantId).and(qRole.id.eq(roleId));
        Role role = complicateQueryDao.findOne(jpaQueryFactory.select(QRole.role,QRole.role).from(QRole.role).where(predicate),Role.class);
        if (Objects.isNull(role)){
            //拒绝访问该资源，在tenantId下没有找到对一个的资源
            log.error("在tenantId {}下没有找到对一个的角色资源{}",tenantId,roleId);
            return ;
        }
        if (Role.Type.DEFAULT == role.getType()){
            log.error("角色{} 是超级管理员，因此访不能被删除",roleId);
            throw new CommonException(400,"resource.conflict");
        }

        //删除role——module
        roleModuleRepository.deleteAllByRoleId(roleId);

        //删除role——organization
        roleOrganizationRepository.deleteAllByRoleId(roleId);

        //删除role——deviceGroup
        roleDeviceGroupRepository.deleteAllByRoleId(roleId);

        //删除accountRole对应关系
        //查询数据库
        List<AccountRole> accountRoles = accountRoleRepository.findAllByRoleId(role.getId());
        for (AccountRole accountRole: accountRoles) {
            if (Objects.nonNull(accountRole)){
                String accountIdKey = RedisCommonKeyUtil.ACCOUNT_ROLE+accountRole.getAccountId();
                if (StringUtils.isNotBlank(redisService.getValue(accountIdKey))){
                    redisService.deleteKey(accountIdKey);
                }
                accountRoleRepository.save(AccountRole.builder().roleId(null).accountId(accountRole.getAccountId()).build());
            }
        }

        //删除role
        roleRepository.delete(role.getId());
        //删除redis中的role_resource关联
        String roleResourceKey = RedisCommonKeyUtil.ROLE_RESOURCE+role.getId();
        String roleOrgKey = RedisCommonKeyUtil.ROLE_ORG+role.getId();
        String roleDevKey = RedisCommonKeyUtil.ROLE_DEV+role.getId();
        if (redisService.hasKey(roleResourceKey) ){
            redisService.deleteKey(roleResourceKey);
        }
        if (redisService.hasKey(roleOrgKey) ){
            redisService.deleteKey(roleOrgKey);
        }
        if (redisService.hasKey(roleDevKey)) {
            redisService.deleteKey(roleDevKey);
        }
    }

    @Override
    public List<Role> findAllByNameAndTenantId(String name,long tenantId){
        List<Role> roles = roleRepository.findAllByNameAndTenantId(name, tenantId);
        return roles;
    }


    @Override
    public List<Role> getRolesInAllTenant() {
        return (List<Role>) roleRepository.findAll();
    }
}
