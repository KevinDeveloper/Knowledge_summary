package com.opnext.oservice.repository.device;

import com.opnext.oservice.domain.device.TenantActiveCode;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @Title: 
 * @Description: 
 * @author tianzc
 * @Date 下午5:09 18/5/7
 */ 
public interface TenantActiveCodeRepository extends PagingAndSortingRepository<TenantActiveCode, Integer>, QueryDslPredicateExecutor<TenantActiveCode> {
}
