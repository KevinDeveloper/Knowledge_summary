package com.opnext.oservice.domain.account;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

/**
 * @author wanglu
 */
@Data
@Builder
public class Account {
    private Long id;
    private String loginName;
    private String password;
    private Long tenantId;
    private Boolean isRoot;
    /**
     * 0停用，1启用
     */
    private Integer status;
    private String email;
    private Long createdBy;
    private String phone;
    private Long createTime;
    @Tolerate
    public Account(){}
}