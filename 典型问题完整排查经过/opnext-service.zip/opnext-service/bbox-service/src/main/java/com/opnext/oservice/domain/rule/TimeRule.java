package com.opnext.oservice.domain.rule;

import io.swagger.annotations.ApiModel;
import lombok.Data;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/25 13:10
 */
@Data
@ApiModel(description="规则时间段对象")
public class TimeRule extends com.opnext.domain.access.TimeRule {

}

