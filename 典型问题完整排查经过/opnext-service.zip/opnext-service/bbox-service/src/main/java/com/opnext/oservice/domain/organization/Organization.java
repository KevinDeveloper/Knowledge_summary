package com.opnext.oservice.domain.organization;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 组织
 * @ClassName: organization
 * @Description:
 * @Author: Kevin
 * @Date: 2018/5/10 15:24
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
@Table(name = "organization")
@EntityListeners(AuditingEntityListener.class)
public class Organization implements Serializable {
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Integer id;

    @Column(name = "parent_id")
    private Integer parentId;

    @Column(name = "tenant_id")
    private Long tenantId;

    @Column(name = "operator_id")
    private Long operatorId;

    @Column(name = "name")
    private String name;

    @Column(name = "remark")
    private String remark;

    @Column(name = "org_type")
    private OrgType orgType ;

    @Column(name = "create_time")
    @CreatedDate
    private Date createTime;

    @Column(name = "update_time")
    @LastModifiedDate
    private Date updateTime;

    @Transient
    public static String otherOrgName = "other";
    /**
     * 组织类型
     */
    public enum OrgType{
        /**
         * saas组织
         */
        SAAS((byte) 0),
        /**
         * other组织
         */
        OTHER((byte)1);

        private byte value;

        OrgType(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }

}
