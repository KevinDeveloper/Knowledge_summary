package com.opnext.oservice.repository.log;

import com.opnext.oservice.domain.log.OperationLog;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @author wanglu
 */
public interface OperationLogRepository extends PagingAndSortingRepository<OperationLog, Integer>,
        QueryDslPredicateExecutor<OperationLog> {
}
