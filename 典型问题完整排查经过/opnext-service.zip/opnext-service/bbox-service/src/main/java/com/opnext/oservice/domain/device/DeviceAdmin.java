package com.opnext.oservice.domain.device;

import com.opnext.oservice.domain.converter.DeviceAdminAvatarsConverter;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.util.Date;
import java.util.List;

/**
 * @Title: 设备管理员类
 * @Description: --
 * @author tianzc
 * @Date 下午4:46 18/5/7
 */
@Entity
@Data
@Table(name = "device_admin")
@EntityListeners(AuditingEntityListener.class)
public class DeviceAdmin {

    @Id
    @GeneratedValue
    private Integer id;
    /**
     * 设备管理员名称
     */
    private String name;
    /**
     * 设备管理员密码
     */
    private String password;
    /**
     * 联系方式
     */
    private String phone;

    @Column(name = "avatars")
    @Convert(converter = DeviceAdminAvatarsConverter.class)
    private List<String> avatars;

    /**
     * 备注
     */
    private String remark;

    @Column(name = "create_time")
    @CreatedDate
    private Date createTime;

    @Column(name = "update_time")
    @LastModifiedDate
    private Date updateTime;

    /**
     * 操作者id
     */
    @Column(name = "operator_id")
    private Long operatorId;

    @Column(name = "operator_name")
    private String operatorName;


    @Column(name = "tenant_id")
    private Long tenantId;

    @Transient
    private Integer[] deviceIds;
}
