package com.opnext.oservice.domain.rule;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Author: lixiuwen
 * @Date: 2018/9/17 16:35
 */
@Data
@Entity
@Table(name = "person")
public class OrgPerson {
    @Id
    private String id;

    @Column(name="organization_id")
    private int organizationId;
}
