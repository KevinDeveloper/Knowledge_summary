package com.opnext.oservice.domain.converter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import javax.persistence.AttributeConverter;
import java.util.ArrayList;
import java.util.List;

/**
 * @author tianzc
 */
@Slf4j
public class DeviceAdminAvatarsConverter implements AttributeConverter<List<String>, String> {

    /**
     * Converts the value stored in the entity attribute into the
     * data representation to be stored in the database.
     *
     * @param attribute the entity attribute value to be converted
     * @return the converted data to be stored in the database column
     */
    @Override
    public String convertToDatabaseColumn(List<String> attribute) {
        ObjectMapper mapper = new ObjectMapper();
        String str = null;
        try {
            if (!CollectionUtils.isEmpty(attribute)) {
                str = mapper.writeValueAsString(attribute);
            }
        } catch (JsonProcessingException e) {
            log.error("jackson转换异常", e);
        }
        return str;
    }

    /**
     * Converts the data stored in the database column into the
     * value to be stored in the entity attribute.
     * Note that it is the responsibility of the converter writer to
     * specify the correct dbData type for the corresponding column
     * for use by the JDBC driver: i.e., persistence providers are
     * not expected to do such type conversion.
     *
     * @param dbData the data from the database column to be converted
     * @return the converted value to be stored in the entity attribute
     */
    @Override
    public List<String> convertToEntityAttribute(String dbData) {
        ObjectMapper mapper = new ObjectMapper();
        List<String> list = new ArrayList<>();
        try {
            if (StringUtils.isNoneBlank(dbData)) {
                JavaType javaType = mapper.getTypeFactory().constructParametricType(List.class, String.class);
                list = mapper.readValue(dbData, javaType);
            } else {
                return list;
            }
        } catch (Exception e) {
            log.error("jackson转换异常", e);
        }
        return list;
    }
}
