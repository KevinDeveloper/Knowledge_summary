package com.opnext.oservice.service.device;

import com.opnext.oservice.domain.device.SFailRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * @author tianzc
 */
public interface FailRecordService {
    /**
     * 获取设备处理失败记录
     *
     * @param pageable 分页参数：page 查询页，size 分页条数
     * @param sFailRecord 查询条件：commandId 指令id，deviceSn 设备sn
     * @return page 返回分页对象
     * @throws Exception
     */
    Page getPage(Pageable pageable, SFailRecord sFailRecord) throws Exception;
}
