package com.opnext.oservice.service.log;

import com.opnext.oservice.domain.authority.role.QResource;
import com.opnext.oservice.domain.authority.role.Resource;
import com.opnext.oservice.domain.log.OperationLog;
import com.opnext.oservice.dto.authority.role.ResourceDTO;
import com.opnext.oservice.service.authority.ResourceService;
import com.querydsl.core.types.Predicate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.Objects;

/**
 * @author wanglu
 */
@Slf4j
@Service
public class LogAsyncTask {
    @Autowired
    ResourceService resourceService;
    @Autowired
    OperationLogService operationLogService;

    @Async
    public void saveOperateLog(String methodMappingStr,String methodName,Long accountId,String loginName,Long tenantId, int status) throws Exception{
        if (!methodName.equals(Resource.Method.POST.name())
                && !methodName.equals(Resource.Method.PUT.name())
                && !methodName.equals(Resource.Method.DELETE.name())){
            log.debug("不是PUT POST DELETE接口，不记录日志");
            return;
        }

        if (Objects.isNull(accountId) || accountId==0){
            log.info("第三方的接口调用，不记录操作记录");
            return;
        }

        QResource qresource =QResource.resource;
        Predicate predicate =qresource.url.eq(methodMappingStr).and(qresource.method.eq(Resource.Method.valueOf(methodName)));
        ResourceDTO resourceDTO = resourceService.findApiResource(predicate);

        if (Objects.isNull(resourceDTO)){
            log.error("该接口不存在,{}",methodMappingStr);
            return;
        }

        try {
            operationLogService.save(
                    OperationLog.builder()
                            .accountId(accountId)
                            .loginName(loginName)
                            .moduleId(resourceDTO.getModuleId())
                            .moduleName(resourceDTO.getModuleName())
                            .resourceId(resourceDTO.getResourceId())
                            .resourceName(resourceDTO.getResourceName())
                            .tenantId(tenantId)
                            .occurTime(new Date())
                            .resultStatus(status>=400?OperationLog.ResultStatus.FAILED:OperationLog.ResultStatus.SUCCESS)
                            .build()
            );
        }catch (Exception e1){
            log.error("保存操作记录失败,{}",e1);
        }
    }
}
