package com.opnext.oservice.service.rule.impl;

import com.google.common.collect.Sets;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.domain.PersonType;
import com.opnext.domain.response.IDRuleResp;
import com.opnext.omessage.support.SimpleMessageTemplate;
import com.opnext.oservice.conf.AuthorizeProperties;
import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.domain.device.QDevice;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.domain.rule.QRuleApply;
import com.opnext.oservice.domain.rule.QRuleDevice;
import com.opnext.oservice.domain.rule.Rule;
import com.opnext.oservice.domain.rule.RuleDevice;
import com.opnext.oservice.feign.OMessageFeign;
import com.opnext.oservice.repository.ComplicateQueryDao;
import com.opnext.oservice.repository.rule.RuleDeviceRepository;
import com.opnext.oservice.service.rule.RuleApplyService;
import com.opnext.oservice.service.rule.RuleApplySyncService;
import com.opnext.oservice.service.rule.RuleDeviceService;
import com.opnext.oservice.service.rule.RuleService;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.*;

/**
 * @Author: lixiuwen
 * @Date: 2018/7/2 19:01
 */
@Slf4j
@Service
public class RuleDeviceServiceImpl implements RuleDeviceService {
    @Resource
    private OMessageFeign oMessageFeign;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    private RuleService ruleService;
    @Autowired
    private RuleApplyService ruleApplyService;
    @Autowired
    private RuleApplySyncService ruleApplySyncService;
    @Autowired
    private RuleDeviceRepository ruleDeviceRepository;
    @Autowired
    private AuthorizeProperties authorizeProperties;
    @Autowired
    private ComplicateQueryDao complicateQueryDao;

    /**
     * 删除规则中设备
     *
     * @param deviceSnList     设备Sn集合
     * @param ruleId           规则ID
     * @param oserviceOperator 当前登录人信息
     * @throws Exception
     */
    @Override
    public void delDeviceFromRule(List<String> deviceSnList, Integer ruleId, OserviceOperator oserviceOperator) throws Exception {
        if (deviceSnList == null || deviceSnList.size() == 0 || ruleId == null) {
            log.debug("参数为空");
            return;
        }
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        long lCount = jpaQueryFactory
                .selectFrom(qRuleDevice)
                .where(qRuleDevice.deviceSn.in(deviceSnList)
                        .and(qRuleDevice.tenantId.eq(oserviceOperator.getTenantId()))
                        .and(qRuleDevice.ruleId.eq(ruleId)))
                .fetchCount();
        if (lCount != deviceSnList.size()) {
            log.debug("参数不匹配");
            throw new CommonException("org.parameter.incorrect");
        }
        Predicate predicate = qRuleDevice.deviceSn.in(deviceSnList).and(qRuleDevice.ruleId.eq(ruleId)).and(qRuleDevice.tenantId.eq(oserviceOperator.getTenantId()));
        Long lResult = jpaQueryFactory.delete(qRuleDevice).where(predicate).execute();
        log.info(String.format("设备批量移除规则，设备数：%d，执行成功数：%d", deviceSnList.size(), lResult));
        List<Integer> delRuleIdList = new ArrayList<>();
        delRuleIdList.add(ruleId);
        //发送DeleteRule指令
        sendDelRuleToDevice(deviceSnList, delRuleIdList, oserviceOperator);
    }

    /**
     * 向规则中添加设备
     *
     * @param deviceSnList     设备Sn集合
     * @param rule             规则
     * @param oserviceOperator 当前登录人信息
     * @throws Exception
     */
    @Override
    public void addDeviceToRule(List<String> deviceSnList, Rule rule, OserviceOperator oserviceOperator) throws Exception {
        if (deviceSnList == null || deviceSnList.size() == 0 || rule == null) {
            log.debug("参数为空");
            return;
        }
        QDevice qDevice = QDevice.device;
        List<Tuple> tupleList = jpaQueryFactory.select(qDevice.id, qDevice.sn)
                .from(qDevice)
                .where(qDevice.sn.in(deviceSnList).and(qDevice.tenantId.eq(oserviceOperator.getTenantId())))
                .fetch();
        if (tupleList == null) {
            String notExistDeviceSn = StringUtils.join(deviceSnList, ",");
            log.debug("SN号不存在.{}", notExistDeviceSn);
            throw new CommonException(StringUtils.join(deviceSnList, ",") + "org.parameter.incorrect");
        }
        Map<String, Integer> idAndSnMap = new HashMap<>(tupleList.size());
        List<String> newDeviceSnList = new ArrayList<>();
        tupleList.forEach(tuple -> {
            newDeviceSnList.add(tuple.get(qDevice.sn));
            idAndSnMap.put(tuple.get(qDevice.sn), tuple.get(qDevice.id));
        });
        if (newDeviceSnList.size() != deviceSnList.size()) {
            deviceSnList.removeAll(newDeviceSnList);
            String notExistDeviceSn = StringUtils.join(deviceSnList, ",");
            log.debug("SN号不存在.{}", notExistDeviceSn);
            throw new CommonException(String.format(Messages.get("unexist.formatter"), notExistDeviceSn));
        }
        List<RuleDevice> ruleDevices = new ArrayList<>();
        for (String deviceSn : newDeviceSnList) {
            if (!idAndSnMap.containsKey(deviceSn)) {
                newDeviceSnList.remove(deviceSn);
                continue;
            }
            RuleDevice ruleDevice = new RuleDevice();
            ruleDevice.setDeviceId(idAndSnMap.get(deviceSn));
            ruleDevice.setDeviceSn(deviceSn);
            ruleDevice.setCreateTime(new Date());
            ruleDevice.setCreateBy(String.valueOf(oserviceOperator.getUserId()));
            ruleDevice.setTenantId(oserviceOperator.getTenantId());
            ruleDevice.setAppId(oserviceOperator.getAppId());
            ruleDevice.setRuleId(rule.getId());
            ruleDevices.add(ruleDevice);
        }
        if (ruleDevices.size() == 0) {
            log.debug("设备不存在");
            throw new CommonException("DataNotFound");
        }
        ruleDeviceRepository.save(ruleDevices);
        //发送GetRule指令.
        sendGetRuleToDevice(newDeviceSnList, rule.toDomainRule(authorizeProperties.getClientId()), oserviceOperator);
        //添加要绑定的人员到同步表中
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        Predicate predicate = qRuleApply.ruleId.eq(rule.getId()).and(qRuleApply.tenantId.eq(oserviceOperator.getTenantId()));
        List<String> personIdList = null;
        if (rule.getType() == Rule.RuleType.ORGNIZATION.ordinal()) {
            predicate = ((BooleanExpression) predicate).and(qRuleApply.organizationId.isNotNull());
            List<Integer> organizationIdList = jpaQueryFactory.select(qRuleApply.organizationId).from(qRuleApply).where(predicate).fetch();
            if (CollectionUtils.isNotEmpty(organizationIdList)) {
                personIdList = ruleService.orgIdToPersonId(organizationIdList, oserviceOperator.getTenantId());
            }
        } else {
            predicate = ((BooleanExpression) predicate).and(qRuleApply.personId.isNotNull());
            personIdList = jpaQueryFactory.select(qRuleApply.personId).from(qRuleApply).where(predicate).fetch();
        }
        if (CollectionUtils.isNotEmpty(personIdList)) {
            String commandId = ruleApplySyncService.insertApplySync(rule.getId(), IDRuleResp.OperationType.BIND, personIdList);
            ruleApplyService.sendRuleApplyToDevice(newDeviceSnList, commandId, IDRuleResp.OperationType.BIND, oserviceOperator);
        }
    }

    /**
     * 向设备发送删除规则指令
     *
     * @param deviceSnList     设备Sn集合
     * @param delRuleIdList    规则ID集合
     * @param oserviceOperator 当前登录人信息
     */
    @Override
    public void sendDelRuleToDevice(List<String> deviceSnList, List<Integer> delRuleIdList, OserviceOperator oserviceOperator) {
        if (deviceSnList == null || deviceSnList.size() == 0) {
            log.debug("deviceSnList is null");
            return;
        }
        SimpleMessageTemplate template = SimpleMessageTemplate
                .operator(String.valueOf(oserviceOperator.getTenantId()), String.valueOf(oserviceOperator.getLoginName()))
                .appId(oserviceOperator.getAppId())
                .scope(Sets.newHashSet(deviceSnList));
        //发送DeleteRule指令
        List<String> resultList = oMessageFeign.send(template.deleteRule(delRuleIdList));
        log.debug("deleteRule，Result:" + String.valueOf(resultList));
    }

    /**
     * 向设备发送获取规则指令
     *
     * @param deviceSnList     设备ID集合
     * @param domainRule       规则信息
     * @param oserviceOperator 当前登录人信息
     */
    @Override
    public void sendGetRuleToDevice(List<String> deviceSnList, com.opnext.domain.access.Rule domainRule, OserviceOperator oserviceOperator) {
        if (deviceSnList == null || deviceSnList.size() == 0) {
            log.debug("deviceSnList is null");
            return;
        }
        SimpleMessageTemplate template = SimpleMessageTemplate
                .operator(String.valueOf(oserviceOperator.getTenantId()), String.valueOf(oserviceOperator.getLoginName()))
                .appId(oserviceOperator.getAppId())
                .scope(Sets.newHashSet(deviceSnList));
        //发送GetRule指令
        List<com.opnext.domain.access.Rule> domainRuleList = new ArrayList<>();
        domainRuleList.add(domainRule);
        List<String> resultList = oMessageFeign.send(template.getRule(domainRuleList));
        log.debug("getRule，Result:" + String.valueOf(resultList));
    }

    /**
     * 根据规则ID获取绑定的SN号集合
     *
     * @param ruleId 规则ID
     * @return
     */
    @Override
    public List<String> getSnsByRuleId(int ruleId) {
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        return jpaQueryFactory.selectDistinct(qRuleDevice.deviceSn)
                .from(qRuleDevice)
                .where(qRuleDevice.ruleId.eq(ruleId)).fetch();
    }

    /**
     * 获取规则集合下设备的数量
     *
     * @param ruleIdList 规则集合
     * @return
     */
    @Override
    public Map<Integer, Long> getDeviceCountMap(List<Integer> ruleIdList) {
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        List<Tuple> tuplesDeviceCount = jpaQueryFactory
                .select(qRuleDevice.ruleId, qRuleDevice.deviceSn.count())
                .from(qRuleDevice)
                .where(qRuleDevice.ruleId.in(ruleIdList))
                .groupBy(qRuleDevice.ruleId)
                .fetch();
        Map<Integer, Long> deviceCountMap = new HashMap<>(tuplesDeviceCount.size());
        tuplesDeviceCount.forEach(tuple -> deviceCountMap.put(tuple.get(qRuleDevice.ruleId), tuple.get(1, Long.class)));
        return deviceCountMap;
    }

    /**
     * 获取规则下绑定的所有设备ID
     *
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return
     */
    @Override
    public List<Integer> getDeviceIdByRuleId(int ruleId, long tenantId) {
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        Predicate predicate = qRuleDevice.ruleId.eq(ruleId).and(qRuleDevice.tenantId.eq(tenantId));
        return jpaQueryFactory.select(qRuleDevice.deviceId).from(qRuleDevice).where(predicate).fetch();
    }

    /**
     * 获取规则绑定的设备
     *
     * @param predicate 查询条件
     * @param pageable  分页信息
     * @return
     */
    @Override
    public Page<Device> getDevice(Predicate predicate, Pageable pageable) {
        QDevice qDevice = QDevice.device;
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        return complicateQueryDao.find(jpaQueryFactory.select(qDevice)
                .from(qDevice, qRuleDevice)
                .where(predicate)
                .orderBy(qDevice.status.asc()), pageable);
    }

    /**
     * 删除设备时调用此接口
     *
     * @param deviceSnList 设备SN集合
     * @param tenantId     租户ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void whenDelDevice(List<String> deviceSnList, long tenantId) {
        if (deviceSnList == null || deviceSnList.size() == 0) {
            return;
        }
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        //删除规则设备关联表
        jpaQueryFactory.delete(qRuleDevice).where(qRuleDevice.deviceSn.in(deviceSnList).and(qRuleDevice.tenantId.eq(tenantId))).execute();
    }

    /**
     * 根据SN号集合获取设备组ID集合
     *
     * @param sns      设备SN号集合
     * @param tenantId 租户ID
     * @return 设备所属设备组ID集合
     */
    @Override
    public List<Integer> getGroupIdsBySns(List<String> sns, long tenantId) {
        if (CollectionUtils.isEmpty(sns)) {
            return null;
        }
        QDevice qDevice = QDevice.device;
        return jpaQueryFactory.select(qDevice.groupId)
                .from(qDevice)
                .where(qDevice.sn.in(sns)
                        .and(qDevice.tenantId.eq(tenantId)))
                .groupBy(qDevice.groupId)
                .fetch();
    }
}
