package com.opnext.oservice.domain.device;

import com.opnext.domain.config.OConfigGroup;
import lombok.Data;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;

/** 
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午5:02 18/5/7
 */
@Entity
@Data
@Document(collection = "deviceConfig")
@CompoundIndexes({
        @CompoundIndex(unique = true, name = "unique_serviceType_tenantId_paramKey", def = "{'serviceType': 1, 'tenantId': -1, 'paramKey': 1}"),
        @CompoundIndex(name = "idx_version", def = "{'version': -1}")
})
public class DeviceConfig implements Serializable {

    @Id
    private String id;
    private String paramKey;
    private String name;
    private String serviceType;
    private String sn;
    private Long version;
    private String description;
    private Long createTime;
    private Long updateTime;
    private Long tenantId;

    private OConfigGroup objConfig;


    /**
     * 配置请求类型
     */
    public enum ServiceType {

        /**
         * 基础类型
         */
        BASE,
        /**
         * 单个设个获取配置
         */
        SN,
        /**
         * 分库识别类型
         */
        GROUP;
    }

}
