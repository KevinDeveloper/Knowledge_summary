package com.opnext.oservice.service.log;

import com.opnext.oservice.domain.log.OperationLog;
import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
/**
 * @author wanglu
 * @date 2018/07/19
 */
public interface OperationLogService {
    /**
     * 获取所有操作日志
     * @param predicate
     * @param pageable
     * @return
     */
    Page<OperationLog> findAll(Predicate predicate,Pageable pageable);

    /**
     * 错做记录保存
     * @param operationLog
     */
    void save(OperationLog operationLog);
}
