package com.opnext.oservice.domain.command;

/**
 * 业务类型
 * @author tianzc
 */
public enum BusinessType {
    PERSON, RULE, ADMIN
}
