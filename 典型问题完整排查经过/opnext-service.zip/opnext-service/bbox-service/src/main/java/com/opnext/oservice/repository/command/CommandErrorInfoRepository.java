package com.opnext.oservice.repository.command;

import com.opnext.oservice.domain.command.CommandErrorInfo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

/**
 * @author tianzc
 */
public interface CommandErrorInfoRepository extends MongoRepository<CommandErrorInfo, String>,
        QueryDslPredicateExecutor<CommandErrorInfo> {
}
