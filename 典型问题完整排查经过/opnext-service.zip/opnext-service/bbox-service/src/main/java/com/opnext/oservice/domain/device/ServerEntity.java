package com.opnext.oservice.domain.device;

import lombok.Data;

/**
 * @author tianzc
 */
@Data
public class ServerEntity {
    private String version;
    private String licenseFile;
    private String secureKey;
    private ServerUri server;
}
