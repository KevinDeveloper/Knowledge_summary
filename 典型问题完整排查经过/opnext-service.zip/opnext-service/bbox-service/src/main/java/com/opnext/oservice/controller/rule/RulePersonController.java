package com.opnext.oservice.controller.rule;

import com.alibaba.fastjson.JSONObject;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.domain.PersonType;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.person.PersonVo;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.domain.rule.QRuleApply;
import com.opnext.oservice.domain.rule.Rule;
import com.opnext.oservice.service.rule.RuleApplyService;
import com.opnext.oservice.service.rule.RuleService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/25 13:10
 */
@Slf4j
@RestController
@Api(value="规则和人员接口",tags={"规则和人员接口"})
@RequestMapping("/api/rule/person")
public class RulePersonController {
    @Autowired
    private RuleService ruleService;
    @Autowired
    private RuleApplyService ruleApplyService;

    @ApiOperation(value = "获取规则绑定的人员", notes = "获取规则绑定的人员")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "name", value = "姓名"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "number", value = "编号"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "organizationId", value = "组织ID"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "ruleId", value = "规则id"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "offset", value = "偏移量"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "pageNumber", value = "页数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "pageSize", value = "每页大小"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，name,desc表示在按name倒序排列，不填默认按照updateTime倒序排列")
    })
    @GetMapping("/")
    public CommonResponse<Page<PersonVo>> getPersonByRuleId(@RequestParam(required = false) String name,
                                                           @RequestParam(required = false) String number,
                                                           @RequestParam(required = false) Integer organizationId,
                                                           @RequestParam Integer ruleId,
                                                           @PageableDefault Pageable pageable) throws CommonException {
        log.debug("进入到'获取规则绑定的人员'接口");
        if (ruleId == null) {
            log.debug("参数为空");
            throw new CommonException("string.notEmpty");
        }
        Long tenantId = OperatorContext.getOperator().getTenantId();
        Rule rule = ruleService.findRuleByIdAndTenantId(ruleId, tenantId);
        if (rule == null) {
            log.debug("规则不存在");
            throw new CommonException("DataNotFound");
        }
        QPerson qPerson = QPerson.person;
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        Predicate predicate = (qRuleApply.ruleId.eq(ruleId)).and(qPerson.tenantId.eq(tenantId)).and(qPerson.type.eq(PersonType.FREQUENTER));
        if (rule.getType() == Rule.RuleType.ORGNIZATION.ordinal()) {
            predicate = ((BooleanExpression) predicate).and(qPerson.organizationId.eq(qRuleApply.organizationId)).and(qRuleApply.organizationId.isNotNull());
        } else {
            predicate = ((BooleanExpression) predicate).and(qPerson.id.eq(qRuleApply.personId)).and(qRuleApply.personId.isNotNull());
        }
        if (StringUtils.isNotBlank(name)) {
            predicate = ((BooleanExpression) predicate).and(qPerson.name.contains(name));
        }
        if (number != null) {
            predicate = ((BooleanExpression) predicate).and(qPerson.no.contains(number));
        }
        if (organizationId != null) {
            predicate = ((BooleanExpression) predicate).and(qPerson.organizationId.eq(organizationId));
        }
        return CommonResponse.ok(ruleApplyService.getPersonByRuleId(predicate, pageable));
    }

    @ApiIgnore
    @ApiOperation(value = "获取规则绑定的人员ID和组织ID")
    @GetMapping("/id/{ruleId}")
    public JSONObject getPersonAndOrgByRuleId(@PathVariable("ruleId") Integer ruleId) throws CommonException {
        log.debug("获取规则绑定的人员ID和组织ID'接口");
        if (ruleId == null) {
            log.debug("参数为空");
            throw new CommonException("string.notEmpty");
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Rule rule = ruleService.findRuleByIdAndTenantId(ruleId, oserviceOperator.getTenantId());
        if (rule == null) {
            log.debug("规则为空");
            throw new CommonException("DataNotFound");
        }
        JSONObject object = new JSONObject();
        if (rule.getType() == Rule.RuleType.PERSON.ordinal()) {
            object.put("organizationIds", ruleApplyService.getPersonOrgIdByRuleId(ruleId, oserviceOperator.getTenantId()));
            object.put("personIds", ruleApplyService.getPersonIdByRuleId(ruleId, oserviceOperator.getTenantId()));
        } else if (rule.getType() == Rule.RuleType.ORGNIZATION.ordinal()) {
            object.put("organizationIds", ruleApplyService.getOrganizationIdByRuleId(ruleId, oserviceOperator.getTenantId()));
        }
        return object;
    }
}
