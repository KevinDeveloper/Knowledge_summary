package com.opnext.oservice.controller;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.context.CommonContext;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.MultipartFileResp;
import com.opnext.oservice.service.UploadServiceV2;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import opnext.server.support.util.UrlUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午3:10 18/5/9
 */
@Slf4j
@RestController
@RequestMapping("/api/upload/v2")
@Api(value="v2-照片上传接口",tags={"照片上传接口"})
public class UploadControllerV2 {

    @Autowired
    UploadServiceV2 uploadServiceV2;

    @ApiOperation(value = "批量上传正面照片", notes = "上传照片，返回裁剪后的照片信息")
    @RequestMapping(value = "/batch-image",method = RequestMethod.POST, consumes = "multipart/*", headers = "content-type=multipart/form-data")
    @ResponseBody
    public CommonResponse batchUploadImage(HttpServletRequest request) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        // 获取、处理上传图片
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        Map<String, MultipartFile> multipartFileMap = multipartRequest.getFileMap();
        List<MultipartFileResp> multipartFileRespList = null;
        // 批量上传最多不能超过5个图片
        if (multipartFileMap.size() > 5) {
            log.info("批量上传最多支持上传5张图片");
            throw new CommonException("imageFile.limit");
        } else if (multipartFileMap.size() > 0){
            List<MultipartFile> multipartFileList = new ArrayList<>();
            for (Map.Entry<String, MultipartFile> entry : multipartFileMap.entrySet()) {
                multipartFileList.add(entry.getValue());
            }
            // 调用图片处理
            multipartFileRespList = uploadServiceV2.batchUploadImage(multipartFileList,oserviceOperator);
            String schemeAndHost = GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme());
            multipartFileRespList.replaceAll(fileResp -> {
                if (fileResp.isFlag()) {
                    // 获取信息，相对地址处理
                    Optional<String> optional = UrlUtil.getShowPath(schemeAndHost, fileResp.getUrl());
                    if (optional.isPresent()) {
                        fileResp.setUrl(optional.get());
                    }
                } else {
                    // 国际化处理
                    fileResp.setMessage(Messages.get(fileResp.getMessage()));
                }
                return fileResp;
            });
        } else {
            throw new CommonException("file.isEmpty");
        }
        return CommonResponse.ok(multipartFileRespList);
    }

}
