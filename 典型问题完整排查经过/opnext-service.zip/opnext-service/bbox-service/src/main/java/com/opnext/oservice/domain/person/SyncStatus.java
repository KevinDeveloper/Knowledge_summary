package com.opnext.oservice.domain.person;

import lombok.AllArgsConstructor;

/**
 * @author tianzc
 */
@AllArgsConstructor
public enum SyncStatus {
    /**
     * 默认状态不需要进行同步
     */
    DATA_DEFAULT((byte)0),

    /**
     * 未同步
     */
    DATA_NOT_SYNC((byte)1),
    /**
     * 已同步
     */
    DATA_ALREADY_SYNC((byte)2);
    private Byte value;
    public Byte value(){
        return this.value;
    }
}
