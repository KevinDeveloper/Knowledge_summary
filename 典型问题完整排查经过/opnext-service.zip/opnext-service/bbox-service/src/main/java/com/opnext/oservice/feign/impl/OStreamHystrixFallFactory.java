package com.opnext.oservice.feign.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.feign.OStreamFeign;
import feign.FeignException;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

/**
 * @author tianzc
 */
@Slf4j
@Component(value = "oStreamHystrixFallFactory")
public class OStreamHystrixFallFactory implements FallbackFactory<OStreamFeign> {
    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public OStreamFeign create(Throwable throwable) {
        log.info("o-stream fallback; reason was: {}",throwable.getMessage());
        return new OStreamFeign() {
            @Override
            public CommonResponse getNettyHost() throws Exception {
                return innerHandlerException(throwable, new Object());
            }
            public CommonResponse innerHandlerException(Throwable throwable, Object object) throws Exception{
                if (StringUtils.isBlank(throwable.getMessage())){
                    throw (Exception) throwable;
                }

                String errorMessage = throwable.getMessage().substring(throwable.getMessage().indexOf("\n")+1);
                CommonResponse.ErrorResponse errorResponse = objectMapper.readValue(errorMessage,CommonResponse.ErrorResponse.class);

                if (errorResponse.getStatus()>= HttpStatus.BAD_REQUEST.value() && errorResponse.getStatus()<HttpStatus.INTERNAL_SERVER_ERROR.value()) {

                    if (throwable instanceof FeignException){
                        throw (FeignException) throwable;
                    }else{
                        throw (Exception) throwable;
                    }
                }
                return CommonResponse.ok(object);
            }
        };
    }
}
