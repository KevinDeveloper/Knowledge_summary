package com.opnext.oservice.repository.person;

import com.opnext.oservice.domain.person.PersonSync;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @author tianzc
 */
public interface PersonSyncRepository  extends PagingAndSortingRepository<PersonSync, Integer>,QueryDslPredicateExecutor<PersonSync> {
}
