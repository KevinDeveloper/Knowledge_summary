package com.opnext.oservice.repository.device;

import com.opnext.oservice.domain.device.HistoryDevice;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:02 18/5/7
 */
public interface HistoryDeviceRepository extends PagingAndSortingRepository<HistoryDevice, Integer>,
        QueryDslPredicateExecutor<HistoryDevice> {
}
