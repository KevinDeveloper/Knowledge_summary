package com.opnext.oservice.repository.device.alarm;

import com.opnext.oservice.domain.device.alarm.DeviceAlarm;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @author wanglu
 */
public interface DeviceAlarmRepository extends PagingAndSortingRepository<DeviceAlarm, String>,
        QueryDslPredicateExecutor<DeviceAlarm> {

    /**
     * 通过阅读状态查询总数
     * @param readStatus
     * @param tenantId
     * @return
     */
    int countByReadStatusAndTenantId(boolean readStatus,long tenantId);

}
