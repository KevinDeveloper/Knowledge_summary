package com.opnext.oservice.feign;

import com.opnext.oservice.domain.fastdfs.FastdfsUploadResp;
import com.opnext.oservice.feign.impl.OcfsHystrixFallBack;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author tianzc
 */
@FeignClient(value = "ocfs",fallback = OcfsHystrixFallBack.class)
public interface OcfsFeign {
    /**
     * 上传文件，返回文件地址
     * @return
     */
    @RequestMapping(value = "/api/ocfs/file/upload",produces = {MediaType.APPLICATION_JSON_UTF8_VALUE}, method = RequestMethod.POST, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    FastdfsUploadResp upload(@RequestPart(value = "file") MultipartFile file);

}
