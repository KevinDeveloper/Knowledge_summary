package com.opnext.oservice.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author wanglu
 */
@Component
@Data
@ConfigurationProperties(prefix = "remote-rest.auth-center")
public class AuthorizeProperties {
    String host;
    String callbackTokenUrl;
    String authorizeUrl;
    String clientId;
    String secretId;
    String oauthTokenUrl;
    String logoutUrl;
    String authCookieName;
    String authRefreshCookieName;
}
