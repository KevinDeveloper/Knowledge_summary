package com.opnext.oservice.controller.rule;

import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.bboxdomain.context.CommonContext;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.domain.access.Rule;
import com.opnext.domain.access.RulePerson;
import com.opnext.domain.response.RulePersonResp;
import com.opnext.oservice.conf.AuthorizeProperties;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.domain.rule.QRule;
import com.opnext.oservice.domain.rule.QRuleApply;
import com.opnext.oservice.domain.rule.QRuleDevice;
import com.opnext.oservice.feign.OMessageFeign;
import com.opnext.oservice.service.rule.RuleApplySyncService;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @Author: lixiuwen
 * @Date: 2018/6/21 13:26
 */
@Slf4j
@RestController
@RequestMapping("/api/devapi")
public class RuleApiController {
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    private RuleApplySyncService ruleApplySyncService;
    @Autowired
    private AuthorizeProperties authorizeProperties;
    @Resource
    private OMessageFeign oMessageFeign;
    @Value("${server.context-path}")
    private String serverPath;
    /**
     * 终端获取人员信息时，每页最大数量
     */
    private static final int PAGE_SIZE = 100;


    /**
     * 终端获取要绑定或者解绑的人员信息
     *
     * @param pageable   分页数据
     * @param workflowId
     * @param commandId
     * @param requestId
     * @param batchId
     * @return
     * @throws Exception
     */
    @ApiIgnore
    @GetMapping("/getRulePersonIds/{workflowId}/{commandId}/{requestId}/{batchId}")
    public RulePersonResp getRulePersonIds(@PageableDefault(size = PAGE_SIZE) Pageable pageable,
                                           @PathVariable("workflowId") String workflowId,
                                           @PathVariable("commandId") String commandId,
                                           @PathVariable("requestId") String requestId,
                                           @PathVariable("batchId") String batchId) throws Exception {
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        log.info("进入到'终端获取规则人员'接口。SN:{},page:{},size:{}", oserviceDevApiOperator.getSn(), pageable.getPageNumber(), pageable.getPageSize());
        if (batchId == null) {
            log.debug("参数为空");
            throw new CommonException("string.notEmpty");
        }
        if (pageable.getPageNumber() == 0) {
            //业务处理Callback数据的同时，需要调用消息中心的rest接口，来告诉消息中心此消息已回调成功
            try {
                ResponseEntity entity = oMessageFeign.callback(workflowId, commandId, requestId);
                if (Objects.isNull(entity)) {
                    log.error("消息回调失败,返回值为空");
                } else if (entity.getStatusCode() != HttpStatus.OK) {
                    log.error("消息回调失败,status:{},code:{}", entity.getStatusCode(), entity.getStatusCodeValue());
                }
            } catch (Exception e) {
                log.error("消息回调异常workflowId:{},commandId:{},requestId:{}", workflowId, commandId, requestId);
            }
        }
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        return ruleApplySyncService.getRulePerson(batchId, workflowId, commandId, requestId, pageable,urlPrefix);
    }

    /**
     * 终端获取当前设备所启用的规则
     *
     * @return
     */
    @ApiIgnore
    @GetMapping("/rule")
    public List<Rule> getRulesByDeviceSn() {
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        log.debug("进入到'终端获取当前设备所启用的规则'接口.SN:" + oserviceDevApiOperator.getSn());
        QRule qRule = QRule.rule;
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        List<com.opnext.oservice.domain.rule.Rule> ruleList = jpaQueryFactory.select(qRule)
                .from(qRule, qRuleDevice)
                .where(qRule.id.eq(qRuleDevice.ruleId).and(qRuleDevice.deviceSn.eq(oserviceDevApiOperator.getSn())))
                .fetch();
        if (ruleList == null || ruleList.size() == 0) {
            return new ArrayList<>();
        }
        List<Rule> returnRuleList = new ArrayList<>();
        ruleList.forEach(item -> returnRuleList.add(item.toDomainRule(authorizeProperties.getClientId())));
        return returnRuleList;
    }

    /**
     * 根据规则的ID获取绑定的人员信息
     *
     * @param ruleId 规则ID
     * @return
     */
    @ApiIgnore
    @GetMapping("/rules/{ruleId}/person")
    public List<RulePerson> getPersonByRuleId(@PathVariable("ruleId") int ruleId) throws CommonException {
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        log.debug("进入到'根据规则的ID获取绑定的人员信息'接口.SN:" + oserviceDevApiOperator.getSn() + ",ruleId:" + ruleId);
        Long tenantId = oserviceDevApiOperator.getTenantId();
        QRule qRule = QRule.rule;
        com.opnext.oservice.domain.rule.Rule rule = jpaQueryFactory.select(qRule).from(qRule).where(qRule.id.eq(ruleId).and(qRule.tenantId.eq(tenantId))).fetchOne();
        if (rule == null) {
            log.debug("规则不存在");
            throw new CommonException("DataNotFound");
        }
        QPerson qPerson = QPerson.person;
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        List<Person> personList = jpaQueryFactory
                .select(qPerson)
                .from(qPerson, qRuleApply)
                .where(qPerson.id.eq(qRuleApply.personId).and(qRuleApply.ruleId.eq(ruleId)).and(qRuleApply.tenantId.eq(tenantId)))
                .fetch();
        if (personList == null || personList.size() == 0) {
            return new ArrayList<>();
        }
        List<RulePerson> rulePersonList = new ArrayList<>();
        personList.forEach(person -> {
            RulePerson rulePerson = new RulePerson();
            rulePerson.setPersonId(person.getId());
            rulePerson.setVersion(person.getUpdateTime().getTime());
            rulePerson.setInfo(person.toPersonInfo());
            rulePersonList.add(rulePerson);
        });
        return rulePersonList;
    }
}
