package com.opnext.oservice.domain.authority.role;

import lombok.Data;

import javax.persistence.*;

/**
 * @author wanglu
 */
@Entity
@Table(name = "resource")
@Data
public class Resource {
    @Id
    @GeneratedValue
    private Integer id;
    private String name;
    private String url;
    private Method method;
    private Scope scope;
    @Column(name = "module_id")
    private Integer moduleId;

    public enum Method{
        /**
         * 返回服务器针对特定资源所支持的HTTP请求方法。也可以利用向Web服务器发送'*'的请求来测试服务器的功能性
         */
        OPTIONS((byte) 0),
        /**
         * 向服务器索要与GET请求相一致的响应，只不过响应体将不会被返回。在不必传输整个响应内容的情况下，就可以获取包含在响应消息头中的元信息。
         */
        HEAD((byte) 1),
        /**
         * 向特定的资源发出请求。
         */
        GET((byte) 2),
        /**
         * 向指定资源提交数据进行处理请求（例如提交表单或者上传文件）。数据被包含在请求体中。POST请求可能会导致新的资源的创建和/或已有资源的修改。
         */
        POST((byte) 3),
        /**
         * 向指定资源位置上传其最新内容。
         */
        PUT((byte) 4),
        /**
         * 请求服务器删除Request-URI所标识的资源。
         */
        DELETE((byte) 5),
        /**
         * 回显服务器收到的请求，主要用于测试或诊断。
         */
        TRACE((byte) 6),
        /**
         * HTTP/1.1协议中预留给能够将连接改为管道方式的代理服务器。
         */
        CONNECT((byte) 7);

        private byte value;

        Method(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }

    public enum Scope{
        /**
         * 超级管理员（表示不能角色授权），只有超管角色能够调用的接口
         */
        SUPER_ADMIN((byte) 0),
        /**
         * 任意管理账号（表示可以角色授权），只有拥有权限的角色才能调用的接口
         */
        ADMIN((byte)1),
        /**
         * 所有管理员（表示可以角色授权），只要是管理员就可以调用此接口，不过滤角色
         */
        All((byte)2);
        private byte value;

        Scope(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }

}
