package com.opnext.oservice.domain.log;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.util.Date;

/**
 * @author wanglu
 */
@Data
@Table(name = "operation_log")
@Entity
@Builder
public class OperationLog {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    @Column(name = "account_id")
    private Long accountId;
    @Column(name = "login_name")
    private String loginName;

    @Column(name = "module_id")
    private Integer moduleId;

    @Column(name = "module_name")
    private String moduleName;

    @Column(name = "resource_id")
    private Integer resourceId;

    @Column(name = "resource_name")
    private String resourceName;

    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    @Column(name="occur_time")
    private Date occurTime;

    @Column(name="tenant_id")
    private Long tenantId;

    @Column(name="result")
    private ResultStatus resultStatus;

    @Tolerate
    public OperationLog(){}

    public enum ResultStatus{
        /**
         * 操作成功
         */
        SUCCESS((byte) 0),
        /**
         * 操作失败
         */
        FAILED((byte)1);

        private byte value;

        ResultStatus(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }
}
