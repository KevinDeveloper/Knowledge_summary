package com.opnext.oservice.dto.appcenter;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * @author wanglu
 */
@Data
public class WeChatBindReqDTO {
    @NotNull(message="tenant.parameter.notEmpty")
    private Long tenantId;
    @NotEmpty(message="tenant.parameter.notEmpty")
    private String no;
}
