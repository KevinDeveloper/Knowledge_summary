package com.opnext.oservice.domain.rule.MultiKeys;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: lixiuwen
 * @Date: 2018/6/21 17:49
 * @Param deviceSn
 * @Param ruleId
 * 由这两个共同组成复合主键
 */
@Data
public class RuleDeviceMultiKeysClass implements Serializable {

    /**
     * 设备SN
     */
    private String deviceSn;

    /**
     * 规则ID
     */
    private Integer ruleId;

    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((deviceSn == null) ? 0 : deviceSn.hashCode());
        result = PRIME * result + ((ruleId == null) ? 0 : ruleId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }

        final RuleDeviceMultiKeysClass other = (RuleDeviceMultiKeysClass) obj;
        if (deviceSn == null) {
            if (other.deviceSn != null) {
                return false;
            }
        } else if (!deviceSn.equals(other.deviceSn)) {
            return false;
        }
        if (ruleId == null) {
            if (other.ruleId != null) {
                return false;
            }
        } else if (!ruleId.equals(other.ruleId)) {
            return false;
        }

        return true;
    }
}
