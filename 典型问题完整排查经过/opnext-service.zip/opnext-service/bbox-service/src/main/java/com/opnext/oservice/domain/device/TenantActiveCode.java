package com.opnext.oservice.domain.device;

import jdk.nashorn.internal.ir.annotations.Ignore;
import lombok.Data;

import javax.persistence.*;

/**
 * @Title: 
 * @Description: 
 * @author tianzc
 * @Date 下午5:09 18/5/7
 */ 
@Entity
@Data
@Table(name = "tenant_active_code")
public class TenantActiveCode {

    @Id
    @GeneratedValue
    private Integer id;
    @Column(name = "active_code")
    private String activeCode;
    @Ignore
    @Column(name = "tenant_id")
    private Long tenantId;

    /**
     * 冗余关联数据
     */
    @Transient
    private String url;
}
