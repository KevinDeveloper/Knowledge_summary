package com.opnext.oservice.service.authority;

import com.opnext.oservice.domain.account.Account;
import com.opnext.oservice.domain.authority.role.Role;
import com.opnext.oservice.dto.account.AccountDTO;
import com.opnext.oservice.dto.authority.AuthorityDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

/**
 * @author wanglu
 */
public interface AdminService {

    /**
     * 分页查询管理员列表
     * @param loginname
     * @param role
     * @param status
     * @param pageable
     * @param tenantId
     * @return
     * @throws Exception
     */
    Page<AuthorityDTO> getAdminPage(String loginname, Role role, String status, Pageable pageable, long tenantId) throws Exception;

    /**
     * 新增管理员
     * @param accountDTO
     * @param accountId
     * @param tenantId
     * @return
     * @throws Exception
     */
    Account addAdmin(AccountDTO accountDTO, long accountId, long tenantId)throws Exception;

    /**
     * 删除管理员
     * @param id
     * @param tenantId
     * @throws Exception
     */
    void deleteAdmin(long id,long tenantId) throws Exception;

    /**
     * 账号绑定角色
     * @param id
     * @param roleParam
     * @param tenantId
     * @throws Exception
     */
    void bindRole(long id,Role roleParam,long tenantId) throws Exception;

    /**
     * 为账号绑定超级管理员角色
     * @param id
     */
    void bindSuperRole(long id);
    /**
     * 账号解绑角色
     * @param id
     */
    void unbindRole(long id);
}
