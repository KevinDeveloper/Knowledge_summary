package com.opnext.oservice.feign;

import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.domain.device.License;
import com.opnext.oservice.feign.impl.StoreApiHystrixFallFactory;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author tianzc
 */
@FeignClient(value = "store-api", path = "/store-api/api",fallbackFactory = StoreApiHystrixFallFactory.class)
public interface StoreApiFeign {

    /**
     * 获取商店license文件地址
     * @param sn
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET, value = "/license/obtainLicense")
    CommonResponse<License> getLicense(@RequestParam("sn") String sn) throws Exception;
}
