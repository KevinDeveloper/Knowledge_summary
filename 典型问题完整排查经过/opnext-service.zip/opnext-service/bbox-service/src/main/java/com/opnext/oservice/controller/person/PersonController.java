package com.opnext.oservice.controller.person;

import com.alibaba.fastjson.JSONObject;
import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.batch.BatchResult;
import com.opnext.bboxdomain.batch.BatchStateBean;
import com.opnext.bboxdomain.batch.BatchStateType;
import com.opnext.bboxdomain.batch.ExportResult;
import com.opnext.bboxdomain.batch.ExportStateType;
import com.opnext.bboxdomain.context.CommonContext;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.bboxsupport.validator.IsEmptyValidator;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.domain.PersonType;
import com.opnext.domain.Sex;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.ServerConfig;
import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.domain.person.PersonBatchResult;
import com.opnext.oservice.domain.person.PersonVo;
import com.opnext.oservice.dto.person.PersonProjection;
import com.opnext.oservice.redis.RedisCacheUtil;
import com.opnext.oservice.service.AsyncService;
import com.opnext.oservice.service.ServerConfigService;
import com.opnext.oservice.service.person.BatchStateManageService;
import com.opnext.oservice.service.person.PersonService;
import com.opnext.oservice.util.DateUtil;
import com.opnext.oservice.util.FileUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import opnext.server.support.util.UrlUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationHome;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午5:05 18/5/7
 */
@Slf4j
@RestController
@RequestMapping("/api/person")
@Api(value="人员管理接口",tags={"人员管理接口"})
public class PersonController {

    @Autowired
    private PersonService personService;

    @Autowired
    ServerConfigService serverConfigService;

    @Autowired
    private AsyncService asyncService;

    @Autowired
    private RedisCacheUtil redisCacheUtil;

    @ApiIgnore
    @ApiOperation(value = "性别类型", notes = "获取性别类型，返回性别枚举，需要调用方进行国际化")
    @RequestMapping(value = "/gender", method = RequestMethod.GET)
    public CommonResponse sexTypeList() {
        return CommonResponse.ok(Sex.values());
    }

    @ApiOperation(value = "人员列表", notes = "获取人员列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "name", value = "人员名称"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "no", value = "人员编号"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "organizationId", value = "组织id"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "offset", value = "偏移量"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "pageNumber", value = "页数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "pageSize", value = "每页大小"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=version,updateTime,asc&sort=name,desc")
    })
    @RequestMapping(value = "", method = RequestMethod.GET)
    public CommonResponse<Page<PersonVo>> page(@PageableDefault Pageable pageable, String name, String no, Integer organizationId) throws Exception {
        log.debug("获取人员请求参数 name：{}, no：{}, organizationId：{}", name, no, organizationId);
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        Page page = personService.getPage(pageable, name, no, organizationId, urlPrefix);
        return CommonResponse.ok(page);
    }
    @ApiIgnore
    @ApiOperation(value = "人员列表(list)", notes = "根据组织id获取人员列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", required = true, dataType = "Integer", name = "organizationId", value = "组织id"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "size", value = "分页条数")
    })
    @RequestMapping(value = "/_list", method = RequestMethod.GET)
    public CommonResponse list(@PageableDefault Pageable pageable, Integer organizationId) throws Exception {
        log.debug("获取人员列表请求参数 organizationId：{}", organizationId);
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        List<PersonProjection> personDTOList = personService.getList(pageable, organizationId, oserviceOperator);
        return CommonResponse.ok(personDTOList);
    }
    @ApiIgnore
    @ApiOperation(value = "组织总人数", notes = "根据组织id获取组织总人数，不包含子组织人数")
    @RequestMapping(value = "/org/_count", method = RequestMethod.GET)
    public CommonResponse getPersonCountByOrgId(Integer[] organizationId) throws Exception {
        log.info("获取组织下人员个数请求参数 organizationId：{}", organizationId);
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        List<Map<String, Long>> map = personService.getPersonCountByOrgId(organizationId, oserviceOperator);
        return CommonResponse.ok(map);
    }

    @ApiOperation(value = "获取人员详情信息", notes = "根据id")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public CommonResponse<Person> get(@PathVariable String id) throws Exception {
        log.info("获取人员详情请求参数 id：{}", id);
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        Person person = personService.getOne(id, urlPrefix);
        return CommonResponse.ok(person);
    }

    @ApiIgnore
    @ApiOperation(value = "人员批量保存", notes = "为第三方提供")
    @RequestMapping(value = "/batchSave", method = RequestMethod.POST)
    public CommonResponse batchSave(@RequestBody List<Person> personList) throws Exception {
        log.info("人员保存参数:{}", personList);
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        List<Person> list = personService.batchSave(personList, PersonType.VISITOR,urlPrefix);
        return CommonResponse.ok(list);
    }

    @ApiOperation(value = "新增人员", notes = "")
    @RequestMapping(value = "", method = RequestMethod.POST)
    public CommonResponse<Person> save(@RequestBody Person person) throws Exception {
        log.info("人员保存参数:{}", person);
        ComplexResult ret = personService.fluentValidatorPerson(person, true);
        if (!ret.isSuccess()) {
            log.error("人员参数异常{}", ret);
            throw new CommonException(400, "parameter.incorrect", ret);
        }
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        Person resultPerson = personService.save(person,urlPrefix);
        return CommonResponse.ok(resultPerson);
    }

    @ApiOperation(value = "更新人员信息", notes = "根据id更新人员信息")
    @ApiImplicitParam(paramType = "path", dataType = "String", name = "id", value = "人员id")
    @RequestMapping(value = "/{id}", method = RequestMethod.POST)
    public void update(@RequestBody Person person, @PathVariable String id) throws Exception {
        log.debug("人员更新参数:{}", person);
        ComplexResult ret = personService.fluentValidatorPerson(person, true);
        if (!ret.isSuccess()) {
            log.error("人员参数异常{}", ret);
            throw new CommonException(400, "parameter.incorrect", ret);
        }
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        person.setId(id);
        personService.update(person,urlPrefix);
    }

    @ApiIgnore
    @ApiOperation(value = "删除人员", notes = "根据id单个删除人员")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public void delete(@PathVariable String id) throws Exception {
        personService.delete(id);
    }

    @ApiOperation(value = "批量删除", notes = "根据id批量删除人员")
    @ApiImplicitParam(dataType = "String", name = "ids", value = "人员id数组")
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public void batchDelete(@RequestBody String[] ids) throws Exception {
        personService.delete(ids);
    }

    /**
     * ---------------------人员密码配置 start--------------------------
     */
    @ApiIgnore
    @ApiOperation(value = "获取人员配置密码", notes = "人员配置密码所属租户")
    @RequestMapping(value = "/config/password", method = RequestMethod.GET)
    public ServerConfig getPersonPwdConfig() throws Exception {
        log.info("获取人员配置密码");
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        return serverConfigService.getPersonPwdConfig(oserviceOperator.getTenantId());
    }

    @ApiIgnore
    @ApiOperation(value = "更新人员配置密码", notes = "根据id更新人员配置密码")
    @RequestMapping(value = "/config/password/{id}", method = RequestMethod.POST)
    public void update(@RequestBody ServerConfig serverConfig, @PathVariable Integer id) throws Exception {
        log.debug("人员密码更新参数serverConfig：{}，id：{}", serverConfig, id);
        serverConfig.setId(id);
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(serverConfig.getConfigValue(), new IsEmptyValidator("configValue"))
                .on(serverConfig.getConfigValue(), new IsStringWithinLengthRangeValidator("configValue", 6, 20))
                .doValidate().result(toComplex());
        if (!ret.isSuccess()) {
            log.error("更新配置参数异常{}", ret);
            throw new CommonException(400, "parameter.incorrect", ret);
        }
        serverConfigService.update(serverConfig);
    }

    /**
     * ---------------------人员密码配置 end--------------------------
     */


    /**
     * =======================人员批量导入=============================
     */
    @Autowired
    private BatchStateManageService batchStateManageService;
    @ApiIgnore
    @ApiOperation(value = "下载人员导入模板（静态模板）", notes = "下载人员导入模板")
    @RequestMapping(value = "/downloadPersonImportExcel", method = RequestMethod.GET)
    public void downloadPersonExcel(HttpServletRequest request, HttpServletResponse response) throws Exception {
        log.info("下载人员导入模板（静态模板） - 开始");
        long startTime = System.currentTimeMillis();
        String lan = Messages.getLocale().getLanguage();
        String excelName = File.separator + "excel" + File.separator + "personImportExcel_" + lan + ".xlsx";
        log.info("下载人员导入模板名为：excelName={}", excelName);
        org.springframework.core.io.Resource fileRource = null;
        try {
            try {
                fileRource = new ClassPathResource(excelName);
                if (Objects.isNull(fileRource) || Objects.isNull(fileRource.getInputStream())) {
                    log.error("加载人员导入模板为空，将使用默认模板");
                    excelName = File.separator + "excel" + File.separator + "personImportExcel_default.xlsx";
                    fileRource = new ClassPathResource(excelName);
                }
            } catch (Exception e) {
                log.error("加载人员导入模板异常，将使用默认模板，e={}", e);
                excelName = File.separator + "excel" + File.separator + "personImportExcel_default.xlsx";
                fileRource = new ClassPathResource(excelName);
            }
        } catch (Exception e) {
            log.error("加载模板文件异常，e={}", e);
            throw new CommonException("person.import.excel.exception");
        }
        String fileName = "importPersons_" + DateUtil.parseDateToStr(new Date(), DateUtil.DATE_TIME_FORMAT_YYYYMMDDHHMISS) + ".xlsx";

        OutputStream out = null;
        InputStream inputStream = null;
        try {
            response.reset();
            response.setHeader("content-Type", "application/vnd.ms-excel ");
            response.setContentType("Content-Type:application/vnd.ms-excel ");
            response.setContentType("application/octet-stream; charset=utf-8");
            response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
            out = response.getOutputStream();
            inputStream = fileRource.getInputStream();
            out.write(FileUtil.readInputStream(inputStream));
            out.flush();
        } catch (IOException e) {
            log.error("下载人员导入模板， 输出异常，e={}", e);
        } finally {
            if (Objects.nonNull(inputStream)) {
                inputStream.close();
            }
            if (Objects.nonNull(out)) {
                out.close();
            }
        }
        log.info("下载人员导入模板（静态模板） - 结束， 耗时={}", (System.currentTimeMillis() - startTime));
    }

    @ApiIgnore
    @ApiOperation(value = "上传批量导入文件 - 用于权限判断,不作业务功能 ", notes = "上传批量导入文件")
    @RequestMapping(value = "/batchAddPreview", method = RequestMethod.POST)
    public void batchAddPreview(HttpServletRequest request, @RequestParam String uploadType) throws Exception {
        log.info("由于本接口比较耗时，接口实现放在bbox-batch服务中");
    }

    @ApiOperation(value = "上传文件解析数据预览", notes = "上传文件解析数据预览")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数")
    })
    @ApiIgnore
    @RequestMapping(value = "/batchImportDataPage", method = RequestMethod.GET)
    public ResponseEntity batchImportDataPage(@PageableDefault Pageable pageable) throws Exception {
        log.info("上传文件解析数据预览 - 开始,pageable={}", JSONObject.toJSONString(pageable));
        long startTime = System.currentTimeMillis();
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        long tenantId = oserviceOperator.getTenantId();
        long userId = oserviceOperator.getUserId();
        //判断批量导入状态
        BatchStateBean batchStateBean = batchStateManageService.getBatchStateBean(tenantId);
        if (Objects.isNull(batchStateBean)) {
            throw new CommonException("person.batchAdd.batchstate.get.error");
        }
        log.info("上传文件解析数据预览, batchStateBean={}", batchStateBean.toString());
        //1、判断是否是当前用户
        if (BatchStateManageService.BATCH_PERSON_USER_EMPTY.longValue() == batchStateBean.getUserId().longValue()) {
            throw new CommonException("person.batchAdd.batchstate.error");
        }
        if (userId != batchStateBean.getUserId().longValue()) {
            log.info("非当前用户");
            throw new CommonException("person.batchAdd.curUser.error");
        }
        //2、判断前置状态  - 可预览状态， 导入完成
        if (BatchStateType.STATE_PREVIEWING.value() != batchStateBean.getBatchStateType().longValue() && BatchStateType.STATE_IMPORTED.value() != batchStateBean.getBatchStateType().longValue()) {
            log.info("当前非预览状态");
            throw new CommonException("person.batchAdd.batchstate.error");
        }
        Page page = personService.batchImportDataPage(pageable, oserviceOperator, urlPrefix);
        log.info("上传文件解析数据预览 - 结束，耗时={}", System.currentTimeMillis() - startTime);
        return ResponseEntity.ok(page);
    }
    @ApiIgnore
    @ApiOperation(value = "上传文件解析数据入库", notes = "上传文件解析数据入库")
    @RequestMapping(value = "/batchImportDataResult", method = RequestMethod.POST)
    public void batchImportDataResult() throws Exception {
        log.info("上传文件解析数据入库 - 开始");
        long startTime = System.currentTimeMillis();
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        long tenantId = oserviceOperator.getTenantId();
        long userId = oserviceOperator.getUserId();
        BatchStateBean batchStateBean = batchStateManageService.getBatchStateBean(tenantId);
        if (Objects.isNull(batchStateBean)) {
            log.error("获取导入状态为空，处理异常");
            throw new CommonException("person.batchAdd.batchstate.get.error");
        }
        log.info("获取租户当前批量导入状态 ,batchStateBean={}", batchStateBean.toString());
        //1、判断是否是当前用户
        if (userId != batchStateBean.getUserId()) {
            throw new CommonException("person.batchAdd.curUser.error");
        }

        //判断当前 批量导入状态 , 开始加锁
        String distributedKey = "batch_async_import_" + oserviceOperator.getUserId();
        long curTime = System.currentTimeMillis();
        try {
            boolean keyResult = redisCacheUtil.getDistributedLock(distributedKey, curTime, 3000L, TimeUnit.MILLISECONDS);
            if (!keyResult) {
                log.info("未获取到分布式锁，当前时段在有其他用户操作");
                throw new CommonException(416, "person.batchAdd.hashother");
            } else {
                //2、判断前置状态是否合法  可预览、导入失败
                if (BatchStateType.STATE_PREVIEWING.value() != batchStateBean.getBatchStateType()
                        && BatchStateType.STATE_IMPORTE_FAIL.value() != batchStateBean.getBatchStateType()) {
                    log.info("批量入库,判断前置状态是否合法(可预览2、导入失败6), 当前状态={}", batchStateBean.getBatchStateType());
                    throw new CommonException("person.batchAdd.batchstate.error");
                } else {
                    //1、更新导入状态 - 导入中
                    batchStateManageService.setBatchState(tenantId, BatchStateType.STATE_IMPORTING);
                }
            }
        } catch (Exception e) {
            log.info("未获取到分布式锁，当前时段在有其他用户操作");
            throw new CommonException(416, "person.batchAdd.hashother");
        }finally {
            Long cacheTime = redisCacheUtil.getCacheObject(distributedKey);
            if (Objects.nonNull(cacheTime) && curTime == cacheTime) {
                redisCacheUtil.delete(distributedKey);
            }
        }

        try {
            asyncService.insertBatchPersons(oserviceOperator, urlPrefix);
        } catch (Exception e) {
            log.error("批量导入数据入库处理 - 异常， e={}", e);
            //更新导入状态 - 导入失败
            batchStateManageService.setBatchState(tenantId, BatchStateType.STATE_IMPORTE_FAIL);
        }
        log.info("上传文件解析数据入库 - 结束,耗时{} (ms)", (System.currentTimeMillis() - startTime));
    }

    @ApiIgnore
    @ApiOperation(value = "批量导入结果统计", notes = "批量导入成功失败统计")
    @RequestMapping(value = "/batchAddResultCount", method = RequestMethod.GET)
    public ResponseEntity batchAddResultCount() throws Exception {
        log.info("批量导入结果统计");
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        BatchResult result = personService.batchAddResultCount(oserviceOperator);
        log.info("批量导入结果统计 - 结束 ,result={}", JSONObject.toJSONString(result));
        return ResponseEntity.ok(result);
    }

    /**
     * =======================导出人员==================================
     */
    @ApiIgnore
    @ApiOperation(value = "获取导出的人员列表")
    @RequestMapping(value = "/getExportPersons", method = RequestMethod.GET)
    public ResponseEntity exportPersonList(String name, String no, Integer organizationId) throws Exception {
        log.info("获取导出的人员列表");
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        List<PersonVo> personVos = personService.getExportPersons(tenantId, name, no, organizationId);
        return ResponseEntity.ok(personVos);
    }
    @ApiIgnore
    @ApiOperation(value = "导出人员———通知处理", notes = "导出人员")
    @RequestMapping(value = "/exportPersons", method = RequestMethod.GET)
    public void exportPersons(HttpServletRequest request, HttpServletResponse response, String name, String no, Integer organizationId) throws Exception {
        log.info("导出人员,通知处理 - 开始, 参数 name={}, no={}, organizationId={}", name, no, organizationId);
        long start = System.currentTimeMillis();
        //检查参数
        String orgIdStr = "";
        if (Objects.nonNull(organizationId)) {
            orgIdStr = String.valueOf(organizationId);
        }
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(name, new IsStringWithinLengthRangeValidator("name", 0, 64, true))
                .on(no, new IsStringWithinLengthRangeValidator("no", 0, 20, true))
                .on(orgIdStr, new IsStringWithinLengthRangeValidator("organizationId", 0, 32, true))
                .doValidate()
                .result(toComplex());
        if (!ret.isSuccess()) {
            log.debug("参数错误");
            throw new CommonException(400, "parameter.incorrect", ret);
        }

        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long startTime = System.currentTimeMillis();

        //判断导出状态
        ExportResult exportResult = batchStateManageService.getExportState(oserviceOperator.getTenantId(), oserviceOperator.getUserId());
        if (ExportStateType.STATE_NORMAL.value() != exportResult.getExportState() &&
                ExportStateType.STATE_FAIL.value() != exportResult.getExportState()) {
            log.info("当前正有导出任务，exportState={}", exportResult.getExportState());
            throw new CommonException("export.person.hastask");
        }

        long count = personService.getExportPersonsCount(tenantId, name, no, organizationId);
        log.info(" 查询出导出人员数量 size={}, 耗时 {}(ms)", count, System.currentTimeMillis() - startTime);
        if (count < 1) {
            log.info("无导出人员");
            throw new CommonException("export.person.empty");
        }
        if (count > PersonBatchResult.EXPORT_PERSON_SIZE_MAX) {
            log.info("待导出人员数量为size={}, 超出系统设置最大数max={}", count, PersonBatchResult.EXPORT_PERSON_SIZE_MAX);
            throw new CommonException("export.person.size.outofmax");
        }

        //用户空间文件夹
//        String userRootPath = request.getServletContext().getRealPath("/") + tenantId + "_" + oserviceOperator.getUserId();
        ApplicationHome home = new ApplicationHome(getClass());
        String userRootPath = home.getDir().getAbsolutePath() + File.separator + batchStateManageService.getExportUserRotPath(oserviceOperator);

        FileUtil.deletefilesOrDir(userRootPath);
        FileUtil.createDirByPathName(userRootPath);
        log.info("userRootPath= {}", userRootPath);
        //全部文件压缩包
        String allFilesZip = "exportPersons_" + DateUtil.parseDateToStr(new Date(), DateUtil.DATE_TIME_FORMAT_YYYYMMDDHHMISS) + ".zip";
        String allFilesZipPath = userRootPath + File.separator + allFilesZip;
        //全部文件夹（excel 和avatar.zip）
        String exportDir = "exportPerson_" + tenantId + "_" + oserviceOperator.getUserId();
        String exportDirPath = userRootPath + File.separator + exportDir;
        FileUtil.createDirByPathName(exportDirPath);
        //avatar 压缩包 文件名
        String allAvatarsZip = "avatars_" + DateUtil.parseDateToStr(new Date(), DateUtil.DATE_TIME_FORMAT_YYYYMMDDHHMISS) + ".zip";
        String allAvatarsZipPath = exportDirPath + File.separator + allAvatarsZip;
        //存放全部人员照片 文件夹
        String avatarDirName = "avatarDir_" + tenantId + "_" + oserviceOperator.getUserId();
        String avatarsDirPath = exportDirPath + File.separator + avatarDirName;
        String fileExcelName = "exportPersons_" + DateUtil.parseDateToStr(new Date(), DateUtil.DATE_TIME_FORMAT_YYYYMMDDHHMISS) + ".xlsx";
        String fileExcelPath = exportDirPath + File.separator + fileExcelName;

        //设置导出状态 - 导出中
        exportResult = new ExportResult();
        exportResult.setExportState(ExportStateType.STATE_EXPORTING.value());
        batchStateManageService.setExportState(oserviceOperator.getTenantId(), oserviceOperator.getUserId(), exportResult);
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        asyncService.exportPerson(oserviceOperator, name, no, organizationId, fileExcelPath, avatarsDirPath, allAvatarsZipPath, exportDirPath, allFilesZipPath, allFilesZip,urlPrefix);

        log.info("导出人员,通知处理 - 结束 ，耗时={}ms", (System.currentTimeMillis() - start));

    }
    @ApiIgnore
    @ApiOperation(value = "获取导出状态和地址", notes = "导出人员状态,状态:失败(-1), 初始状态(0),正在导出(1),导出成功(2)")
    @RequestMapping(value = "/exportState", method = RequestMethod.GET)
    public ResponseEntity getExportState() throws Exception {
        log.info("获取导出状态和地址 - 开始");
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        ExportResult exportResult = batchStateManageService.getExportState(oserviceOperator.getTenantId(), oserviceOperator.getUserId());

        //判断当前状态是否是在 异步解析中
        if (exportResult.getExportState() == ExportStateType.STATE_EXPORTING.value()) {
            log.debug("判断存活流程 - 1、当前状态为导出中");
            if (!batchStateManageService.isExistAsyncTaskKey(oserviceOperator.getTenantId(), oserviceOperator.getUserId(), BatchStateManageService.EXPORT_PERSON_KEY_UNDERWAY)) {
                log.info("判断存活流程 - 存活标志超时未更新，判定异步导出任务异常，更新状态为失败, tenantId={}, userId={}", oserviceOperator.getTenantId(), oserviceOperator.getUserId());
                //设置导出状态  - 失败
                exportResult = new ExportResult();
                exportResult.setExportState(ExportStateType.STATE_FAIL.value());
                batchStateManageService.setExportState(oserviceOperator.getTenantId(), oserviceOperator.getUserId(), exportResult);
                //清空当前租户内的批量导入临时数据
                try {
                    ApplicationHome home = new ApplicationHome(getClass());
                    String userRootPath = home.getDir().getAbsolutePath() + File.separator + batchStateManageService.getExportUserRotPath(oserviceOperator);
                    FileUtil.deletefilesOrDir(userRootPath);

                } catch (Exception e1) {
                    log.error("导出任务失败, 清空临时数据, 异常e={}", e1);
                }
            }

        }
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        //处理下载地址，拼接成全地址
        Optional<String> optional = UrlUtil.getShowPath(GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()), exportResult.getFilePath());
        if(optional.isPresent()){
            exportResult.setFilePath(optional.get());
        }
        log.info("获取导出状态和地址 - 结束，exportState={}, filePath ={}", exportResult.getExportState(), exportResult.getFilePath());
        return ResponseEntity.ok(exportResult);
    }
    @ApiIgnore
    @ApiOperation(value = "重置导出状态", notes = "重置导出状态")
    @RequestMapping(value = "/export-status", method = RequestMethod.DELETE)
    public void batchAddClear(HttpServletRequest request) throws Exception {
        log.info("重置导出状态 - 开始");
        long startTime = System.currentTimeMillis();
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        //就绪状态
        ExportResult exportResult = new ExportResult();
        batchStateManageService.setExportState(oserviceOperator.getTenantId(), oserviceOperator.getUserId(), exportResult);
        log.info("重置导出状态 - 结束 ,耗时={}", (System.currentTimeMillis() - startTime));
    }


}
