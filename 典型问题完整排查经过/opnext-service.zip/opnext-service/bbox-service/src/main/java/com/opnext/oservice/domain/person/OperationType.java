package com.opnext.oservice.domain.person;

import lombok.AllArgsConstructor;

/**
 * @author tianzc
 */
@AllArgsConstructor
public enum  OperationType {
    /**
     * 新增
     */
    INSERT((byte)0),

    /**
     * 更新
     */
    UPDATE((byte)1),
    /**
     * 删除
     */
    DELETE((byte)2);
    private Byte value;
    public Byte value(){
        return this.value;
    }
}
