package com.opnext.oservice.domain.person;

import lombok.AllArgsConstructor;

/**
 * @ClassName: PropertyType
 * @Description:是否是固定字段：0固定字段，1扩展字段
 * @Author: Kevin
 * @Date: 2018/5/18 19:10
 */
@AllArgsConstructor
public enum PropertyType {
    /**
     * 0固定字段，
     */
    fixed(0),
    /**
     * 1扩展字段
     */
    extended(1);
    private int value;
    public int value(){
        return this.value;
    }

    /**
     * 通过 val 值索引 PropertyType
     * @param val val
     * @return PropertyType
     */
    public static PropertyType indexOfVal(int val) {
        for (PropertyType propertyType : values()) {
            if (propertyType.value == val) {
                return propertyType;
            }
        }

        throw new IllegalArgumentException("param value " + val);
    }


}
