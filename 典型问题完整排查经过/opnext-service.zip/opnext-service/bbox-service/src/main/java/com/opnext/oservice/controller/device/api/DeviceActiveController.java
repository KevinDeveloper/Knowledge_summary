package com.opnext.oservice.controller.device.api;

import com.opnext.bboxdomain.context.CommonContext;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.domain.device.ServerEntity;
import com.opnext.oservice.service.device.api.DeviceApiService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.HashMap;
import java.util.Map;

/**
 * @author tianzc
 */
@Slf4j
@RestController
@RequestMapping("/devapi")
public class DeviceActiveController {
    @Autowired
    DeviceApiService deviceApiService;

    @ApiOperation(value = "系统检测接口", notes = "返回时间戳")
    @RequestMapping(value = "/server/version/ops", method = RequestMethod.GET)
    public CommonResponse getServerVersion() throws Exception{
        Map<String, Object> map = new HashMap<>();
        map.put("version", deviceApiService.getServerVersion());
        Long timestamp = System.currentTimeMillis() / 1000;
        map.put("timestamp", timestamp);
        log.info("-----系统检测接口返回值：{}", map);
        return CommonResponse.ok(map);
    }

    @ApiOperation(value = "终端设备激活", notes = "")
    @RequestMapping(value = "/devices", method = RequestMethod.POST)
    public CommonResponse deviveActive(HttpServletRequest request,@RequestBody @Valid DeviceApiController.DeviceActiveRequest deviceActiveRequest) throws Exception {
        log.info("------设备激活接口参数：{}", deviceActiveRequest);
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        ServerEntity obj = deviceApiService.deviceActive(deviceActiveRequest, urlPrefix);
        return CommonResponse.ok(obj);
    }

    @ApiOperation(value = "检查sn是否有效", notes = "netty调用")
    @RequestMapping(value = "/check/{sn}", method = RequestMethod.GET)
    public CommonResponse getDeviceStatus(@PathVariable String sn) throws Exception{
        long count = deviceApiService.getCountBySn(sn);
        return CommonResponse.ok(count);
    }
}
