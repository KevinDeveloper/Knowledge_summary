package com.opnext.oservice.repository.device;

import com.opnext.oservice.domain.device.DeviceGroup;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午5:03 18/5/7
 */ 
public interface DeviceGroupRepository extends PagingAndSortingRepository<DeviceGroup, Integer>, QueryDslPredicateExecutor<DeviceGroup> {
}
