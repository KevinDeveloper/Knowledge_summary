package com.opnext.oservice.domain.accessrecord;

import com.opnext.domain.Sex;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author tianzc
 */
@Data
@ApiModel(description="身份证信息")
public class IdentifyCard implements Serializable {
    /**
     * 姓名
     */
    @ApiModelProperty(value="姓名")
    private String name;
    /**
     *  性别
     */
    @ApiModelProperty(value="性别")
    private Sex sex;
    /**
     * 民族
     */
    @ApiModelProperty(value="民族")
    private String nation;
    /**
     * 出生日期
     */
    @ApiModelProperty(value="出生日期")
    private String birthday;
    /**
     * 住址
     */
    @ApiModelProperty(value="地址")
    private String address;
    /**
     * 证件号码
     */
    @ApiModelProperty(value="证件号")
    private String idCard;
    /**
     * 签发机关
     */
    @ApiModelProperty(value="签发机关")
    private String signOrg;
    /**
     * 签发日期
     */
    @ApiModelProperty(value="签发日期")
    private String signBegin;
    /**
     * 有效期至
     */
    @ApiModelProperty(value="有效期")
    private String signEnd;
    /**
     * 国家代码
     */
    @ApiModelProperty(value="国家代码")
    private String countryCode;
    /**
     * 出生地点
     */
    @ApiModelProperty(value="出生地点")
    private String birthPlace;
    /**
     * 签发地点
     */
    @ApiModelProperty(value="签发地点")
    private String issuePlace;
    /**
     * 身份证照片
     */
    @ApiModelProperty(value="身份证照片")
    private String imageUrl;
}
