package com.opnext.oservice.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class FileUtil {

    private static Logger logger = LoggerFactory.getLogger(FileUtil.class);

    /**
     * 删除文件
     *
     * @param filePathAndName String 文件路径及名称 如c:/fqf.txt
     * @return boolean
     */
    public static boolean delFile(String filePathAndName) {
        try {
            String filePath = filePathAndName;
            filePath = filePath.toString();
            File myDelFile = new File(filePath);
            myDelFile.delete();
            return true;
        } catch (Exception e) {
            logger.error("删除文件操作出错 e = {}", e);

        }
        return false;
    }

    /**
     * 删除文件
     *
     * @param file File 删除文件
     * @return boolean
     */
    public static void delFile(File file) {
        try {
            file.delete();
        } catch (Exception e) {
            logger.error("删除文件操作出错 e = {}", e);
            ;

        }

    }

    /**
     * 递归删除目录下的所有文件及子目录下所有文件
     *
     * @param dir 将要删除的文件目录
     * @return boolean Returns "true" if all deletions were successful. If a
     * deletion fails, the method stops attempting to delete and returns
     * "false".
     */
    public static boolean deleteDir(File dir) {
        if (dir.isDirectory()) {
            String[] children = dir.list();
            // 递归删除目录中的子目录下
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        // 目录此时为空，可以删除
        return dir.delete();
    }

    public static boolean deleteDir(String dirpath) {
        File dir = new File(dirpath);
        if (dir.isDirectory()) {
            String[] children = dir.list();
            // 递归删除目录中的子目录下
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        // 目录此时为空，可以删除
        return dir.delete();
    }

    public static boolean deleteFileAndParent(String dirpath) {
        File dir = new File(dirpath);
        File parentFile = new File(dir.getParent());
        if (dir.isFile()) {
            delFile(dir);
        } else if (dir.isDirectory()) {
            String[] children = dir.list();
            // 递归删除目录中的子目录下
            for (int i = 0; i < children.length; i++) {
                boolean success = deleteDir(new File(dir, children[i]));
                if (!success) {
                    return false;
                }
            }
        }
        deleteDir(parentFile);
        // 目录此时为空，可以删除
        return dir.delete();
    }

    /**
     * 根据文件名生成访问路径
     *
     * @param fileName 文件名
     * @return 访问路径
     */
    public static String getUrlByFileName(String fileName) {
        StringBuilder sb = new StringBuilder();
        int i = 0, l = fileName.split("\\.")[0].length();
        for (; i < 16; i += 2) {
            if (l < i + 3) {
                break;
            }
            sb.append(fileName.substring(i, i + 2));
            sb.append("/");
        }
        sb.append(fileName.substring(i));
        return sb.toString();
    }


    /**
     * 文件重命名 ,命名成org_+原文件名称,比如以前为1.jpg,现在命名成了org_1.jpg
     *
     * @param file 文件目录
     */
    public static File renameFile(File file) {
        if (file.exists() && file.isFile()) {
            String orignalName = file.getName();
            String parentDir = file.getParentFile().getAbsolutePath();
            File newFile = new File(parentDir + File.separator + "org_" + orignalName);
            file.renameTo(newFile);
            logger.debug("重命名后的文件为：" + newFile.getAbsolutePath());
            return newFile;
        }
        return null;
    }


    /**
     * //加密解密图片
     *
     * @param inFile  源文件
     * @param outFile 目标文件
     */
    private static void encodePic(File inFile, File outFile) {
        logger.debug("进入了加密图片方法");
        long timeMillis = System.currentTimeMillis();
        if (!outFile.exists()) {
            logger.error("目标文件不存在");
        }
        //建立数据通道让图片的二进制数据流入
        try {
            FileInputStream input = new FileInputStream(inFile);
            FileOutputStream output = new FileOutputStream(outFile);
            // 边读，把读到的数据异或一个数据把数据写入
            byte[] b = new byte[10];
            byte[] left = new byte[1024 * 1024];
            input.read(b, 0, 10);
            for (int i = 0; i < 10; i++) {
                output.write(b[i] ^ 12);
            }
            int n = 0;
            while (-1 != (n = input.read(left))) {
                output.write(left, 0, n);
            }

            // 关闭资源
            output.close();
            input.close();
        } catch (FileNotFoundException e) {
            logger.error("e = {}", e);
        } catch (IOException e) {
            logger.error("e = {}", e);
        }
        logger.debug("加密图片时间为：" + (System.currentTimeMillis() - timeMillis));
    }


    public static byte[] readInputStream(InputStream inStream) throws Exception {
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        //创建一个Buffer字符串
        byte[] buffer = new byte[1024];
        //每次读取的字符串长度，如果为-1，代表全部读取完毕
        int len = 0;
        //使用一个输入流从buffer里把数据读取出来
        while ((len = inStream.read(buffer)) != -1) {
            //用输出流往buffer里写入数据，中间参数代表从哪个位置开始读，len代表读取的长度
            outStream.write(buffer, 0, len);
        }
        //关闭输入流
        inStream.close();
        //把outStream里的数据写入内存
        return outStream.toByteArray();
    }

    /**
     * 将图片文件转化为字节数组字符串，并对其进行Base64编码处理
     */
    public static byte[] getImageDataRemote(String imgFile) {
        // imgFile = "d://test.jpg";//待处理的图片
        InputStream inStream = null;
        byte[] data = null;
        //读取图片字节数组
        try {
            //inStream = new FileInputStream(imgFile);//imgFile
            //new一个URL对象
            URL url = new URL(imgFile);
            //打开链接
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            //设置请求方式为"GET"
            conn.setRequestMethod("GET");
            //超时响应时间为5秒
//            conn.setConnectTimeout(5 * 1000);
            //通过输入流获取图片数据
            inStream = conn.getInputStream();
            //得到图片的二进制数据，以二进制封装得到数据，具有通用性
            data = readInputStream(inStream);
            return data;
        } catch (Exception e) {
            logger.error("获取文件服务器上图片失败：{}", e);
            return null;
        }
    }

    public static void buff2Image(byte[] b, String tagSrc) throws Exception {
        FileOutputStream fout = new FileOutputStream(tagSrc);
        //将字节写入文件
        fout.write(b);
        fout.close();
    }

    public static byte[] image2Bytes(String imgSrc) throws Exception {
        FileInputStream fin = new FileInputStream(new File(imgSrc));
        //可能溢出,简单起见就不考虑太多,如果太大就要另外想办法，比如一次传入固定长度byte[]
        byte[] bytes = new byte[fin.available()];
        //将文件内容写入字节数组，提供测试的case
        fin.read(bytes);

        fin.close();
        return bytes;
    }

    /**
     * 根据路径，创建一级目录
     *
     * @param dirPathName
     * @throws Exception
     */
    public static void createDirByPathName(String dirPathName) throws Exception {
        File exportFile = new File(dirPathName);
        if (!exportFile.exists()) {
            exportFile.mkdirs();
        }
    }

    /**
     * 对临时生成的文件夹和文件夹下的文件进行删除
     */
    public static void deletefilesOrDir(String delpath) {
        try {
            File file = new File(delpath);
            if (!file.exists()) {
                return;
            }
            //判断是不是一个目录
            if (!file.isDirectory()) {
                file.delete();
            } else {
                String[] filelist = file.list();
                for (int i = 0; i < filelist.length; i++) {
                    File delfile = new File(delpath + File.separator + filelist[i]);
                    if (!delfile.isDirectory()) {
                        delfile.delete();
                    } else {
                        //递归删除
                        deletefilesOrDir(delpath + File.separator + filelist[i]);
                    }
                }
                file.delete();
            }
        } catch (Exception e) {
            logger.error("e = {}", e);
            ;
        }
    }

}
