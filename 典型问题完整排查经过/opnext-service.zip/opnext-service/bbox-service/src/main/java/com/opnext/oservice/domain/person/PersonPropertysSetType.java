package com.opnext.oservice.domain.person;

import lombok.AllArgsConstructor;

/**
 * @ClassName: PersonPropertysSetType
 * @Description:
 * @Author: Kevin
 * @Date: 2018/6/5 14:33
 */
@AllArgsConstructor
public enum PersonPropertysSetType {
    no(0),
    name(1),
    idCard(2),
    orgName(3);
    private int value;

    public int value() {
        return this.value;
    }
}
