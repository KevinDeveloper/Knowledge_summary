package com.opnext.oservice.domain.tenant;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

/**
 * @author lixiuwen
 */

@Entity
@Table(name = "tenant_wechat")
@Data
@EntityListeners(AuditingEntityListener.class)
@NoArgsConstructor
@AllArgsConstructor
public class TenantWechat {
    /**
     * 租户ID
     */
    @Id
    @Column(name = "tenant_id")
    private Long tenantId;
    /**
     * 微信公众号APPID
     */
    @Column(name = "app_id")
    private String appId;

    /**
     * 创建时间
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    @CreatedDate
    private Date createTime;
}
