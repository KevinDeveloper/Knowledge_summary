package com.opnext.oservice.domain.person;

import lombok.Data;

/**
 * 人员同步错误返回
 * @author tianzc
 */
@Data
public class PersonSyncError {
    /**
     * 人员id
     */
    private String id;
    /**
     * 人员编号
     */
    private String no;
    /**
     * 人员姓名
     */
    private String name;
    /**
     * 错误原因
     */
    private String errorMsg;

}
