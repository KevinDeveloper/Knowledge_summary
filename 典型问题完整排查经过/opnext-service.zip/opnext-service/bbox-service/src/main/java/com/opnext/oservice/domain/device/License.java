package com.opnext.oservice.domain.device;

import lombok.Data;

/**
 * @author tianzc
 */
@Data
public class License {
    private String sn;
    private String urlPath;
}
