package com.opnext.oservice.feign;

import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.controller.authority.AuthorizationController;
import com.opnext.oservice.domain.account.Account;
import com.opnext.oservice.domain.tenant.Tenant;
import com.opnext.oservice.dto.PageFeign;
import com.opnext.oservice.dto.authority.AuthorityDTO;
import com.opnext.oservice.feign.impl.UserCenterFallFactory;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.List;
import java.util.Map;

/**
 * @author wanglu
 */
@FeignClient(value = "user-center",path = "/user-center/api",fallbackFactory = UserCenterFallFactory.class)
public interface UserCenterFeign {

    /**
     * 查询管理员列表（分页）
     * @param urlVariables
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET, value = "/users")
    CommonResponse<PageFeign<Account>> getAccountPage(Object... urlVariables) throws Exception;

    /**
     * 查询管理员列表（AuthorityDTO对象）不分页
     * @param urlVariables
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET, value = "/users")
    CommonResponse<PageFeign<AuthorityDTO>> getAuthorityAccountPage(Object... urlVariables)throws Exception;

    /**
     * 检查密码是否正确
     * @param account
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.POST, value = "/user/pwd/_verify")
    CommonResponse<Boolean> verifyPassword(Account account)throws Exception;

    /**
     * 修改密码
     * @param account
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.POST, value = "/user")
    CommonResponse modifyAccount(Account account)throws Exception;

    /**
     * 修改账号状态：启动、关闭
     * @param changeAccountStatusParam
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.POST, value = "/user/status/switch")
    CommonResponse<List<Long>> changeAccountStatus(AuthorizationController.ChangeAccountStatusParam changeAccountStatusParam)throws Exception;

    /**
     * 添加子账号
     * @param account
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.POST, value = "/user")
    CommonResponse<Account> addAccount(Account account)throws Exception;

    /**
     * 删除子账号
     * @param paramMap
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/user")
    CommonResponse deleteAccount(Map paramMap)throws Exception;

    /**
     * 租户详情查询
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET, value = "/tenant/{id}")
    CommonResponse<Tenant> getTenantById(@PathVariable("id") Long id)throws Exception;
}

