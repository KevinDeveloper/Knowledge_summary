package com.opnext.oservice.domain.converter;

import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.MapLikeType;
import com.opnext.domain.ResourceType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import javax.persistence.AttributeConverter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author tianzc
 */
@Slf4j
public class PersonAvatarsConverter implements AttributeConverter<Map<ResourceType, List<String>>, String> {
    /**
     * Converts the value stored in the entity attribute into the
     * data representation to be stored in the database.
     *
     * @param attribute the entity attribute value to be converted
     * @return the converted data to be stored in the database column
     */
    @Override
    public String convertToDatabaseColumn(Map<ResourceType, List<String>> attribute) {
        ObjectMapper mapper = new ObjectMapper();
        String str = null;
        try {
            if (!CollectionUtils.isEmpty(attribute)) {
                str = mapper.writeValueAsString(attribute);
            }
        } catch (Exception e) {
            log.error("--------PersonAvatars attribute jackson转换异常，参数：", attribute);
            log.error("jackson转换异常", e);
        }
        return str;
    }

    /**
     * Converts the data stored in the database column into the
     * value to be stored in the entity attribute.
     * Note that it is the responsibility of the converter writer to
     * specify the correct dbData type for the corresponding column
     * for use by the JDBC driver: i.e., persistence providers are
     * not expected to do such type conversion.
     *
     * @param dbData the data from the database column to be converted
     * @return the converted value to be stored in the entity attribute
     */
    @Override
    public Map<ResourceType, List<String>> convertToEntityAttribute(String dbData) {
        ObjectMapper mapper = new ObjectMapper();
        Map<ResourceType, List<String>> map = new HashMap<>();
        try {
            if (StringUtils.isNoneBlank(dbData)) {
                JavaType javaTypeKey = mapper.getTypeFactory().constructType(ResourceType.class);
                JavaType javaTypeVal = mapper.getTypeFactory().constructParametricType(List.class, String.class);
                MapLikeType mapLikeType = mapper.getTypeFactory().constructMapLikeType(Map.class, javaTypeKey, javaTypeVal);
                map = mapper.readValue(dbData, mapLikeType);
            } else {
                return map;
            }
        } catch (Exception e) {
            log.error("-------PersonAvatars dbData jackson转换异常，参数：{}", dbData);
            log.error("jackson转换异常：{}", e.getMessage());
        }
        return map;
    }
}
