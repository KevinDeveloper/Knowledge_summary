package com.opnext.oservice.repository.accessrecord;

import com.opnext.oservice.domain.accessrecord.AccessRecordInfo;
import com.opnext.oservice.repository.base.impl.BaseMongoDaoImpl;
import org.springframework.stereotype.Service;

/**
 * @author tianzc
 */
@Service
public class AccessRecordDao extends BaseMongoDaoImpl<AccessRecordInfo> {
}
