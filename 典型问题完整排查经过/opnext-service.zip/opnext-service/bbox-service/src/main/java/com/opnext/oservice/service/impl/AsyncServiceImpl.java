package com.opnext.oservice.service.impl;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.batch.BatchStateType;
import com.opnext.bboxdomain.batch.ExportResult;
import com.opnext.bboxdomain.batch.ExportStateType;
import com.opnext.bboxdomain.context.CommonContext;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.domain.message.Command;
import com.opnext.domain.request.FeedBackRequest;
import com.opnext.omessage.support.CallBackBuilder;
import com.opnext.omessage.support.MessageContext;
import com.opnext.omessage.support.SimpleMessageTemplate;
import com.opnext.oservice.conf.Constant;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.command.BusinessType;
import com.opnext.oservice.domain.command.CommandErrorInfo;
import com.opnext.oservice.domain.command.QCommandErrorInfo;
import com.opnext.oservice.domain.device.QDevice;
import com.opnext.oservice.domain.person.OperationType;
import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.domain.person.PersonConfigVo;
import com.opnext.oservice.domain.person.PersonSync;
import com.opnext.oservice.domain.person.PersonVo;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.feign.OMessageFeign;
import com.opnext.oservice.repository.command.CommandErrorInfoDao;
import com.opnext.oservice.repository.command.CommandErrorInfoRepository;
import com.opnext.oservice.repository.device.DeviceRepository;
import com.opnext.oservice.repository.person.PersonRepository;
import com.opnext.oservice.repository.person.PersonSyncRepository;
import com.opnext.oservice.service.AsyncService;
import com.opnext.oservice.service.fastdfs.FastTmpFileManagerService;
import com.opnext.oservice.service.person.BatchStateManageService;
import com.opnext.oservice.service.person.PersonService;
import com.opnext.oservice.util.DateUtil;
import com.opnext.oservice.util.FileUtil;
import com.opnext.oservice.util.ZipUtil;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationHome;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author tianzc
 */
@Slf4j
@Service
public class AsyncServiceImpl implements AsyncService {
    @Value("${server.context-path}")
    private String serverPath;

    @Autowired
    private PersonRepository personRepository;
    @Autowired
    private PersonSyncRepository personSyncRepository;
    @Autowired
    private DeviceRepository deviceRepository;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    CommandErrorInfoDao commandErrorInfoDao;
    @Autowired
    CommandErrorInfoRepository commandErrorInfoRepository;

    @Resource
    private OMessageFeign oMessageFeign;

    @Lazy
    @Autowired
    private PersonService personService;


    @Autowired
    private BatchStateManageService batchStateManageService;

    @Lazy
    @Autowired
    private FastTmpFileManagerService tmpFileManagerService;

    /**
     * 通过syncVersion 获取人员列表
     *
     * @param syncVersion
     * @param operationType
     */
    @Override
    @Async
    public void syncPerson(long syncVersion, OperationType operationType) {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QPerson.person.syncVersion.eq(syncVersion);
        predicate = ((BooleanExpression) predicate).and(QPerson.person.tenantId.eq(tenantId));
        // 获取修改数据
        List<Person> personList = (List<Person>) personRepository.findAll(predicate);
        if (Objects.nonNull(personList)) {
            PersonSync personSync;
            List<PersonSync> list = new ArrayList<>();
            // 数据入库到同步表
            for (int i = 0; i < personList.size(); i++) {
                personSync = new PersonSync();
                personSync.setPersonId(personList.get(i).getId());
                personSync.setSyncVersion(syncVersion);
                personSync.setTenantId(tenantId);
                personSync.setOperationType(operationType);
                personSync.setOperatorId(oserviceOperator.getUserId());
                personSync.setOperatorName(oserviceOperator.getLoginName());
                list.add(personSync);
                if ((i + 1) % 200 == 0) {
                    personSyncRepository.save(list);
                    list = new ArrayList<>();
                }
            }
            personSyncRepository.save(list);
        } else {
            log.error("需要同步数据不存在！");
        }
        // 下发指令
    }

    /**
     * @param person
     * @param operationType
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
//    @Async
    public void syncPerson(Person person, OperationType operationType, OserviceOperator oserviceOperator) {
        syncPerson(Lists.newArrayList(person), operationType, oserviceOperator);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
//    @Async
    public void syncPerson(List<Person> personList, OperationType operationType, OserviceOperator oserviceOperator) {
        Long tenantId = oserviceOperator.getTenantId();
        long syncVersion = System.currentTimeMillis();
        if (!CollectionUtils.isEmpty(personList)) {
            PersonSync personSync;
            List<PersonSync> list = new ArrayList<>();
            List<String> personIdList = new ArrayList<>();
            // 数据入库到同步表
            int i = 0;
            for (Person person : personList) {
                personSync = new PersonSync();
                personSync.setPersonId(person.getId());
                personSync.setNo(person.getNo());
                personSync.setSyncVersion(syncVersion);
                personSync.setTenantId(tenantId);
                personSync.setOperatorId(oserviceOperator.getUserId());
                personSync.setOperatorName(oserviceOperator.getLoginName());
                personSync.setOperationType(operationType);
                personSync.setCreateTime(new Date());
                list.add(personSync);
                // 生成personId列表
                personIdList.add(person.getId());
                // 判断是否入库
                if ((i + 1) % 500 == 0) {
                    personSyncRepository.save(list);
                    list = new ArrayList<>();
                }
                i++;
            }
            if (list.size() > 0) {
                personSyncRepository.save(list);
            }

            // 1、根据tenantId获取设备sn
            QDevice qDevice = QDevice.device;
            Predicate predicate = qDevice.tenantId.eq(tenantId);
            List<String> deviceSnlList = jpaQueryFactory.select(qDevice.sn)
                    .from(qDevice).where(predicate).fetch();
            // 根据operationType添加相应的逻辑（删除）
            // 待完善tianzc
            // /callback/person/{operationType}/{syncVersion}
            if (CollectionUtils.isEmpty(deviceSnlList)) {
                log.info("------人员管理模块-同步人员,没有需要同步设备");
            } else {
                log.info("------人员管理模块-同步人员，设备sn：{}", deviceSnlList);
                String terminalGatewayHost = "";
                String relativeUrl = "%s%s/api/devapi/callback/person/{workflowId}/{commandId}/{requestId}?page=%s&operationType=%s&syncVersion=%s";
                String strUrl = String.format(relativeUrl, terminalGatewayHost, serverPath, 0, operationType, syncVersion);
                MessageContext context;
                if (operationType.equals(OperationType.DELETE)) {
                    context = SimpleMessageTemplate
                            .operator(String.valueOf(oserviceOperator.getTenantId()), oserviceOperator.getLoginName())
                            .appId(oserviceOperator.getAppId())
                            .scope(Sets.newHashSet(deviceSnlList)).deletePerson(strUrl);
                } else {
                    context = SimpleMessageTemplate
                            .operator(String.valueOf(oserviceOperator.getTenantId()), oserviceOperator.getLoginName())
                            .appId(oserviceOperator.getAppId())
                            .scope(Sets.newHashSet(deviceSnlList)).getPerson(strUrl);

                }
                String feedback = String.format("%s%s/api/devapi/feedback/{workflowId}/{commandId}/{requestId}/%s"
                        , terminalGatewayHost
                        , serverPath
                        , BusinessType.PERSON);
                context.setFeedBack(CallBackBuilder.ready().url(feedback).method(Command.Method.POST).build());
                oMessageFeign.send(context);
            }
        } else {
            log.error("需要同步数据不存在！personIdList：{}", personList);
        }
    }

    /**
     * 异步处理终端指令反馈
     *
     * @param command
     * @param businessType
     * @param feedBackRequest
     */
    @Override
    @Async
    public void deviceFeedBack(Command command, OserviceDevApiOperator oserviceDevApiOperator, BusinessType businessType, FeedBackRequest feedBackRequest) {
        try {
            if (FeedBackRequest.FeedBackStatus.SUCCESS.equals(feedBackRequest.getStatus())) {
                QCommandErrorInfo qCommandErrorInfo = QCommandErrorInfo.commandErrorInfo;
                Predicate predicate = qCommandErrorInfo.requestId.eq(command.getRequestId());
                long count = commandErrorInfoRepository.count(predicate);
                // 根据错误条数判断调用message 返回结果状态
                if (count > 0) {
                    feedBackRequest.setStatus(FeedBackRequest.FeedBackStatus.FAIL);
                } else {
                    feedBackRequest.setStatus(FeedBackRequest.FeedBackStatus.SUCCESS);
                }
            }
            if (FeedBackRequest.FeedBackStatus.FAIL.equals(feedBackRequest.getStatus())) {
                List<FeedBackRequest.FeedBackError> errorList = feedBackRequest.getErrorData();
                if (CollectionUtils.isEmpty(errorList)) {
                    FeedBackRequest.FeedBackError feedBackError;
                    if (BusinessType.PERSON.equals(businessType)) {
                        errorList = new ArrayList<>();
                        feedBackError = new FeedBackRequest.FeedBackError();
                        feedBackError.setKey("url_" + businessType.name());
                        String content = String.format("/device/failedCommand/%s&%s", command.getCommandId(), oserviceDevApiOperator.getSn());
                        feedBackError.setContent(content);
                        errorList.add(feedBackError);
                    } else if (BusinessType.ADMIN.equals(businessType)) {
                        errorList = new ArrayList<>();
                        Iterable<CommandErrorInfo> errorInfoList = commandErrorInfoRepository.findAll(QCommandErrorInfo.commandErrorInfo.requestId.eq(command.getRequestId()));
                        Iterator iterator = errorInfoList.iterator();
                        while (iterator.hasNext()) {
                            CommandErrorInfo errorInfo = (CommandErrorInfo) iterator.next();
                            feedBackError = new FeedBackRequest.FeedBackError();
                            feedBackError.setKey("tips_" + businessType.name());
                            feedBackError.setExplain((String) errorInfo.getErrorData().get("name"));
                            feedBackError.setContent((String) errorInfo.getErrorData().get("errorMsg"));
                            errorList.add(feedBackError);
                        }
                    } else {
                        log.info("------feedBack业务类型businessType：{} 无效", businessType);
                    }
                }
                feedBackRequest.setErrorData(errorList);
            }
            // 数据处理
            oMessageFeign.feedback(command.getWorkflowId(), command.getCommandId(), command.getRequestId(), feedBackRequest);
        } catch (Exception e) {
            log.info("调用请求oMessage反馈接口异常：{}", e);
        }
    }

    /**
     * 删除指定文件
     * 删除7天前文件夹
     *
     * @param imgFilePath
     */
    @Override
    @Async
    public void clearImgEmptyFile(String imgFilePath) {
        try {
            if (StringUtils.isNotBlank(imgFilePath)) {
                File file = new File(imgFilePath);
                file.delete();
            }
        } catch (Exception e) {
            log.error("--临时文件删除失败：", e);
        }
        try {
            // 删除两天前的文件夹以及文件
            ApplicationHome home = new ApplicationHome(getClass());
            String basePath = home.getDir().getAbsolutePath() + File.separator + "imgFiles";
            File baseFile = new File(basePath);
            if (baseFile.isDirectory()) {
                File[] tempList = baseFile.listFiles();
                if (null != tempList && tempList.length > 0) {
                    for (File tmpfile : tempList) {
                        if (tmpfile.isDirectory()) {
                            String tmpFileName = tmpfile.getName();
                            Date fileDate = null;
                            try {
                                fileDate = DateUtil.parseStrToDate(tmpFileName, "yyyy-MM-dd");
                            } catch (Exception e) {
                                log.error("上传文件夹下未知文件夹：" + tmpFileName);
                            }
                            if (fileDate != null) {
                                // 两个时间差
                                long m = DateUtil.getCurrDistanceDays(fileDate, DateUtil.getDayBeginTime(new Date()));
                                if (m > 7) {
                                    log.info("删除文件夹" + tmpfile.getPath());
                                    FileUtil.deleteDir(tmpfile);
                                }
                            }
                        }
                    }
                } else {
                    log.debug("上传路径下没有文件和文件夹");
                }
            } else {
                log.debug("上传路径不存在");
            }
        } catch (Exception e) {
            log.error("删除7天前的临时文件任务异常：{}", e);
        }
    }

    @Async
    @Override
    public void exportPerson(OserviceOperator oserviceOperator, String name, String no, Integer organizationId, String fileExcelPath, String avatarsDirPath, String allAvatarsZipPath, String exportDirPath, String allFilesZipPath, String allFilesZip,  RequestUrlPrefix urlPrefix) {
        log.info("异步处理导出人员 - 开始");
        long tenantId = oserviceOperator.getTenantId();
        long start = System.currentTimeMillis();
        //异步线程传递多语言
        if (Objects.nonNull(oserviceOperator.getCurLocale())) {
            log.info("异步处理导出人员设置语言为：locale={}, tenantId={}, userId={}", oserviceOperator.getCurLocale(), oserviceOperator.getTenantId(), oserviceOperator.getUserId());
            Messages.setLocale(oserviceOperator.getCurLocale());
        }

        ScheduledExecutorService scheduledExecutor = new ScheduledThreadPoolExecutor(1);
        scheduledExecutor.scheduleAtFixedRate(() -> {
            try {
                //更新异步任务存活时间
                batchStateManageService.setUnderWayExport(oserviceOperator.getTenantId(), oserviceOperator.getUserId(), BatchStateManageService.EXPORT_PERSON_KEY_UNDERWAY);
                log.info("更新异步任务存活时间,  异步解析人员");
            } catch (Exception e) {
                log.error("异步任务定时管理器异常，e={}", e);
            }
        }, 0, 1, TimeUnit.MINUTES);
        ExecutorService executor = new ThreadPoolExecutor(2, 2, 0L, TimeUnit.MILLISECONDS, new LinkedBlockingQueue<>(3));
        try {

            //设置导出状态 - 导出中
            ExportResult exportResult = new ExportResult();
            exportResult.setExportState(ExportStateType.STATE_EXPORTING.value());
            batchStateManageService.setExportState(oserviceOperator.getTenantId(), oserviceOperator.getUserId(), exportResult);

            long startTime = System.currentTimeMillis();
            List<PersonVo> personVos = personService.getExportPersons(tenantId, name, no, organizationId);
            if (CollectionUtils.isEmpty(personVos)) {
                throw new CommonException("export.person.get.error");
            }
            log.info(" 查询出导出人员数量 size={}, 耗时 {}(ms)", personVos.size(), System.currentTimeMillis() - startTime);
            startTime = System.currentTimeMillis();
            List<PersonConfigVo> configs = personService.getFormatPersonConfigs(tenantId);
            if (CollectionUtils.isEmpty(configs)) {
                throw new CommonException("export.person.handle.error");
            }
            log.info(" 查询出导出人员字段数量 size={}, 耗时 {}(ms)", configs.size(), System.currentTimeMillis() - startTime);

            List<Future> futures = new ArrayList<>();
            //>excel文件处理
            futures.add(executor.submit(() -> {
                try {
                    //异步线程传递多语言
                    if (Objects.nonNull(oserviceOperator.getCurLocale())) {
                        Messages.setLocale(oserviceOperator.getCurLocale());
                    }
                    long startTime1 = System.currentTimeMillis();
                    personService.exportAndSaveExcelPersons(personVos, configs, fileExcelPath);
                    log.info(" 导出人员数据到excel , 耗时 {}(ms)", System.currentTimeMillis() - startTime1);
                } catch (Exception e) {
                    log.error("导出人员，导出人员数据到excel 异常，e:{}", e);
                    throw new CommonException(e);
                }
                return null;
            }));
            //>处理人员图片
            futures.add(executor.submit(() -> {
                long s = System.currentTimeMillis();
                try {
                    personService.downloadAndZipPersonAvatars(personVos, avatarsDirPath, allAvatarsZipPath);
                } catch (Exception e) {
                    log.error("导出人员，并发处理图片异常，e:{}", e);
                    throw new CommonException(e);
                }
                log.info(" 处理人员图片并压缩, 耗时 {}(ms)", System.currentTimeMillis() - s);
                return null;

            }));
            for (Future future : futures) {
                future.get();
            }
            log.info("并发处理人员excel数据和图片数据结束");
            //>压缩excel和头像zip
            startTime = System.currentTimeMillis();
            ZipUtil.fileToZip(exportDirPath, allFilesZipPath);
            log.info(" 压缩图片和excel, 耗时 {}(ms)", System.currentTimeMillis() - startTime);

            startTime = System.currentTimeMillis();
            File allFile = new File(allFilesZipPath);
            if (!allFile.exists()) {
                throw new CommonException("export.person.allFile.exception");
            }
            //String allFileId = dfsClient.uploadWithOriginalName(allFile, allFilesZip);
            //allFileId = new String(Base64Utils.encode(allFileId.getBytes()));
            Optional<String> allFileIdOptional = tmpFileManagerService.uploadFileWithOriginalName(allFile, allFilesZip, oserviceOperator);
            if (!allFileIdOptional.isPresent()) {
                throw new CommonException();
            }
            String allFileId = allFileIdOptional.get();
            log.info(" 上传人员导出数据 excel 和zip, 耗时 {}(ms)", System.currentTimeMillis() - startTime);

           // String allFilePath = GlobleConfig.ServerUrl.fastdfsGatewayHost + Constant.FASTDFS_SERVER_DOWNLOAD_URI + "/" + allFileId;
            String allFilePath = "";
            if(GlobleConfig.ServerConfig.urlStoreRelative){
                allFilePath = Constant.FASTDFS_SERVER_DOWNLOAD_URI + "/" + allFileId;
            }else{

                allFilePath = GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()) + Constant.FASTDFS_SERVER_DOWNLOAD_URI + "/" + allFileId;
            }
            log.info("导出文件下载地址， filePath={}", allFilePath);
            //设置导出状态  - 成功+地址
            exportResult = new ExportResult();
            exportResult.setExportState(ExportStateType.STATE_SUCCESS.value());
            exportResult.setFilePath(allFilePath);
            batchStateManageService.setExportState(oserviceOperator.getTenantId(), oserviceOperator.getUserId(), exportResult);
        } catch (Exception e) {
            log.error("导出人员失败，e={}", e);
            //设置导出状态  - 失败
            ExportResult exportResult = new ExportResult();
            exportResult.setExportState(ExportStateType.STATE_FAIL.value());
            batchStateManageService.setExportState(oserviceOperator.getTenantId(), oserviceOperator.getUserId(), exportResult);

        } finally {
            //>删除临时数据
            long startTime = System.currentTimeMillis();
            //删除图片压缩包
            FileUtil.deletefilesOrDir(allAvatarsZipPath);
            //删除所有的导出文件夹
            FileUtil.deletefilesOrDir(exportDirPath);
            //删除导出的整体压缩包
            FileUtil.deletefilesOrDir(allFilesZipPath);
            log.info("删除临时文件， 耗时={}ms", (System.currentTimeMillis() - startTime));
            executor.shutdown();
            scheduledExecutor.shutdown();
        }
        log.info("异步处理导出人员 - 结束, 耗时={}ms", ((System.currentTimeMillis() - start)));

    }

    /**
     * 异步处理人员入库
     */
    @Async
    @Override
    public void insertBatchPersons(OserviceOperator oserviceOperator, RequestUrlPrefix urlPrefix) {
        log.info("异步处理人员入库 - 开始");
        long startTime = System.currentTimeMillis();
        long tenantId = oserviceOperator.getTenantId();

        if (Objects.nonNull(oserviceOperator.getCurLocale())) {
            log.info("异步入库设置语言为：locale={}, tenantId={}, userId={}", oserviceOperator.getCurLocale(), oserviceOperator.getTenantId(), oserviceOperator.getUserId());
            Messages.setLocale(oserviceOperator.getCurLocale());
        }

        ScheduledExecutorService scheduledExecutor = new ScheduledThreadPoolExecutor(1);
        scheduledExecutor.scheduleAtFixedRate(() -> {
            try {
                //更新异步任务存活时间
                batchStateManageService.setUnderWay(oserviceOperator.getTenantId(), BatchStateManageService.BATCH_PERSON_KEY_UNDERWAY);
                log.info("更新异步任务存活时间,  异步解析人员");
            } catch (Exception e) {
                log.error("异步任务定时管理器异常，e={}", e);
            }
        }, 0, 1, TimeUnit.MINUTES);


        //1、更新导入状态 - 导入中
        //batchStateManageService.setBatchState(tenantId, BatchStateType.STATE_IMPORTING);

        try {
            //2、数据入库
            personService.batchImportDataInsert(oserviceOperator,urlPrefix );
            //3、更新导入状态 - 导入完成
            batchStateManageService.setBatchState(tenantId, BatchStateType.STATE_IMPORTED);
        } catch (Exception e) {
            log.error("批量导入数据入库处理 - 异常， e={}", e);
            //更新导入状态 - 导入失败
            batchStateManageService.setBatchState(tenantId, BatchStateType.STATE_IMPORTE_FAIL);
        } finally {
            scheduledExecutor.shutdown();
        }
        log.info("异步处理人员入库 - 结束, 耗时={}", (System.currentTimeMillis() - startTime));
    }
}
