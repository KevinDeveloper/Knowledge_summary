package com.opnext.oservice.repository.device;

import com.opnext.oservice.domain.device.DeviceAdmin;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @Title: 设备管理员Repository
 * @Description: --
 * @author tianzc
 * @Date 下午4:48 18/5/7
 */
public interface DeviceAdminRepository extends PagingAndSortingRepository<DeviceAdmin, Integer>, QueryDslPredicateExecutor<DeviceAdmin> {
}
