package com.opnext.oservice.service.person;

import com.opnext.oservice.domain.person.PersonConfigVo;
import com.opnext.oservice.domain.person.PropertyRequest;

import java.util.List;

/**
 * @ClassName: PersonConfigService
 * @Description:
 * @Author: Kevin
 * @Date: 2018/5/18 15:06
 */
public interface PersonConfigService {
    /**
     * 初始化人员配置
     * @param tenantId
     * @param operatorId
     * @throws Exception
     */
    void initPersonConfig(Long tenantId,Long operatorId) throws Exception;

    /**
     * 更新人员配置
     * @param tenantId
     * @param operatorId
     * @param propertyRequest
     * @throws Exception
     */
    void updatePersonConfig(Long tenantId,Long operatorId, PropertyRequest propertyRequest) throws Exception;

    /**
     * 查询人员配置列表
     * @param tenantId
     * @return
     * @throws Exception
     */
    List<PersonConfigVo> personConfigList(Long tenantId) throws Exception;


    /**
     * 删除人员字段配置
     * @param tenantId
     * @param operatorId
     * @param configIds
     * @throws Exception
     */
    void deletePersonConfig(Long tenantId,Long operatorId, Integer[] configIds ) throws Exception;





}
