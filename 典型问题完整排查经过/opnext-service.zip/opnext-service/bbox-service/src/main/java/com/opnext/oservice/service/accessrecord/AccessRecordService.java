package com.opnext.oservice.service.accessrecord;

import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.domain.accessrecord.AccessRecordInfo;
import com.opnext.oservice.domain.accessrecord.SearchAccessRecord;
import com.opnext.oservice.domain.accessrecord.SearchAccessRecordOa;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @author tianzc
 */
public interface AccessRecordService {

    /**
     * 获取识别记录列表
     * @param pageable
     * @param searchAccessRecord
     * @return
     * @throws Exception
     */
    Page getPage(Pageable pageable, SearchAccessRecord searchAccessRecord) throws Exception;

    /**
     * 获取识别记录列表
     * @param pageable
     * @param searchAccessRecord
     * @return
     * @throws Exception
     */
    Page getPageOfCollection(Pageable pageable, SearchAccessRecord searchAccessRecord, OserviceOperator oserviceOperator,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 获取识别记录列表
     * @param pageable
     * @param searchAccessRecordOa
     * @return
     * @throws Exception
     */
    Page getPageOaOfCollection(Pageable pageable, SearchAccessRecordOa searchAccessRecordOa, OserviceOperator oserviceOperator, RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 获取识别记录列表
     * @param id
     * @return
     * @throws Exception
     */
    AccessRecordInfo getOne(String id) throws Exception;

    /**
     * 获取识别记录列表
     * @param id
     * @return
     * @throws Exception
     */
    AccessRecordInfo getOneOfCollection(String id, Long tenantId,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 保存识别记录
     * @param accessRecord
     * @param oserviceDevApiOperator
     * @return
     */
    CommonResponse save(AccessRecordInfo accessRecord, OserviceDevApiOperator oserviceDevApiOperator) throws Exception;

    CommonResponse batchSave(List<AccessRecordInfo> accessRecordInfoList, OserviceDevApiOperator oserviceDevApiOperator) throws Exception;

    /**
     * 根据租户分集合存储
     * @param accessRecordInfoList
     * @param oserviceDevApiOperator
     * @return
     * @throws Exception
     */
    CommonResponse batchSaveOfcollection(List<AccessRecordInfo> accessRecordInfoList, OserviceDevApiOperator oserviceDevApiOperator, RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 删除人员id
     * @param ids
     * @return
     */
    CommonResponse delete(String[] ids);

    /**
     * 删除人员id
     * @param ids
     * @return
     */
    CommonResponse deleteOfCollection(String[] ids, Long tenantId);
}
