package com.opnext.oservice.dto.authority.role;

import com.opnext.oservice.domain.authority.role.Resource;
import lombok.Data;

/**
 * @author wanglu
 */
@Data
public class ResourceDTO {
    private Integer resourceId;
    private String resourceName;
    private Resource.Method method;
    private Integer moduleId;
    private String moduleName;
}
