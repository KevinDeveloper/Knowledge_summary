package com.opnext.oservice.controller.device;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.validator.IsObjectEmptyValidator;
import com.opnext.domain.config.OConfigGroup;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.device.DeviceAdminIdRel;
import com.opnext.oservice.domain.device.DeviceStatus;
import com.opnext.oservice.domain.device.DeviceSync;
import com.opnext.oservice.domain.device.DeviceType;
import com.opnext.oservice.domain.device.SearchDevice;
import com.opnext.oservice.repository.device.DeviceRepository;
import com.opnext.oservice.service.base.BaseRedisService;
import com.opnext.oservice.service.device.DeviceAdminService;
import com.opnext.oservice.service.device.DeviceService;
import com.opnext.oservice.validator.IsSizeRangeValidator;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;
import java.util.Set;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author tianzc
 */
@Slf4j
@RestController
@RequestMapping("/api/device")
public class DeviceController {

    @Autowired
    DeviceService deviceService;
    @Autowired
    DeviceAdminService adminService;
    @Autowired
    DeviceRepository deviceRepository;
    @Autowired
    BaseRedisService redisService;

    @ApiOperation(value = "设备类型", notes = "获取设备类型")
    @RequestMapping(value = "/type", method = RequestMethod.GET)
    public CommonResponse deviceTypeList() throws Exception{
        return CommonResponse.ok(DeviceType.values());
    }

    @ApiOperation(value = "设备状态", notes = "获取设备状态")
    @RequestMapping(value = "/status", method = RequestMethod.GET)
    public CommonResponse deviceStatusList() throws Exception{
        return CommonResponse.ok(DeviceStatus.values());
    }

    @ApiOperation(value = "设备列表", notes = "/api/device")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "type", value = "设备类型枚举String"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "status", value = "设备状态枚举String"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=version,updateTime,asc&sort=name,desc")
    })
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    public CommonResponse page(@PageableDefault Pageable pageable, SearchDevice sDevice) throws Exception{
        log.info("获取设备列表参数：{}", sDevice);
        Page page =  deviceService.getDevicePage(pageable, sDevice);
        return CommonResponse.ok(page);
    }

    @ApiOperation(value = "获取已关联设备组或未关联设别组设备列表", notes = "获取设备列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "groupId", value = "设备组id")
    })
    @RequestMapping(value = "/list/group", method = RequestMethod.GET)
    public CommonResponse listByGroupFlag(Integer groupId) throws Exception{
        List list =  deviceService.listByGroupFlag(groupId);
        return CommonResponse.ok(list);
    }

    /**
     * 远程设备单次开门
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "设备单次开门", notes = "")
    @RequestMapping(value = "/door/{sn}/_open", method = RequestMethod.POST)
    public CommonResponse doorSingleOpen(@PathVariable String sn) throws Exception {
        if (StringUtils.isBlank(sn)) {
            throw new CommonException("string.notEmpty");
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        return deviceService.doorSingleOpen(sn, oserviceOperator);
    }

    /**
     * 远程设备重启
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "设备重启", notes = "")
    @RequestMapping(value = "/_reboot", method = RequestMethod.POST)
    public CommonResponse rebootDevice(@RequestBody Set<String> snSet) throws Exception {
        if (CollectionUtils.isEmpty(snSet)) {
            throw new CommonException("string.notEmpty");
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        return deviceService.rebootDevice(snSet, oserviceOperator);
    }

    /**
     * 远程设备常开
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "设备常开", notes = "")
    @RequestMapping(value = "/door/open-always", method = RequestMethod.GET)
    public CommonResponse doorOpenAlways(@RequestBody Set<String> snSet) throws Exception {
        if (CollectionUtils.isEmpty(snSet)) {
            throw new CommonException("string.notEmpty");
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        return deviceService.doorOpenAlways(snSet, oserviceOperator);
    }

    /**
     * 远程设备常开取消
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "设备常开取消", notes = "")
    @RequestMapping(value = "/door/open-cancel", method = RequestMethod.POST)
    public CommonResponse doorOpenCancel(@RequestBody Set<String> snSet) throws Exception {
        if (CollectionUtils.isEmpty(snSet)) {
            throw new CommonException("string.notEmpty");
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        return deviceService.doorOpenCancel(snSet, oserviceOperator);
    }

    /**
     * 获取设备激活码
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "获取设备激活码", notes = "")
    @RequestMapping(value = "/active-code", method = RequestMethod.GET)
    public CommonResponse getActiveCode() throws Exception {
        return CommonResponse.ok(deviceService.getActiveCode());
    }

    /**
     * 设备激活码刷新
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "更新设备激活码", notes = "根据id更新设备激活码")
    @RequestMapping(value = "/active-code/{id}", method = RequestMethod.POST)
    public CommonResponse refreshActiveCode(@PathVariable Integer id) throws Exception {
        return CommonResponse.ok(deviceService.refreshActiveCode(id));
    }

    /**
     * 解绑设备管理员
     * 下发指令，终端更新管理员
     *
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "解绑设备管理员", notes = "解绑设备管理员，下发指令，终端更新管理员")
    @RequestMapping(value = "/adminrel/delete", method = RequestMethod.POST)
    public void deleteDeviceAdmin(@RequestBody Integer[] deviceIds) throws Exception {
        adminService.deleteDeviceAdmin(deviceIds, null);
    }
    /**
     * 关联设备管理员
     * 下发指令，终端更新管理员
     *
     * @param idRel
     * @return
     * @throws Exception
     */
    @ApiIgnore
    @ApiOperation(value = "关联设备管理员", notes = "")
    @RequestMapping(value = "/adminrel/bind", method = RequestMethod.POST)
    public void bindDeviceAdmin(@RequestBody DeviceAdminIdRel idRel) throws Exception {
        log.info("关联数据：{}", idRel);
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(idRel.getDeviceIds(), new IsObjectEmptyValidator<>("deviceIds"))
                .on(idRel.getAdminIds(), new IsObjectEmptyValidator<>("adminIds"))
                .on(idRel.getAdminIds().length, new IsSizeRangeValidator("adminIds", 0,10))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("关联设备管理员参数异常{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        deviceService.bindDeviceAdmin(idRel.getDeviceIds(), idRel.getAdminIds());
    }

    /**
     *
     * @param deviceIds
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "移除设备组", notes = "")
    @RequestMapping(value = "/grouprel/delete", method = RequestMethod.POST)
    public void deleteDeviceGroup(@RequestBody Integer[] deviceIds) throws Exception {
        deviceService.deleteDeviceGroup(deviceIds);
    }

    /**
     *
     * @param sn
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "获取设备设置", notes = "")
    @RequestMapping(value = "/devconfig/{sn}", method = RequestMethod.GET)
    public CommonResponse getDeviceConfig(@PathVariable String sn) throws Exception {
        OConfigGroup jsonObject = deviceService.getDeviceConfig(sn);
        return CommonResponse.ok(jsonObject);
    }

    /**
     *
     * @param sn
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "根据sn更新设置", notes = "待完善tianzc")
    @RequestMapping(value = "/devconfig/{sn}", method = RequestMethod.POST)
    public void updateDeviceConfig(@PathVariable String sn, @RequestBody DeviceSync deviceSync) throws Exception {
        log.info("根据sn更新设置sn：{}", sn);
        log.debug("提交数据：{}", deviceSync);
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(deviceSync.getObjConfig(), new IsObjectEmptyValidator<>("oConfigGroup"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("设备配置参数异常{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        deviceService.updateDeviceConfig(sn,deviceSync);
    }
}
