package com.opnext.oservice.domain.person;

import lombok.Data;

import java.util.List;

/**
 * @author tianzc
 */
@Data
public class PropertyRequest {
    List<PersonConfig> configs;
    Integer[] ids;
}
