package com.opnext.oservice.service.rule;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.domain.rule.Rule;
import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Map;

/**
 * @Author: lixiuwen
 * @Date: 2018/7/2 19:01
 */
public interface RuleDeviceService {

    /**
     * 删除规则中设备
     *
     * @param deviceSnList     设备Sn集合
     * @param ruleId           规则ID
     * @param oserviceOperator 当前登录人信息
     * @throws Exception
     */
    void delDeviceFromRule(List<String> deviceSnList, Integer ruleId, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 向规则中添加设备
     *
     * @param deviceSnList     设备Sn集合
     * @param rule             规则
     * @param oserviceOperator 当前登录人信息
     * @throws Exception
     */
    void addDeviceToRule(List<String> deviceSnList, Rule rule, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 向设备发送删除规则指令
     *
     * @param deviceSnList     设备Sn集合
     * @param delRuleIdList    规则ID集合
     * @param oserviceOperator 当前登录人信息
     */
    void sendDelRuleToDevice(List<String> deviceSnList, List<Integer> delRuleIdList, OserviceOperator oserviceOperator);

    /**
     * 向设备发送获取规则指令
     *
     * @param deviceSnList     设备ID集合
     * @param domainRule       规则信息
     * @param oserviceOperator 当前登录人信息
     */
    void sendGetRuleToDevice(List<String> deviceSnList, com.opnext.domain.access.Rule domainRule, OserviceOperator oserviceOperator);

    /**
     * 根据规则ID获取绑定的SN号集合
     *
     * @param ruleId 规则ID
     * @return
     */
    List<String> getSnsByRuleId(int ruleId);

    /**
     * 获取规则集合下设备的数量
     *
     * @param ruleIdList 规则集合
     * @return
     */
    Map<Integer, Long> getDeviceCountMap(List<Integer> ruleIdList);

    /**
     * 获取规则下绑定的所有设备ID
     *
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return
     */
    List<Integer> getDeviceIdByRuleId(int ruleId, long tenantId);

    /**
     * 获取规则绑定的设备
     *
     * @param predicate 查询条件
     * @param pageable  分页信息
     * @return
     */
    Page<Device> getDevice(Predicate predicate, Pageable pageable);

    /**
     * 删除设备时调用此接口
     *
     * @param deviceSnList 设备SN集合
     * @param tenantId     租户ID
     */
    void whenDelDevice(List<String> deviceSnList, long tenantId);

    /**
     * 根据SN号集合获取设备组ID集合
     *
     * @param sns      设备SN号集合
     * @param tenantId 租户ID
     * @return 设备所属设备组ID集合
     */
    List<Integer> getGroupIdsBySns(List<String> sns, long tenantId);
}
