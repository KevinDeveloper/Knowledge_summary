package com.opnext.oservice.feign;

import com.opnext.oservice.conf.SpringMultipartEncoder2;
import com.opnext.oservice.feign.impl.AlgorithmRestHystrixFallBackFactory;
import com.opnexts.algo.core.domain.response.DetectResponse;
import com.opnexts.algo.core.domain.response.QualityResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * @author tianzc
 */
@FeignClient(value = "o-algorithm", path = "/api/algorithm",fallbackFactory = AlgorithmRestHystrixFallBackFactory.class, configuration = SpringMultipartEncoder2.class)
public interface AlgorithmRestClient {

    /**
     * 单人脸检测 接口
     *
     * @param faceImages      人脸图片
     * @return                人脸信息
     * @throws IOException    IO 异常
     */
    @PostMapping(value = "detect", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    List<DetectResponse> detect(@RequestPart("faceImages") MultipartFile[] faceImages) throws IOException;

    /**
     * 单人脸质量检测 接口
     *
     * @param faceImages      人脸图片
     * @return                人脸信息
     * @throws IOException    IO 异常
     */
    @PostMapping(value = "quality", consumes = MediaType.MULTIPART_FORM_DATA_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    List<QualityResponse> quality(@RequestPart("faceImages") MultipartFile[] faceImages) throws IOException;
}