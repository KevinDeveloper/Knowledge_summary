package com.opnext.oservice.service;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboximage.OperateImageV2;
import com.opnext.bboximage.util.IOUtils;
import com.opnext.bboximage.util.ImageBase64;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.MultipartFileImpl;
import com.opnext.oservice.conf.Constant;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.domain.MultipartFileResp;
import com.opnext.oservice.feign.AlgorithmRestClient;
import com.opnext.oservice.service.fastdfs.FastTmpFileManagerService;
import com.opnext.oservice.util.DateUtil;
import com.opnext.oservice.util.UUIDUtil;
import com.opnexts.algo.core.domain.QualityResult;
import com.opnexts.algo.core.domain.Rect;
import com.opnexts.algo.core.domain.response.DetectResponse;
import com.opnexts.algo.core.domain.response.QualityResponse;
import com.opnexts.algo.core.exception.FaceImageException;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.http.entity.ContentType;
import org.springframework.boot.ApplicationHome;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * @author tianzc
 */
@Slf4j
@Component
public class ImageHandlerV2 {
    /**
     * 比对算法Feign
     */
    @Resource
    private AlgorithmRestClient algorithmRestClient;
    /**
     * 异步处理
     * 清除文件
     */
    @Resource
    private AsyncService asyncService;
    /**
     * 处理上传临时文件
     */
    @Resource
    private FastTmpFileManagerService fastTmpFileManagerService;
    @Resource
    private OperateImageV2 operateImageV2;

    /**
     * 根据spring-multipartFile上传文件
     * @param multipartFileList
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    public List<MultipartFileResp> checkAndCutAndUploadImage(List<MultipartFile> multipartFileList, OserviceOperator oserviceOperator) throws Exception {
        List<MultipartFileResp> respList = new ArrayList<>();
        // 待检测合格人物正面照集合
        List<MultipartFile> faceImageList = new ArrayList<>();
        multipartFileList.forEach(multipartFile -> {
            try {
                // 文件格式校验
                checkFormat(multipartFile);
                faceImageList.add(multipartFile);
            } catch (CommonException e) {
                MultipartFileResp fileResp = MultipartFileResp.builder().flag(false).fileName(multipartFile.getOriginalFilename()).message(e.getMessage()).build();
                respList.add(fileResp);
            }
        });
        // 校验待检测人物正面照集合不为空
        if (CollectionUtils.isNotEmpty(faceImageList)) {
            MultipartFile[] faceImages = faceImageList.toArray(new MultipartFile[faceImageList.size()]);
            // 根据是否进行质量检测调用相应接口
            // 文件检测，裁剪，上传文件服务器，返回文件id
            List<MultipartFileResp> algoResp = new ArrayList<>();
            if (GlobleConfig.AlgorithmConfig.qualityDetect) {
                algoResp = qualityImageAlgorithm(faceImages,oserviceOperator);
            } else {
                algoResp = detectImageAlgorithm(faceImages,oserviceOperator);
            }
            respList.addAll(algoResp);
        }
        return respList;
    }

    /**
     *
     * @param fileList
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    public List<MultipartFileResp> checkAndCutAndUploadImageForList(List<File> fileList, OserviceOperator oserviceOperator) throws Exception {
        List<MultipartFileResp> respList = new ArrayList<>();
        // 待检测合格人物正面照集合
        List<MultipartFile> faceImageList = new ArrayList<>();
        fileList.forEach(file -> {
            try {
                // 文件格式校验
                checkFormat(file);
                try {
                    FileInputStream fileInputStream = new FileInputStream(file);
                    MultipartFile multipartFile = new MultipartFileImpl(file.getName(), file.getName(),
                            ContentType.APPLICATION_OCTET_STREAM.toString(), fileInputStream);
                    faceImageList.add(multipartFile);
                } catch (Exception e) {
                    log.error("File转MultipartFile异常", e);
                    MultipartFileResp fileResp = MultipartFileResp.builder().flag(false).fileName(file.getName()).message("imageFile.exception").build();
                    respList.add(fileResp);
                }
            } catch (CommonException e) {
                MultipartFileResp fileResp = MultipartFileResp.builder().flag(false).fileName(file.getName()).message(e.getMessage()).build();
                respList.add(fileResp);
            }
        });
        if (CollectionUtils.isNotEmpty(faceImageList)) {
            MultipartFile[] faceImages = faceImageList.toArray(new MultipartFile[faceImageList.size()]);
            // 根据是否进行质量检测调用相应接口
            // 文件检测，裁剪，上传文件服务器，返回文件id
            List<MultipartFileResp> algoResp = new ArrayList<>();
            if (GlobleConfig.AlgorithmConfig.qualityDetect) {
                algoResp = qualityImageAlgorithm(faceImages,oserviceOperator);
            } else {
                algoResp = detectImageAlgorithm(faceImages,oserviceOperator);
            }
            respList.addAll(algoResp);
        }
        return respList;
    }


    /**
     * 使用SDK上传文件到文件服务器
     * @param imgData
     * @return
     * @throws Exception
     */
    public String uploadImageSDK(byte[] imgData,String fileName, OserviceOperator oserviceOperator) throws Exception {
        String imgFilePath = null;
        try{
            String dateStr = DateUtil.parseDateToStr(new Date(), "yyyy-MM-dd");
            ApplicationHome home = new ApplicationHome(getClass());
            String path = home.getDir().getAbsolutePath() + File.separator + "imgFiles" + File.separator +dateStr;
            imgFilePath = ImageBase64.generateImage(imgData, UUIDUtil.uuid(), "jpg", path);
            Optional<String> optional = fastTmpFileManagerService.uploadFileWithOriginalName(new File(imgFilePath),fileName, oserviceOperator);
            if (optional.isPresent()) {
                return optional.get();
            } else {
                log.error("==使用SDK上传文件异常fid：null");
                throw new CommonException("imageFile.upload.exception");
            }
        } catch (Exception e) {
            log.error("==使用SDK上传文件异常：{}", e);
            throw new CommonException("imageFile.upload.exception");
        } finally {
            asyncService.clearImgEmptyFile(imgFilePath);
        }
    }

    public void cropImage(OserviceOperator oserviceOperator, MultipartFile multipartFile,MultipartFileResp fileResp, Rect rectFace) {
        try {
            InputStream inputStream = multipartFile.getInputStream();
            String imgBase64 = ImageBase64.getImageBase64Str(inputStream);
            // 关闭输入流
            IOUtils.closeQuietly(inputStream);
            Optional<byte[]> optionalBytes = operateImageV2.cropImage(imgBase64, rectFace);
            if (optionalBytes.isPresent()) {
                try {
                    String fId = uploadImageSDK(optionalBytes.get(), multipartFile.getOriginalFilename(), oserviceOperator);
                    String url = Constant.FASTDFS_SERVER_DOWNLOAD_URI + "/" + fId;
                    fileResp.setFlag(true);
                    fileResp.setUrl(url);
                } catch (Exception e) {
                    if (e instanceof CommonException) {
                        fileResp.setMessage(e.getMessage());
                    } else {
                        fileResp.setMessage("imageFile.upload.exception");
                        log.error("SDK文件上传异常", e);
                    }
                }
            } else {
                fileResp.setMessage("imageFile.cut.exception");
            }
        } catch (Exception e) {
            fileResp.setMessage("imageFile.cut.exception");
            log.error("图片裁剪异常", e);
        }
    }

    public void cropImage(OserviceOperator oserviceOperator, File file, MultipartFileResp fileResp, Rect rectFace) {
        try {
            String imgBase64 = ImageBase64.getImageBase64Str(file);
            Optional<byte[]> optionalBytes = operateImageV2.cropImage(imgBase64, rectFace);
            if (optionalBytes.isPresent()) {
                try {
                    String fId  = uploadImageSDK(optionalBytes.get(), file.getName(), oserviceOperator);
                    String url = Constant.FASTDFS_SERVER_DOWNLOAD_URI + "/" + fId;
                    fileResp.setFlag(true);
                    fileResp.setUrl(url);
                } catch (Exception e) {
                    if (e instanceof CommonException) {
                        fileResp.setMessage(e.getMessage());
                    } else {
                        fileResp.setMessage("imageFile.upload.exception");
                        log.error("SDK文件上传异常", e);
                    }
                }
            } else {
                fileResp.setMessage("imageFile.cut.exception");
            }
        } catch (Exception e) {
            fileResp.setMessage("imageFile.cut.exception");
            log.error("图片裁剪异常", e);
        }
    }

    public List<MultipartFileResp> detectImageAlgorithm(List<File> faceImageList,OserviceOperator oserviceOperator) throws Exception {
            // 待完善
            List<DetectResponse> detectResponseList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(detectResponseList)) {
            List<MultipartFileResp> multipartFileResps = new ArrayList<>();
            for (int i = 0; i < detectResponseList.size(); i++) {
                DetectResponse detectResponse = detectResponseList.get(i);
                File faceImage = faceImageList.get(i);
                MultipartFileResp fileResp = MultipartFileResp.builder().flag(false).fileName(faceImage.getName()).build();
                if (detectResponse.isHasFace()) {
                    if (Objects.nonNull(detectResponse.getFaceDetect())) {
                        if (detectResponse.getFaceDetect().getDetectFaceCount() > 1) {
                            fileResp.setMessage("algorithm.exception.more.face");
                        } else {
                            cropImage(oserviceOperator,faceImage,fileResp, detectResponse.getFaceDetect().getDetectResult().getRectFace());
                        }
                    } else {
                        fileResp.setMessage("algorithm.exception");
                    }
                } else {
                    // 算法错误类型校验
                    algorithmExceptionType(fileResp,detectResponse.getError());
                }
                multipartFileResps.add(fileResp);
            }
            return multipartFileResps;
        } else {
            throw new CommonException("algorithm.exception");
        }
    }

    /**
     * 人物正面照算法质量检测
     * @param faceImageList
     * @throws Exception
     */
    public List<MultipartFileResp> qualityImageAlgorithm(List<File> faceImageList,OserviceOperator oserviceOperator) throws Exception {
        // 待完善
        List<QualityResponse> qualityResponseList = new ArrayList<>();
        if (CollectionUtils.isNotEmpty(qualityResponseList)) {
            List<MultipartFileResp> fileRespList = new ArrayList<>();
            for (int i = 0; i < qualityResponseList.size(); i++) {
                QualityResponse qualityResponse = qualityResponseList.get(i);
                File faceImage = faceImageList.get(i);
                MultipartFileResp fileResp = MultipartFileResp.builder().flag(false).fileName(faceImage.getName()).build();
                if (qualityResponse.isHasFace()) {
                    if (Objects.nonNull(qualityResponse.getFaceQuality())) {
                        if (qualityResponse.getFaceQuality().getDetectFaceCount() > 1) {
                            fileResp.setMessage("algorithm.exception.more.face");
                        } else {
                            boolean flag = false;
                            try {
                                // 校验图片质量信息
                                checkQuality(qualityResponse.getFaceQuality().getQualityResult());
                                flag = true;
                            } catch (CommonException e) {
                                fileResp.setMessage(e.getMessage());
                            } catch (Exception e) {
                                log.error("图片质量校验异常", e);
                                fileResp.setMessage("algorithm.exception");
                            }
                            if (flag) {
                                cropImage(oserviceOperator, faceImage, fileResp, qualityResponse.getFaceQuality().getDetectResult().getRectFace());
                            }
                        }
                    } else {
                        fileResp.setMessage("algorithm.exception");
                    }
                } else {
                    algorithmExceptionType(fileResp,qualityResponse.getError());
                }
                fileRespList.add(fileResp);
            }
            return fileRespList;
        } else {
            throw new CommonException("algorithm.exception");
        }
    }


    /**
     * 人物正面照算法检测
     * 待完善，暂不支持多张照片
     * @param faceImages
     * @throws Exception
     */
    public List<MultipartFileResp> detectImageAlgorithm(MultipartFile[] faceImages,OserviceOperator oserviceOperator) throws Exception {
        List<DetectResponse> detectResponseList = algorithmRestClient.detect(faceImages);
        if (CollectionUtils.isNotEmpty(detectResponseList)) {
            List<MultipartFileResp> multipartFileResps = new ArrayList<>();
            for (int i = 0; i < detectResponseList.size(); i++) {
                DetectResponse detectResponse = detectResponseList.get(i);
                MultipartFile faceImage = faceImages[i];
                MultipartFileResp fileResp = MultipartFileResp.builder().flag(false).fileName(faceImage.getOriginalFilename()).build();
                if (detectResponse.isHasFace()) {
                    if (Objects.nonNull(detectResponse.getFaceDetect())) {
                        if (detectResponse.getFaceDetect().getDetectFaceCount() > 1) {
                            fileResp.setMessage("algorithm.exception.more.face");
                        } else {
                            cropImage(oserviceOperator,faceImage,fileResp, detectResponse.getFaceDetect().getDetectResult().getRectFace());
                        }
                    } else {
                        fileResp.setMessage("algorithm.exception");
                    }
                } else {
                    // 算法错误类型校验
                    algorithmExceptionType(fileResp,detectResponse.getError());
                }
                multipartFileResps.add(fileResp);
            }
            return multipartFileResps;
        } else {
            throw new CommonException("algorithm.exception");
        }
    }

    /**
     * 人物正面照算法质量检测
     * @param faceImages
     * @throws Exception
     */
    public List<MultipartFileResp> qualityImageAlgorithm(MultipartFile[] faceImages,OserviceOperator oserviceOperator) throws Exception {
        List<QualityResponse> qualityResponseList = algorithmRestClient.quality(faceImages);
        if (CollectionUtils.isNotEmpty(qualityResponseList)) {
            List<MultipartFileResp> fileRespList = new ArrayList<>();
            for (int i = 0; i < qualityResponseList.size(); i++) {
                QualityResponse qualityResponse = qualityResponseList.get(i);
                MultipartFile faceImage = faceImages[i];
                MultipartFileResp fileResp = MultipartFileResp.builder().flag(false).fileName(faceImage.getOriginalFilename()).build();
                if (qualityResponse.isHasFace()) {
                    if (Objects.nonNull(qualityResponse.getFaceQuality())) {
                        if (qualityResponse.getFaceQuality().getDetectFaceCount() > 1) {
                            fileResp.setMessage("algorithm.exception.more.face");
                        } else {
                            boolean flag = false;
                            try {
                                // 校验图片质量信息
                                checkQuality(qualityResponse.getFaceQuality().getQualityResult());
                                flag = true;
                            } catch (CommonException e) {
                                fileResp.setMessage(e.getMessage());
                            } catch (Exception e) {
                                log.error("图片质量校验异常", e);
                                fileResp.setMessage("algorithm.exception");
                            }
                            if (flag) {
                                cropImage(oserviceOperator, faceImage, fileResp, qualityResponse.getFaceQuality().getDetectResult().getRectFace());
                            }
                        }
                    } else {
                        fileResp.setMessage("algorithm.exception");
                    }
                } else {
                    algorithmExceptionType(fileResp,qualityResponse.getError());
                }
                fileRespList.add(fileResp);
            }
            return fileRespList;
        } else {
            throw new CommonException("algorithm.exception");
        }
    }
    /**
     * 处理算法返回错误类型
     * @param fileResp
     * @param exType
     */
    public void algorithmExceptionType(MultipartFileResp fileResp, FaceImageException.Type exType) {
        fileResp.setFlag(false);
        // 算法异常
        if (FaceImageException.Type.ALGO_EXCEPTION.equals(exType)) {
            fileResp.setMessage("algorithm.exception");
        } else if (FaceImageException.Type.NO_IMAGE_RECT.equals(exType)) {
            fileResp.setMessage("algorithm.exception.no.image.rect");
        } else if (FaceImageException.Type.NO_FACE.equals(exType)) {
            fileResp.setMessage("algorithm.exception.not.face");
        } else {
            fileResp.setMessage("algorithm.exception");
        }
    }
    /**
     * 算法校验
     * @param quality
     * @throws Exception
     */
    public void checkQuality(QualityResult quality) throws Exception {
        if (Objects.isNull(quality)) {
            throw new CommonException("algorithm.exception");
        }
        log.info("==图片质量检测quality：{}", quality);
        // 标识清晰程度校验
        if (GlobleConfig.AlgorithmConfig.qualityClear) {
            if (quality.getClearLevel() > GlobleConfig.AlgorithmQuality.clearLevel) {
                log.info("==图片质量检测-人脸模糊");
                throw new CommonException("algorithm.quality.clearLevel");
            }
        }
        if (GlobleConfig.AlgorithmConfig.qualityVisible) {
            // 标识遮挡
            if (quality.getVisLevel() > GlobleConfig.AlgorithmQuality.visLevel) {
                log.info("==图片质量检测-人脸遮挡");
                throw new CommonException("algorithm.quality.visLevel");
            }
        }
        // 标识眼镜
        if (GlobleConfig.AlgorithmConfig.qualityGlass) {
            if (quality.getGlassLevel() > GlobleConfig.AlgorithmQuality.glassLevel) {
                log.info("==图片质量检测-人脸戴墨镜");
                throw new CommonException("algorithm.quality.glassLevel");
            }
        }
        // 判断是否进行人脸角度检验
        if (GlobleConfig.AlgorithmConfig.qualityAngle) {
            float[] angle = quality.getAngle();
            // 照片检验角度
            if (angle[2] > angle[0] && angle[2] > angle[1]) {
                log.info("图片质量检测-人脸左右旋转的概率过大");
                throw new CommonException("algorithm.quality.yaw");
            } else if (angle[1] > angle[0] && angle[1] > angle[2]) {
                log.info("图片质量检测-人脸上下旋转的概率过大");
                throw new CommonException("algorithm.quality.pitch");
            } else {
                log.debug("人脸角度检测正常");
            }
        }
    }

    /**
     * 校验图片格式，大小，像素
     * 仅支持照片上传，jpg、png、bmp格式，照片尺寸不低于320*320px，照片最大为10MB
     * @param multipartFile
     * @throws Exception
     */
    public void checkFormat(MultipartFile multipartFile) throws CommonException {
        try {
            boolean flag = operateImageV2.checkFormatMultipartFile(multipartFile);
            if (!flag) {
                throw new CommonException("imageFile.check.format");
            }
            // 校验图片大小
            flag = operateImageV2.checkSizeMultipartFile(multipartFile);
            if (!flag) {
                throw new CommonException("imageFile.check.max.size");
            }
            // 校验图片像素
            flag = operateImageV2.checkImagePixelMultipartFile(multipartFile);
            if (!flag) {
                throw new CommonException("imageFile.check.min.pixel");
            }
        } catch (Exception e) {
            log.error("图片格式校验异常", e);
            throw new CommonException("imageFile.exception");
        }
    }

    /**
     * 校验图片格式，大小，像素
     * 仅支持照片上传，jpg、png、bmp格式，照片尺寸不低于320*320px，照片最大为10MB
     * @param imgFile
     * @throws Exception
     */
    public void checkFormat(File imgFile) throws CommonException{
        try {
            boolean flag = operateImageV2.checkFormatFile(imgFile);
            if (!flag) {
                throw new CommonException("imageFile.check.format");
            }
            // 校验图片大小
            flag = operateImageV2.checkSizeFile(imgFile);
            if (!flag) {
                throw new CommonException("imageFile.check.max.size");
            }
            // 校验图片像素
            flag = operateImageV2.checkImagePixelFile(imgFile);
            if (!flag) {
                throw new CommonException("imageFile.check.min.pixel");
            }
        } catch (Exception e) {
            log.error("图片格式校验异常", e);
            throw new CommonException("imageFile.exception");
        }
    }
}
