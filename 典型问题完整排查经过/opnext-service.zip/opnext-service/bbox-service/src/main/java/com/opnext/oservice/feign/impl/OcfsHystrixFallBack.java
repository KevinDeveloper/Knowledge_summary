package com.opnext.oservice.feign.impl;

import com.opnext.oservice.domain.fastdfs.FastdfsUploadResp;
import com.opnext.oservice.feign.OcfsFeign;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

/**
 * @author tianzc
 */
@Slf4j
@Service
public class OcfsHystrixFallBack implements OcfsFeign {

    /**
     * 上传文件，返回文件地址
     *
     * @param file
     * @return
     */
    @Override
    public FastdfsUploadResp upload(MultipartFile file) {
        return null;
    }
}
