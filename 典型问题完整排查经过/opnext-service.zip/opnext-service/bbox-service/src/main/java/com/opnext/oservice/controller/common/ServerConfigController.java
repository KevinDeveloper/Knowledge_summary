package com.opnext.oservice.controller.common;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.validator.IsEmptyValidator;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.ServerConfig;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.service.ServerConfigService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author tianzc
 */
@Slf4j
@RestController
@RequestMapping("/api/serverConfig")
public class ServerConfigController {
    @Autowired
    ServerConfigService serverConfigService;

    @ApiOperation(value = "获取人员密码", notes = "")
    @RequestMapping(value = "/getPersonPwd", method = RequestMethod.GET)
    public ServerConfig getPersonPwdConfig() throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        return serverConfigService.getPersonPwdConfig(oserviceOperator.getTenantId());
    }

    @ApiOperation(value = "配置更新", notes = "")
    @RequestMapping(value = "/update/{id}", method = RequestMethod.POST)
    public void update(@RequestBody ServerConfig serverConfig, @PathVariable Integer id) throws Exception {
        log.info("更新参数:{}", serverConfig);
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(serverConfig.getConfigValue(), new IsEmptyValidator("configValue"))
                .on(serverConfig.getConfigValue(), new IsStringWithinLengthRangeValidator("configValue", 1, 256))
                .doValidate().result(toComplex());
        if (!ret.isSuccess()) {
            log.error("更新配置参数异常{}", ret);
            throw new CommonException(400, "parameter.incorrect", ret);
        }
        serverConfig.setId(id);
        serverConfigService.update(serverConfig);
    }
}
