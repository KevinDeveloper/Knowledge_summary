package com.opnext.oservice.util;

import com.opnext.domain.ResourceType;
import opnext.server.support.util.UrlUtil;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * @ClassName: FileUrlPathHandle
 * @Description: 文件 url地址处理
 * @Author: Kevin
 * @Date: 2018/10/10 16:23
 */
public class FileUrlPathHandle {

    /**
     * 处理人员的照片地址为显示地址
     *
     * @param avatarsMap
     * @param schemeAndHost
     * @return
     */
    public static Map<ResourceType, List<String>> getShowAvatarsMap(Map<ResourceType, List<String>> avatarsMap , final String schemeAndHost) {
        if (CollectionUtils.isEmpty(avatarsMap)) {
            return avatarsMap;
        }
        Map<ResourceType, List<String>> resultMap = new HashMap<>();
        avatarsMap.forEach((k, list) -> {
            List<String> copyList = new ArrayList<>();
            if( !CollectionUtils.isEmpty(list)) {
                list.forEach(avatarPath -> {
                    Optional<String> optional = UrlUtil.getShowPath(schemeAndHost, avatarPath);
                    if (optional.isPresent()) {
                        avatarPath = optional.get();
                    }
                    copyList.add(avatarPath);
                });
            }
            resultMap.put(k, copyList);
        });
        return resultMap;
    }

    /**
     * 处理人员的照片地址为保存地址
     *
     * @param avatarsMap
     * @param schemeAndHost
     * @param isRelative
     * @return
     */
    public static Map<ResourceType, List<String>> getStoreAvatarsMap(Map<ResourceType, List<String>> avatarsMap, final String schemeAndHost, final boolean isRelative) {
        if (CollectionUtils.isEmpty(avatarsMap)) {
            return avatarsMap;
        }
        Map<ResourceType, List<String>> resultMap = new HashMap<>();
        avatarsMap.forEach((k, list) -> {
            List<String> copyList = new ArrayList<>();
            if( !CollectionUtils.isEmpty(list)) {
                list.forEach(avatarPath -> {
                    Optional<String> optional = UrlUtil.getStorePath(schemeAndHost, avatarPath, isRelative);
                    if (optional.isPresent()) {
                        avatarPath = optional.get();
                    }
                    copyList.add(avatarPath);
                });
            }
            resultMap.put(k, copyList);
        });

        return resultMap;
    }


}
