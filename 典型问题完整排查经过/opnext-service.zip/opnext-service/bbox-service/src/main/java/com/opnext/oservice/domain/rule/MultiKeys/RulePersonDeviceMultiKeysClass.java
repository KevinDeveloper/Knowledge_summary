package com.opnext.oservice.domain.rule.MultiKeys;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: lixiuwen
 * @Date: 2018/6/21 17:49
 * @Param personId
 * @Param deviceSn
 * 由这两个共同组成复合主键
 */
@Data
public class RulePersonDeviceMultiKeysClass implements Serializable {

    /**
     * 应用于人员ID
     */
    private String personId;

    /**
     * 设备Sn
     */
    private String deviceSn;

    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((personId == null) ? 0 : personId.hashCode());
        result = PRIME * result + ((deviceSn == null) ? 0 : deviceSn.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }

        final RulePersonDeviceMultiKeysClass other = (RulePersonDeviceMultiKeysClass) obj;
        if (personId == null) {
            if (other.personId != null) {
                return false;
            }
        } else if (!personId.equals(other.personId)) {
            return false;
        }
        if (deviceSn == null) {
            if (other.deviceSn != null) {
                return false;
            }
        } else if (!deviceSn.equals(other.deviceSn)) {
            return false;
        }

        return true;
    }
}
