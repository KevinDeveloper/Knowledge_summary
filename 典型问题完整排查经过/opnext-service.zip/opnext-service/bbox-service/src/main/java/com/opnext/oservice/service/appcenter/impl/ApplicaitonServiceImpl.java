package com.opnext.oservice.service.appcenter.impl;

import com.opnext.oservice.domain.appcenter.Application;
import com.opnext.oservice.repository.appcenter.ApplicationRepositry;
import com.opnext.oservice.service.appcenter.ApplicationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author wanglu
 */
@Service
public class ApplicaitonServiceImpl implements ApplicationService {
    @Autowired
    ApplicationRepositry applicationRepositry;

    @Override
    public List<Application> getApplications(long tenantId) {
        return applicationRepositry.getAllByTenantId(tenantId);
    }

    @Override
    public void saveApplication(Application application) {
        applicationRepositry.save(application);
    }

    @Override
    public void modifyApplication(Application application) {
        applicationRepositry.save(application);
    }

    @Override
    public Application getApplicationById(int id, long tenantId) {
        Application application =applicationRepositry.getApplicationByIdAndTenantId(id,tenantId);
        return application;
    }

    @Override
    public List<Application> getApplicationsByAppId(String appId, long tenantId) {
        return applicationRepositry.getApplicationsByAppIdAndTenantId(appId,tenantId);
    }

}
