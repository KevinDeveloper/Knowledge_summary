package com.opnext.oservice.controller.authority;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.google.common.base.Splitter;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.RedisCommonKeyUtil;
import com.opnext.bboxsupport.validator.*;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.account.Account;
import com.opnext.oservice.domain.authority.role.*;
import com.opnext.oservice.dto.account.AccountDTO;
import com.opnext.oservice.dto.authority.AuthorityDTO;
import com.opnext.oservice.service.account.AccountService;
import com.opnext.oservice.service.authority.AdminService;
import com.opnext.oservice.service.base.BaseRedisService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;
import java.util.stream.Collectors;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author wanglu
 */
@Slf4j
@RestController
@RequestMapping("/api/authority")
public class AuthorizationController {
    public static final String NO_ROLE = "-1";
    @Autowired
    private AccountService accountService;
    @Autowired
    private BaseRedisService redisService;
    @Autowired
    private AdminService adminService;

    @ApiOperation(value = "查询管理员列表", notes = "如通过邮箱获取管理员；通过登陆账号获取管理员列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "loginName", value = "登录名"),
            @ApiImplicitParam(paramType = "query", dataType = "long", name = "role", value = "角色"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "status", value = "状态"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=xxx,desc表示根据xxx字段倒叙排序")
    })
    @RequestMapping(value = "/",method = RequestMethod.GET)
    public Page<AuthorityDTO> getAccount(@RequestParam(required = false) String loginName,
                                          @RequestParam(required = false) Role role,
                                          @RequestParam(required = false) String status,
                                          @PageableDefault Pageable pageable) throws Exception {
        //分页查询账号列表（调用用户中心接口）
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        return adminService.getAdminPage(loginName,role,status,pageable,tenantId);
    }

    @ApiOperation(value = "创建管理员", notes = "新建管理员")
    @RequestMapping(value = "/",method = RequestMethod.POST)
    public Account addAccount(@RequestBody AccountDTO accountDTO,BindingResult bindingResult) throws Exception{
        //校验
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(accountDTO.getLoginName(), new IsEmptyValidator("loginName"))
                .on(accountDTO.getLoginName(), new IsStringWithinLengthRangeValidator("loginName",6,20))
                .on(accountDTO.getLoginName(), new IsLoginnameValidator("loginName"))
                .on(accountDTO.getEmail(), new IsEmptyValidator("email"))
                .on(accountDTO.getEmail(), new IsEmailValidator("email"))
                .on(accountDTO.getPassword(), new IsEmptyValidator("password"))
                .on(accountDTO.getPassword(), new IsStringWithinLengthRangeValidator("password",0,20))
                .on(accountDTO.getPassword(), new HasEasySpecialCharValidator("password"))
                .on(accountDTO.getPhone(), new IsStringWithinLengthRangeValidator("phone",0,20))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("新建管理员参数异常{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }

        //判断邮箱是否已经被使用
        Account account1 = Account.builder().email(accountDTO.getEmail()).build();
        List<Account> accountList = accountService.getAccountList(account1);
        if (Objects.nonNull(accountList) && !accountList.isEmpty()){
            log.error("创建账号失败,邮箱已经被占用");
            bindingResult.addError(new ObjectError("email", "tenant.email.used") );
            throw new CommonException(400, "tenant.email.used",bindingResult);
        }

        Account account2 = Account.builder().loginName(accountDTO.getLoginName()).build();
        List<Account> accountList2 = accountService.getAccountList(account2);
        if (Objects.nonNull(accountList2) && !accountList2.isEmpty()){
            log.error("创建账号失败，登陆账号已经被占用");
            bindingResult.addError(new ObjectError("loginName", "tenant.loginName.used") );
            throw new CommonException(400, "tenant.loginName.used",bindingResult);
        }

        if (StringUtils.isNotBlank(accountDTO.getPhone())) {
            Account account3 = Account.builder().phone(accountDTO.getPhone()).build();
            List<Account> accountList3 = accountService.getAccountList(account3);
            if (Objects.nonNull(accountList3) && !accountList3.isEmpty()) {
                log.error("创建账号失败，电话号码已经被占用");
                bindingResult.addError(new ObjectError("phone", "tenant.phone.used"));
                throw new CommonException(400, "tenant.phone.used", bindingResult);
            }
        }

        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        return adminService.addAdmin(accountDTO,oserviceOperator.getUserId(),oserviceOperator.getTenantId());
    }

    @ApiOperation(value = "修改管理员", notes = "修改管理员")
    @RequestMapping(value = "/{id}/",method = RequestMethod.POST)
    public void modifyAccount(@PathVariable long id, @RequestBody AccountDTO accountDTO,BindingResult bindingResult) throws Exception{
        //校验
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(id+"", new IsEmptyValidator("id"))
                .on(accountDTO.getEmail(), new IsEmptyValidator("email"))
                .on(accountDTO.getEmail(), new IsEmailValidator("email"))
                .on(accountDTO.getPassword(), new IsStringWithinLengthRangeValidator("password",0,20))
                .on(accountDTO.getPassword(), new HasEasySpecialCharValidator("password"))
                .on(accountDTO.getPhone(), new IsStringWithinLengthRangeValidator("phone",0,20))
                .doValidate()
                .result(toComplex());

        if(!ret.isSuccess()){
            log.error("修改管理员参数异常{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }

        //查询Accoount对象
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        List<Account> accountList = accountService.getAccountList(
                Account.builder()
                        .tenantId(oserviceOperator.getTenantId())
                        .id(id).build());
        if (Objects.isNull(accountList) || accountList.isEmpty()){
            log.error("在tenantId {}下没有找到对的管理员{}", oserviceOperator.getTenantId(),id);
            return;
        }
        if (accountList.get(0).getIsRoot()){
            log.error("不能修改超级管理员 {}",id);
            throw new CommonException(400,"resource.conflict");
        }

        //判断邮箱是否已经被使用
        Account account1 = Account.builder().email(accountDTO.getEmail()).build();
        List<Account> accounts1 = accountService.getAccountList(account1);
        if (Objects.nonNull(accounts1) && !accounts1.isEmpty()){
            long pid = accounts1.get(0).getId();
            if (id != pid){
                log.error("修改账号失败,邮箱已经被占用{},{}",id,accountDTO.getEmail());
                bindingResult.addError(new ObjectError("email", "tenant.email.used") );
                throw new CommonException(400, "tenant.email.used",bindingResult);
            }

        }

        Account account2 = Account.builder().loginName(accountDTO.getLoginName()).build();
        List<Account> accounts2 = accountService.getAccountList(account2);
        if (Objects.nonNull(accounts2) && !accounts2.isEmpty()){
            long pid = accounts2.get(0).getId();
            if (id != pid) {
                log.error("修改账号失败，登陆账号已经被占用{},{}",id,accountDTO.getLoginName());
                bindingResult.addError(new ObjectError("loginName", "tenant.loginName.used"));
                throw new CommonException(400, "tenant.loginName.used", bindingResult);
            }
        }

        if (StringUtils.isNotBlank(accountDTO.getPhone())) {
            Account account3 = Account.builder().phone(accountDTO.getPhone()).build();
            List<Account> accounts3 = accountService.getAccountList(account3);
            if (Objects.nonNull(accounts3) && !accounts3.isEmpty()) {
                long pid = accounts3.get(0).getId();
                if (id != pid) {
                    log.error("修改账号失败，电话号码已经被占用{},{}",id,accountDTO.getPhone());
                    bindingResult.addError(new ObjectError("phone", "tenant.phone.used"));
                    throw new CommonException(400, "tenant.phone.used", bindingResult);
                }
            }
        }

        Account account = accountList.get(0);
        account.setPassword(accountDTO.getPassword());
        account.setPhone(accountDTO.getPhone());
        account.setEmail(accountDTO.getEmail());
        accountService.modifyAccount(account);
    }

    @ApiOperation(value = "启用/停用管理员状态", notes = "修改管理员状态")
    @ApiImplicitParams({ @ApiImplicitParam(paramType = "body", dataType = "ChangeAccountStatusParam", name = "accountStatusParam", value = "ids:以逗号分割的账号id；status：0表示停用，1表示启用") })
    @RequestMapping(value = "/status",method = RequestMethod.POST)
    public void modifyAccountStatus(@RequestBody @Valid ChangeAccountStatusParam accountStatusParam, BindingResult bindingResult) throws Exception{
        //校验
        if (bindingResult.hasErrors()){
            log.error("启用/停用管理员参数异常{}",bindingResult);
            throw new CommonException(400,"parameter.incorrect",bindingResult);
        }

        //获取租户的超级管理员，for循环传入的行号id，如果有超管的id，则直接报错
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Long tenantId = oserviceOperator.getTenantId();
        accountStatusParam.setTenantId(tenantId);
        //判断，不能停用超级管理员
        String idStr = accountStatusParam.getIds();
        List<String> idList = Splitter.on(",").omitEmptyStrings().splitToList(idStr);

        Page<Account> page = accountService.getAccountPage(Account.builder().tenantId(tenantId).isRoot(true).build());
        Account account = page.getContent().get(0);

        for (int i =0;i< idList.size();i++){
            if (idList.get(i).equals(account.getId()+"")){
                throw new CommonException(400,"account.supper.cannot.operate");
            }
        }
        //获取到操作返回的id（表示本租户的id，for循环删除其对应的redis信息）
        List<Long> list = accountService.changeAccountStatus(accountStatusParam);
        //0停用  1启用
        if (accountStatusParam.status == 0){
            for (int i =0;i< list.size();i++){
                String id = list.get(i)+"";
                String roleIdStr = redisService.getValue(RedisCommonKeyUtil.ACCOUNT_ROLE+id);
                if (StringUtils.isNotBlank(roleIdStr)) {
                    redisService.deleteKey(RedisCommonKeyUtil.ACCOUNT_ROLE + id);
                }
            }
        }
    }

    @ApiOperation(value = "删除管理员", notes = "删除管理员")
    @RequestMapping(value = "/{id}",method = RequestMethod.DELETE)
    public void deleteAccount(@PathVariable long id) throws Exception{
        //判断这个管理员id，是否是管理员租户下的
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        List<Account> accountList = accountService.getAccountList(Account.builder().tenantId(tenantId).id(id).build());
        if (Objects.isNull(accountList) || accountList.isEmpty()){
            log.error("在tenantId {}下没有找到对的管理员{}", tenantId,id);
            return ;
        }

        if (accountList.get(0).getIsRoot() ){
            log.error("不能删除超级管理员");
            throw new CommonException(400,"resource.conflict");
        }

        adminService.deleteAdmin(id,tenantId);
    }

    @ApiOperation(value = "授权角色", notes = "授权角色")
    @RequestMapping(value = "/{id}/role",method = RequestMethod.POST)
    public void bindRole(@PathVariable long id,@RequestBody Role roleParam) throws Exception{
        //校验
        if (Objects.isNull(roleParam) || Objects.isNull(roleParam.getId())){
            log.error("参数错误，角色id不能为空");
            throw new CommonException("parameter.incorrect");
        }
        //判断这个管理员id，是否是管理员租户下的
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();

        List<Account> accountList = accountService.getAccountList(Account.builder().tenantId(tenantId).id(id).build());
        if (Objects.isNull(accountList) || accountList.isEmpty()){
            log.error("在tenantId {}下没有找到对的管理员{}", tenantId,id);
            return ;
        }
        if (accountList.get(0).getIsRoot()){
            log.error("超级管理员不能修改授权");
            throw new CommonException(400,"resource.conflict");
        }
        adminService.bindRole(id,roleParam,tenantId);
    }

    @ApiOperation(value = "删除角色授权", notes = "授权角色")
    @RequestMapping(value = "/{id}/role",method = RequestMethod.DELETE)
    public void unbindRole(@PathVariable long id) throws Exception{
        //判断这个管理员id，是否是管理员租户下的
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        List<Account> accountList = accountService.getAccountList(Account.builder().tenantId(tenantId).id(id).build());
        if (Objects.isNull(accountList) || accountList.isEmpty()){
            log.error("在tenantId {}下没有找到对的管理员{}", tenantId,id);
            return ;
        }
        if (accountList.get(0).getIsRoot()){
            log.error("不能删除超级管理员的授权");
            throw new CommonException(400,"resource.conflict");
        }
        adminService.unbindRole(id);
    }

    @ApiOperation(value = "检查权限", notes = "检查是否有权限访问某资源")
    @RequestMapping(value = "/_check",method = RequestMethod.GET)
    public OserviceOperator checkAuth(@RequestParam String apiPath, @RequestParam String method) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long accountId = oserviceOperator.getUserId();
        OserviceOperator.UserType userType = oserviceOperator.getUserType();

        //如果是超管/global/api调用者，拥有所有权限直接返回200
        if (userType != OserviceOperator.UserType.COMMON){
            return oserviceOperator;
        }

        //普通管理员：判断角色
        String roleIdStr =redisService.getValue(RedisCommonKeyUtil.ACCOUNT_ROLE+accountId);

        //如果没有角色，且访问的不是公共API，则返回无权限
        if (StringUtils.isNotBlank(roleIdStr) && NO_ROLE.equals(roleIdStr)){
            String pubUrl = redisService.getMapValue(RedisCommonKeyUtil.PUB_RESOURCES,apiPath);
            if (StringUtils.isBlank(pubUrl)){
                log.error("无角色的用户，没有权限访问此接口的权限，返回403");
                throw new CommonException(403,"has.no.permission");
            }
            return oserviceOperator;
        }

        //拥有正常角色，获取角色关联的API资源，验证本次访问的资源是否在其中
        String resRedisKey = RedisCommonKeyUtil.ROLE_RESOURCE+roleIdStr;
        List<Resource> resources = redisService.getListValue(resRedisKey);
        if (resources.size()<1){
            log.error("用户没有访问任何接口的权利，返回403");
            throw new CommonException(403,"has.no.permission");
        }

        List<Resource> resourceList =resources.stream().filter(resource -> apiPath.equals(resource.getUrl())&&method.equalsIgnoreCase(resource.getMethod().name())).collect(Collectors.toList());
        if (Objects.isNull(resourceList) || resourceList.size()==0){
            log.error("用户没有访问此接口的权限，返回403");
            throw new CommonException(403,"has.no.permission");
        }
        return oserviceOperator;
    }

    @Data
    public static class ChangeAccountStatusParam{
        @NotEmpty
        private String ids;
        private int status;
        private long tenantId;
    }

}
