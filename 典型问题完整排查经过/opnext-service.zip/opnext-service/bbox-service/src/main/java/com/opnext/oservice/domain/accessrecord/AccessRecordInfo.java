package com.opnext.oservice.domain.accessrecord;

import com.opnext.domain.ResourceType;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author tianzc
 */
@Data
@Entity
@Document(collection = "accessRecordInfo")
@CompoundIndexes({
        @CompoundIndex(background = true, name = "idx_name_result_groupId_no_syncTime_sn", def = "{'name':1,'resultType':-1,'deviceInfo.groupId':1,'personInfo.no':1,'syncTime':-1,'deviceInfo.sn':1}"),
        @CompoundIndex(background = true, name = "idx_sn_syncTime_result_no_name", def = "{'deviceInfo.sn':1,'syncTime':-1,'resultType':-1,'personInfo.no':1,'name':1}"),
        @CompoundIndex(background = true, name = "idx_groupId_result_syncTime", def = "{'deviceInfo.groupId':1,'resultType':-1,'syncTime':-1}"),
        @CompoundIndex(background = true, name = "idx_appId_type_syncTime", def = "{'personInfo.appId':1,'personInfo.type':-1,'syncTime':-1}"),
        @CompoundIndex(background = true, name = "idx_name_phone_idCard", def = "{'personInfo.name':1,'personInfo.phone':-1,'identifyCard.idCard':1}"),
        @CompoundIndex(background = true, name = "idx_syncTime", def = "{'syncTime': -1}"),
        @CompoundIndex(background = true, name = "idx_result", def = "{'resultType': -1}"),
        @CompoundIndex(background = true, name = "idx_no", def = "{'personInfo.no': 1}"),
        @CompoundIndex(background = true, name = "idx_ruleId", def = "{'personInfo.ruleId': -1}"),
        @CompoundIndex(background = true, name = "idx_passMode", def = "{'passMode': 1}"),
        @CompoundIndex(background = true, name = "idx_direction", def = "{'deviceInfo.direction': 1}"),
        @CompoundIndex(background = true, name = "idx_areaName", def = "{'deviceInfo.areaName': 1}")
})
@ApiModel(description="识别记录详情")
public class AccessRecordInfo implements Serializable{
    @Id
    @ApiModelProperty(value="识别记录id")
    private String id;
    @ApiModelProperty(value="人员姓名")
    private String name;
    // 通行证
    @ApiModelProperty(value="卡号")
    private String idNumber;
    @ApiModelProperty(value="设备信息")
    private DeviceInfo deviceInfo;
    @ApiModelProperty(value="人员信息")
    private PersonInfo personInfo;
//    /**
//     *  证件信息（身份证、护照）
//     */
    @ApiModelProperty(value="证件信息")
    private IdentifyCard identifyCard;
    @ApiModelProperty(value="二维码")
    private String qrCode;
    @ApiModelProperty(value="通行认证信息")
    private HashMap identifyInfo;
    @ApiModelProperty(value="通行时间")
    private Long syncTime;
    @ApiModelProperty(value="创建时间")
    private Long createTime;
    @ApiModelProperty(value="通行结果")
    private ResultType resultType;
    @ApiModelProperty(value="通行结果")
    private RejectReason rejectReason;
    @ApiModelProperty(value="通行类型")
    private Type type;
    @ApiModelProperty(value="通行模式")
    private PassMode passMode;
    /**
     * 可见光打分
     */
    @ApiModelProperty(value="可见光打分")
    private String score;
    /**
     * 近红外打分
     */
    @ApiModelProperty(value="近红外打分")
    private String nirScore;
    /**
     * 照片地址
     * 可见光URL地址数组
     * 近红外URL地址数组
     * ResourceType枚举（可见光，近红外）
     * Map<ResourceType, List<URL>>
     */
    @ApiModelProperty(value="照片地址")
    private HashMap<ResourceType, List<String>> avatars;

    /**
     * 租户id
     */
    @ApiModelProperty(value="租户id")
    private Long tenantId;


    /**
     * 通行方式
     */
    @AllArgsConstructor
    @ApiModel(description="通行模式")
    public enum PassMode{
        /**
         * 人脸
         */
        FACE,
        /**
         * 人脸+身份证
         */
        FACE_AND_ID,
        /**
         * 人脸+护照
         */
        FACE_AND_PASSPORT,
        /**
         * 人脸+门禁卡
         */
        FACE_AND_GUARD,
        /**
         * 人脸+IC卡
         */
        FACE_AND_IC,
        /**
         * 二维码
         */
        QCODE,
        /**
         * 扫码枪
         */
        SCANNING_GUN
    }

    @Slf4j
    @AllArgsConstructor
    @ApiModel(description="通行结果")
    public enum ResultType {
        /**
         * 通过
         */
        TERMINAL_VALIDATION_PASS("SUCCESS"),
        /**
         * 验证不通过
         */
        TERMINAL_VALIDATION_FAILURE("FAIL");
        private String value;

        private static Map<String, ResultType> valMap = new HashMap<>();

        public String value(){
            return this.value;
        }

        static {
            for (ResultType result : values()) {
                valMap.put(result.value, result);
            }
        }
        public static ResultType indexOfVal(String value) {
            ResultType resultType = valMap.get(value);
            if(null == resultType){
                log.error("ResultType中没有找到匹配的 " + value);
                throw new IllegalArgumentException("No element matches " + value);
            }
            return resultType;
        }
    }

    @AllArgsConstructor
    @ApiModel(description="拒绝原因")
    public enum RejectReason {
        /**
         * 人脸比对不通过
         */
        FACIAL_COMPARISON_NOT_PASS,
        /**
         * 黑名单拒绝通行
         */
        BLACKLIST_EXCEEDS_REFUSE,
        /**
         * 人员规则
         */
        PERSONNAL_RULE_VALIDATION_FAILURE,
        /**
         * 指纹验证失败
         */
        FINGERPRINT_VALIDATION_FAILURE,
        /**
         * 无效认证（无效卡）
         */
        INVALID_VALIDATION
    }

    @AllArgsConstructor
    @ApiModel(description="进出类型")
    public enum Type {
        IN_TYPE,OUT_TYPE
    }
}
