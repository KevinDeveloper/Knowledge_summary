package com.opnext.oservice.controller.authority;

import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.RedisCommonKeyUtil;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.authority.AccountRole;
import com.opnext.oservice.domain.authority.role.Module;
import com.opnext.oservice.dto.authority.role.ModuleDTO;
import com.opnext.oservice.service.authority.ModuleService;
import com.opnext.oservice.service.authority.RoleService;
import com.opnext.oservice.service.base.BaseRedisService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

/**
 * @author wanglu
 */
@Slf4j
@RestController
@RequestMapping("/api/module")
public class ModuleController {
    @Autowired
    private ModuleService moduleService;
    @Autowired
    private RoleService roleService;
    @Autowired
    private BaseRedisService redisService;

    @ApiOperation(value = "获取模块菜单列表", notes = "获取全部菜单列表，用于给子账号授权")
    @RequestMapping(value = "/",method = RequestMethod.GET)
    public List<ModuleDTO> getAllModule() {
        return moduleService.getAllModule();

    }

    @ApiOperation(value = "获取可访问的菜单列表", notes = "获取可访问的菜单列表，用于登陆后获取页面左侧菜单")
    @RequestMapping(value = "/auth",method = RequestMethod.GET)
    public List<ModuleDTO> getAuthModule() throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long accountId = oserviceOperator.getUserId();
        String suRole = "0";
        String noRole = "-1";
        //从redis里读取角色，判断是否为超级管理员，如果是，则返回全部模块
        String roleIdStr = redisService.getValue(RedisCommonKeyUtil.ACCOUNT_ROLE+accountId);

        if (StringUtils.isBlank(roleIdStr)){
            AccountRole accountRole = roleService.getAccountRoleByAccountId(accountId);
            if (Objects.isNull(accountRole)) {
                throw new CommonException(400,"account.role.not.found");
            }
            if (Objects.isNull(accountRole.getRoleId())){
                roleIdStr = noRole;
            }else{
                roleIdStr=accountRole.getRoleId()+"";
            }
            redisService.setKey(RedisCommonKeyUtil.ACCOUNT_ROLE+accountId,roleIdStr);
        }
        if (suRole.equals(roleIdStr)){
            return getAllModule();
        }
        if (noRole.equals(roleIdStr)){
            return new ArrayList<>(0);
            //throw new CommonException(403,"has.no.permission");
        }

        //步骤2：通过角色返回能够访问的model列表
        List<ModuleDTO> modules = moduleService.findModuleListByRoleId(Long.parseLong(roleIdStr));
        return modules;
    }

    @ApiOperation(value = "获取主功能", notes = "获取主功能（用于操作日志主功能那个的查询）")
    @RequestMapping(value = "/mainFunction",method = RequestMethod.GET)
    public List<Module> getMainFunction() throws Exception {
        List<Module> modules = moduleService.getMainFunction();
        return modules;
    }

}
