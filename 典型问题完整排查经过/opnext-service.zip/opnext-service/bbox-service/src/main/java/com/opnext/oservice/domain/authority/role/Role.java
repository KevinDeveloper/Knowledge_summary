package com.opnext.oservice.domain.authority.role;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import javax.persistence.*;
import java.util.Date;

/**
 * @author wanglu
 */
@Entity
@Table(name = "role")
@Data
@Builder
public class Role {
    @Tolerate
    public Role(){}
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    private Type type;

    //表示外建：所属租户
    @Column(name="tenant_id")
    private Long tenantId;

    @Column(name="created_by")
    private Long createdBy;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="create_time")
    @CreatedDate
    private Date createTime;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name="update_time")
    @LastModifiedDate
    private Date updateTime;

    public enum Type{
        /**
         * 默认角色
         */
        DEFAULT((byte) 0),
        /**
         * 手动创建的角色
         */
        CREATED((byte)1);

        private byte value;

        Type(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }

}
