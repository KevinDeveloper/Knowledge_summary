package com.opnext.oservice.repository.rule;

import com.opnext.oservice.domain.rule.RuleDevice;
import com.opnext.oservice.domain.rule.MultiKeys.RuleDeviceMultiKeysClass;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 14:03
 */
public interface RuleDeviceRepository extends PagingAndSortingRepository<RuleDevice, RuleDeviceMultiKeysClass>, QueryDslPredicateExecutor<RuleDevice> {

    /**
     * 根据设备、规则、租户的ID查询对应关系
     *
     * @param deviceId 设备ID
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return 查询结果
     */
    RuleDevice findRuleDeviceByDeviceIdAndRuleIdAndTenantId(int deviceId, int ruleId, long tenantId);

    /**
     * 根据设备Sn、规则ID和租户ID查询对应关系
     *
     * @param deviceSn 设备ID
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return 查询结果
     */
    RuleDevice findByDeviceSnAndRuleIdAndTenantId(String deviceSn, int ruleId, long tenantId);

    /**
     * 根据规则ID和租户ID删除管理表
     *
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return 受影响行数
     */
    int deleteByRuleIdAndTenantId(int ruleId, long tenantId);
}
