package com.opnext.oservice.service.device.impl;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.device.DeviceGroup;
import com.opnext.oservice.domain.device.DeviceGroupVo;
import com.opnext.oservice.domain.device.QDevice;
import com.opnext.oservice.domain.device.QDeviceGroup;
import com.opnext.oservice.domain.device.QDeviceGroupVo;
import com.opnext.oservice.dto.CommonFailedStatus;
import com.opnext.oservice.repository.ComplicateQueryDao;
import com.opnext.oservice.repository.ComplicateQueryDslDao;
import com.opnext.oservice.repository.device.DeviceGroupRepository;
import com.opnext.oservice.repository.device.DeviceRepository;
import com.opnext.oservice.service.device.DeviceGroupService;
import com.querydsl.core.types.Path;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:02 18/5/7
 */ @Slf4j
@Service
public class DeviceGroupServiceImpl implements DeviceGroupService {

    @Autowired
    DeviceGroupRepository groupRepository;
    @Autowired
    DeviceRepository deviceRepository;
    @Autowired
    private ComplicateQueryDao complicateQueryDao;
    @Autowired
    private ComplicateQueryDslDao complicateQueryDslDao;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;


    /**
     * 分页获取设备组列表
     *
     * @param pageable
     * @param name
     * @return
     * @throws Exception
     */
    @Override
    public Page getPage(Pageable pageable, String name) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Long tenantId = oserviceOperator.getTenantId();
        List<Integer> groupList = oserviceOperator.getDeviceGroups();
        Page page;
        Predicate predicate = null;
        if (Objects.nonNull(tenantId)) {
            predicate = (predicate == null ? QDeviceGroup.deviceGroup.tenantId.eq(tenantId):
                    ((BooleanExpression) predicate).and(QDeviceGroup.deviceGroup.tenantId.eq(tenantId)));
        }
        if (CollectionUtils.isEmpty(groupList)) {
            if (OserviceOperator.UserType.COMMON.equals(oserviceOperator.getUserType())) {
                page = new PageImpl(new ArrayList(), pageable, 0);
                return page;
            }
        } else {
            predicate = (predicate == null ? QDeviceGroup.deviceGroup.id.in(groupList):
                    ((BooleanExpression) predicate).and(QDeviceGroup.deviceGroup.id.in(groupList)));
        }
        if (StringUtils.isNotBlank(name)){
            predicate = (predicate == null ? QDeviceGroup.deviceGroup.groupName.contains(name):
                    ((BooleanExpression) predicate).and(QDeviceGroup.deviceGroup.groupName.contains(name)));
        }

        QDeviceGroup qDeviceGroup = QDeviceGroup.deviceGroup;
        QDevice qDevice = QDevice.device;
        LinkedList<Path> linkedList = new LinkedList<>();
        linkedList.add(QDeviceGroupVo.deviceGroupVo);
        linkedList.add(QDeviceGroupVo.deviceGroupVo.deviceCount);
        // 获取设备组关联的设备数
        page = complicateQueryDslDao.find(
                jpaQueryFactory.select(qDeviceGroup,
                        qDevice.groupId.count().as(QDeviceGroupVo.deviceGroupVo.deviceCount))
                        .from(qDeviceGroup)
                        .leftJoin(qDevice)
                        .on(qDeviceGroup.id.eq(qDevice.groupId))
                        .where(predicate)
                        .groupBy(qDeviceGroup.id)
                        .orderBy(qDeviceGroup.updateTime.desc())
                , pageable, DeviceGroupVo.class, linkedList);

        return page;
    }

    /**
     * 获取所有设备列表
     *
     * @return
     * @throws Exception
     */
    @Override
    public List getAllList() throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Long tenantId = oserviceOperator.getTenantId();
        List<Integer> groupList = oserviceOperator.getDeviceGroups();
        Predicate predicate = null;
        if (Objects.nonNull(tenantId)) {
            predicate = (predicate == null ? QDeviceGroup.deviceGroup.tenantId.eq(tenantId):
                    ((BooleanExpression) predicate).and(QDeviceGroup.deviceGroup.tenantId.eq(tenantId)));
        }
        List<DeviceGroup> deviceGroupList = new ArrayList<>();
        if (CollectionUtils.isEmpty(groupList)) {
            if (OserviceOperator.UserType.COMMON.equals(oserviceOperator.getUserType())) {
                return deviceGroupList;
            }
        } else {
            predicate = (predicate == null ? QDeviceGroup.deviceGroup.id.in(groupList):
                    ((BooleanExpression) predicate).and(QDeviceGroup.deviceGroup.id.in(groupList)));
        }
        deviceGroupList = (List<DeviceGroup>) groupRepository.findAll(predicate);
        return deviceGroupList;
    }

    /**
     * 根据id获取设备组
     *
     * @param id
     * @return
     * @throws Exception
     */
    @Override
    public DeviceGroup getInfo(Integer id) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Long tenantId = oserviceOperator.getTenantId();
        List<Integer> groupList = oserviceOperator.getDeviceGroups();
        Predicate predicate = null;
        if (Objects.nonNull(tenantId)) {
            predicate = (predicate == null ? QDeviceGroup.deviceGroup.tenantId.eq(tenantId):
                    ((BooleanExpression) predicate).and(QDeviceGroup.deviceGroup.tenantId.eq(tenantId)));
        }
        DeviceGroup deviceGroup = null;
        if (!CollectionUtils.isEmpty(groupList)) {
            if (!groupList.contains(id)) {
                return deviceGroup;
            }
        } else {
            if (OserviceOperator.UserType.COMMON.equals(oserviceOperator.getUserType())) {
                return deviceGroup;
            }
        }
        predicate = (predicate == null ? QDeviceGroup.deviceGroup.id.eq(id):
                ((BooleanExpression) predicate).and(QDeviceGroup.deviceGroup.id.eq(id)));
        deviceGroup = groupRepository.findOne(predicate);
        return deviceGroup;
    }

    /**
     * 保存设备组，并关联设备
     *
     * @param deviceGroup
     * @throws Exception
     */
    @Transactional(rollbackFor = {Exception.class})
    @Override
    public DeviceGroup save(DeviceGroup deviceGroup) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        deviceGroup.setTenantId(tenantId);
        DeviceGroup resultGroup = groupRepository.save(deviceGroup);
        // 为设备关联设备组
        if (null != deviceGroup.getDeviceIds() && deviceGroup.getDeviceIds().length > 0) {
            Predicate predicate = QDevice.device.id.in(deviceGroup.getDeviceIds());
            predicate = ((BooleanExpression) predicate).and(QDevice.device.tenantId.eq(tenantId));
            Long count = jpaQueryFactory.update(QDevice.device)
                    .set(QDevice.device.updateTime, new Date())
                    .set(QDevice.device.groupId, resultGroup.getId())
                    .set(QDevice.device.groupName, resultGroup.getGroupName())
                    .where(predicate).execute();
        }
        return resultGroup;
    }

    /**
     * 更新设备名称
     *
     * @param deviceGroup
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateGroup(DeviceGroup deviceGroup) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        try {
            // 判断设备组数据，校验设备是否存在错误数据
            if (Objects.nonNull(deviceGroup) && deviceGroup.getDeviceIds().length > 0) {
                Predicate predicate = QDevice.device.id.in(deviceGroup.getDeviceIds());
                predicate = ((BooleanExpression) predicate).and(QDevice.device.tenantId.eq(oserviceOperator.getTenantId()));
                predicate = ((BooleanExpression) predicate).and(QDevice.device.groupId.isNotNull());
                predicate = ((BooleanExpression) predicate).and(QDevice.device.groupId.notIn(deviceGroup.getId()));
                long count = deviceRepository.count(predicate);
                if (count > 0) {
                    log.info("提交数据有误，存在关联其他设备组的设备");
                    throw new CommonException("data.wrong");
                }
            }
            Predicate predicate = QDeviceGroup.deviceGroup.tenantId.eq(oserviceOperator.getTenantId());
            predicate = ((BooleanExpression) predicate).and(QDeviceGroup.deviceGroup.id.eq(deviceGroup.getId()));

            long count = jpaQueryFactory.update(QDeviceGroup.deviceGroup)
                    .set(QDeviceGroup.deviceGroup.groupName, deviceGroup.getGroupName())
                    .set(QDeviceGroup.deviceGroup.updateTime, new Date())
                    .where(predicate)
                    .execute();
            if (count == 0) {
                log.info("根据参数无有效可更新数据；参数id：{}", deviceGroup.getId());
                throw new CommonException("DataNotFound");
            }
            // 移除设备关联的此设备组
            jpaQueryFactory.update(QDevice.device)
                    .setNull(QDevice.device.groupId).setNull(QDevice.device.groupName)
                    .set(QDevice.device.updateTime, new Date())
                    .where(QDevice.device.groupId.eq(deviceGroup.getId()).and(QDevice.device.tenantId.eq(oserviceOperator.getTenantId())))
                    .execute();
            // 设备关联设备组
            jpaQueryFactory.update(QDevice.device)
                    .set(QDevice.device.updateTime, new Date())
                    .set(QDevice.device.groupId, deviceGroup.getId())
                    .set(QDevice.device.groupName, deviceGroup.getGroupName())
                    .where(QDevice.device.id.in(deviceGroup.getDeviceIds()).and(QDevice.device.tenantId.eq(oserviceOperator.getTenantId())))
                    .execute();
        } catch (Exception e) {
            log.error("数据操作异常：{}", e);
            throw new CommonException(HttpStatus.BAD_REQUEST.value(), CommonFailedStatus.DATABASE_EXCEPTION.getMessage(), null,CommonFailedStatus.DATABASE_EXCEPTION.getValue());
        }
    }

    /**
     * 更新设备名称
     *
     * @param groupNme
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateGroupName(Integer id, String groupNme) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Predicate predicate = QDeviceGroup.deviceGroup.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QDeviceGroup.deviceGroup.id.eq(id));
        jpaQueryFactory.update(QDeviceGroup.deviceGroup)
                .set(QDeviceGroup.deviceGroup.groupName, groupNme)
                .where(predicate).execute();

        Predicate devicePredicate = QDevice.device.tenantId.eq(tenantId);
        devicePredicate = ((BooleanExpression) devicePredicate).and(QDevice.device.groupId.eq(id));
        // 更新设备关联的设备组名称
        jpaQueryFactory.update(QDevice.device)
                .set(QDevice.device.groupName,groupNme)
                .where(devicePredicate).execute();
    }

    /**
     * 删除设备组，移除设备关联设备组
     *
     * @param ids
     * @throws Exception
     */
    @Transactional( rollbackFor = Exception.class)
    @Override
    public void delete(Integer[] ids) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Predicate devicePredicate = QDevice.device.tenantId.eq(tenantId);
        devicePredicate = ((BooleanExpression) devicePredicate).and(QDevice.device.groupId.in(ids));
        // 移除设备关联的设备组
        jpaQueryFactory.update(QDevice.device)
                .setNull(QDevice.device.groupId)
                .setNull(QDevice.device.groupName)
                .where(devicePredicate).execute();
        // 删除设备组
        Predicate predicate = QDeviceGroup.deviceGroup.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QDeviceGroup.deviceGroup.id.in(ids));
        jpaQueryFactory.delete(QDeviceGroup.deviceGroup)
                .where(predicate).execute();
    }

    /**
     * 处理设备组列表返回数据
     * @param groupVoList
     * @param deviceCountList
     * @return
     * @throws Exception
     */
    public List handleData(List<DeviceGroupVo> groupVoList, List<DeviceGroupVo> deviceCountList) throws Exception{
        for (DeviceGroupVo deviceGroupVo : groupVoList) {
            for (DeviceGroupVo groupVo : deviceCountList) {
                if (deviceGroupVo.getId().equals(groupVo.getId())) {
                    deviceGroupVo.setDeviceCount(groupVo.getDeviceCount());
                }
            }
        }
        return groupVoList;
    }
}
