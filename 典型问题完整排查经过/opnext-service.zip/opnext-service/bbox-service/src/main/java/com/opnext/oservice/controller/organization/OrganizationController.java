package com.opnext.oservice.controller.organization;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxdomain.organization.OrgDelType;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.organization.OrgVo;
import com.opnext.oservice.domain.organization.Organization;
import com.opnext.oservice.service.organization.OrganizationService;
import com.opnext.oservice.validator.IsOrganizationValidator;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @ClassName: OrganizationController
 * @Description:
 * @Author: Kevin
 * @Date: 2018/5/10 16:04
 */
@Slf4j
@RestController
@RequestMapping("/api/org")
public class OrganizationController {

    @Autowired
    private OrganizationService organizationService;


    @ApiOperation(value = "初始化根组织", notes = "")
    @ApiImplicitParam(name = "orgName", value = "初始化根组织名")
    @RequestMapping(value = "/init", method = RequestMethod.POST)
    public void init(String orgName) throws Exception {
        log.info("进入到租户注册初始化组织接口");
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(orgName, new IsStringWithinLengthRangeValidator("orgName", 1, 64, true))
                .doValidate()
                .result(toComplex());
        if (!ret.isSuccess()) {
            log.debug("初始化根组织异常， 参数错误， orgName={}", orgName);
            throw new CommonException(400, "parameter.incorrect", ret);
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        organizationService.initRootOrgInTenant(oserviceOperator.getTenantId(), oserviceOperator.getUserId(), orgName);
    }

    @ApiOperation(value = "新建组织", notes = "")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public void save(@RequestBody OrgVo orgVo) throws Exception {
        log.info("进入到新建组织接口");
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        organizationService.checkOperator(oserviceOperator);
        Organization organization = new Organization();
        BeanUtils.copyProperties(orgVo, organization);
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(organization, new IsOrganizationValidator("organization"))
                .on(organization.getName(), new IsStringWithinLengthRangeValidator("name", 1, 64, true))
                .doValidate()
                .result(toComplex());
        if (!ret.isSuccess()) {
            log.debug("参数错误");
            throw new CommonException(400, "parameter.incorrect", ret);
        }
        organizationService.saveOrg(organization);
    }

    @ApiOperation(value = "更新组织", notes = "根据组织id更新组织")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "orgId", value = "待更新的组织id", required = true, dataType = "String"),
    })
    @Transactional(rollbackFor = Exception.class)
    @RequestMapping(value = "/update/{orgId}", method = RequestMethod.POST)
    public void update(@PathVariable String orgId, @RequestBody OrgVo orgVo) throws Exception {
        log.info("进入到更新组织接口");
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        organizationService.checkOperator(oserviceOperator);
        orgVo.setId(Integer.valueOf(orgId));
        Organization organization = new Organization();
        BeanUtils.copyProperties(orgVo, organization);
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(organization, new IsOrganizationValidator("organization"))
                .on(organization.getName(), new IsStringWithinLengthRangeValidator("name", 1, 64, true))
                .doValidate()
                .result(toComplex());
        if (!ret.isSuccess()) {
            log.debug("参数错误");
            throw new CommonException(400, "parameter.incorrect", ret);
        }

        organizationService.updateOrgById(organization.getId(), organization);
    }

    @ApiOperation(value = "删除组织", notes = "根据组织id删除组织")
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public void delete(@RequestBody Integer[] ids) throws Exception {
        log.info("根据组织id删除组织,ids={}", Arrays.toString(ids));
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        organizationService.checkOperator(oserviceOperator);
        organizationService.deleteOrgByIds(ids);

    }


    @ApiOperation(value = "删除组织", notes = "根据组织id删除组织, 平移到新组织")
    @RequestMapping(value = "/{orgId}", method = RequestMethod.DELETE)
    public void delete(@PathVariable Integer orgId, @RequestParam OrgDelType type , Integer targetOrgId) throws Exception {
        log.info("删除组织,orgId={}, type={},  tartgetOrgId={}, ", orgId, type.value(), targetOrgId);
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        organizationService.checkOperator(oserviceOperator);
        if(Objects.isNull(orgId) || Objects.isNull(type)){
            log.info("删除组织，组织id及删除类型不能为空");
            throw new CommonException(400, "parameter.incorrect");
        }
        if(type.value() == OrgDelType.DEL_DIRECT.value()){
            organizationService.deleteOrgDirect(oserviceOperator,orgId);
        }else if( type.value() == OrgDelType.DEL_MOVE.value()){
            organizationService.deleteOrgMove(oserviceOperator,orgId, targetOrgId);
        }else{
            log.info("删除组织，删除类型不匹配");
            throw new CommonException(400, "parameter.incorrect");
        }
        log.info("删除组织,orgId={}, type={},  tartgetOrgId={}, ", orgId, type.value(), targetOrgId);
    }

    @ApiIgnore
    @ApiOperation(value = "全部组织列表", notes = "获取全部组织列表(非分页，平级)")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseEntity list() throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        List<OrgVo> organizationList = organizationService.listAllOrg(oserviceOperator);
        return ResponseEntity.ok(organizationList);
    }

    @ApiOperation(value = "组织树", notes = "获取全部组织树(树状)")
    @RequestMapping(value = "/node", method = RequestMethod.GET)
    public ResponseEntity orgNode() throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        OrgVo org = organizationService.orgNode(oserviceOperator);
        List<OrgVo> list = new ArrayList<>();
        list.add(org);
        return ResponseEntity.ok(list);
    }


    @ApiIgnore
    @ApiOperation(value = "获取特定组织下的全部子组织列表 - 开发自测", notes = "获取特定组织下的全部子组织列表")
    @RequestMapping(value = "/nodeForOne", method = RequestMethod.GET)
    public ResponseEntity orgListForOne(Integer parentId, String orgName) throws Exception {
        List<OrgVo> orgList = organizationService.listOrgByParentId(parentId, orgName);
        return ResponseEntity.ok(orgList);
    }

    @ApiOperation(value = "获取第三方组织", notes = "获取第三方组织")
    @RequestMapping(value = "/otherOrg", method = RequestMethod.GET)
    public ResponseEntity otherOrg() throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Organization other = organizationService.getOtherOrgByTenantId(tenantId);
        OrgVo orgVo = new OrgVo();
        BeanUtils.copyProperties(other, orgVo);
        return ResponseEntity.ok(orgVo);
    }

}
