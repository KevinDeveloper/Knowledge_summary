package com.opnext.oservice.service.authority.impl;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.RedisCommonKeyUtil;
import com.opnext.bboxsupport.util.RedisLifeTimeUtil;
import com.opnext.oservice.domain.authority.AccountRole;
import com.opnext.oservice.domain.authority.role.*;
import com.opnext.oservice.repository.authority.*;
import com.opnext.oservice.service.authority.PermissionService;
import com.opnext.oservice.service.base.BaseRedisService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author wanglu
 */
@Service
@Slf4j
public class PermissionServiceImpl implements PermissionService {
    @Autowired
    private ResourceRepository resourceRepository;
    @Autowired
    private BaseRedisService redisService;
    @Autowired
    private RoleModuleRepository roleModuleRepository;
    @Autowired
    private ModuleResourceRepository moduleResourceRepository;
    @Autowired
    private RoleOrganizationRepository organizationRepository;
    @Autowired
    private RoleDeviceGroupRepository roleDeviceGroupRepository;
    @Autowired
    private AccountRoleRepository accountRoleRepository;

    static final String SU_ROLE = "0";
    static final String NO_ROLE = "-1";

    @Override
    public List<Resource> getResourcesByRoleId(long roleId){
        //roleResource_${roleId}
        String redisKey = RedisCommonKeyUtil.ROLE_RESOURCE+roleId;

        List<Resource> resources = redisService.getListValue(redisKey);
        if (CollectionUtils.isEmpty(resources)){
            //查询resource放入redis中
            List<RoleModule> roleModules = roleModuleRepository.findAllByRoleId(roleId);
            List<Integer> moduleIds = roleModules.stream().map(roleModule -> {return roleModule.getModuleId();}).collect(Collectors.toList());
            List<ModuleResource> moduleResources = moduleResourceRepository.findAllByModuleIdIn(moduleIds);
            List<Integer> resourceIds = moduleResources.stream().map(moduleResource -> { return moduleResource.getResourceId(); }).distinct().collect(Collectors.toList());
            resources = resourceRepository.findDistinctByIdInOrScope(resourceIds,Resource.Scope.All);
            if (!CollectionUtils.isEmpty(resources)){
                redisService.setListValue(redisKey, resources);
            }
        }
        redisService.setLifeTime(redisKey,RedisLifeTimeUtil.roleRightTime());
        return resources;
    }

    @Override
    public List<Integer> getOrgIdListByRoleId(long roleId){
        //roleOrg_${roleId}
        String orgRedisKey = RedisCommonKeyUtil.ROLE_ORG+roleId;
        List<Integer> orgIdList = redisService.getListValue(orgRedisKey);

        if (CollectionUtils.isEmpty(orgIdList)){
            List<RoleOrganization> roleOrganizations = organizationRepository.findAllByRoleId(roleId);
            orgIdList = roleOrganizations.stream().map(roleOrg -> {
                return roleOrg.getOrganizationId();
            }).collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(orgIdList)){
                redisService.setListValue(orgRedisKey, orgIdList);
            }
        }
        redisService.setLifeTime(orgRedisKey,RedisLifeTimeUtil.roleRightTime());
        return orgIdList;
    }

    @Override
    public List<Integer> getDeviceGroupIdListByRoleId(long roleId){
        //roleDev_${roleId}
        String devGroupRedisKey = RedisCommonKeyUtil.ROLE_DEV+roleId;
        List<Integer> deviceGroupIdList = redisService.getListValue(devGroupRedisKey);

        if (CollectionUtils.isEmpty(deviceGroupIdList)){
            List<RoleDeviceGroup> roleDeviceGroups = roleDeviceGroupRepository.findAllByRoleId(roleId);
            deviceGroupIdList = roleDeviceGroups.stream().map(roleDeviceGroup -> {
                return roleDeviceGroup.getDeviceGroupId();
            }).collect(Collectors.toList());
            if (!CollectionUtils.isEmpty(deviceGroupIdList)){
                redisService.setListValue(devGroupRedisKey, deviceGroupIdList);
            }
        }
        redisService.setLifeTime(devGroupRedisKey,RedisLifeTimeUtil.roleRightTime());
        return deviceGroupIdList;
    }

    @Override
    public String getRoleStrByOperator(OserviceOperator oserviceOperator) throws Exception{
        long accountId = oserviceOperator.getUserId();
        String roleIdStr;
        if (oserviceOperator.getUserType().value()== OserviceOperator.UserType.SUPER.value()){
            roleIdStr = SU_ROLE;
            return roleIdStr;
        }
        roleIdStr = redisService.getValue(RedisCommonKeyUtil.ACCOUNT_ROLE+accountId);
        //无：从DB中查询放入redis中
        if (StringUtils.isBlank(roleIdStr)){
            AccountRole accountRole = accountRoleRepository.findByAccountId(accountId);
            if (Objects.isNull(accountRole)) {
                log.error("没有找到账号对应的角色");
                throw new CommonException(403,"account.role.not.found");
            }
            if (Objects.isNull(accountRole.getRoleId())){
                roleIdStr = NO_ROLE;
            }else{
                roleIdStr=accountRole.getRoleId()+"";
            }
            redisService.setKey(RedisCommonKeyUtil.ACCOUNT_ROLE+accountId,roleIdStr);
        }
        return roleIdStr;
    }

    @Override
    public void initPubResource(){
        //初始化公共资源到redis中
        Boolean hasPubRes = redisService.hasKey(RedisCommonKeyUtil.PUB_RESOURCES);
        if(!hasPubRes){
            List<Resource> resources = resourceRepository.findDistinctByScope(Resource.Scope.All);
            Map<String,String> resourceMap = new HashMap<>(resources.size());
            resources.forEach(resource -> resourceMap.put(resource.getUrl(),resource.getUrl()));
            redisService.setAllMapValue(RedisCommonKeyUtil.PUB_RESOURCES,resourceMap);
        }
    }

}
