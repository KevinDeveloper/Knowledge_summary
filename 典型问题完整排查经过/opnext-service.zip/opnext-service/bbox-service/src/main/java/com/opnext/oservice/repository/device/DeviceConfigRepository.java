package com.opnext.oservice.repository.device;

import com.opnext.oservice.domain.device.DeviceConfig;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

import java.util.List;

/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午5:02 18/5/7
 */ 
public interface DeviceConfigRepository extends MongoRepository<DeviceConfig, String>,
        QueryDslPredicateExecutor<DeviceConfig> {


    /**
     * 获取设备设置列表
     * @param query
     * @return
     */
    List<DeviceConfig> findAll(Query query);

    /**
     * 删除设置
     * @param id
     * @param tenantId
     * @return
     */
    Integer deleteByIdAndTenantId(String id, Integer tenantId);

    /**
     * 根据id，服务类型
     * @param id
     * @param serviceType
     * @return
     */
    DeviceConfig findByIdAndServiceType(String id, String serviceType);

    /**
     * 根据id，服务类型，租户查询
     * @param id
     * @param serviceType
     * @return
     */
    DeviceConfig findByIdAndServiceTypeAndTenantId(String id, String serviceType, Long tenantId);

    /**
     *
     * @param sn
     * @param serviceType
     * @return
     */
    DeviceConfig findBySnAndServiceTypeAndTenantId(String sn, String serviceType, Long tenantId);

}
