package com.opnext.oservice.repository.authority;

import com.opnext.oservice.domain.authority.role.RoleOrganization;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @author wanglu
 */

public interface RoleOrganizationRepository extends PagingAndSortingRepository<RoleOrganization, Long>,
        QueryDslPredicateExecutor<RoleOrganization> {
    /**
     * 通过角色id查询全部角色组织关联
     * @param roleId
     * @return
     */
    List<RoleOrganization> findAllByRoleId(long roleId);

    /**
     * 通过roleId删除所有组织关联
     * @param roleId
     */
    void deleteAllByRoleId(long roleId);
}
