package com.opnext.oservice.domain.device;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:04 18/5/7
 */
@Slf4j
@AllArgsConstructor
@ApiModel(description="设备状态")
public enum DeviceStatus {

    /**
     * 设备断网
     */
    @ApiModelProperty(value="设备断网")
    DEVICE_OFF_LINE(0),
    /**
     * 设备无心跳
     */
//    DEVICE_NO_HEARTBEAT(1),
    /**
     * 设备正常
     */
    @ApiModelProperty(value="设备正常")
    DEVICE_RECOVERY(1);
    private Integer value;
    public Integer value(){
        return this.value;
    }
    private static Map<String, DeviceStatus> valMap = new HashMap<>();

    static {
        for (DeviceStatus deviceStatus : values()) {
            valMap.put(deviceStatus.name(), deviceStatus);
        }
    }

    public static DeviceStatus indexOfVal(String value) {
        DeviceStatus deviceStatus = valMap.get(value);
        if(null == deviceStatus){
            log.error("DeviceType中没有找到匹配的 " + value);
            throw new IllegalArgumentException("No element matches " + value);
        }
        return deviceStatus;
    }
}
