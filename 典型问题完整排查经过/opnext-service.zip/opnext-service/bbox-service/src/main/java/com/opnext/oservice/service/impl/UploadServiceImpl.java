package com.opnext.oservice.service.impl;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.domain.MultipartFileResp;
import com.opnext.oservice.service.ImageHandler;
import com.opnext.oservice.service.UploadService;
import com.opnext.oservice.service.callable.ImageCallable;
import com.opnext.oservice.service.callable.MultipartImageCallable;
import lombok.extern.slf4j.Slf4j;
import opnext.server.support.util.UrlUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午3:18 18/5/9
 */
@Slf4j
@Service
public class UploadServiceImpl implements UploadService {

    @Resource
    private ImageHandler imageHandler;

    /** 批量导入时，大于这个数时开始使用多线程预览数据处理 */
    public static final int MAX_ROW_NUM = 10;
    /** 批量导入，预处理数据，设置处理数据的多线程的最大个数 */
    public static final int MAXTHREAD_COUNT = 10;

    /**
     * 可见光照片上传
     *
     * @param multipartFile
     * @return
     */
    @Override
    public Map<String, MultipartFileResp> uploadImage(MultipartFile multipartFile, OserviceOperator oserviceOperator,RequestUrlPrefix urlPrefix) throws Exception {
        Map<String, MultipartFileResp> mapResp = new HashMap<>();
        try {
            mapResp = imageHandler.checkAndCutAndUploadImage(multipartFile, oserviceOperator);
            String schemeAndHost = GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme());
            mapResp.forEach((fileName, fileResp) -> {
                Optional<String> optional = UrlUtil.getShowPath(schemeAndHost, fileResp.getUrl());
                if (optional.isPresent()) {
                    fileResp.setUrl(optional.get());
                }
            });
        } catch (Exception e) {
            log.error("MultipartFile调用图片处理方法异常：{}",e.getMessage());
            String msg = e.getMessage();
            if (StringUtils.isBlank(msg)) {
                msg = "imageFile.exception";
            }
            String fileName = multipartFile.getOriginalFilename();
            MultipartFileResp fileResp = MultipartFileResp.builder()
                    .flag(false).message(msg).fileName(fileName).build();
            mapResp.put(fileName, fileResp);
        }
        return mapResp;
    }

    /**
     * 批量上传文件（用于人员批量上传）
     *
     * @param multipartFiles
     * @return
     * @throws Exception
     */
    @Override
    public Map<String, MultipartFileResp> batchUploadImage(List<MultipartFile> multipartFiles,OserviceOperator oserviceOperator) throws Exception {
        Map<String, MultipartFileResp> map = new HashMap<>();
        try {
            if (multipartFiles.size() > UploadServiceImpl.MAX_ROW_NUM) {
                int threadCount = multipartFiles.size() / UploadServiceImpl.MAX_ROW_NUM;
                threadCount = threadCount > UploadServiceImpl.MAXTHREAD_COUNT ? UploadServiceImpl.MAXTHREAD_COUNT : threadCount;
                ExecutorService executorService = new ThreadPoolExecutor(0, threadCount, 0L, TimeUnit.SECONDS, new SynchronousQueue<Runnable>());
                CountDownLatch countDownLatch = new CountDownLatch(threadCount);
                List<Future<Map<String, MultipartFileResp>>> futures = new ArrayList<>();
                int rowSize = multipartFiles.size() / threadCount;
                log.warn("线程池处理文件数据转换，threadCount=" + threadCount + ", rowSize=" + rowSize);
                int startIndex;
                int endIndex;
                for (int i = 0; i < threadCount; i++) {
                    startIndex = rowSize * i;
                    endIndex = rowSize * (i + 1);
                    if (i == threadCount - 1) {
                        endIndex = multipartFiles.size();
                    }
                    List<MultipartFile> fileList = multipartFiles.subList(startIndex, endIndex);
                    MultipartImageCallable imageCallable = new MultipartImageCallable(fileList, imageHandler, countDownLatch, oserviceOperator);
                    futures.add(executorService.submit(imageCallable));
                }
                executorService.shutdown();
                countDownLatch.await();
                Map<String, MultipartFileResp> temp;
                for (Future<Map<String, MultipartFileResp>> tempFutrue : futures) {
                    temp = tempFutrue.get();
                    if (null != temp) {
                        map.putAll(temp);
                    }
                }
            } else { //单个线程处理
                log.info("单个线程处理");
                map = handleImageMultipartFile(multipartFiles,oserviceOperator);
            }
        } catch (Exception e) {
            log.error("批量导入，获取Map<String, MultipartFileResp>异常,{}",e);
        }
        return map;
    }

    /**
     * 批量上传文件（用于人员批量上传）
     *
     * @param multipartFiles
     * @return
     * @throws Exception
     */
    @Override
    public Map<String, MultipartFileResp> batchUploadImageForFile(List<File> multipartFiles,OserviceOperator oserviceOperator) throws Exception {
        Map<String, MultipartFileResp> map = new HashMap<>();
        try {
            if (multipartFiles.size() > UploadServiceImpl.MAX_ROW_NUM) {
                int threadCount = multipartFiles.size() / UploadServiceImpl.MAX_ROW_NUM;
                threadCount = threadCount > UploadServiceImpl.MAXTHREAD_COUNT ? UploadServiceImpl.MAXTHREAD_COUNT : threadCount;
                ExecutorService executorService = new ThreadPoolExecutor(0, threadCount,
                        0L, TimeUnit.SECONDS,
                        new SynchronousQueue<Runnable>());
                CountDownLatch countDownLatch = new CountDownLatch(threadCount);
                List<Future<Map<String, MultipartFileResp>>> futures = new ArrayList<>();
                int rowSize = multipartFiles.size() / threadCount;
                log.warn("线程池处理文件数据转换，threadCount=" + threadCount + ", rowSize=" + rowSize);
                int startIndex;
                int endIndex;
                for (int i = 0; i < threadCount; i++) {
                    startIndex = rowSize * i;
                    endIndex = rowSize * (i + 1);
                    if (i == threadCount - 1) {
                        endIndex = multipartFiles.size();
                    }
                    List<File> fileList = multipartFiles.subList(startIndex, endIndex);
                    ImageCallable imageCallable = new ImageCallable(fileList, imageHandler, countDownLatch, oserviceOperator);
                    futures.add(executorService.submit(imageCallable));
                }
                executorService.shutdown();
                countDownLatch.await();
                Map<String, MultipartFileResp> temp;
                for (Future<Map<String, MultipartFileResp>> tempFutrue : futures) {
                    temp = tempFutrue.get();
                    if (null != temp) {
                        map.putAll(temp);
                    }
                }
            } else { //单个线程处理
                log.info("单个线程处理");
                map = handleImageFile(multipartFiles, oserviceOperator);
            }
        } catch (Exception e) {
            log.error("批量导入，获取Map<String, MultipartFileResp>异常,{}",e);
        }
        return map;
    }

    /**
     *
     * @param fileList
     * @return
     */
    public Map<String, MultipartFileResp> handleImageFile(List<File> fileList, OserviceOperator oserviceOperator){
        Map<String, MultipartFileResp> map = new HashMap<>();
        int size = fileList.size();
        for (int i = 0; i < size; i++ ) {
            try {
                Map<String, MultipartFileResp> mapResp = imageHandler.checkAndCutAndUploadImage(fileList.get(i), oserviceOperator);
                map.putAll(mapResp);
            } catch (Exception e) {
                log.error("File数据-调用图片处理方法异常：{}",e.getMessage());
                String msg = e.getMessage();
                if (StringUtils.isBlank(msg)) {
                    msg = "imageFile.exception";
                }
                String fileName = fileList.get(i).getName();
                MultipartFileResp fileResp = MultipartFileResp.builder()
                        .flag(false).message(msg).fileName(fileName).build();
                map.put(fileName, fileResp);
            }
        }
        return map;
    }

    /**
     *
     * @param fileList
     * @return
     */
    public Map<String, MultipartFileResp> handleImageMultipartFile(List<MultipartFile> fileList, OserviceOperator oserviceOperator){
        Map<String, MultipartFileResp> map = new HashMap<>();
        int size = fileList.size();
        for (int i = 0; i < size; i++ ) {
            try {
                Map<String, MultipartFileResp> mapResp = imageHandler.checkAndCutAndUploadImage(fileList.get(i),oserviceOperator);
                map.putAll(mapResp);
            } catch (Exception e) {
                log.error("MultipartFile数据-调用图片处理方法异常：{}",e.getMessage());
                String msg = e.getMessage();
                if (StringUtils.isBlank(msg)) {
                    msg = "imageFile.exception";
                }
                String fileName = fileList.get(i).getOriginalFilename();
                MultipartFileResp fileResp = MultipartFileResp.builder()
                        .flag(false).message(msg).fileName(fileName).build();
                map.put(fileName, fileResp);
            }
        }
        return map;
    }
}
