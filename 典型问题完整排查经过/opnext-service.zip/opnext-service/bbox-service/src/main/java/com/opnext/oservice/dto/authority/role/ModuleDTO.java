package com.opnext.oservice.dto.authority.role;

import com.opnext.oservice.domain.authority.role.Module.Scope;
import com.opnext.oservice.domain.authority.role.Module.IsMainFunction;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

/**
 * @author wanglu
 */
@Data
@Builder
public class ModuleDTO {
    private Integer id;
    private String name;
    private Scope scope;
    private IsMainFunction isMainFunction;
    private ModuleDTO pid;

    @Tolerate
    public ModuleDTO(){}
}
