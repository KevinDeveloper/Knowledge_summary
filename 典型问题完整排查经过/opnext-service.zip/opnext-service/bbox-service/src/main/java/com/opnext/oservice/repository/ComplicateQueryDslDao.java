package com.opnext.oservice.repository;

import com.querydsl.core.Tuple;
import com.querydsl.core.types.Path;
import com.querydsl.jpa.impl.JPAQuery;
import lombok.SneakyThrows;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.NoRepositoryBean;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午5:16 18/5/8
 */
@NoRepositoryBean
public interface ComplicateQueryDslDao extends ComplicateQueryDao {

    /**
     * 查询，自定字段
     * @param query
     * @param pageable
     * @param returnClass
     * @param linkedList
     * @param <T>
     * @return
     */
    default <T> Page<T> find(JPAQuery<Tuple> query, Pageable pageable, Class<T> returnClass, LinkedList linkedList) {
        return  find(query, pageable, new ClassExtractor<T>(returnClass, linkedList));
    }

    /**
     * 查询
     * @param query
     * @param pageable
     * @param extractor
     * @param <T>
     * @return
     */
    default <T> Page<T> find(JPAQuery<Tuple> query, Pageable pageable, Extractor<T> extractor) {
        long count = query.fetchCount();
        List<Tuple> list = new ArrayList<>();
        if (count > 0) {
            list = query.offset(pageable.getOffset()).limit(pageable.getPageSize()).fetch();
        }
        return new PageImpl<>(list.stream().map(extractor::extract).collect(Collectors.toList())
                , pageable, count);
    }
    interface Extractor<T> {
        /**
         * 查询
         * @param tuple
         * @return
         */
        T extract(Tuple tuple);
    }

    class ClassExtractor<T> implements Extractor<T> {
        private Class<T> clazz;
        private LinkedList<Path> linkedList;

        ClassExtractor(Class<T> clazz) {
            this.clazz = clazz;
        }

        ClassExtractor(Class<T> clazz, LinkedList linkedList) {
            this.clazz = clazz;
            this.linkedList = linkedList;
        }

        @Override
        @SneakyThrows(Exception.class)
        public T extract(Tuple tuple) {
            T t = clazz.newInstance();
            Object[] objects = tuple.toArray();
            for (int i = objects.length - 1; i >= 0; i--) {
                if(null != objects[i]) {
                    if (null != linkedList && baseType(linkedList.get(i).getType())) {
                        String setPropertyName = initialToUpperCase(linkedList.get(i).getMetadata().getName());
                        clazz.getMethod(setPropertyName, linkedList.get(i).getType()).invoke(t, objects[i]);
                    } else {
                        BeanUtils.copyProperties(objects[i], t);
                    }
                }
            }
            return t;
        }

        public Boolean baseType(Class clazz) {
            boolean flag = (clazz.equals(String.class) || clazz.equals(Integer.class)||
                    clazz.equals(Byte.class) || clazz.equals(Long.class) ||
                    clazz.equals(Double.class) || clazz.equals(Float.class) ||
                    clazz.equals(Character.class) || clazz.equals(Short.class) ||
                    clazz.equals(BigDecimal.class) || clazz.equals(BigInteger.class) ||
                    clazz.equals(Boolean.class) || clazz.equals(Date.class) ||
                    clazz.isPrimitive());
            return flag;
        }

        public String initialToUpperCase(String propertyName) {
            StringBuffer setPropertyName = new StringBuffer();
            setPropertyName.append("set");
            setPropertyName.append(propertyName.substring(0, 1).toUpperCase());
            setPropertyName.append(propertyName.substring(1));
            return setPropertyName.toString();
        }
    }
}
