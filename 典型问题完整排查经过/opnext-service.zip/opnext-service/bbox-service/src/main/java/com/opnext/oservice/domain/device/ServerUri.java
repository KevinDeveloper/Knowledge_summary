package com.opnext.oservice.domain.device;

import lombok.Data;

import java.util.List;

/**
 * @Title: 
 * @Description: 
 * @author tianzc
 * @Date 下午5:08 18/5/7
 */ 
@Data
public class ServerUri {
    private Boolean isSecurity;
    private List<ServerApi> apis;
    private List<ServerHost> hosts;

}
