package com.opnext.oservice.repository.authority;

import com.opnext.oservice.domain.authority.role.Resource;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @author wanglu
 */
public interface ResourceRepository extends PagingAndSortingRepository<Resource, Integer>,
        QueryDslPredicateExecutor<Resource> {
    /**
     * 通过resourceId查询resource列表对象（去重）
     * @param resourceIds
     * @param scope
     * @return
     */
    List<Resource> findDistinctByIdInOrScope(List<Integer> resourceIds, Resource.Scope scope);

    /**
     * 查询公共API，任意角色的用户或者没有角色的用户都可以访问的接口
     * @param scope
     * @return
     */
    List<Resource> findDistinctByScope( Resource.Scope scope);
}
