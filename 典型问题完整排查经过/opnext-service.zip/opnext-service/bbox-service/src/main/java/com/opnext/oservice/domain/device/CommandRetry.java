package com.opnext.oservice.domain.device;

import lombok.Builder;
import lombok.Data;

/**
 * @author tianzc
 */
@Data
@Builder
public class CommandRetry {
    private String requestId;
    private String operator;
    private String tenantId;
}
