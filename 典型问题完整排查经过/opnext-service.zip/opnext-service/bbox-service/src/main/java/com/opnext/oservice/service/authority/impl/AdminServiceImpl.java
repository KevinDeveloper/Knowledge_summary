package com.opnext.oservice.service.authority.impl;

import com.google.common.collect.Maps;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.bboxsupport.util.RedisCommonKeyUtil;
import com.opnext.bboxsupport.util.StringUtil;
import com.opnext.oservice.domain.account.Account;
import com.opnext.oservice.domain.authority.AccountRole;
import com.opnext.oservice.domain.authority.QAccountRole;
import com.opnext.oservice.domain.authority.role.QRole;
import com.opnext.oservice.domain.authority.role.Role;
import com.opnext.oservice.domain.tenant.Tenant;
import com.opnext.oservice.dto.account.AccountDTO;
import com.opnext.oservice.dto.authority.AuthorityDTO;
import com.opnext.oservice.dto.authority.role.AccountRoleDTO;
import com.opnext.oservice.repository.ComplicateQueryDao;
import com.opnext.oservice.repository.authority.AccountRoleRepository;
import com.opnext.oservice.repository.authority.RoleRepository;
import com.opnext.oservice.service.account.AccountService;
import com.opnext.oservice.service.authority.AdminService;
import com.opnext.oservice.service.base.BaseRedisService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.Projections;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author wanglu
 */
@Service
@Slf4j
public class AdminServiceImpl implements AdminService {
    @Autowired
    private AccountService accountService;
    @Autowired
    private AccountRoleRepository accountRoleRepository;
    @Autowired
    private ComplicateQueryDao complicateQueryDao;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    private BaseRedisService redisService;
    @Autowired
    private RoleRepository roleRepository;

    @Override
    public Page<AuthorityDTO> getAdminPage(String loginname, Role role,String status,Pageable pageable,long tenantId) throws Exception{
        Account accountParam = new Account();
        accountParam.setTenantId(tenantId);
        if(StringUtils.isNotBlank(loginname)){
            String loginnameLike = "%"+loginname+"%";
            accountParam.setLoginName(loginnameLike);
        }
        if("0".equals(status)|| "1".equals(status)){
            accountParam.setStatus(Integer.parseInt(status));
        }
        //获取租户对象
        Tenant tenant =accountService.getTenantById(tenantId);

        List<AuthorityDTO> accountList = accountService.getAuthorityAccountList(accountParam);
        if (Objects.isNull(accountList) || accountList.isEmpty()){
            return new PageImpl<>(new ArrayList<>(),pageable,0);
        }

        //准备 List<Long> accountIds用于查询 账号角色关联表
        //准备 Map<Long,AuthorityDTO> map 用于待会的对象关联
        List<Long> accountIds = accountList.stream().map(authorityDTO -> {return  authorityDTO.getId() ;}).collect(Collectors.toList());
        Map<Long,AuthorityDTO> map = accountList.stream().collect(Collectors.toMap(AuthorityDTO::getId, Function.identity()));
        //查询账号角色列表
        QAccountRole qAccountRole = QAccountRole.accountRole;
        QRole qRole = QRole.role;
        Predicate predicate=qAccountRole.accountId.in(accountIds);
        if (role !=null){
            predicate=((BooleanExpression) predicate).and(qAccountRole.roleId.eq(role.getId()));
        }
        Page<AccountRoleDTO> authorityRolePage = complicateQueryDao.find(
                jpaQueryFactory.select(Projections.bean(
                        AccountRoleDTO.class,
                        qAccountRole.accountId.as("accountId"),
                        qRole.id,
                        qRole.name,
                        qRole.description,
                        qRole.type,
                        qRole.createdBy,
                        qRole.createTime,
                        qRole.updateTime,
                        qRole.tenantId))
                        .from(qAccountRole)
                        .leftJoin(qRole).on(qAccountRole.roleId.eq(qRole.id))
                        .where(predicate),pageable);

        Page<AuthorityDTO> authorityDTOS = new PageImpl(
                authorityRolePage.getContent().stream().map(
                        accountRole -> {
                            long accountId = accountRole.getAccountId();
                            AuthorityDTO t = new AuthorityDTO();
                            Role role1 = new Role();
                            BeanUtils.copyProperties(accountRole,role1);
                            BeanUtils.copyProperties(map.get(accountId),t,"role","tenant");
                            if (role1.getId()!=null && role1.getId()==0L){
                                role1.setName(Messages.get(role1.getName()));
                                role1.setDescription(Messages.get(role1.getDescription()));
                            }
                            t.setAccountId(accountId);
                            t.setTenant(tenant);
                            t.setRole(role1);
                            return t;
                        }
                ).collect(Collectors.toList())
                , pageable, authorityRolePage.getTotalElements());

        return authorityDTOS;
    }

    @Override
    @Transactional(rollbackFor=Exception.class)
    public Account addAdmin(AccountDTO accountDTO,long accountId,long tenantId)throws Exception{
        Account account = new Account();
        BeanUtils.copyProperties(accountDTO,account);
        account.setId(null);
        account.setTenantId(tenantId);
        account.setCreatedBy(accountId);
        account.setIsRoot(false);
        account.setStatus(1);
        Account res = accountService.addAccount(account);
        /*
         * 加入角色权限表，其中角色为空（账号和角色是1：1的关系，用户模块不在本项目中管理,通过调用远端接口方式取得。
         * 为方便对账号和角色进行关联查询，因此这样设计
         * 未来将角色权限放到用户中心处，需要更改此处代码的逻辑）
         * by wanglu
         */
        AccountRole accountRole = AccountRole.builder().accountId(res.getId()).roleId(null).build();
        accountRoleRepository.save(accountRole);
        return res;
    }

    @Override
    public void deleteAdmin(long id,long tenantId) throws Exception{
        Map map=Maps.newHashMap();
        map.put("id",id);
        map.put("tenantId", tenantId);
        accountService.deleteAccount(map);
        accountRoleRepository.delete(id);
        try {
            String roleIdStr = redisService.getValue(RedisCommonKeyUtil.ACCOUNT_ROLE+id);
            if (StringUtils.isNotBlank(roleIdStr)) {
                redisService.deleteKey(RedisCommonKeyUtil.ACCOUNT_ROLE + id);
            }
        }catch (Exception e){
            log.error("从redis删除账号相关的角色信息失败，redis服务异常");
        }
    }

    @Override
    @Transactional(rollbackFor=Exception.class)
    public void bindRole(long id,Role roleParam,long tenantId) throws Exception{
        //判断账号是否已经拥有角色，如果有，则返回错误
        AccountRole accountRole = accountRoleRepository.findByAccountId(id);
        if (Objects.nonNull(accountRole) && Objects.nonNull(accountRole.getRoleId())){
            log.error("账号已经绑定了角色，绑定新角色前需要先解绑上一个角色");
            throw new CommonException(400,"account.role.bind.conflict");
        }
        //判断角色id是这个租户下的角色
        Role role = roleRepository.findAllByIdAndTenantId(roleParam.getId(), tenantId);
        if (Objects.isNull(role)){
            log.error("在tenantId {}下没有找到对的角色{}", tenantId,roleParam.getId());
            return ;
        }
        AccountRole accountRole1 = AccountRole.builder().roleId(role.getId()).accountId(id).build();
        accountRoleRepository.save(accountRole1);
        redisService.deleteKey(RedisCommonKeyUtil.ACCOUNT_ROLE+id);
    }

    @Override
    public void bindSuperRole(long id){
        accountRoleRepository.save(AccountRole.builder().roleId(0L).accountId(id).build());
    }

    @Override
    public void unbindRole(long id){
        accountRoleRepository.save(AccountRole.builder().accountId(id).roleId(null).build());
        try {
            String roleIdStr = redisService.getValue(RedisCommonKeyUtil.ACCOUNT_ROLE+id);
            if (StringUtils.isNotBlank(roleIdStr)) {
                redisService.deleteKey(RedisCommonKeyUtil.ACCOUNT_ROLE + id);
            }
        }catch (Exception e){
            log.error("删除角色授权时从redis删除账号相关的角色信息失败，redis服务异常");
        }
    }
}
