package com.opnext.oservice.repository.organization;

import com.opnext.oservice.domain.organization.Organization;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * 组织jpa
 * @ClassName: OrganizationRepository
 * @Description:
 * @Author: Kevin
 * @Date: 2018/5/10 16:01
 */
public interface OrganizationRepository extends PagingAndSortingRepository<Organization, Integer>,
        QueryDslPredicateExecutor<Organization> {

//    @Modifying
//    @Query("delete from organization org where org.id in :ids")
//    public void deleteOrgByIds(@Param(value = "ids") List<Integer> ids);

//    @Modifying
//    @Query("update organization org set sc.deleted = true where sc.id in :ids")
//    public void updateOrgById(@Param(value = "id") Integer id ,@Param(value = "org") organization org);

}
