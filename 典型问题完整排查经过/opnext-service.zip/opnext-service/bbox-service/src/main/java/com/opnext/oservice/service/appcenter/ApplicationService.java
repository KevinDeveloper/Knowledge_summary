package com.opnext.oservice.service.appcenter;

import com.opnext.oservice.domain.appcenter.Application;

import java.util.List;

/**
 * @author wanglu
 */
public interface ApplicationService {

    /**
     * 通过租户获取app列表
     * @param tenantId
     * @return
     */
    List<Application> getApplications(long tenantId);

    /**
     * 通过id查询应用
     * @param id
     * @param tenantId
     * @return
     */
    Application getApplicationById(int id,long tenantId);

    /**
     * 通过appId获取应用列表
     * @param appId
     * @param tenantId
     * @return
     */
    List<Application> getApplicationsByAppId(String appId,long tenantId);

    /**
     * 保存应用
     * @param application
     */
    void saveApplication(Application application);

    /**
     * 修改应用
     * @param application
     */
    void modifyApplication(Application application);
}