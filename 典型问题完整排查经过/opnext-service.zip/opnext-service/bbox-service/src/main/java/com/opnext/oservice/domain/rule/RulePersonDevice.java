package com.opnext.oservice.domain.rule;

import com.opnext.oservice.domain.rule.MultiKeys.RulePersonDeviceMultiKeysClass;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @Author: lixiuwen
 * @Date: 2018/6/12 10:34
 */
@Entity
@Table(name = "rule_person_device")
@Data
@EntityListeners(AuditingEntityListener.class)
@IdClass(RulePersonDeviceMultiKeysClass.class)
public class RulePersonDevice implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 应用于人员ID
     */
    @Id
    @Column(name = "person_id")
    private String personId;

    /**
     * 设备Sn
     */
    @Id
    @Column(name = "device_sn")
    private String deviceSn;

    /**
     * 规则ID
     */
    @Column(name = "rule_id")
    private Integer ruleId;

    /**
     * 应用ID
     */
    @Column(name = "app_id")
    private String appId;

    /**
     * 创建时间
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    @CreatedDate
    private Date createTime;

    /**
     * 租户ID
     */
    @Column(name = "tenant_id")
    private Long tenantId;
}
