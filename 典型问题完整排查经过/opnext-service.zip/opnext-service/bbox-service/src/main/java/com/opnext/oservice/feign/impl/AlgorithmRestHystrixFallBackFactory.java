package com.opnext.oservice.feign.impl;

import com.opnext.oservice.feign.AlgorithmRestClient;
import com.opnexts.algo.core.domain.response.DetectResponse;
import com.opnexts.algo.core.domain.response.QualityResponse;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

/**
 * @author tianzc
 */
@Slf4j
@Component("algorithmRestHystrixFallBackFactory")
public class AlgorithmRestHystrixFallBackFactory implements FallbackFactory<AlgorithmRestClient> {

    @Override
    public AlgorithmRestClient create(Throwable throwable) {
        return new AlgorithmRestClient() {
            @Override
            public List<DetectResponse> detect(MultipartFile[] faceImages) throws IOException {
                log.error("call AlgorithmFeign detect error", throwable);
                return null;
            }

            @Override
            public List<QualityResponse> quality(MultipartFile[] faceImages) throws IOException {
                log.error("call AlgorithmFeign detect error", throwable);
                return null;
            }
        };
    }
}
