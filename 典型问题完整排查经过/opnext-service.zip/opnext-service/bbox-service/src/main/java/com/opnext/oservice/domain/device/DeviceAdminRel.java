package com.opnext.oservice.domain.device;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Title: 设备与设备管理员关联类
 * @Description: --
 * @author tianzc
 * @Date 下午4:48 18/5/7
 */
@Entity
@Data
@Table(name = "device_admin_rel")
public class DeviceAdminRel {

    @Id
    @GeneratedValue
    private Integer id;

    @Column(name = "device_id")
    private Integer deviceId;

    @Column(name = "device_admin_id")
    private Integer deviceAdminId;

    @Column(name = "tenant_id")
    private long tenantId;
}
