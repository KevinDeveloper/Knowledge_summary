package com.opnext.oservice.service.device.message.impl;

import com.beebox.push.event.Event;
import com.google.common.collect.Sets;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.domain.message.Report;
import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.domain.device.DeviceStatus;
import com.opnext.oservice.domain.device.QDevice;
import com.opnext.oservice.domain.device.alarm.DeviceAlarm;
import com.opnext.oservice.domain.device.alarm.DeviceAlarmType;
import com.opnext.oservice.repository.device.DeviceRepository;
import com.opnext.oservice.repository.device.alarm.DeviceAlarmRepository;
import com.opnext.oservice.repository.device.alarm.DeviceAlarmTypeRepository;
import com.opnext.oservice.service.device.api.DeviceApiService;
import com.opnext.oservice.service.device.message.DeviceMessageService;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * @author wanglu
 */
@Slf4j
@Service(value = "deviceMessageSersvice")
public class DeviceMessageServiceImpl implements DeviceMessageService {
    @Autowired
    DeviceAlarmRepository deviceAlarmRepository;
    @Autowired
    DeviceRepository deviceRepository;
    @Autowired
    DeviceAlarmTypeRepository deviceAlarmTypeRepository;
    @Autowired
    JPAQueryFactory jpaQueryFactory;
    @Resource
    private DeviceApiService deviceApiService;

    @Override
    public void uploadAlarm(Report report) throws Exception{
        DeviceAlarmType deviceAlarmType =
                deviceAlarmTypeRepository.findDeviceAlarmTypeByName(report.getData());
        if(Objects.isNull(deviceAlarmType)){
            log.error("终端告警上传失败,通过告警类型参数没有找到对应的告警类型实体");
            throw new CommonException("device.alarm.upload.alarmType.error");
        }
        //通过deviceSn获取所在tenant_id和Tenant；如果Tenant不存在，则抛异常
        Device device = deviceRepository.findBySn(report.getSn());
        if(Objects.isNull(device)){
            log.error("终端告警上传失败，通过sn号没有找到对应的租户");
            throw new CommonException("device.alarm.upload.sn.error");
        }
        //准备插入参数
        DeviceAlarm deviceAlarm =new DeviceAlarm();
        deviceAlarm.setDescription(report.getData());
        deviceAlarm.setOccurTime(new Date());
        deviceAlarm.setDeviceAlarmType(deviceAlarmType.getId());
        deviceAlarm.setDeviceSn(device.getSn());
        deviceAlarm.setTenantId(device.getTenantId());
        deviceAlarm.setReadStatus(false);
        deviceAlarm.setCreateTime(new Date());
        log.info("准备保存终端告警，参数为:{}",deviceAlarm.toString());
        deviceAlarmRepository.save(deviceAlarm);
    }

    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateStaus(Report report) throws Exception{
        //通过deviceSn获取所在tenant_id和Tenant；如果Tenant不存在，则抛异常
        Device device = deviceRepository.findBySn(report.getSn());
        if(Objects.isNull(device)){
            log.error("终端状态修改失败，通过sn：{}号没有找到对应的租户", report.getSn());
            throw new CommonException("device.sn.error");
        }
        DeviceStatus deviceStatus = DeviceStatus.DEVICE_OFF_LINE;
        try {
            deviceStatus= DeviceStatus.indexOfVal(report.getData());
        } catch (Exception e) {
            log.error("获取设备状态异常：{}", e);
        }
        QDevice qDevice = QDevice.device;
        Predicate predicate = qDevice.sn.eq(report.getSn());
        // 更新设备状态
        jpaQueryFactory.update(QDevice.device)
                .set(QDevice.device.status, deviceStatus)
                .set(QDevice.device.updateTime, new Date())
                .where(predicate)
                .execute();
        log.info("设备sn：{}，更新状态为：{}",report.getSn(), deviceStatus.name());
        deviceApiService.pushDeviceInfo(report.getSn(), Event.EventType.DEVICE_ACTIVE,device.getTenantId());
    }

    /**
     * 补偿处理，更新断网设备
     *
     * @param onlineSet
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateOnlineStatus(Set<String> onlineSet) throws Exception {
        // 获取断网设备
        QDevice qDevice = QDevice.device;
        List<String> snsList = jpaQueryFactory.select(qDevice.sn)
                .from(qDevice)
                .where(qDevice.status.eq(DeviceStatus.DEVICE_OFF_LINE))
                .fetch();
        if (!CollectionUtils.isEmpty(snsList)) {
            Set<String> snsSet = Sets.newHashSet(snsList);
            if (!CollectionUtils.isEmpty(onlineSet)) {
                onlineSet.retainAll(snsSet);
                if (!CollectionUtils.isEmpty(onlineSet)) {

                    log.debug("在线设备补偿设备：{}", onlineSet);
                    Predicate predicate = qDevice.sn.in(onlineSet);
                    // 更新设备状态
                    jpaQueryFactory.update(QDevice.device)
                            .set(QDevice.device.status, DeviceStatus.DEVICE_RECOVERY)
                            .set(QDevice.device.updateTime, new Date())
                            .where(predicate)
                            .execute();
                    List<Tuple> tupleList = jpaQueryFactory.select(qDevice.sn,qDevice.tenantId)
                            .from(qDevice)
                            .where(predicate)
                            .fetch();
                    tupleList.forEach(obj -> {
                        try {
                            deviceApiService.pushDeviceInfo(obj.toArray()[0].toString(), Event.EventType.DEVICE_ACTIVE,(Long)obj.toArray()[0]);
                        } catch (Exception e) {
                            log.error("pushServer服务异常",e);
                        }
                    });
                    // 批量sn推送
                }
            }
        }
    }
}
