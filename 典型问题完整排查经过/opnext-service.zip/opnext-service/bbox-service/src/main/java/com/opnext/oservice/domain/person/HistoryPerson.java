package com.opnext.oservice.domain.person;

import com.opnext.domain.PersonType;
import com.opnext.domain.ResourceType;
import com.opnext.domain.Sex;
import com.opnext.oservice.domain.converter.PersonAvatarsConverter;
import com.opnext.oservice.domain.converter.PersonVariableConverter;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:05 18/5/7
 */
@Entity
@Data
@Table(name = "history_person")
@EntityListeners(AuditingEntityListener.class)
public class HistoryPerson {
    /**
     * 人员id
     */
    @Id
    private String id;
    /**
     * 人员名称
     */
    @Column(name = "name")
    private String name;
    /**
     * 人员编号
     */
    @Column(name = "no")
    private String no;
    /**
     * 人员性别
     */
    @Column(name = "sex")
    private Sex sex;
    /**
     * 身份证号
     */
    @Column(name = "id_card")
    private String idCard;
    /**
     * 手机号
     */
    @Column(name = "phone")
    private String phone;
    /**
     * 职务
     */
    @Column(name = "position")
    private String position;
    /**
     * 邮箱
     */
    @Column(name = "mail")
    private String mail;
    /**
     * IC卡号
     */
    @Column(name = "ic_number")
    private String icNumber;
    /**
     * 韦根号
     */
    @Column(name = "wg_number")
    private String wgNumber;
    /**
     * 组织id
     */
    @Column(name = "organization_id")
    private Integer organizationId;
    /**
     * 规则id
     */
    @Column(name = "rule_id")
    private Integer ruleId;
    /**
     * 同步状态
     */
    @Column(name = "sync_status")
    private SyncStatus syncStatus;
    /**
     * 同步版本号
     */
    @Column(name = "sync_version")
    private Long syncVersion;
    /**
     * 入职时间
     */
    @Column(name = "hiredate")
    private Date hiredate;
    /**
     * 特征库id
     */
    @Column(name = "group_id")
    private String groupId;
    /**
     * 备注
     */
    private String remark;
    @Column(name="create_time")
    @CreatedDate
    private Date createTime;
    @Column(name="update_time")
    @LastModifiedDate
    private Date updateTime;
    @Column(name = "tenant_id")
    private Long tenantId;
    /**
     * 操作者id
     */
    @Column(name = "operator_id")
    private Long operatorId;
    /**
     * 操作账号
     */
    @Column(name = "operator_name")
    private String operatorName;
    @Column(name = "app_id")
    private String appId;
    /**
     * 扩展字段map
     */
    @Column(name = "variable")
    @Convert(converter = PersonVariableConverter.class)
    private Map<String, String> variable;
    /**
     * 照片Map包含可见光，近红外
     */
    @Column(name = "avatars")
    @Convert(converter = PersonAvatarsConverter.class)
    private Map<ResourceType, List<String>> avatars;
    /**
     * 人员类型
     */
    @Column(name = "type")
    private PersonType type;

}
