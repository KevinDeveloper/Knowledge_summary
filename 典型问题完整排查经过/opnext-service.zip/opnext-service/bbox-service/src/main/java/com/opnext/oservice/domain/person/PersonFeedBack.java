package com.opnext.oservice.domain.person;

import lombok.Data;

/**
 * 反馈处理数据
 * @author tianzc
 */
@Data
public class PersonFeedBack {
}
