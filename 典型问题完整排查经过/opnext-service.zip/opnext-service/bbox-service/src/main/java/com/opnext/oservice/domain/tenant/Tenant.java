package com.opnext.oservice.domain.tenant;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

/**
 * @author wanglu
 */
@ApiModel(description = "租户对象")
@Data
@Builder
public class Tenant {
    @Tolerate Tenant() {}
    @ApiModelProperty(value = "租户id")
    private Long id;
    @ApiModelProperty(value = "租户名称")
    private String name;
    @ApiModelProperty(value = "业务类型")
    private Integer businessType;
    @ApiModelProperty(value = "区域代码")
    private Integer countryCode;
    @ApiModelProperty(value = "租户联系人")
    private String contact;
    @ApiModelProperty(value = "租户联系人电话")
    private String contactPhone;
    @ApiModelProperty(value = "超级管理员登陆账号")
    private String loginName;
    @ApiModelProperty(value = "租户联系邮箱")
    private String email;
}
