package com.opnext.oservice.domain.algorithm;

import lombok.Data;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午1:19 18/5/12
 */
@Data
public class RightEye {
    private int x;
    private int y;
}
