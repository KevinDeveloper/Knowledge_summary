package com.opnext.oservice.service.device.impl;

import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.device.CommandRetry;
import com.opnext.oservice.dto.PageFeign;
import com.opnext.oservice.dto.command.CommandRecord;
import com.opnext.oservice.dto.command.SearchCommandReq;
import com.opnext.oservice.feign.OMessageFeign;
import com.opnext.oservice.service.device.CommandRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Objects;

/**
 * @author wanglu
 */
@Service
@Slf4j
public class CommandRecordServiceImpl implements CommandRecordService {
    @Resource
    private OMessageFeign oMessageFeign;

    @Override
    public Page<CommandRecord> getCommandRecords(SearchCommandReq searchCommandReq)throws Exception {
        CommonResponse<PageFeign<CommandRecord>> pageFeign =  oMessageFeign.getCommandRecord(searchCommandReq);
        if (pageFeign.getEntity() instanceof Page){
            return (Page<CommandRecord>)pageFeign.getEntity();
        }
        Page<CommandRecord> commandRecordPage = PageFeign.localPageToSpringPage(pageFeign.getEntity());
        return commandRecordPage;
    }

    @Override
    public CommandRecord getCommandRecordDetail(String requestId,String tenantId)throws Exception{
        CommonResponse<CommandRecord> commonResponse = oMessageFeign.getCommandRecordDetail(requestId,tenantId);
        return commonResponse.getEntity();
    }

    /**
     * 重新下发指令
     *  待完善tianzc
     * @param requestId
     * @param oserviceOperator
     * @throws Exception
     */
    @Override
    public void sendCommand(String requestId, OserviceOperator oserviceOperator) throws Exception {
        CommandRetry commandRetry = CommandRetry.builder().requestId(requestId)
                .operator(oserviceOperator.getLoginName())
                .tenantId(String.valueOf(oserviceOperator.getTenantId()))
                .build();
        // 重新下发
        CommonResponse commonResponse = oMessageFeign.commandRetry(commandRetry);
        if (Objects.nonNull(commonResponse)) {
            if(200 != commonResponse.getStatus()) {
                log.info("重新发送指令失败");
                throw new CommonException("InternalServerError");
            }
            log.info("发送成功；原requestId：{}，新requestId：{}", requestId, commonResponse.getEntity());
        } else {
            log.info("重新发送指令异常");
            throw new CommonException("InternalServerError");
        }

    }
}
