package com.opnext.oservice.service.rule.impl;

import com.alibaba.fastjson.JSONObject;
import com.beebox.push.common.amqp.PushClient;
import com.beebox.push.event.Event;
import com.beebox.push.event.EventBuilder;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.domain.PersonType;
import com.opnext.domain.response.IDRuleResp;
import com.opnext.oservice.conf.AuthorizeProperties;
import com.opnext.oservice.conf.Constant;
import com.opnext.oservice.domain.person.HistoryPerson;
import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.domain.rule.QRule;
import com.opnext.oservice.domain.rule.QRuleApply;
import com.opnext.oservice.domain.rule.QRuleDevice;
import com.opnext.oservice.domain.rule.Rule;
import com.opnext.oservice.repository.person.HistoryPersonRepository;
import com.opnext.oservice.repository.person.PersonRepository;
import com.opnext.oservice.repository.rule.RuleRepository;
import com.opnext.oservice.service.base.BaseRedisService;
import com.opnext.oservice.service.person.PersonService;
import com.opnext.oservice.service.rule.RuleApplyService;
import com.opnext.oservice.service.rule.RuleApplySyncService;
import com.opnext.oservice.service.rule.RuleDeviceService;
import com.opnext.oservice.service.rule.RuleService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.collections4.ListUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.hibernate.Session;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 15:56
 */
@Slf4j
@Service
public class RuleServiceImpl implements RuleService {

    @Autowired
    private RuleRepository ruleRepository;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    private RuleDeviceService ruleDeviceService;
    @Autowired
    private RuleApplyService ruleApplyService;
    @Autowired
    private PushClient pushClient;
    @Autowired
    private AuthorizeProperties authorizeProperties;
    @Autowired
    private RuleApplySyncService ruleApplySyncService;
    @Autowired
    private BaseRedisService redisService;
    @Autowired
    private EntityManager entityManager;
    @Autowired
    private PersonRepository personRepository;
    @Autowired
    private HistoryPersonRepository historyPersonRepository;

    /**
     * 组织转换成人员
     *
     * @param organizationIdList 组织ID结婚
     * @param tenantId           租户ID
     */
    @Override
    public List<String> orgIdToPersonId(List<Integer> organizationIdList, long tenantId) {
        if (CollectionUtils.isNotEmpty(organizationIdList)) {
            QPerson qPerson = QPerson.person;
            return jpaQueryFactory
                    .select(qPerson.id)
                    .from(qPerson)
                    .where(qPerson.organizationId.in(organizationIdList)
                            .and(qPerson.tenantId.eq(tenantId))
                            .and(qPerson.type.eq(PersonType.FREQUENTER)))
                    .fetch();
        }
        return new ArrayList<>();
    }

    /**
     * 删除规则
     *
     * @param ruleIds          规则ID集合
     * @param oserviceOperator 当前操作人信息
     * @throws CommonException
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void delRules(List<Integer> ruleIds, OserviceOperator oserviceOperator) throws CommonException {
        if (ruleIds == null || ruleIds.size() == 0) {
            return;
        }
        QRule qRule = QRule.rule;
        Predicate predicate = qRule.id.in(ruleIds).and(qRule.tenantId.eq(oserviceOperator.getTenantId()));
        long lCount = jpaQueryFactory.selectFrom(qRule).where(predicate).fetchCount();
        if (lCount != ruleIds.size()) {
            log.debug("参数不匹配");
            throw new CommonException("org.parameter.incorrect");
        }
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        List<String> deviceSnList = jpaQueryFactory.select(qRuleDevice.deviceSn).from(qRuleDevice).where(qRuleDevice.ruleId.in(ruleIds)).fetch();
        if (deviceSnList != null && deviceSnList.size() > 0) {
            ruleDeviceService.sendDelRuleToDevice(deviceSnList, ruleIds, oserviceOperator);
        }
        //删除规则
        jpaQueryFactory.delete(qRule).where(predicate).execute();
        //删除关联表
        whenDelRule(ruleIds, oserviceOperator.getTenantId());
        //消息推送
        pushRule(ruleIds, oserviceOperator.getTenantId(), Event.EventType.RULE_DELETE);
    }

    /**
     * 删除人员规则和规则下的访客
     *
     * @param ruleId           规则ID
     * @param oserviceOperator 当前操作人信息
     * @throws CommonException
     */
    @Override
    public void delRuleAndPerson(Integer ruleId, OserviceOperator oserviceOperator) {
        List<String> personIdList = ruleApplyService.getPersonIdByRuleId(ruleId, oserviceOperator.getTenantId());
        List<Integer> ruleIdList = new ArrayList<>();
        ruleIdList.add(ruleId);
        try {
            delRules(ruleIdList, oserviceOperator);
        } catch (CommonException e) {
            log.info("删除访客规则异常,{}", e);
            return;
        }
        if (CollectionUtils.isEmpty(personIdList)) {
            return;
        }
        try {
            // 获取要删除人员
            Page<Person> page;
            Predicate predicate = QPerson.person.tenantId.eq(oserviceOperator.getTenantId());
            predicate = ((BooleanExpression) predicate).and(QPerson.person.id.in(personIdList));
            Sort sort = new Sort(Sort.Direction.ASC, "id");
            Pageable pageable = new PageRequest(0, Constant.PERSON_PAGEABLE_SIZE, sort);
            List<HistoryPerson> historyPersonList = new ArrayList<>();
            HistoryPerson historyPerson = new HistoryPerson();
            do {
                page = personRepository.findAll(predicate, pageable);
                pageable = new PageRequest(page.getNumber() + 1, page.getSize(), sort);
                if (page.getNumberOfElements() > 0) {
                    int i = 0;
                    List<Person> personList = page.getContent();
                    for (Person person : personList) {
                        entityManager.unwrap(Session.class).evict(person);
                        BeanUtils.copyProperties(person, historyPerson);
                        historyPerson.setOperatorId(oserviceOperator.getUserId());
                        historyPerson.setOperatorName(oserviceOperator.getLoginName());
                        historyPerson.setUpdateTime(new Date());
                        historyPersonList.add(historyPerson);
                        if ((i + 1) % Constant.BATCH_INSERT_SIZE == 0) {
                            historyPersonRepository.save(historyPersonList);
                            historyPersonList = new ArrayList<>();
                        }
                        i++;
                    }
                    if (CollectionUtils.isNotEmpty(historyPersonList)) {
                        historyPersonRepository.save(historyPersonList);
                        historyPersonList = new ArrayList<>();
                    }
                }
            } while (!page.isLast());
            jpaQueryFactory.delete(QPerson.person).where(predicate).execute();
        } catch (Exception e) {
            log.info("删除访客异常,{}", e);
        }
    }


    /**
     * 删除规则时调用此接口
     *
     * @param ruleIdList 人员ID集合
     * @param tenantId   租户ID
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void whenDelRule(List<Integer> ruleIdList, long tenantId) {
        if (ruleIdList == null || ruleIdList.size() == 0) {
            return;
        }
        QRuleApply qRuleApply = QRuleApply.ruleApply;
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        //删除规则人员关联表
        jpaQueryFactory.delete(qRuleApply).where(qRuleApply.ruleId.in(ruleIdList).and(qRuleApply.tenantId.eq(tenantId))).execute();
        //删除规则设备关联表
        jpaQueryFactory.delete(qRuleDevice).where(qRuleDevice.ruleId.in(ruleIdList).and(qRuleDevice.tenantId.eq(tenantId))).execute();
    }

    /**
     * 添加规则
     *
     * @param rule             规则
     * @param oserviceOperator 当前操作人信息
     * @return 添加后的规则信息
     * @throws CommonException
     */
    @Override
    public Rule addRule(Rule rule, OserviceOperator oserviceOperator) throws CommonException {
        rule.setId(null);
        rule.setCreateBy(String.valueOf(oserviceOperator.getUserId()));
        rule.setTenantId(oserviceOperator.getTenantId());
        rule.setAppId(oserviceOperator.getAppId());
        rule.setCreateTime(new Date());
        rule.setUpdateTime(rule.getCreateTime());
        Rule newRule = ruleRepository.save(rule);
        newRule.setStatus(Calendar.getInstance().before(rule.getValidTill()) ? Rule.Status.NORMAL : Rule.Status.FINISH);
        rule.setId(newRule.getId());
        //添加规则与人员的关系表
        ruleApplyService.addRuleApply(rule, oserviceOperator);
        //新增的规则未与设备绑定，所以不下发到设备，在/rule/device/issue/接口中下发到设备
        return newRule;
    }

    /**
     * 添加规则（异步方法）
     *
     * @param rule             规则
     * @param oserviceOperator 当前操作人信息
     * @return 添加后的规则信息
     * @throws Exception
     */
//    @Async
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void addRuleAsync(Rule rule, OserviceOperator oserviceOperator) {
        try {
            addRule(rule, oserviceOperator);
            //消息推送
            pushRule(rule, oserviceOperator.getTenantId(), Event.EventType.RULE_ADD);
        } catch (Exception e) {
            log.error("异步添加规则异常：{}", e);
        } finally {
            redisService.deleteKey(oserviceOperator.getUserId() + "_ADD_LOCK");
        }
    }

    /**
     * 更新规则（异步方法）
     *
     * @param rule             规则
     * @param oserviceOperator 当前操作人信息
     */
//    @Async
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void updateRuleAsync(Rule rule, OserviceOperator oserviceOperator) {
        try {
            //修改规则
            save(rule);
            //获取规则绑定的设备
            List<String> deviceSnList = ruleDeviceService.getSnsByRuleId(rule.getId());
            //发送GetRule指令
            ruleDeviceService.sendGetRuleToDevice(deviceSnList, rule.toDomainRule(authorizeProperties.getClientId()), oserviceOperator);
            if (rule.getType() == Rule.RuleType.PERSON.ordinal()) {
                if (CollectionUtils.isNotEmpty(rule.getOrganizationIds())) {
                    List<String> personList = orgIdToPersonId(rule.getOrganizationIds(), oserviceOperator.getTenantId());
                    rule.getPersonIds().removeAll(personList);
                    rule.getPersonIds().addAll(personList);
                }
                List<String> removePersonIdList = ruleApplyService.getPersonIdByRuleId(rule.getId(), oserviceOperator.getTenantId());
                List<String> addPersonIdList = new ArrayList<>(rule.getPersonIds());
                addPersonIdList.removeAll(removePersonIdList);
                removePersonIdList.removeAll(rule.getPersonIds());
                //人员移出规则
                ruleApplyService.removePersonFromRule(rule.getId(), removePersonIdList, oserviceOperator, deviceSnList);
                //人员添加到规则
                ruleApplyService.addPersonToRule(rule.getId(), addPersonIdList, oserviceOperator, deviceSnList);
            } else if (rule.getType() == Rule.RuleType.ORGNIZATION.ordinal()) {
                List<Integer> removeOrgIdList = ruleApplyService.getOrganizationIdByRuleId(rule.getId(), oserviceOperator.getTenantId());
                List<Integer> addOrgIdList = new ArrayList<>(rule.getOrganizationIds());
                addOrgIdList.removeAll(removeOrgIdList);
                removeOrgIdList.removeAll(rule.getOrganizationIds());
                //组织移出规则
                ruleApplyService.removeOrgFromRule(rule.getId(), removeOrgIdList, oserviceOperator, deviceSnList);
                //组织添加到规则
                ruleApplyService.addOrgToRule(rule.getId(), addOrgIdList, oserviceOperator, deviceSnList);
            }
            //规则更新 消息推送
            pushRule(rule, oserviceOperator.getTenantId(), Event.EventType.RULE_UPDATE);
        } catch (Exception e) {
            log.error("异步更新规则异常：{}", e);
        } finally {
            redisService.deleteKey(oserviceOperator.getUserId() + "_UPDATE_LOCK");
        }
    }

    /**
     * 强制更新规则（异步方法）
     *
     * @param rule             规则
     * @param oserviceOperator 当前操作人
     */
//    @Async
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void compulsoryUpdateAsync(Rule rule, OserviceOperator oserviceOperator) {
        try {
            save(rule);
            List<String> deviceSns = ruleDeviceService.getSnsByRuleId(rule.getId());
            if (CollectionUtils.isEmpty(deviceSns)) {
                return;
            }
            ruleDeviceService.sendGetRuleToDevice(deviceSns, rule.toDomainRule(authorizeProperties.getClientId()), oserviceOperator);
            List<String> personIdList;
            if (rule.getType() == Rule.RuleType.PERSON.ordinal()) {
                personIdList = ruleApplyService.getPersonIdByRuleId(rule.getId(), oserviceOperator.getTenantId());
            } else if (CollectionUtils.isNotEmpty(rule.getOrganizationIds())) {
                personIdList = orgIdToPersonId(rule.getOrganizationIds(), oserviceOperator.getTenantId());
            } else {
                return;
            }
            if (CollectionUtils.isEmpty(personIdList)) {
                return;
            }
            String commandId = ruleApplySyncService.insertApplySync(rule.getId(), IDRuleResp.OperationType.BIND, personIdList);
            ruleApplyService.sendRuleApplyToDevice(deviceSns, commandId, IDRuleResp.OperationType.BIND, oserviceOperator);
        } catch (Exception e) {
            log.error("异步强制更新规则异常：{}", e);
        } finally {
            redisService.deleteKey(oserviceOperator.getUserId() + "_UPDATE_LOCK");
        }
    }

    /**
     * 修改过期的规则
     *
     * @param rule             过期规则
     * @param oserviceOperator 当前操作人信息
     * @throws CommonException
     */
    @Override
    @Transactional(rollbackFor = Exception.class)
    public void modifyOverdueRule(Rule rule, OserviceOperator oserviceOperator) throws Exception {
        QRuleDevice qRuleDevice = QRuleDevice.ruleDevice;
        List<String> deviceSnList = jpaQueryFactory
                .select(qRuleDevice.deviceSn)
                .from(qRuleDevice)
                .where(qRuleDevice.ruleId.eq(rule.getId()).and(qRuleDevice.tenantId.eq(oserviceOperator.getTenantId())))
                .fetch();
        //删除规则
        QRule qRule = QRule.rule;
        jpaQueryFactory.delete(qRule).where(qRule.id.eq(rule.getId())).execute();
        List<Integer> ruleIdList = new ArrayList<>();
        ruleIdList.add(rule.getId());
        //删除关联表
        whenDelRule(ruleIdList, oserviceOperator.getTenantId());
        //创建规则
        Rule newRule = addRule(rule, oserviceOperator);
        if (newRule == null) {
            throw new CommonException("database.operate.failed");
        }
        if (deviceSnList != null && !deviceSnList.isEmpty()) {
            ruleDeviceService.addDeviceToRule(deviceSnList, newRule, oserviceOperator);
        }
    }

    /**
     * 根据id和租户id获取规则
     *
     * @param id
     * @param tenantId
     * @return
     */
    @Override
    public Rule findRuleByIdAndTenantId(int id, long tenantId) {
        return ruleRepository.findRuleByIdAndTenantId(id, tenantId);
    }

    /**
     * 根据姓名查询规则
     *
     * @param name
     * @param tenantId
     * @return
     */
    @Override
    public Rule findRuleByNameAndTenantId(String name, long tenantId) {
        return ruleRepository.findRuleByNameAndTenantId(name, tenantId);
    }

    /**
     * 查询列表
     *
     * @param predicate 查询条件
     * @param pageable  分页信息
     * @return
     */
    @Override
    public Page<Rule> findAll(Predicate predicate, Pageable pageable) {
        return ruleRepository.findAll(predicate, pageable);
    }

    /**
     * 保存规则
     *
     * @param rule 规则内容
     * @return
     */
    @Override
    public Rule save(Rule rule) {
        return ruleRepository.save(rule);
    }

    /**
     * 推送规则
     *
     * @param obj       规则
     * @param tenantId  租户ID
     * @param eventType 事件类型
     */
    @Override
    public void pushRule(Object obj, long tenantId, Event.EventType eventType) {
        //消息推送
        log.info("推送规则：eventType:{}", eventType.name());
        log.debug("推送内容：{}", obj);
        Event event = EventBuilder.newBuilder()
                .tenantId(String.valueOf(tenantId))
                .entity(JSONObject.toJSONString(obj))
                .timestamp(System.currentTimeMillis())
                .type(eventType).build();
        pushClient.send(event);
    }


}
