package com.opnext.oservice.feign;

import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.domain.request.FeedBackRequest;
import com.opnext.omessage.support.MessageContext;
import com.opnext.oservice.domain.device.CommandRetry;
import com.opnext.oservice.dto.PageFeign;
import com.opnext.oservice.dto.command.CommandRecord;
import com.opnext.oservice.feign.impl.OMessageHystrixFallFactory;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @author tianzc
 */
@FeignClient(value = "o-message", path = "/o-message/api", fallbackFactory = OMessageHystrixFallFactory.class)
public interface OMessageFeign {
    /**
     * 发送命令
     *
     * 在方法中写入如下代码来创建MessageContext，SimpleMessageTemplate是非线程安全的，请不要将他单例化
     * scope方法应该填入实际的设备列表，传入DEBUG在测试环境下回群发所有已注册的终端实例
     * scope方法后面调用具体的业务方法。
     *
     * @param messageContext
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    List<String> send(@RequestBody MessageContext messageContext);


    /**
     * 删除设备失败指令
     * @param sn
     * @return
     */
    @RequestMapping(value = "/all/command/fail/{sn}", method = RequestMethod.GET)
    ResponseEntity deleteCommand(@PathVariable("sn") String sn) throws Exception;


    /**
     * CallBack在bbox-service中处理的时候需要调用该方法
     * @param workflowId
     * @param commandId
     * @param requestId
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/callback/{workflowId}/{commandId}/{requestId}", method = RequestMethod.GET)
    ResponseEntity callback(@PathVariable("workflowId") String workflowId, @PathVariable("commandId") String commandId, @PathVariable("requestId") String requestId) throws Exception;

    /**
     * 回调地址是消息的终结状态，由终端上报给服务端，通常是POST请求，
     * 接入和交互方式和Callback基本一致，需要增加一个FeedBackRequest，目前业务端不需要关心Feedback
     * @param workflowId
     * @param commandId
     * @param requestId
     * @param feedBackRequest
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/feedback/{workflowId}/{commandId}/{requestId}", method = RequestMethod.POST)
    ResponseEntity feedback(@PathVariable("workflowId") String workflowId, @PathVariable("commandId") String commandId, @PathVariable("requestId") String requestId, @RequestBody FeedBackRequest feedBackRequest) throws Exception;

    /**
     * 获取终端指令记录
     * @param variables
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET, value = "/command/records")
    CommonResponse<PageFeign<CommandRecord>> getCommandRecord(Object... variables) throws Exception;

    /**
     * 通过指令记录id查询指令记录详情
     * @param requestId
     * @param tenantId
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET, value = "/command/record/{requestId}")
    CommonResponse<CommandRecord> getCommandRecordDetail(@PathVariable("requestId") String requestId,@RequestParam("tenantId") String tenantId) throws Exception;

    /**
     * 通过指令记录requestId 重新下发
     * @param commandRetry
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.POST, value = "/retry")
    CommonResponse commandRetry(@RequestBody CommandRetry commandRetry) throws Exception;

}
