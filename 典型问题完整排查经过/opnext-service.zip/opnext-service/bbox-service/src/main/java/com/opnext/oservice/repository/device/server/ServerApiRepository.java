package com.opnext.oservice.repository.device.server;

import com.opnext.oservice.domain.device.ServerApi;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:06 18/5/7
 */
public interface ServerApiRepository extends PagingAndSortingRepository<ServerApi, Integer>, QueryDslPredicateExecutor {
}
