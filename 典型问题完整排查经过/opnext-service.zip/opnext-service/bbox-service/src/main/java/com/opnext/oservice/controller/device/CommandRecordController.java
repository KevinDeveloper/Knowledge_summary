package com.opnext.oservice.controller.device;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.validator.IsTimestampLongValidator;
import com.opnext.domain.message.Code;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.dto.command.CommandRecord;
import com.opnext.oservice.dto.command.SearchCommandReq;
import com.opnext.oservice.service.device.CommandRecordService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author
 */
@Slf4j
@RestController
@RequestMapping("/api/device/command")
public class CommandRecordController {

    @Resource
    private CommandRecordService commandRecordService;

    @ApiOperation(value = "获取指令列表", notes = "获取告警级别，返回枚举字符串，需要定义字符串的国际化文字")
    @RequestMapping(value = "/code",method = RequestMethod.GET)
    public Code[] getCommandCode(){
         return Stream.of(Code.values()).filter(code -> code.value() >= 100).toArray(Code[]::new);
    }

    @ApiOperation(value = "查询命令下发记录", notes = "获取查询命令下发记录列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "long", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "query", dataType = "long", name = "endTime", value = "结束时间"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sn", value = "设备sn号"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "code", value = "指令类型"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "page", value = "分页页码，从0开始"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "size", value = "分页条数，默认10"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=xxx,desc表示根据xxx字段倒叙排序")
    })
    @RequestMapping(value = "/records",method = RequestMethod.GET)
    public Page<CommandRecord> getCommandRecords(@RequestParam(required = false) Long startTime,
                                                 @RequestParam(required = false) Long endTime,
                                                 @RequestParam(required = false) String sn,
                                                 @RequestParam(required = false) Code code,
                                                 @RequestParam(required = false) Integer page,
                                                 @RequestParam(required = false) Integer size,
                                                 @RequestParam(required = false) String sort)throws Exception{
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(startTime, new IsTimestampLongValidator("startTime"))
                .on(endTime, new IsTimestampLongValidator("endTime"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("指令查询失败，开始、结束时间参数错误");
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        SearchCommandReq searchCommandReq = new SearchCommandReq();
        if (startTime != null){
            searchCommandReq.setStartTime(startTime);
        }
        if (endTime !=null){
            searchCommandReq.setEndTime(endTime);
        }
        if (StringUtils.isNotBlank(sn)){
            Set<String> sns = new HashSet<>(1);
            sns.add(sn);
            searchCommandReq.setSns(sns);
        }
        if (code !=null){
            Set<Code> codes = new HashSet<>(1);
            codes.add(code);
            searchCommandReq.setCode(codes);
        }
        if (page!=null){
            searchCommandReq.setPage(page);
        }
        if (size!=null){
            searchCommandReq.setSize(size);
        }
        if (sort!=null){
            searchCommandReq.setSort(sort);
        }
        Set<String> tenantIds = new HashSet<>(1);
        tenantIds.add(oserviceOperator.getTenantId()+"");
        searchCommandReq.setTenantIds(tenantIds);
        Page<CommandRecord> commandRecordPage =  commandRecordService.getCommandRecords(searchCommandReq);
        return commandRecordPage;
    }

    @ApiOperation(value = "查询指令记录详情", notes = "根据指令记录id查询指令下发记录的详情")
    @RequestMapping(value = "/record/{requestId}",method = RequestMethod.GET)
    public CommandRecord getCommandRecords(@PathVariable String requestId)throws Exception{
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        CommandRecord commandRecord =  commandRecordService.getCommandRecordDetail(requestId, oserviceOperator.getTenantId()+"");
        return commandRecord;
    }

    @ApiOperation(value = "重新下发指令", notes = "根据requestId重新下发指令")
    @RequestMapping(value = "/{requestId}/_retry",method = RequestMethod.POST)
    public CommonResponse sendCommand(@PathVariable String requestId) throws Exception{
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        commandRecordService.sendCommand(requestId, oserviceOperator);
        return CommonResponse.ok(new HashMap<>());
    }
}
