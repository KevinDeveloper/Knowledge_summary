package com.opnext.oservice.controller.device;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.opnext.bboxdomain.context.CommonContext;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.domain.device.DeviceAdmin;
import com.opnext.oservice.domain.device.SearchDevice;
import com.opnext.oservice.repository.device.DeviceAdminRepository;
import com.opnext.oservice.service.device.DeviceAdminService;
import com.opnext.oservice.service.device.DeviceService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @Title: 设备管理员Controller
 * @Description: --
 * @author tianzc
 * @Date 下午4:45 18/5/7
 */
@Slf4j
@RestController
@RequestMapping("/api/device/admin")
public class DeviceAdminController {

    @Autowired
    DeviceAdminRepository deviceAdminRepository;
    @Autowired
    DeviceAdminService adminService;
    @Autowired
    DeviceService deviceService;

    @ApiOperation(value = "设备管理员列表", notes = "获取设备管理员列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "name", value = "设备管理员姓名"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "phone", value = "手机号"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=version,updateTime,asc&sort=name,desc")
    })
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    public Page page(@PageableDefault Pageable pageable, String name, String phone) throws Exception{
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        Page page =  adminService.getPage(pageable, name, phone, urlPrefix);
        return page;
    }

    @ApiOperation(value = "单个获取设备管理员", notes = "根据id获取设备管理员")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public CommonResponse<DeviceAdmin> getInfo(@PathVariable Integer id) throws Exception{
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        DeviceAdmin deviceAdmin = adminService.getInfo(id,urlPrefix);
        return CommonResponse.ok(deviceAdmin);
    }

    @ApiOperation(value = "保存设备管理员", notes = "")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public CommonResponse<DeviceAdmin> save(@RequestBody DeviceAdmin deviceAdmin) throws Exception {
        // 数据校验
        ComplexResult ret  = adminService.fluentValidator(deviceAdmin);
        if(!ret.isSuccess()){
            log.error("新建设备管理员参数异常{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        DeviceAdmin resultAdmin = adminService.save(deviceAdmin,urlPrefix);
        return CommonResponse.ok(resultAdmin);
    }

    @ApiOperation(value = "更新设备管理员", notes = "待完善tianzc，下发指令，通知设备更新管理员")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public void update(@RequestBody DeviceAdmin deviceAdmin) throws Exception {
        log.info("设备管理员更新deviceAdmin：{}", deviceAdmin);
        // 数据校验
        ComplexResult ret  = adminService.fluentValidator(deviceAdmin);
        if(!ret.isSuccess()){
            log.error("更新设备管理员参数异常{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        adminService.update(deviceAdmin,urlPrefix);
    }

    @ApiOperation(value = "删除设备管理员", notes = "下发指令，通知设备更新管理员")
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public void delete(@RequestBody Integer[] ids) throws Exception {
        adminService.delete(ids);
    }

    @ApiIgnore()
    @ApiOperation(value = "根据设备管理员获取设备列表", notes = "获取设备列表返回")
    @RequestMapping(value = "/page/{id}", method = RequestMethod.GET)
    public CommonResponse<Page> getDevicePage(@PageableDefault Pageable pageable, SearchDevice sDevice, @PathVariable Integer id) throws Exception {
        Page page = adminService.getDevicePage(pageable,sDevice,id);
        return CommonResponse.ok(page);
    }

    @ApiOperation(value = "管理员关联设备", notes = "")
    @RequestMapping(value = "/devicerel/{id}", method = RequestMethod.POST)
    public void bindDevice(@RequestBody Integer[] deviceIds, @PathVariable Integer id) throws Exception {
        log.info("管理员关联设备参数deviceIds：{}，id：{}", deviceIds, id);
        adminService.bindDevice(deviceIds,id);
    }

    /**
     * 解绑设备管理员
     * 下发指令，终端更新管理员
     *
     * @return
     * @throws Exception
     */
    @ApiOperation(value = "解绑设备管理员", notes = "待完善tianzc，下发指令，终端更新管理员")
    @RequestMapping(value = "/devicerel/delete/{id}", method = RequestMethod.POST)
    public void deleteDeviceAdmin(@RequestBody Integer[] deviceIds, @PathVariable Integer id) throws Exception {
        log.info("解绑设备管理员参数deviceIds：{}，id：{}", deviceIds, id);
        Integer[] adminIds = {id};
        adminService.deleteDeviceAdmin(deviceIds, adminIds);
    }

}
