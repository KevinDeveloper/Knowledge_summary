package com.opnext.oservice.repository.command;

import com.opnext.oservice.domain.command.CommandErrorInfo;
import com.opnext.oservice.repository.base.impl.BaseMongoDaoImpl;
import org.springframework.stereotype.Service;

/**
 * @author tianzc
 */
@Service
public class CommandErrorInfoDao extends BaseMongoDaoImpl<CommandErrorInfo> {
}
