package com.opnext.oservice.service.rule;

import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.domain.response.IDRuleResp;
import com.opnext.domain.response.RulePersonResp;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 15:56
 */
public interface RuleApplySyncService {

    /**
     * 获取要下发的人员信息
     *
     * @param batchId
     * @param workflowId
     * @param commandId
     * @param requestId
     * @param pageable
     * @return
     * @throws CommonException
     */
    RulePersonResp getRulePerson(String batchId, String workflowId, String commandId, String requestId, Pageable pageable, RequestUrlPrefix urlPrefix) throws CommonException;

    /**
     * 获取绑定人员信息
     *
     * @param ruleId
     * @param batchId
     * @param workflowId
     * @param commandId
     * @param requestId
     * @param pageable
     * @return
     */
    RulePersonResp getBindPerson(int ruleId, String batchId, String workflowId, String commandId, String requestId, Pageable pageable,RequestUrlPrefix urlPrefix);

    /**
     * 获取解绑人员信息
     *
     * @param ruleId
     * @param batchId
     * @param workflowId
     * @param commandId
     * @param requestId
     * @param pageable
     * @return
     */
    RulePersonResp getUnBindPerson(int ruleId, String batchId, String workflowId, String commandId, String requestId, Pageable pageable,RequestUrlPrefix urlPrefix);

    /**
     * 根据人员ID列表添加人员解绑信息到规则应用同步表中
     *
     * @param ruleId        规则ID
     * @param operationType 操作类型（BIND;绑定、UNBIND:解绑）
     * @param personIdList  人员ID列表
     * @return 本次添加的批次ID
     */
    String insertApplySync(int ruleId, IDRuleResp.OperationType operationType, List<String> personIdList);
}
