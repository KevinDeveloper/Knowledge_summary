package com.opnext.oservice.util;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.opnext.domain.config.OConfig;
import com.opnext.domain.config.OConfigGroup;
import com.opnext.domain.descriptor.VisibleDescriptor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author tianzc
 */
@Slf4j
public class HandleDeviceConfig {

    /**
     * 处理Object对象转成OConfigGroup
     * @param oConfig
     * @return
     * @throws Exception
     */
    public static OConfigGroup objectToOConfigGroup(OConfig oConfig) throws Exception {
        Object getObjVal = oConfig.getValue();
        if (!(getObjVal instanceof OConfigGroup || getObjVal instanceof Map)) {
            return null;
        }
        OConfigGroup configGroup = null;
        // 判断object类型
        if (getObjVal instanceof Map) {
            Map map = (Map) oConfig.getValue();
            configGroup = JsonConvertor.jsonToBean(JsonConvertor.mapToJson(map), OConfigGroup.class);
            oConfig.setValue(configGroup);
        } else {
            configGroup = (OConfigGroup) oConfig.getValue();
        }
        return configGroup;
    }

    /**
     * 修改指定key对应OConfig的key值
     * @param key
     * @param oConfig
     * @param setKey
     * @return
     * @throws Exception
     */
    public static OConfig setOconfigGroupKey(String key, OConfig oConfig, String setKey) throws Exception {
        if (StringUtils.isNoneBlank(oConfig.getKey()) && key.equals(oConfig.getKey())){
            oConfig.setKey(setKey);
            return oConfig;
        }
        // 获取对象
        OConfigGroup configGroup = objectToOConfigGroup(oConfig);
        if (Objects.isNull(configGroup)) {
            return null;
        }
        OConfig configResp = null;
        Iterator<OConfig> it = configGroup.getConfigList().iterator();
        while (it.hasNext()) {
            OConfig configIt = it.next();
            configResp = setOconfigGroupKey(key, configIt, setKey);
            if (configResp != null){
                break;
            }
        }
        if (configResp != null){
            ((OConfigGroup) oConfig.getValue()).setConfigList(Lists.newArrayList(configResp));
        } else {
            return null;
        }
        return oConfig;
    }

    /**
     * 根据key值修改指定config的name，或desc描述
     * @param key
     * @param oConfig
     * @return
     */
    public static OConfig setOconfigGroupVals(String key, OConfig oConfig, String... vals) throws Exception {
        if (StringUtils.isNoneBlank(oConfig.getKey()) && key.equals(oConfig.getKey())){
            int len = vals.length;
            if (len > 2) {
                throw new Exception("length limit 2");
            }
            if (len == 1) {
                OConfigGroup oConfigGroup = objectToOConfigGroup(oConfig);
                oConfigGroup.setName(vals[0]);
                VisibleDescriptor descriptor = oConfig.getDescriptor();
                descriptor.setExplain(vals[0]);
            } else {
                OConfigGroup oConfigGroup = objectToOConfigGroup(oConfig);
                oConfigGroup.setName(vals[0]);
                VisibleDescriptor descriptor = oConfig.getDescriptor();
                descriptor.setExplain(vals[1]);
            }
            return oConfig;
        }
        // 获取对象
        OConfigGroup configGroup = objectToOConfigGroup(oConfig);
        if (Objects.isNull(configGroup)) {
            return null;
        }
        OConfig configResp = null;
        Iterator<OConfig> it = configGroup.getConfigList().iterator();
        while (it.hasNext()) {
            OConfig configIt = it.next();
            configResp = setOconfigGroupVals(key, configIt, vals);
            if (configResp != null){
                break;
            }
        }
        if (configResp != null){
            ((OConfigGroup) oConfig.getValue()).setConfigList(Lists.newArrayList(configResp));
        } else {
            return null;
        }
        return oConfig;
    }

    /**
     *  获取保留结构OConfig
     * @param key
     * @param oConfig
     * @return
     * @throws Exception
     */
    public static OConfig getTreeObject(String key, OConfig oConfig) throws Exception {
        return getTreeObject(key,oConfig, null);
    }
    public static OConfig getTreeObject(String key, OConfig oConfig, List<OConfig> oConfigList) throws Exception {
        return getTreeObject(key, oConfig, oConfigList,false);
    }
    public static OConfig getTreeObject(String key, OConfig oConfig, List<OConfig> oConfigList, boolean addFlag) throws Exception {
        return getOConfig(key, null, oConfig, true, oConfigList, addFlag);
    }

    /**
     *
     * @param key       指定要处理的可以
     * @param holdKey   需要保留数据的key集合
     * @param oConfig   原始数据
     * @return
     * @throws Exception
     */
    public static OConfig getTreeObject(String key, List<String> holdKey, OConfig oConfig) throws Exception {
        return getTreeObject(key, holdKey, oConfig, null);
    }
    /**
     * 获取根据key值获取指定数据的数据或数据结构
     * @param key           指定要处理的可以
     * @param holdKey       需要保留的key对应值
     * @param oConfig       原始数据
     * @param oConfigList   对指定key数据修改的数据
     * @return
     * @throws Exception
     */
    public static OConfig getTreeObject(String key, List<String> holdKey, OConfig oConfig,List<OConfig> oConfigList) throws Exception {
        return getTreeObject(key, holdKey, oConfig, oConfigList, false);
    }
    /**
     * 获取根据key值获取指定数据的数据或数据结构
     * @param key           指定的ley
     * @param holdKey       需要保留的key对应值
     * @param oConfig       原始数据
     * @param oConfigList   需要处理的数据
     * @param addFlag       默认false，数据覆盖，true新增
     * @return
     * @throws Exception
     */
    public static OConfig getTreeObject(String key,List<String> holdKey, OConfig oConfig, List<OConfig> oConfigList, boolean addFlag) throws Exception {
        return getOConfig(key, holdKey, oConfig, true, oConfigList, addFlag);
    }

    /**
     * 获取根据key值获取指定数据的数据或数据结构
     * @param key           指定的ley
     * @param oConfig       原始数据
     * @return
     * @throws Exception
     */
    public static OConfig getOConfig(String key, OConfig oConfig) throws Exception{
        return getOConfig(key, oConfig, null);
    }
    /**
     * 获取根据key值获取指定数据的数据或数据结构
     * @param key           指定的ley
     * @param oConfig       原始数据
     * @param oConfigList   需要处理的数据
     * @return
     * @throws Exception
     */
    public static OConfig getOConfig(String key, OConfig oConfig, List<OConfig> oConfigList) throws Exception{
        return getOConfig(key, oConfig, oConfigList, false);
    }
    /**
     * 获取根据key值获取指定数据的数据或数据结构
     * @param key           指定的ley
     * @param oConfig       原始数据
     * @param oConfigList   需要处理的数据
     * @param addFlag       默认false，数据覆盖，true新增
     * @return
     * @throws Exception
     */
    public static OConfig getOConfig(String key, OConfig oConfig,List<OConfig> oConfigList,Boolean addFlag) throws Exception {
        return getOConfig(key,null, oConfig,false, oConfigList, addFlag);
    }

    /**
     * 获取根据key值获取指定数据的数据或数据结构
     * @param key           指定的ley
     * @param holdKey       需要保留的key对应值
     * @param oConfig       原始数据
     * @param treeFlag      是否保留结构
     * @param oConfigList   需要处理的数据
     * @param addFlag       默认false，数据覆盖，true新增
     * @return
     * @throws Exception
     */
    public static OConfig getOConfig(String key,List<String> holdKey, OConfig oConfig, Boolean treeFlag, List<OConfig> oConfigList, Boolean addFlag) throws Exception {
        // 判断如果传值为null，直接返回
        if (Objects.isNull(oConfig)){
            return null;
        }
        // 判断是否满足key条件
        if (StringUtils.isNoneBlank(oConfig.getKey()) && key.equals(oConfig.getKey())){
            if (Objects.nonNull(oConfigList)) {
                OConfigGroup configGroup = objectToOConfigGroup(oConfig);
                // 添加标志为真进行新增
                if (addFlag) {
                    configGroup.getConfigList().addAll(oConfigList);
                } else {
                    // 为false覆盖
                    configGroup.setConfigList(oConfigList);
                }
                oConfig.setValue(configGroup);
            }
            return oConfig;
        }
        OConfig configResp = null;
        // 获取对象
        OConfigGroup configGroup = objectToOConfigGroup(oConfig);
        if (Objects.isNull(configGroup)) {
            return null;
        }
        Iterator<OConfig> it = configGroup.getConfigList().iterator();
        while (it.hasNext()) {
            OConfig configIt = it.next();
            configResp = getOConfig(key,holdKey,configIt,treeFlag, oConfigList, addFlag);
            if (configResp != null){
                break;
            }
        }
        if (treeFlag) {
            if (configResp != null){
                if (Objects.nonNull(holdKey)) {
                    OConfigGroup temp = (OConfigGroup) oConfig.getValue();
                    List<OConfig> configList = new ArrayList<>();
                    //不存在移除OConfig
                    Iterator<OConfig> tempIt = temp.getConfigList().iterator();
                    while (tempIt.hasNext()) {
                        OConfig configTempIt = tempIt.next();
                        if(holdKey.contains(configTempIt.getKey())){
                            configList.add(configTempIt);
                        } else {
                            tempIt.remove();
                        }
                    }
                    configList.add(configResp);
                    temp.setConfigList(configList);
                } else {
                    ((OConfigGroup) oConfig.getValue()).setConfigList(Lists.newArrayList(configResp));
                }
            } else {
                return null;
            }
            return oConfig;
        } else {
            return configResp;
        }
    }

    /**
     * 移除指定节点
     * @param key
     * @param oConfig
     * @return
     */
    public static OConfig removeConfig(String key, OConfig oConfig) throws Exception {
        if (StringUtils.isNoneBlank(oConfig.getKey()) && key.equals(oConfig.getKey())){
            return oConfig;
        }
        OConfig configResp = null;
        // 获取对象
        OConfigGroup configGroup = objectToOConfigGroup(oConfig);
        if (Objects.isNull(configGroup)) {
            return null;
        }
        Iterator<OConfig> it = configGroup.getConfigList().iterator();
        while (it.hasNext()) {
            OConfig configIt = it.next();
            configResp = removeConfig(key, configIt);
            if (configResp != null){
                break;
            }
        }
        if (configResp != null){
            if (StringUtils.isNoneBlank(configResp.getKey()) && key.equals(configResp.getKey())) {
                ((OConfigGroup) oConfig.getValue()).getConfigList().remove(configResp);
            }
        } else {
            return null;
        }
        return oConfig;
    }

    /**
     * 数据组装处理，包装一层，统一数据结构
     * @return
     */
    public static OConfig encapsulationObject(OConfigGroup oConfigGroup) {
        OConfig oConfig = new OConfig();
        oConfig.setValue(oConfigGroup);
        return oConfig;
    }

    /**
     * 将格式化还原，获取OConfigGroup
     * @return
     */
    public static OConfigGroup getOConfigGroup(OConfig oConfig){
        OConfigGroup oConfigGroup = (OConfigGroup) oConfig.getValue();
        return oConfigGroup;
    }

    public static OConfigGroup getStringToConfig() throws IOException {
        String jsonStr = "{\"configList\":[{\"descriptor\":{\"explain\":\"关于设备\",\"limit\":0,\"readonly\":false,\"required\":true,\"ui\":{\"type\":\"TEXTAREA\"},\"unique\":true},\"key\":\"about_device\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"设备名称\",\"limit\":0,\"readonly\":true,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.deviceName\",\"value\":\"10002\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"设备类型\",\"limit\":0,\"readonly\":true,\"required\":true,\"unique\":true},\"key\":\"ro.setting.deviceType\",\"value\":\"闸机\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"SN\",\"limit\":0,\"readonly\":true,\"required\":true,\"unique\":true},\"key\":\"ro.setting.deviceSn\",\"value\":\"C1030231727087\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"软件版本号\",\"limit\":0,\"readonly\":true,\"required\":true,\"unique\":true},\"key\":\"ro.setting.softVersion\",\"value\":\"2.0\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"算法版本号\",\"limit\":0,\"readonly\":true,\"required\":true,\"unique\":true},\"key\":\"ro.setting.algorithmVersion\",\"value\":\"6.0\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"硬件版本号\",\"limit\":0,\"readonly\":true,\"required\":true,\"unique\":true},\"key\":\"ro.setting.hardwareVersion\",\"value\":\"V3.0\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"无线MAC地址\",\"limit\":0,\"readonly\":true,\"required\":true,\"unique\":true},\"key\":\"ro.setting.wifiAddress\",\"value\":\"00-00-00-00-00-00-E0\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"有线MAC地址\",\"limit\":0,\"readonly\":true,\"required\":true,\"unique\":true},\"key\":\"ro.setting.wiredAddress\",\"value\":\"00-00-00-00-00-00-E0\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"人数上限\",\"limit\":0,\"readonly\":true,\"required\":true,\"unique\":true},\"key\":\"ro.setting.maxmember\",\"value\":\"20000\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"制造商\",\"limit\":0,\"readonly\":true,\"required\":true,\"unique\":true},\"key\":\"ro.setting.manufacturer\",\"value\":\"公司\"}],\"name\":\"关于设备\"}},{\"descriptor\":{\"explain\":\"通用设置\",\"limit\":0,\"readonly\":false,\"required\":true,\"ui\":{\"type\":\"TEXT\"},\"unique\":true},\"key\":\"common_setting\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"items\":[{\"name\":\"简体中文\",\"value\":\"0\"},{\"name\":\"英文\",\"value\":\"1\"}],\"type\":\"SELECT\"},\"explain\":\"系统语言\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.language\",\"value\":\"0\"},{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"音量开关\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.isSilent\",\"value\":\"1\"},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"音量大小\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.voiceNumber\",\"value\":\"5\"},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"音量大小\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.brightness\",\"value\":\"91\"}],\"name\":\"通用设置\"}},{\"descriptor\":{\"explain\":\"人脸识别设置\",\"limit\":0,\"readonly\":false,\"required\":true,\"ui\":{\"type\":\"TEXT\"},\"unique\":true},\"key\":\"face_recognize_setting\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"照片质量判断\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"quality_check\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"质量判断开关\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.qualityJudgment\",\"value\":\"true\"},{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"角度限制\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.angleLimit\",\"value\":\"true\"},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"最大模糊度限制(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.fuzzinessLimit\",\"value\":\"66\"},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"遮挡限制(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.obscuredLimit\",\"value\":\"58\"}],\"name\":\"质量判断\"}},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"验证模式\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"verify_mode\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"items\":[{\"name\":\"1:N模式\",\"value\":\"0\"},{\"name\":\"1:1模式\",\"value\":\"1\"},{\"name\":\"混合模式\",\"value\":\"2\"}],\"type\":\"RADIO\"},\"explain\":\"验证模式\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.verificationmode\",\"value\":\"0\"}],\"name\":\"验证模式\"}},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"情景模式\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"profiles_select\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"items\":[{\"name\":\"快速情景\",\"value\":\"0\"},{\"name\":\"安全情景\",\"value\":\"1\"},{\"name\":\"自定义情景\",\"value\":\"2\"}],\"type\":\"RADIO\"},\"explain\":\"情景选择\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.matchlevel\",\"value\":\"2\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"参数设置\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"cumstom_profiles_param_settings\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"活体检测可见光阈值(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.matchThreshold.liveThreshold\",\"value\":\"26\"},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"活体检测近红外阈值(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.matchThreshold.liveNirthreshold\",\"value\":\"17\"},{\"descriptor\":{\"ui\":{\"items\":[{\"name\":\"默认\",\"value\":\"0\"}],\"type\":\"SELECT\"},\"explain\":\"识别参数库设置\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.recognizeDB.id\",\"value\":\"0\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"识别参数库\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"recognize_param_db\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"默认\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"paramDB0\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"可见光阈值(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.visibleLight.matchThreshold.parmaDB0\",\"value\":\"80\"},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"近红外阈值(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.nir.matchThreshold.parmaDB0\",\"value\":\"0\"}],\"name\":\"默认\"}},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"库一\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"parmaDB1\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"使用默认库\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.switch.matchThreshold.parmaDB1\",\"value\":\"false\"},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"可见光阈值(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.visibleLight.matchThreshold.parmaDB1\",\"value\":\"80\"},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"近红外阈值(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.nir.matchThreshold.parmaDB1\",\"value\":\"0\"}],\"name\":\"库一\"}}],\"name\":\"识别参数库\"}},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"可见光阈值(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.matchThreshold.one.threshold\",\"value\":\"28\"}],\"name\":\"人脸识别参数设置\"}}],\"name\":\"情景选择\"}}],\"name\":\"人脸识别设置\"}},{\"descriptor\":{\"explain\":\"门禁信号设置\",\"limit\":0,\"readonly\":false,\"required\":true,\"ui\":{\"type\":\"TEXT\"},\"unique\":true},\"key\":\"access_signal_setting\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"items\":[{\"name\":\"韦根26\",\"value\":\"0\"},{\"name\":\"韦根34\",\"value\":\"1\"},{\"name\":\"韦根36\",\"value\":\"3\"}],\"type\":\"RADIO\"},\"explain\":\"韦根类型\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.entrance\",\"value\":\"0\"},{\"descriptor\":{\"ui\":{\"type\":\"RADIO\"},\"explain\":\"通用韦根类型\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.wiegandOutput\",\"value\":\"26\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"自定义类型\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"wiegand_custom_type\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"奇偶检验\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.number_parity\",\"value\":\"true\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"总位数（26-64）\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.total_digits\",\"value\":\"26\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"数据位数\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.data_digits\",\"value\":\"24\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"首位偶校验（1-23）\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.even_check\",\"value\":\"12\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"末位奇校验\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.odd_check\",\"value\":\"12\"}],\"name\":\"门禁信号设置\"}},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"脉冲间隔（100-2000us）\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.pulse.interval_number\",\"value\":\"1000\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"脉冲宽度(20-400us)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.pulse.width_number\",\"value\":\"100\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"验证卡号位数\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.digits_number\",\"value\":\"24\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"1:1不在库卡号\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.door.card.notin\",\"value\":\"\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"1:1验证失败卡号\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.door.card.fail\",\"value\":\"\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"1:N验证成功卡号\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.door.card.success\",\"value\":\"9999\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"干接点信号时长（200-1000ms）\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.dryContact.duration\",\"value\":\"9999\"}],\"name\":\"门禁信号设置\"}},{\"descriptor\":{\"explain\":\"黑名单\",\"limit\":0,\"readonly\":false,\"required\":true,\"ui\":{\"type\":\"TEXT\"},\"unique\":true},\"key\":\"blacklist\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"本地黑名单\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.localBlack\",\"value\":\"false\"}],\"name\":\"黑名单设置\"}},{\"descriptor\":{\"explain\":\"摄像效果设置\",\"limit\":0,\"readonly\":false,\"required\":true,\"ui\":{\"type\":\"TEXT\"},\"unique\":true},\"key\":\"camera_setting\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"补光灯基础亮度(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.baseLed\",\"value\":\"3\"},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"识别中补光灯亮度(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.ledValue\",\"value\":\"1\"},{\"descriptor\":{\"ui\":{\"max\":30,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"识别中补光灯时长\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.ledTime\",\"value\":\"3\"},{\"descriptor\":{\"ui\":{\"max\":100,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"补光灯识别敏感度(%)\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.ledSensitivity\",\"value\":\"8\"},{\"descriptor\":{\"ui\":{\"max\":140,\"min\":30,\"step\":5,\"type\":\"SLIDEBAR\"},\"explain\":\"最小人脸尺寸\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.MinFace\",\"value\":\"100\"}],\"name\":\"摄像效果设置\"}},{\"descriptor\":{\"explain\":\"更多比对方式设置\",\"limit\":0,\"readonly\":false,\"required\":true,\"ui\":{\"type\":\"TEXT\"},\"unique\":true},\"key\":\"compare_mode\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"二维码通行模式\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.qrTraffic\",\"value\":\"false\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"二次核验\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"again_verify\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"本地核验\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.local.verify.toggle\",\"value\":\"false\"}],\"name\":\"二次核验\"}},{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"指纹\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.fingerprint\",\"value\":\"true\"},{\"descriptor\":{\"ui\":{\"items\":[{\"name\":\"人脸或指纹\",\"value\":\"0\"},{\"name\":\"人脸且指纹\",\"value\":\"1\"}],\"type\":\"SELECT\"},\"explain\":\"指纹验证\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.fingerprint.verify.mode\",\"value\":\"0\"},{\"descriptor\":{\"ui\":{\"max\":1000,\"min\":0,\"step\":1,\"type\":\"SLIDEBAR\"},\"explain\":\"指纹比对阈值\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.fingerprintThreshold\",\"value\":\"600\"}],\"name\":\"更多比对方式设置\"}},{\"descriptor\":{\"explain\":\"待机画面设置\",\"limit\":0,\"readonly\":false,\"required\":true,\"ui\":{\"type\":\"TEXT\"},\"unique\":true},\"key\":\"standby_setting\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"待机显示信息\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.standby.message\",\"value\":\"你好\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"待机壁纸\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"standby_wallpaper\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"开启轮播\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.carousel.switch\",\"value\":\"true\"},{\"descriptor\":{\"ui\":{\"type\":\"TEXTAREA\"},\"explain\":\"每轮时间\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.setting.carousel.time\",\"value\":\"20\"}],\"name\":\"待机壁纸\"}}],\"name\":\"待机页面设置\"}},{\"descriptor\":{\"explain\":\"系统升级\",\"limit\":0,\"readonly\":false,\"required\":true,\"ui\":{\"type\":\"TEXT\"},\"unique\":true},\"key\":\"system_update\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TEXT\"},\"explain\":\"升级配置\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"update_setting\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"自动升级\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.ota.auto.update\",\"value\":\"true\"}],\"name\":\"系统升级\"}}],\"name\":\"升级\"}},{\"descriptor\":{\"explain\":\"时间设置\",\"limit\":0,\"readonly\":false,\"required\":true,\"ui\":{\"type\":\"TEXT\"},\"unique\":true},\"key\":\"data_time_setting\",\"value\":{\"configList\":[{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"使用24小时格式\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.time.format.24hour\",\"value\":\"1\"},{\"descriptor\":{\"ui\":{\"items\":[{\"name\":\"yyyy-mm-dd\",\"value\":\"0\"},{\"name\":\"yyyy年mm月dd日\",\"value\":\"1\"},{\"name\":\"yyyy/mm/dd\",\"value\":\"2\"},{\"name\":\"dd/mm/yyyy\",\"value\":\"3\"},{\"name\":\"mm/dd/yyyy\",\"value\":\"4\"}],\"type\":\"SELECT\"},\"explain\":\"选择日期格式\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.date.format.type\",\"value\":\"2\"},{\"descriptor\":{\"ui\":{\"type\":\"TOGGLE\"},\"explain\":\"时间服务同步开关\",\"limit\":0,\"readonly\":false,\"required\":true,\"unique\":true},\"key\":\"bbox.time.net.sync\",\"value\":\"1\"}],\"name\":\"日期时间\"}}],\"name\":\"设置\"}\n";
        ObjectMapper mapper = new ObjectMapper();
        OConfigGroup oConfigGroup = mapper.readValue(jsonStr, OConfigGroup.class);
        return oConfigGroup;
    }

    public static void main(String[] args) throws Exception {
        String str = JSONObject.toJSONString(getStringToConfig());
        log.info("返回数据oConfig：{}", str);
        OConfig oConfig = encapsulationObject(getStringToConfig());
        log.info("返回数据oConfig：{}",JsonConvertor.beanToJson(oConfig.getValue()));

//        String key = "recognize_param_db";
//        String key = "parmaDB1";
//        OConfigGroup oConfigGroup = getOConfigGroup(getTreeObject(key, oConfig));
//        log.info("根据key：{}，返回数据oConfig：{}",key, JSONObject.toJSONString(oConfigGroup));

        String key = "profiles_select";
        oConfig = getTreeObject(key, oConfig);
        log.info("根据key：{}，返回数据oConfig：{}",key, JSONObject.toJSONString(oConfig));

        key = "bbox.setting.recognizeDB.id";
        oConfig = removeConfig(key, oConfig);
        log.info("移除key：{}，返回数据oConfig：{}",key, JSONObject.toJSONString(oConfig));
        key = "recognize_param_db";
        oConfig = removeConfig(key, oConfig);
        log.info("移除key：{}，返回数据oConfig：{}",key, JSONObject.toJSONString(oConfig));
    }

}
