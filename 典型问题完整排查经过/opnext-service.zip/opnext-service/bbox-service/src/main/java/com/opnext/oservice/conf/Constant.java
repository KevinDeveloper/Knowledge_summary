package com.opnext.oservice.conf;

/**
 * @Title: 常量类
 * @Description:
 * @author tianzc
 * @Date 下午4:45 18/5/7
 */
public interface Constant {

    String ACCESS_RECORD_PREFIX = "accessRecordInfo_";

    String TERMINAL_DEFAULT_ADMIN = "terminal-admin";

    /**
     * 文件上传统一资源标志符
     */
    String FASTDFS_SERVER_UPLOAD_URI = "/ocfs/api/file/upload";

    /**
     * 文件下载统一资源标志符
     */
    String FASTDFS_SERVER_DOWNLOAD_URI = "/ocfs/file/download";

    /**
     * 图片类型名
     */
    String IMAGE_FORMAT_NAME = "jpg";

    /** 返回终端的host中的netty的名称值 */
    String NETTY_HOST_NAME = "netty";
    /**
     * 人员size
     */
    int PERSON_PAGEABLE_SIZE = 1000;
    int BATCH_INSERT_SIZE = 500;

    String CONFIG_REDIS_PATTERN_KEY = "config_redis_";
    String OSERVICE_PERSON_ACCESS_RECORD_ROUTINGKEY = "oservice.person_access_record.send.routing_key";

    /**
     * 异步导入任务失败key
     */
    String ASYNC_TASK_IMPORT_KEY = "asyncTaskImportKey";

    /**
     * 异步导出任务失败key
     */
    String ASYNC_TASK_EXPORT_KEY = "asyncTaskExportKey";

}
