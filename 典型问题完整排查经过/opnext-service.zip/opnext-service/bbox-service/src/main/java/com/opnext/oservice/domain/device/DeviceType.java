package com.opnext.oservice.domain.device;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:04 18/5/7
 */
@Slf4j
@AllArgsConstructor
@ApiModel(description="设备类型")
public enum DeviceType {

    /**
     * 立式终端-单屏
     */
    @ApiModelProperty(value="单屏")
    DEVICE_TYPE_SINGLE_SCREEN("1001"),
    /**
     * 挂式终端-门禁
     */
    @ApiModelProperty(value="门禁")
    DEVICE_TYPE_ACCESS_CONTROL("2001"),
    /**
     *  通道终端-闸机
     */
    @ApiModelProperty(value="闸机")
    DEVICE_TYPE_GATE_MACHINE("3001"),
    /**
     * 台式终端-桌面机
     */
    @ApiModelProperty(value="桌面机")
    DEVICE_TYPE_DESKTOP_MACHINE("4001");
//    /**
//     * 摄像头
//     */
//    DEVICE_TYPE_CAMERA("5001");

    private String value;

    private static Map<String, DeviceType> valMap = new HashMap<>();

    public String value(){
        return this.value;
    }

    static {
        for (DeviceType deviceType : values()) {
            valMap.put(deviceType.value, deviceType);
        }
    }

    public static DeviceType indexOfVal(String value) {
        DeviceType deviceType = valMap.get(value);
        if(null == deviceType){
            log.error("DeviceType中没有找到匹配的 " + value);
            throw new IllegalArgumentException("No element matches " + value);
        }
        return deviceType;
    }
}
