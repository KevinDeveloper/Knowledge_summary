package com.opnext.oservice.domain.device.alarm;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author wanglu
 */
@Entity
@Table(name = "device_alarm_type")
@Data
public class DeviceAlarmType {
    @Id
    @GeneratedValue
    private Integer id;
    private String name;
    private DeviceAlarmPriority priority;
}
