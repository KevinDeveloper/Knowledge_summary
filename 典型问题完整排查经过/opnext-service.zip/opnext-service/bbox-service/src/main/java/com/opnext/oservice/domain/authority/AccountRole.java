package com.opnext.oservice.domain.authority;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

import javax.persistence.*;

/**
 * @author wanglu
 */
@Entity
@Data
@Builder
@Table(name = "account_role")
public class AccountRole {

    @Id
    @Column(name="account_id")
    private Long accountId;

    @Column(name="role_id")
    private Long roleId;

    @Tolerate
    AccountRole(){}
}
