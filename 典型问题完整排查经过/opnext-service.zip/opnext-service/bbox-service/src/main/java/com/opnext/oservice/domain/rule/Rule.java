package com.opnext.oservice.domain.rule;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.opnext.oservice.domain.converter.TimeRuleConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import jdk.nashorn.internal.objects.annotations.Getter;
import lombok.Data;
import org.apache.commons.lang.enums.Enum;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/25 13:10
 */
@Entity
@Table(name = "rule")
@Data
@ApiModel(description="规则对象")
@EntityListeners(AuditingEntityListener.class)
public class Rule {
    @Id
    @GeneratedValue
    @ApiModelProperty(value="id")
    private Integer id;

    /**
     * 规则名称
     */
    @ApiModelProperty(value="姓名")
    @Column(name = "name")
    private String name;

    /**
     * 规则描述
     */
    @Column(name = "description")
    @ApiModelProperty(value="描述")
    private String description;

    /**
     * 规则类型
     * 0：人员规则；1：组织规则
     */
    @Column(name = "type")
    @ApiModelProperty(value="类型")
    private byte type;

    /**
     * 通行提示语
     */
    @Column(name = "pass_tip")
    @ApiModelProperty(value="提示语")
    private String passTip;

    /**
     * 通行方式（AccessType枚举类型中的通行方式，多种方式用英文逗号隔开）
     */
    @Column(name = "pass_mode")
    @ApiModelProperty(value="通行方式")
    private String passMode;

    /**
     * 规则时间段（仅在时间规则的日期类型为自定义的时候有效）
     */
    @Column(name = "time_rule")
    @Convert(converter = TimeRuleConverter.class)
    @ApiModelProperty(value="规则时间段")
    private List<TimeRule> timeRule;

    /**
     * 创建时间
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "create_time")
    @CreatedDate
    @ApiModelProperty(value="创建时间")
    private Date createTime;

    /**
     * 修改时间
     */
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "update_time")
    @ApiModelProperty(value="更新时间")
    @LastModifiedDate
    private Date updateTime;

    /**
     * 创建人
     */
    @ApiModelProperty(value="创建人")
    @Column(name = "create_by")
    private String createBy;

    /**
     * 租户ID
     */
    @ApiModelProperty(value="租户id")
    @Column(name = "tenant_id")
    private Long tenantId;

    /**
     * 应用ID
     */
    @ApiModelProperty(value="应用id")
    @JsonIgnore
    @Column(name = "app_id")
    private String appId;

    /**
     * 有效期至
     */
    @Temporal(TemporalType.TIMESTAMP)
    @ApiModelProperty(value="有效期至")
    @Column(name = "valid_till")
    private Date validTill;

    /**
     * 规则状态
     */
    @Transient
    @ApiModelProperty(value="规则状态")
    private Status status;

    @Getter
    public Status getStatus() {
        if (this.validTill == null) {
            return Status.FINISH;
        }
        if (this.validTill.after(new Date())) {
            return Status.NORMAL;
        }
        return Status.FINISH;
    }

    /**
     * 人员ID集合
     */
    @Transient
    @ApiModelProperty(value="人员id集合")
    private List<String> personIds;

    /**
     * 组织ID集合
     */
    @Transient
    @ApiModelProperty(value="组织id集合")
    private List<Integer> organizationIds;

    /**
     * 应用人数
     */
    @Transient
    @ApiModelProperty(value="应用人数")
    private Integer personCount;

    /**
     * 同步设备数
     */
    @Transient
    @ApiModelProperty(value="同步设备数")
    private Integer deviceCount;

    /**
     * 规则状态枚举
     * NORMAL ：正常
     * FINISH  ：结束
     */
    @ApiModel(description="规则状态")
    public enum Status {
        NORMAL, FINISH
    }


    /**
     * 获取终端规则
     *
     * @param serviceAppId SaaS服务的APPID
     * @return
     */
    public com.opnext.domain.access.Rule toDomainRule(String serviceAppId) {
        List<com.opnext.domain.access.Rule.AccessType> typeList = new ArrayList<>();
        if (StringUtils.isNotBlank(this.passMode)) {
            String[] passModeArray = this.passMode.split(",");
            for (String mode : passModeArray) {
                typeList.add(com.opnext.domain.access.Rule.AccessType.valueOf(mode));
            }
        }
        com.opnext.domain.access.Rule rule = new com.opnext.domain.access.Rule();
        rule.setId(this.id);
        rule.setName(this.name);
        rule.setDescription(this.description);
        rule.setPrompt(this.passTip);
        rule.setTimeRule(new ArrayList<>(this.timeRule));
        rule.setType(typeList);
        rule.setValidTill(this.validTill.getTime());
        rule.setIsServiceRule(StringUtils.equals(this.appId, serviceAppId));
        return rule;
    }
    @ApiModel(description="规则类型")
    public enum RuleType {
        PERSON,
        ORGNIZATION;
    }
}
