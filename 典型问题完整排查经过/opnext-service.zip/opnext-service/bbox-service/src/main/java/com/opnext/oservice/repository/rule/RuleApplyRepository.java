package com.opnext.oservice.repository.rule;

import com.opnext.oservice.domain.rule.RuleApply;
import com.opnext.oservice.domain.rule.MultiKeys.RuleApplyMultiKeysClass;
import com.opnext.oservice.repository.BaseRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;
import java.util.Map;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 14:03
 */
public interface RuleApplyRepository extends BaseRepository<RuleApply> {

    /**
     * 根据规则ID和租户ID删除记录
     *
     * @param ruleId   规则ID
     * @param tenantId 租户ID
     * @return 受影响行数
     */
    int deleteByRuleIdAndTenantId(int ruleId, long tenantId);

    /**
     * 根据人员ID删除记录
     *
     * @param personId 人员ID
     * @param tenantId 租户ID
     * @return
     */
    int deleteByPersonIdAndTenantId(String personId, long tenantId);

    @Query(value = "SELECT rule_id as 'ruleId',group_concat(person_id) as 'persons' " +
            "FROM rule_apply " +
            "WHERE person_id IN(?1) and tenant_id=?2 " +
            "GROUP BY rule_id ", nativeQuery = true)
    List<Map<String, Object>> findRuleIdByPersonIds(List<String> personIds, long tenantId);
}
