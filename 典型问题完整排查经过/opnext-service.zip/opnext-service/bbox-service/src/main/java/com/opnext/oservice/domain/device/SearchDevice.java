package com.opnext.oservice.domain.device;

import lombok.Data;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:06 18/5/7
 */
@Data
public class SearchDevice {

    /**
     * 设备名称
     */
    private String name;
    /**
     * 设备SN
     */
    private String sn;

    /**
     * 设备状态
     */
    private DeviceStatus status;
    /**
     * 设备类型
     */
    private DeviceType type;
    /**
     * 设备组id
     */
    private Integer groupId;
    /**
     * 设备管理员名称
     */
    private String deviceAdminName;

    private Integer deviceAdminId;

    /**
     * 是否返回判断设备关联管理员的adminId
     */
//    private Boolean flag = false;
}
