package com.opnext.oservice.domain.authority.role;

import lombok.Data;

import javax.persistence.*;

/**
 * @author wanglu
 */
@Entity
@Data
@Table(name = "module_resource")
public class ModuleResource {
    @Id
    @GeneratedValue
    private Integer id;
    @Column(name="module_id")
    private Integer moduleId;

    @Column(name="resource_id")
    private Integer resourceId;

}
