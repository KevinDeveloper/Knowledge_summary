package com.opnext.oservice.domain.algorithm;

import lombok.Data;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午1:18 18/5/12
 */
@Data
public class LeftEye {
    private int x;
    private int y;
}
