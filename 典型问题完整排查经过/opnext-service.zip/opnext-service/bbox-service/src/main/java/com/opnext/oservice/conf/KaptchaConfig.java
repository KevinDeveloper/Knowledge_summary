package com.opnext.oservice.conf;

import com.google.code.kaptcha.impl.DefaultKaptcha;
import com.google.code.kaptcha.util.Config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import java.util.Properties;

@Component
public class KaptchaConfig {
    @Autowired
    KaptchaProperties kaptchaProperties;
    public static final String HAS_BORDER_FLAG = "true";
    public static final String NO_BORDER_FLAG = "false";

    @Bean
    public DefaultKaptcha getDefaultKaptcha(){
        DefaultKaptcha defaultKaptcha = new DefaultKaptcha();
        String border = kaptchaProperties.getBorder();
        if (HAS_BORDER_FLAG.equals(border)){
            border ="yes";
        }
        if (NO_BORDER_FLAG.equals(border)){
            border="no";
        }
        Properties properties = new Properties();
        properties.setProperty("kaptcha.border", border);
        properties.setProperty("kaptcha.border.color", kaptchaProperties.getBorderColor());
        properties.setProperty("kaptcha.textproducer.font.color", kaptchaProperties.getFontColor());
        properties.setProperty("kaptcha.image.width", kaptchaProperties.getImageWidth());
        properties.setProperty("kaptcha.image.height", kaptchaProperties.getImageHeight());
        properties.setProperty("kaptcha.textproducer.font.size", kaptchaProperties.getFontSize());
        properties.setProperty("kaptcha.textproducer.char.length", kaptchaProperties.getCharLength());
        properties.setProperty("kaptcha.textproducer.font.names", kaptchaProperties.getFontNames());
        Config config = new Config(properties);
        defaultKaptcha.setConfig(config);
        return defaultKaptcha;
    }

}
