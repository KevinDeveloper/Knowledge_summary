package com.opnext.oservice.domain.device;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午5:03 18/5/7
 */ 
@Entity
@Data
public class DeviceVo {

    @Id
    private Integer id;

    /**
     * 设备名称
     */
    private String name;
    /**
     * 设备SN
     */
    private String sn;
    /**
     * 设备类型
     */
    private DeviceType type;

    /**
     * 设备状态
     */
    private DeviceStatus status;
    /**
     * 设备组id
     */

    private Integer groupId;

    private String groupName;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 管理员，以逗号分隔
     */
    private String adminName;

    private Integer adminId;
}
