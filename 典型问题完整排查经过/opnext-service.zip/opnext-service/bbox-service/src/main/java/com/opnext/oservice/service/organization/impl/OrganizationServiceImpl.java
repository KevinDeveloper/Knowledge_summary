package com.opnext.oservice.service.organization.impl;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.organization.OrgVo;
import com.opnext.oservice.domain.organization.Organization;
import com.opnext.oservice.domain.organization.QOrganization;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.repository.organization.OrganizationRepository;
import com.opnext.oservice.service.organization.OrganizationService;
import com.opnext.oservice.service.person.PersonService;
import com.opnext.oservice.service.rule.RuleApplyService;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @ClassName: OrganizationServiceImpl
 * @Description:
 * @Author: Kevin
 * @Date: 2018/5/10 16:06
 */
@Slf4j
@Service
public class OrganizationServiceImpl implements OrganizationService {

    @Autowired
    private OrganizationRepository organizationRepository;

    @Autowired
    private JPAQueryFactory queryFactory;

    @Autowired
    private PersonService personService;

    @Autowired
    private RuleApplyService ruleApplyService;

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void initRootOrgInTenant(Long tenantId, Long operatorId, String orgName) throws Exception {
        if (Objects.isNull(tenantId) || StringUtils.isBlank(orgName)) {
            throw new CommonException("org.parameter.incorrect");
        }
        Organization organization = new Organization();
        organization.setName(orgName);
        organization.setParentId(-1);
        organization.setOperatorId(operatorId);
        organization.setTenantId(tenantId);
        organization.setOrgType(Organization.OrgType.SAAS);
        organization = organizationRepository.save(organization);

        //创建一个“其他组织”
        Organization other = new Organization();
        other.setName(Organization.otherOrgName);
        other.setOrgType(Organization.OrgType.OTHER);
        other.setParentId(organization.getId());
        other.setTenantId(tenantId);
        other.setOperatorId(operatorId);
        organizationRepository.save(other);

    }

    @Override
    public void saveOrg(Organization organization) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long operatorId = oserviceOperator.getUserId();

        // 1、租户下组织id合法性校验
        QOrganization qOrg = QOrganization.organization;
        Predicate predicate = qOrg.tenantId.eq(tenantId).and(qOrg.id.eq(organization.getParentId()));
        Organization parentOrg = organizationRepository.findOne(predicate);
        if (Objects.isNull(parentOrg)) {
            //拒绝访问该资源，在tenantId下没有找到对一个的资源
            log.info("在tenantId {}下没有找到对一个的组织资源{}", tenantId, organization.getParentId());
            throw new CommonException("org.tenantId.orgId");
        }
        if (isExistOrgNameInTenantId(tenantId, organization.getName())) {
            log.info("在tenantId {} 下 组织名{}已经存在", tenantId, organization.getName());
            throw new CommonException("NameRepeat");
        }
        organization.setOrgType(Organization.OrgType.SAAS);
        organization.setTenantId(tenantId);
        organization.setOperatorId(operatorId);
        organizationRepository.save(organization);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void updateOrgById(Integer orgId, Organization organization) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long operatorId = oserviceOperator.getUserId();
        organization.setOperatorId(operatorId);
        // 1、租户下组织id合法性校验
        QOrganization qOrg = QOrganization.organization;
        Predicate predicate = qOrg.tenantId.eq(tenantId).and(qOrg.id.eq(orgId)).and(qOrg.parentId.eq(organization.getParentId()));
        Organization orgOld = organizationRepository.findOne(predicate);
        if (Objects.isNull(orgOld)) {
            //拒绝访问该资源，在tenantId下没有找到对一个的资源
            log.info("在tenantId {}下没有找到对一个的组织资源{}", tenantId, orgId);
            throw new CommonException("org.tenantId.orgId");
        }
        if (!orgOld.getName().equals(organization.getName()) && isExistOrgNameInTenantId(tenantId, organization.getName())) {
            log.info("在tenantId {} 下 组织名{}已经存在", tenantId, organization.getName());
            throw new CommonException("NameRepeat");
        }
        //2、更新组织
        queryFactory.update(qOrg)
                //更新字段列表
                .set(qOrg.name, organization.getName())
//                .set(qOrg.parentId, organization.getParentId())
//                .set(qOrg.remark, organization.getRemark())
                .set(qOrg.operatorId, organization.getOperatorId())
                .set(qOrg.updateTime, new Date())
                //更新条件
                .where(qOrg.id.eq(organization.getId()))
                //执行更新
                .execute();
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteOrgByIds(Integer[] ids) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        //查询根组织
        Organization rootOrg = getRootOrgByTenantId(tenantId);
        //判断该组织下是否有人，或子组织下是否有人
        List<Integer> allIds = new ArrayList<>();
        boolean result = false;
        List<OrgVo> orgVoList = null;
        for (int i = 0; i < ids.length; i++) {
            if (ids[i].intValue() == rootOrg.getId().intValue()) {
                throw new CommonException("org.delete.fail.rootorg");
            }
            orgVoList = listOrgByParentId(ids[i], null);
            List<Integer> idList = new ArrayList<>();
            idList.add(ids[i]);
            if (!CollectionUtils.isEmpty(orgVoList)) {
                orgVoList.forEach(orgVo -> idList.add(orgVo.getId()));
            }
            //判断当前组织列表下是否有人
            int hasPersonCount = personService.getPersonByOrgIds(tenantId, idList);
            if (hasPersonCount > 0) {
                result = true;
                break;
            } else {
                allIds.addAll(idList);
            }
        }
        if (result) {
            throw new CommonException("org.delete.fail.hasperson");
        }

        QOrganization qOrg = QOrganization.organization;
        Predicate predicate = qOrg.tenantId.eq(tenantId).and(qOrg.id.in(allIds));
        queryFactory.delete(qOrg).where(predicate).execute();
        ruleApplyService.whenDelOrg(allIds, oserviceOperator);
    }

    @Override
    public List<OrgVo> listAllOrg(OserviceOperator oserviceOperator) throws Exception {
        long tenantId = oserviceOperator.getTenantId();
        QOrganization qOrg = QOrganization.organization;
        QPerson qPerson = QPerson.person;
        if (Objects.isNull(tenantId)) {
            log.info("租户id不能为空");
            throw new CommonException("org.parameter.incorrect");
        }
        Predicate predicate = qOrg.tenantId.eq(tenantId).and(qOrg.orgType.eq(Organization.OrgType.SAAS));
        List<Organization> list = queryFactory.select(qOrg)
                .from(qOrg)
                .where(predicate).groupBy(qOrg.id).orderBy(qOrg.name.desc()).fetch();

        if (CollectionUtils.isEmpty(list)) {
            log.info("租户组织查询为空");
            return new ArrayList<>();
        }
        List<OrgVo> orgVos = list.stream().map(org -> {
            OrgVo orgVo = new OrgVo();
            BeanUtils.copyProperties(org, orgVo);
            return orgVo;
        }).collect(Collectors.toList());

        /**
         * 帐户授权的组织id 判断
         */
        //1、判断当前用户类型
        boolean isCommon = false;
        if (OserviceOperator.UserType.COMMON == oserviceOperator.getUserType()) {
            isCommon = true;
        }
        if (isCommon) {
            log.info("当前帐户为common角色");
            if (!CollectionUtils.isEmpty(oserviceOperator.getOrganizations())) {
                log.info("帐户授权的组织id allOrgIds={}", oserviceOperator.getOrganizations().toString());
                Set<Integer> allorgsSet = new HashSet<>(oserviceOperator.getOrganizations());
                orgVos.stream().forEach(org -> {
                    if (!allorgsSet.contains(org.getId())) {
                        org.setDisabled(true);
                    }
                });
            } else {
                log.info("帐户授权的组织id 为空");
                orgVos.stream().forEach(org -> {
                    org.setDisabled(true);
                });
            }
        } else {
            log.info("当前帐户为超管类角色，全部组织可用");
        }
        return orgVos;
    }

    @Override
    public OrgVo orgNode(OserviceOperator oserviceOperator) throws Exception {
        List<OrgVo> list = listAllOrg(oserviceOperator);
        //查询根组织
        List<OrgVo> tempOrgs = getChildNodeByParentId(list, -1);
        if (CollectionUtils.isEmpty(tempOrgs) || tempOrgs.size() != 1) {
            log.info("租户根组织为空或者不止一个根组织，数据异常");
            throw new CommonException("org.tenantId.rootOrg.error");
        }
        OrgVo orgNodeVo = tempOrgs.get(0);
        Map<Integer, List<OrgVo>> orgNodeMap = getAllNodeMap(list);
        //----------------------------------需求待确定
//        StopWatch stopWatch = new StopWatch("组织只显示权限组织路径耗时");
//        stopWatch.start();
//        boolean isResult = false;
//        while (!isResult) {
//            Set<Integer> keySet = orgNodeMap.keySet();
//            int preSize = list.size();
//            List<OrgVo> tempList = list.stream().filter(org -> {
//                if (!keySet.contains(org.getId()) && org.isDisabled()) {
//                    return false;
//                } else {
//                    return true;
//                }
//            }).collect(Collectors.toList());
//            orgNodeMap = getAllNodeMap(tempList);
//            if (tempList.size() == preSize) {
//                isResult = true;
//            }
//            list = tempList;
//
//        }
//        stopWatch.stop();
//        log.info(stopWatch.prettyPrint());
        //=================================================================
        orgNodeVo = createNodeByRecurision(orgNodeVo, orgNodeMap);
        return orgNodeVo;
    }


    /**
     * 根据父级组织id，返回直接子组织
     *
     * @param list
     * @param parentId
     * @return
     */
    private List<OrgVo> getChildNodeByParentId(List<OrgVo> list, Integer parentId) {
        if (CollectionUtils.isEmpty(list)) {
            return new ArrayList<>();
        }
        List<OrgVo> organizationList = list.stream().filter(org ->
                org.getParentId().intValue() == parentId.intValue()
        ).collect(Collectors.toList());
        return organizationList;
    }

    /**
     * 对组织list建立一个map结构
     *
     * @param list
     * @return
     */
    private Map<Integer, List<OrgVo>> getAllNodeMap(List<OrgVo> list) {
        Map<Integer, List<OrgVo>> map = new HashMap<>(16);
        list.forEach(org -> {
            Integer pId = org.getParentId();
            List<OrgVo> tempNodes = new ArrayList<>();
            if (map.containsKey(pId)) {
                tempNodes = map.get(pId);
            }
            tempNodes.add(org);
            map.put(pId, tempNodes);
        });
        return map;
    }


    /**
     * 创建一颗组织树
     *
     * @param orgNodeVo
     * @param orgNodeMap
     * @return
     */
    private OrgVo createNodeByRecurision(OrgVo orgNodeVo, Map<Integer, List<OrgVo>> orgNodeMap) {
        Integer curId = orgNodeVo.getId();

        if (!orgNodeMap.containsKey(curId)) {
            return orgNodeVo;
        }
        List<OrgVo> childOrgList = orgNodeMap.get(orgNodeVo.getId());
        if (CollectionUtils.isEmpty(childOrgList)) {
            return orgNodeVo;
        }
//        childOrgList.sort((organization o1, organization o2)->o1.getName().compareTo(o2.getName()));
//        childOrgList.sort(organization::compareByOrgName);
        childOrgList.sort(Comparator.comparing(OrgVo::getUpdateTime));
        orgNodeVo.setChildNodes(childOrgList);
        childOrgList.forEach(org -> createNodeByRecurision(org, orgNodeMap));
        return orgNodeVo;
    }

    @Override
    public Organization findOrgByTenantIdAndName(Long tenantId, String name) throws Exception {
        if (Objects.isNull(tenantId) || StringUtils.isBlank(name)) {
            return null;
        }
        QOrganization qOrg = QOrganization.organization;
        Predicate predicate = qOrg.tenantId.eq(tenantId).and(qOrg.name.eq(name));
        Organization organization = organizationRepository.findOne(predicate);
        return organization;
    }

    @Override
    public boolean isExistOrgNameInTenantId(Long tenantId, String name) throws Exception {
        boolean isExist = false;
        if (Objects.isNull(tenantId)) {
            return isExist;
        }
        Organization organizationList = findOrgByTenantIdAndName(tenantId, name);
        if (!Objects.isNull(organizationList)) {
            isExist = true;
        }
        return isExist;
    }

    @Override
    public Organization findOrgInTenantIdById(Long tenantId, Integer orgId) throws Exception {
        QOrganization qOrg = QOrganization.organization;
        Predicate predicate = qOrg.tenantId.eq(tenantId).and(qOrg.id.eq(orgId));
        return organizationRepository.findOne(predicate);
    }

    @Override
    public List<OrgVo> listOrgByParentId(Integer parentId, String orgName) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();

        // 租户下组织id合法性校验
        QOrganization qOrg = QOrganization.organization;
        Predicate predicate = qOrg.tenantId.eq(tenantId).and(qOrg.id.eq(parentId));
        Organization orgParent = organizationRepository.findOne(predicate);
        if (Objects.isNull(orgParent)) {
            //拒绝访问该资源，在tenantId下没有找到对一个的资源
            log.info("在tenantId {}下没有找到对一个的组织资源{}", tenantId, parentId);
            throw new CommonException("org.tenantId.orgId");
        }
        OrgVo orgVo = new OrgVo();
        BeanUtils.copyProperties(orgParent, orgVo);
        List<OrgVo> list = listAllOrg(oserviceOperator);
        //1、判断parentId 是否是根组织
        if (-1 == orgVo.getParentId().intValue()) {
            if (StringUtils.isNotBlank(orgName)) {
                list = list.stream().filter(org -> org.getName().contains(orgName)).collect(Collectors.toList());
            }
            list.sort(Comparator.comparing(OrgVo::getName));
            return list;
        }
        //2、非根组织
        Map<Integer, List<OrgVo>> orgNodeMap = getAllNodeMap(list);
        //该组织底下无子组织
        if (!orgNodeMap.containsKey(parentId)) {
            return new ArrayList<>();
        }
        //有子组织
        list = getAllChildOrgList(orgVo, orgNodeMap);

        if (StringUtils.isNotBlank(orgName)) {
            list = list.stream().filter(org -> org.getName().contains(orgName)).collect(Collectors.toList());
        }
        list.sort(Comparator.comparing(OrgVo::getName));
        return list;

    }

    /**
     * 返回rootOrg组织下全部的子组织
     *
     * @param rootOrg    非根组织
     * @param orgNodeMap
     * @return
     */
    private List<OrgVo> getAllChildOrgList(OrgVo rootOrg, Map<Integer, List<OrgVo>> orgNodeMap) {
        List<OrgVo> orgList = new ArrayList<>();
        if (Objects.isNull(rootOrg)) {
            return orgList;
        }
        rootOrg.setChildNodes(orgNodeMap.get(rootOrg.getId()));
        if (CollectionUtils.isEmpty(rootOrg.getChildNodes())) {
            return orgList;
        }
        orgList.addAll(rootOrg.getChildNodes());
        rootOrg.getChildNodes().stream().forEach(organization ->
                orgList.addAll(getAllChildOrgList(organization, orgNodeMap)));
        return orgList;

    }

    @Override
    public void checkOperator(OserviceOperator oserviceOperator) throws Exception {
        if (OserviceOperator.UserType.SUPER.value() != oserviceOperator.getUserType().value() &&
                OserviceOperator.UserType.COMMON.value() != oserviceOperator.getUserType().value()) {
            throw new CommonException("org.tenant.rule");
        }
    }

    @Override
    public Organization getOtherOrgByTenantId(long tenantId) throws Exception {
        // 返回租户下的other组织
        QOrganization qOrg = QOrganization.organization;
        Predicate predicate = qOrg.tenantId.eq(tenantId).and(qOrg.orgType.eq(Organization.OrgType.OTHER));
        Organization organization = organizationRepository.findOne(predicate);
        return organization;
    }

    @Override
    public Organization getRootOrgByTenantId(long tenantId) throws Exception {
        // 返回租户下的other组织
        QOrganization qOrg = QOrganization.organization;
        Predicate predicate = qOrg.tenantId.eq(tenantId).and(qOrg.parentId.eq(-1));
        Organization organization = organizationRepository.findOne(predicate);
        return organization;
    }

    /**
     * 根据租户id获取所有
     *
     * @param tenantId
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public Map<Integer, String> getOrgMap(long tenantId, OserviceOperator oserviceOperator) throws Exception {
        QOrganization qOrg = QOrganization.organization;
        Predicate predicate = qOrg.tenantId.eq(tenantId);
        List<Organization> list = queryFactory.selectFrom(qOrg)
                .where(predicate)
                .fetch();
        Map<Integer, String> map = new HashMap<>();
        if (!CollectionUtils.isEmpty(list)) {
            list.forEach(organization -> {
                map.put(organization.getId(), organization.getName());
            });
        }
        return map;
    }


    /**
     * 删除该组织和它下面的子组织 ，以及所有组织包括的人员
     *
     * @param oserviceOperator
     * @param orgId
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteOrgDirect(OserviceOperator oserviceOperator, Integer orgId) throws Exception {
        //判断当前用户是否有该组织的操作权限
        List<OrgVo> listAllOrg = listAllOrg(oserviceOperator);
        OrgVo org = null;
        for (OrgVo orgVo : listAllOrg) {
            if (Objects.equals(orgVo.getId(), orgId)) {
                org = orgVo;
                if (orgVo.isDisabled()) {
                    log.error("没有权限删除该组织");
                    throw new CommonException("has.no.permission");
                }
            }
        }
        //根组织不能删除
        if (Objects.isNull(org)) {
            log.error("当前待删除的组织不存在");
            throw new CommonException("organization.not.exist");
        } else if (org.getParentId() == -1) {
            log.error("根组织不能删除");
            throw new CommonException("root.organization.not.delete");
        }
        //查询出所有的待删除组织
        List<OrgVo> delOrgs = listOrgByParentId(orgId, "");
        List<Integer> delOrgIds = new ArrayList<>();
        delOrgIds.add(org.getId());
        delOrgs.forEach(orgVo -> delOrgIds.add(orgVo.getId()));

        //删除所有组织
        QOrganization qOrganization = QOrganization.organization;
        Predicate orgPredicate = qOrganization.tenantId.eq(oserviceOperator.getTenantId()).and(qOrganization.id.in(delOrgIds));
        queryFactory.delete(qOrganization).where(orgPredicate).execute();
        //清空所有组织规则
        ruleApplyService.whenDelOrg(delOrgIds, oserviceOperator);
        log.info("清空所有待删除的组织规则");

        //删除所有人员
        QPerson qPerson = QPerson.person;
        Predicate predicate = qPerson.tenantId.eq(oserviceOperator.getTenantId()).and(qPerson.organizationId.in(delOrgIds));
        List<String> personIds = queryFactory.select(qPerson.id).from(qPerson).where(predicate).fetch();
        queryFactory.delete(qPerson).where(qPerson.id.in(personIds)).execute();
        //清空人员规则
        ruleApplyService.whenDelPerson(personIds, oserviceOperator.getTenantId());
        log.info("清空所有待删除中的人员规则");

    }

    /**
     * 删除删除该组织和它下面的子组织， 并移动所有组织下面的人员到目标组织
     *
     * @param oserviceOperator
     * @param orgId
     * @param targetOrgId
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteOrgMove(OserviceOperator oserviceOperator, Integer orgId, Integer targetOrgId) throws Exception {
        if(Objects.isNull(targetOrgId)){
            log.info("删除组织，目标组织id及删除类型不能为空");
            throw new CommonException(400, "parameter.incorrect");
        }
        // 源组织和目标组织不能相同
        if(orgId.equals(targetOrgId)) {
            log.info("删除组织，源组织和目标组织不能相同");
            throw new CommonException(400, "parameter.incorrect.org.not.same");
        }
        //判断当前用户是否有待删除组织和目标组织的操作权限
        List<OrgVo> listAllOrg = listAllOrg(oserviceOperator);
        List<OrgVo> orgVoList = new ArrayList<>();
        for (OrgVo orgVo : listAllOrg) {
            if (Objects.equals(orgVo.getId(), orgId)) {
                if (orgVo.getParentId() == -1) {
                    log.error("删除组织不能是根组织");
                    throw new CommonException("root.organization.not.delete");
                }
            }
            if (Objects.equals(orgVo.getId(), orgId) || Objects.equals(orgVo.getId(), targetOrgId)) {
                orgVoList.add(orgVo);
                if (orgVo.isDisabled()) {
                    log.error("没有权限删除该组织");
                    throw new CommonException("has.no.permission");
                }
            }
        }
        if (orgVoList.size() != 2) {
            log.error("待操作组织不存在");
            throw new CommonException("organization.not.exist");
        }
        //查询出所有的待删除组织(删除组织的子组织)
        List<OrgVo> delOrgs = listOrgByParentId(orgId, "");
        List<Integer> delOrgIds = new ArrayList<>();
        delOrgIds.add(orgId);
        delOrgs.forEach(orgVo -> delOrgIds.add(orgVo.getId()));
        if (delOrgIds.contains(targetOrgId)) {
            log.error("目标组织不能是待删除组织的子组织");
            throw new CommonException("current.organization.not.contain.target.organization");
        }

        //删除所有组织
        QOrganization qOrganization = QOrganization.organization;
        Predicate orgPredicate = qOrganization.tenantId.eq(oserviceOperator.getTenantId()).and(qOrganization.id.in(delOrgIds));
        queryFactory.delete(qOrganization).where(orgPredicate).execute();
        //查询出所有待删除组织下的所有人员id
        QPerson qPerson = QPerson.person;
        Predicate predicate = qPerson.tenantId.eq(oserviceOperator.getTenantId()).and(qPerson.organizationId.in(delOrgIds));
        //修改人员组织id为目标组织id
        queryFactory.update(qPerson).set(qPerson.organizationId, targetOrgId).where(predicate).execute();
        List<Tuple> personIdAndOrgIds = queryFactory.select(qPerson.id, qPerson.organizationId).from(qPerson).where(predicate).fetch();

        Map<Integer, List<String>> orgWithPersonIdMap = new HashMap<>();
        if (!CollectionUtils.isEmpty(personIdAndOrgIds)) {
            personIdAndOrgIds.forEach(personIdAndOrgId -> {
                String pId = personIdAndOrgId.get(0, String.class);
                Integer oId = personIdAndOrgId.get(1, Integer.class);
                List<String> pIds = new ArrayList<>();
                if (orgWithPersonIdMap.containsKey(oId)) {
                    pIds = orgWithPersonIdMap.get(oId);
                }
                pIds.add(pId);
                orgWithPersonIdMap.put(oId, pIds);
            });
        }
        //调用这些人员的组织规则变更接口
        orgWithPersonIdMap.forEach((oId, personIds) -> {
            try {
                ruleApplyService.whenEditPersonOrg(personIds, orgId, targetOrgId, oserviceOperator);
            } catch (Exception e) {

            }
        });
        log.info("更改组织删除人员移动后的新的组织规则");
        //清空所有组织规则
        ruleApplyService.whenDelOrg(delOrgIds, oserviceOperator);
        log.info("清空所有待删除的组织规则");

    }
}
