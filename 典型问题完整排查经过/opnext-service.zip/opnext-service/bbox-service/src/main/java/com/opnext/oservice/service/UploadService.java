package com.opnext.oservice.service;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.oservice.domain.MultipartFileResp;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午3:18 18/5/9
 */
public interface UploadService {

    /**
     * 可见光照片上传
     *
     * @param multipartFile
     * @return
     */
    Map<String, MultipartFileResp> uploadImage(MultipartFile multipartFile, OserviceOperator oserviceOperator, RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 批量上传文件照片
     *
     * @param multipartFiles
     * @return
     * @throws Exception
     */
    Map<String, MultipartFileResp> batchUploadImage(List<MultipartFile> multipartFiles,OserviceOperator oserviceOperator) throws Exception;

    /**
     * 批量上传文件照片（用于人员批量上传）
     * @param multipartFiles
     * @return
     * @throws Exception
     */
    Map<String, MultipartFileResp> batchUploadImageForFile(List<File> multipartFiles,OserviceOperator oserviceOperator) throws Exception;
}
