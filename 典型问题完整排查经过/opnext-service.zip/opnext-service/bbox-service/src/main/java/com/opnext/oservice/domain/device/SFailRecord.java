package com.opnext.oservice.domain.device;

import lombok.Data;

/**
 * @author tianzc
 */
@Data
public class SFailRecord {
    private String commandId;
    private String deviceSn;
}
