package com.opnext.oservice.service.device;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.dto.command.CommandRecord;
import com.opnext.oservice.dto.command.SearchCommandReq;
import org.springframework.data.domain.Page;

/**
 * @author wanglu
 */
public interface CommandRecordService {
    /**
     * 获取指令记录的列表
     * @param searchCommandReq
     * @return
     * @throws Exception
     */
    Page<CommandRecord> getCommandRecords(SearchCommandReq searchCommandReq)throws Exception;

    /**
     * 根据指令记录的id查询指令下发记录的详情
     * @param requestId
     * @param tenantId
     * @return
     * @throws Exception
     */
    CommandRecord getCommandRecordDetail(String requestId,String tenantId)throws Exception;

    /**
     * 重新下发指令
     * @param requestId
     * @param oserviceOperator
     * @throws Exception
     */
    void sendCommand(String requestId, OserviceOperator oserviceOperator) throws Exception;
}
