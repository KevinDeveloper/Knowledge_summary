package com.opnext.oservice.domain.accessrecord;

import com.opnext.domain.PersonType;
import lombok.Data;

/**
 * @author tianzc
 */
@Data
public class SendAccessRecord {
    /**
     * 识别记录唯一标识
     */
    private String id;
    /**
     * 识别结果
     */
    private AccessRecordInfo.ResultType resultType;
    /**
     * 人员类型
     */
    private PersonType personType;

    private Long tenantId;

}
