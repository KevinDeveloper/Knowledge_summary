package com.opnext.oservice.feign.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.domain.request.FeedBackRequest;
import com.opnext.omessage.support.MessageContext;
import com.opnext.oservice.domain.device.CommandRetry;
import com.opnext.oservice.dto.PageFeign;
import com.opnext.oservice.dto.command.CommandRecord;
import com.opnext.oservice.feign.OMessageFeign;
import feign.FeignException;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author tianzc
 */
@Slf4j
@Component(value = "oMessageHystrixFallFactory")
public class OMessageHystrixFallFactory implements FallbackFactory<OMessageFeign> {
    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public OMessageFeign create(Throwable throwable) {
        log.info("oMessage fallback; reason was: {}",throwable.getMessage());
        return new OMessageFeign() {

            /**
             * 发送命令
             * <p>
             * 在方法中写入如下代码来创建MessageContext，SimpleMessageTemplate是非线程安全的，请不要将他单例化
             * scope方法应该填入实际的设备列表，传入DEBUG在测试环境下回群发所有已注册的终端实例
             * scope方法后面调用具体的业务方法。
             *
             * @param messageContext
             * @return
             */
            @Override
            public List<String> send(MessageContext messageContext) {
                return null;
            }

            /**
             * 删除设备失败指令
             *
             * @param sn
             * @return
             */
            @Override
            public ResponseEntity deleteCommand(String sn) throws Exception {
                return ResponseEntity.ok(innerHandlerException(throwable, new Object()));
            }

            /**
             * CallBack在bbox-service中处理的时候需要调用该方法
             *
             * @param workflowId
             * @param commandId
             * @param requestId
             * @return
             */
            @Override
            public ResponseEntity callback(String workflowId, String commandId, String requestId) throws Exception {
                return ResponseEntity.ok(innerHandlerException(throwable, new Object()));
            }

            /**
             * 回调地址是消息的终结状态，由终端上报给服务端，通常是POST请求，
             * 接入和交互方式和Callback基本一致，需要增加一个FeedBackRequest，目前业务端不需要关心Feedback
             *
             * @param workflowId
             * @param commandId
             * @param requestId
             * @param feedBackRequest
             * @return
             */
            @Override
            public ResponseEntity feedback(String workflowId, String commandId, String requestId, FeedBackRequest feedBackRequest) throws Exception {
                return ResponseEntity.ok(innerHandlerException(throwable, new Object()));
            }

            @Override
            public CommonResponse<PageFeign<CommandRecord>> getCommandRecord(Object... variables) throws Exception{
                return innerHandlerException(throwable, new PageImpl(new ArrayList(), null, 0));
            }

            @Override
            public CommonResponse<CommandRecord> getCommandRecordDetail(String requestId, String tenantId) throws Exception{
                return innerHandlerException(throwable, new Object());
            }

            /**
             * 通过指令记录requestId 重新下发
             *
             * @param commandRetry
             * @return
             * @throws Exception
             */
            @Override
            public CommonResponse commandRetry(CommandRetry commandRetry) throws Exception {
                return innerHandlerException(throwable, new Object());
            }


            public CommonResponse innerHandlerException(Throwable throwable, Object object) throws Exception{
                if (StringUtils.isBlank(throwable.getMessage())){
                    throw (Exception) throwable;
                }

                String errorMessage = throwable.getMessage().substring(throwable.getMessage().indexOf("\n")+1);
                CommonResponse.ErrorResponse errorResponse = objectMapper.readValue(errorMessage,CommonResponse.ErrorResponse.class);

                if (errorResponse.getStatus()>= HttpStatus.BAD_REQUEST.value() && errorResponse.getStatus()<HttpStatus.INTERNAL_SERVER_ERROR.value()) {

                    if (throwable instanceof FeignException){
                        throw (FeignException) throwable;
                    }else{
                        throw (Exception) throwable;
                    }
                }
                return CommonResponse.ok(object);
            }
        };
    }
}
