package com.opnext.oservice.controller.device;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.validator.IsEmptyValidator;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.oservice.domain.device.DeviceGroup;
import com.opnext.oservice.repository.device.DeviceGroupRepository;
import com.opnext.oservice.service.device.DeviceGroupService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author tianzc
 * @Date 下午5:03 18/5/7
 */ 
@Slf4j
@RestController
@RequestMapping("/api/device/group")
public class DeviceGroupController {

    @Autowired
    DeviceGroupRepository deviceGroupRepository;
    @Autowired
    DeviceGroupService groupService;

    @ApiOperation(value = "设备组列表", notes = "获取设备组列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "name", value = "设备组名称"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=version,updateTime,asc&sort=name,desc")
    })
    @RequestMapping(value = "/page", method = RequestMethod.GET)
    public CommonResponse page(@PageableDefault Pageable pageable, String name) throws Exception{
        Page page =  groupService.getPage(pageable, name);
        return CommonResponse.ok(page);
    }

    @ApiOperation(value = "获取所有设备组列表", notes = "")
    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public CommonResponse getList() throws Exception{
        List<DeviceGroup> list = groupService.getAllList();
        return CommonResponse.ok(list);
    }

    @ApiOperation(value = "获取设备组", notes = "根据id获取设备组")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public CommonResponse<DeviceGroup> getInfo(@PathVariable Integer id) throws Exception {
        DeviceGroup deviceGroup = groupService.getInfo(id);
        return CommonResponse.ok(deviceGroup);
    }

    @ApiOperation(value = "保存设备组", notes = "保存设备组并关联设备")
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public CommonResponse<DeviceGroup> save(@RequestBody DeviceGroup deviceGroup) throws Exception {
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(deviceGroup.getGroupName(), new IsEmptyValidator("groupName"))
                .on(deviceGroup.getGroupName(), new IsStringWithinLengthRangeValidator("groupName", 1, 64, true))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("新建设备组参数异常{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        DeviceGroup resultGroup = groupService.save(deviceGroup);
        return CommonResponse.ok(resultGroup);
    }

    @ApiOperation(value = "更新设备", notes = "更新设备组名称")
    @RequestMapping(value = "/update/{id}", method = RequestMethod.POST)
    public void update(@PathVariable Integer id, @RequestBody DeviceGroup deviceGroup) throws Exception {
        deviceGroup.setId(id);
        ComplexResult ret  = FluentValidator.checkAll()
                .failOver()
                .on(deviceGroup.getGroupName(), new IsEmptyValidator("groupName"))
                .on(deviceGroup.getGroupName(), new IsStringWithinLengthRangeValidator("groupName", 1, 64, true))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("新建设备组参数异常{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        groupService.updateGroup(deviceGroup);
    }

    @ApiOperation(value = "删除设备组", notes = "")
    @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
    public void delete(@RequestBody Integer[] ids) throws Exception {
        groupService.delete(ids);
    }
}
