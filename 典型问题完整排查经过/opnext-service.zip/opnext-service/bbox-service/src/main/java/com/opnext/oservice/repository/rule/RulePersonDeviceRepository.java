package com.opnext.oservice.repository.rule;

import com.opnext.oservice.domain.rule.MultiKeys.RulePersonDeviceMultiKeysClass;
import com.opnext.oservice.domain.rule.RulePersonDevice;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 14:03
 */
public interface RulePersonDeviceRepository extends PagingAndSortingRepository<RulePersonDevice, RulePersonDeviceMultiKeysClass>, QueryDslPredicateExecutor<RulePersonDevice> {

    /**
     * 根据规则ID删除
     * @param ruleId 规则ID
     * @param tenantId 租户ID
     * @return
     */
    int deleteByRuleIdAndTenantId(int ruleId,long tenantId);

    /**
     * 根据人员ID删除
     * @param personId 人员ID
     * @param tenantId 租户ID
     * @return
     */
    int deleteByPersonIdAndTenantId(String personId,long tenantId);

    /**
     * 根据设备SN号删除
     * @param deviceSn 设备SN号
     * @param tenantId 租户ID
     * @return
     */
    int deleteByDeviceSnAndTenantId(String deviceSn,long tenantId);
}
