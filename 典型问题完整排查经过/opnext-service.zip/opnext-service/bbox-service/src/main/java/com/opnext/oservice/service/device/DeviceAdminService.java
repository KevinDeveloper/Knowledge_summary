package com.opnext.oservice.service.device;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.oservice.domain.device.DeviceAdmin;
import com.opnext.oservice.domain.device.SearchDevice;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午4:49 18/5/7
 */
public interface DeviceAdminService {

    /**
     * 分页获取设备管理员列表
     * @param pageable
     * @param name
     * @param phone
     * @return
     * @throws Exception
     */
    Page getPage(Pageable pageable, String name, String phone, RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 根据id获取设备管理员
     * @param id
     * @return
     * @throws Exception
     */
    DeviceAdmin getInfo(Integer id,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     *
     * @param deviceAdmin
     * @return
     */
    ComplexResult fluentValidator(DeviceAdmin deviceAdmin) throws Exception;

    /**
     * 保存设备管理员，并关联设备
     * @param deviceAdmin
     * @throws Exception
     */
    DeviceAdmin save(DeviceAdmin deviceAdmin,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 更新设备管理员
     * @param deviceAdmin
     * @throws Exception
     */
    void update(DeviceAdmin deviceAdmin,RequestUrlPrefix urlPrefix) throws Exception;

    /**
     * 更新设备管理员名称
     * @param name
     * @param id
     * @throws Exception
     */
    void updateName(Integer id, String name) throws Exception;

    /**
     * 删除设备管理员，移除设备关联设备管理员
     * 下发指令更新设备管理员
     * @param ids
     * @throws Exception
     */
    void delete(Integer[] ids) throws Exception;

    /**
     * 获取设备page
     * @param pageable
     * @param sDevice
     * @param id 管理员id
     * @return
     * @throws Exception
     */
    Page getDevicePage(Pageable pageable, SearchDevice sDevice, Integer id) throws Exception;

    /**
     * 关联设备管理员
     * @param deviceIds
     * @param id
     * @throws Exception
     */
    void bindDevice(Integer[] deviceIds, Integer id) throws Exception;

    /**
     * 移除设备管理员
     * @throws Exception
     */
    void deleteDeviceAdmin(Integer[] deviceIds, Integer[] adminIds) throws Exception;

    /**
     *
     * @param tenantId
     * @param oserviceOperator
     * @param snList
     * @throws Exception
     */
    void sendAdminData(OserviceOperator oserviceOperator, List<String> snList) throws Exception;

    /**
     *
     * @param oserviceOperator
     * @param snList
     * @throws Exception
     */
    void sendAdmin(OserviceOperator oserviceOperator, List<String> snList) throws Exception;
}
