package com.opnext.oservice.service.common.impl;

import com.mongodb.BasicDBObject;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.conf.Constant;
import com.opnext.oservice.domain.accessrecord.AccessRecordInfo;
import com.opnext.oservice.service.authority.AdminService;
import com.opnext.oservice.service.authority.RoleService;
import com.opnext.oservice.service.common.InitializationService;
import com.opnext.oservice.service.organization.OrganizationService;
import com.opnext.oservice.service.person.PersonConfigService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.data.mongodb.core.IndexOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexDefinition;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Index;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.lang.annotation.Annotation;
import java.util.HashMap;
import java.util.Objects;

/**
 * @author tianzc
 */
@Slf4j
@Service
public class InitializationServiceImpl implements InitializationService {

    @Resource
    private MongoTemplate mongoTemplate;

    @Resource
    private OrganizationService orgService;

    @Resource
    private PersonConfigService personConfigService;

    @Resource
    private AdminService adminService;

    /**
     * 初始化租户相关信息
     *
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public CommonResponse init(OserviceOperator oserviceOperator, String orgName) throws Exception {
        // 初始化超级管理员角色
        adminService.bindSuperRole(oserviceOperator.getUserId());
        // 初始化该租户组织
        orgService.initRootOrgInTenant(oserviceOperator.getTenantId(), oserviceOperator.getUserId(), orgName);
        // 初始化该租户人员配置
        personConfigService.initPersonConfig(oserviceOperator.getTenantId(), oserviceOperator.getUserId());
        // 初始化该租户识别记录集合
        createAccessRecordCollection(oserviceOperator);
        return CommonResponse.ok(new HashMap<>());
    }

    /**
     * 创建识别记录mongo集合
     *
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public CommonResponse createAccessRecordCollection(OserviceOperator oserviceOperator) throws Exception {
        if (Objects.isNull(oserviceOperator.getTenantId())) {
            log.error("------初始化创建识别记录mongo集合失败，tenantId：{}", oserviceOperator.getTenantId());
            throw new CommonException("init.accessrecord.collection.exception");
        }
        String collectionName = Constant.ACCESS_RECORD_PREFIX +  oserviceOperator.getTenantId();
        IndexOperations indexOperations = mongoTemplate.indexOps(collectionName);
        // 删除索引
        indexOperations.dropAllIndexes();
        Annotation annotation = AnnotationUtils.findAnnotation(AccessRecordInfo.class, CompoundIndexes.class);
        CompoundIndex[] compoundIndices = ((CompoundIndexes) annotation).value();
        for (CompoundIndex compoundIndex : compoundIndices) {
            BasicDBObject basicDBObject = BasicDBObject.parse(compoundIndex.def());
            CompoundIndexDefinition compoundIndexDefinition = new CompoundIndexDefinition(basicDBObject);
            Index index = compoundIndexDefinition.named(compoundIndex.name());
            if (compoundIndex.unique()) {
                index.unique();
            }
            if (compoundIndex.background()) {
                index.background();
            }
            if (compoundIndex.sparse()) {
                index.sparse();
            }
            if (compoundIndex.dropDups()) {
                index.getIndexOptions().put("dropDups", true);
            }
            indexOperations.ensureIndex(compoundIndexDefinition);
        }
        return CommonResponse.ok(new HashMap<>());
    }
}
