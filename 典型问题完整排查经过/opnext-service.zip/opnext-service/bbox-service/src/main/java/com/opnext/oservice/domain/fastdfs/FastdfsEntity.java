package com.opnext.oservice.domain.fastdfs;

import lombok.Data;

import java.util.List;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午5:01 18/5/12
 */
@Data
public class FastdfsEntity {
    private String urlPattern;
    private List<FastdfsItem> items;
}
