package com.opnext.oservice.repository.person;


import com.opnext.oservice.domain.batch.BatchImportData;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface BatchImportRepository extends PagingAndSortingRepository<BatchImportData, Long>, QueryDslPredicateExecutor<BatchImportData> {

}