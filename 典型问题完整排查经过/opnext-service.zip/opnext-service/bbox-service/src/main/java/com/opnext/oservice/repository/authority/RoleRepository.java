package com.opnext.oservice.repository.authority;

import com.opnext.oservice.domain.authority.role.Role;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @author wanglu
 */

public interface RoleRepository extends PagingAndSortingRepository<Role, Long>,
        QueryDslPredicateExecutor<Role> {
    /**
     * 通过角色id和租户id查询角色
     * @param id
     * @param tenantId
     * @return
     */
    Role findAllByIdAndTenantId(long id, long tenantId);

    /**
     * 通过租户查询全部role并且roleId!=0
     * @param tenantId
     * @param id
     * @return
     */
    List<Role> findAllByTenantIdAndIdIsNot(long tenantId, long id);

    /**
     * 通过名称获取全部角色列表
     * @param name
     * @param tenantId
     * @return
     */
    List<Role> findAllByNameAndTenantId(String name,long tenantId);
}
