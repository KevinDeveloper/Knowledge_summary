package com.opnext.oservice.service.common;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonResponse;

/**
 * @author tianzc
 */
public interface InitializationService {

    /**
     * 初始化租户相关信息
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    CommonResponse init(OserviceOperator oserviceOperator, String orgName) throws Exception;

    /**
     * 创建识别记录mongo集合，按租户区分
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    CommonResponse createAccessRecordCollection(OserviceOperator oserviceOperator) throws Exception;
}
