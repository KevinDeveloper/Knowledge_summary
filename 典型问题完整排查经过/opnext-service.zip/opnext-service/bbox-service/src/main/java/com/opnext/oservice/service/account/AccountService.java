package com.opnext.oservice.service.account;

import com.opnext.oservice.controller.authority.AuthorizationController;
import com.opnext.oservice.domain.account.Account;
import com.opnext.oservice.domain.tenant.Tenant;
import com.opnext.oservice.dto.authority.AuthorityDTO;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

/**
 * @author wanglu
 */
public interface AccountService{

    /**
     * 分页获取账号列表
     * @param urlVariables
     * @return
     * @throws Exception
     */
    Page<Account> getAccountPage(Object... urlVariables)throws Exception ;

    /**
     * 判断密码是否正确
     * @param account
     * @return
     * @throws Exception
     */
    Boolean verifyPassword(Account account)throws Exception;

    /**
     * 获取权限账号列表（非分页）
     * @param urlVariables
     * @return
     * @throws Exception
     */
    List<AuthorityDTO> getAuthorityAccountList(Object... urlVariables)throws Exception ;

    /**
     * 获取账号列表（非分页）
     * @param urlVariables
     * @return
     * @throws Exception
     */
    List<Account> getAccountList(Object... urlVariables)throws Exception ;

    /**
     * 新增账号
     * @param account
     * @return
     * @throws Exception
     */
    Account addAccount(Account account) throws Exception;

    /**
     * 修改账号
     * @param account
     * @return
     * @throws Exception
     */
    ResponseEntity modifyAccount(Account account)throws Exception;

    /**
     * 修改账号状态：启用1、停用0
     * @param changeAccountStatusParam
     * @return
     * @throws Exception
     */
    List<Long> changeAccountStatus(AuthorizationController.ChangeAccountStatusParam changeAccountStatusParam)throws Exception;

    /**
     * 删除账号
     * @param paramMap
     * @return
     * @throws Exception
     */
    ResponseEntity deleteAccount(Map paramMap) throws Exception;

    /**
     * 获取租户详情
     * @param id
     * @return
     * @throws Exception
     */
    Tenant getTenantById(long id) throws Exception;
}
