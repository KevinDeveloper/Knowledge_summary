package com.opnext.oservice.util;

import lombok.extern.slf4j.Slf4j;

import java.io.Closeable;
import java.io.IOException;
import java.util.Objects;

/**
 * @author tianzc
 */
@Slf4j
public class CloseUtils {
    private CloseUtils(){}

    public static void closeQuietly(Closeable closeable) {
        if (Objects.nonNull(closeable)) {
            try {
                closeable.close();
            } catch (IOException e) {
                log.error("文件流关闭异常：{}", e.getMessage());
            }
        }
    }
}
