package com.opnext.oservice.controller.device;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.google.common.collect.Lists;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.validator.IsIntegerStringValidator;
import com.opnext.bboxsupport.validator.IsTimestampLongValidator;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.device.alarm.DeviceAlarm;
import com.opnext.oservice.domain.device.alarm.DeviceAlarmPriority;
import com.opnext.oservice.domain.device.alarm.DeviceAlarmType;
import com.opnext.oservice.domain.device.alarm.QDeviceAlarm;
import com.opnext.oservice.service.device.DeviceAlarmService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 *
 * @author wanglu
 */
@Slf4j
@RestController
@RequestMapping("/api/device/alarm")
public class DeviceAlarmController {

    @Autowired
    private DeviceAlarmService deviceAlarmService;


    @ApiOperation(value = "获取预警级别", notes = "获取告警级别，返回枚举字符串，需要定义字符串的国际化文字")
    @RequestMapping(value = "/level",method = RequestMethod.GET)
    public DeviceAlarmPriority[] getAlarmLevel(){
        return DeviceAlarmPriority.values();
    }

    @ApiOperation(value = "获取预警类型", notes = "获取告警类型列表")
    @RequestMapping(value = "/type",method = RequestMethod.GET)
    public Iterable<DeviceAlarmType> getAlarmType(){
        return deviceAlarmService.getAlarmTypeList();
    }

    @ApiOperation(value = "获取未读的终端预警总数", notes = "获取当前未读的终端预警总数")
    @RequestMapping(value = "/count",method = RequestMethod.GET)
    public int getAlarmCount(){
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        return deviceAlarmService.countByReadStatusAndTenantId(false, oserviceOperator.getTenantId());
    }

    @ApiOperation(value = "获取预警列表", notes = "获取告警列表，返回分页结果")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "long", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "query", dataType = "long", name = "endTime", value = "结束时间"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "alarmType", value = "告警类型id"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "deviceAlarmPriority", value = "告警级别枚举String"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码，从0开始"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数，默认10"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=occurTime,desc表示根据occreTime字段倒叙排序")
    })
    @RequestMapping(value = "/",method = RequestMethod.GET)
    public Page<DeviceAlarm> getAlarm(
            @RequestParam(required = false) Long startTime,
            @RequestParam(required = false) Long endTime,
            @RequestParam(required = false) String alarmType,
            @RequestParam(required = false) DeviceAlarmPriority deviceAlarmPriority,
            @PageableDefault Pageable pageable) throws Exception{
        //需要加一个校验
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(startTime, new IsTimestampLongValidator("startTime"))
                .on(endTime, new IsTimestampLongValidator("endTime"))
                .on(alarmType, new IsIntegerStringValidator("alarmType"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        QDeviceAlarm deviceAlarm = QDeviceAlarm.deviceAlarm;
        Long tenantId = oserviceOperator.getTenantId();
        //分页查询：查询租户下全部告警
        Predicate predicate =deviceAlarm.tenantId.eq(tenantId);
        if(StringUtils.isNotBlank(alarmType)){
            predicate = ((BooleanExpression) predicate).and(deviceAlarm.deviceAlarmType.eq(Integer.parseInt(alarmType)));
        }

        if (startTime != null){
            Date date = new Date(startTime);
            predicate=((BooleanExpression) predicate).and(deviceAlarm.occurTime.goe(date));
        }
        if (endTime !=null){
            Date date = new Date(endTime);
            predicate=((BooleanExpression) predicate).and(deviceAlarm.occurTime.loe(date));
        }

        //生成告警类型的map<告警类型ID，告警类型对象>，仅有四项纪录，因此本循环不会带来性能负担
        List<DeviceAlarmType> alarmTypeList = deviceAlarmService.getAlarmTypeList();
        Map<Integer,DeviceAlarmType> map = new HashMap<>(alarmTypeList.size());
        List<Integer> typeIds = Lists.newArrayList();
        for (DeviceAlarmType alarmType1 : alarmTypeList){
            map.put(alarmType1.getId(),alarmType1);
            if (deviceAlarmPriority!=null && alarmType1.getPriority().value()==deviceAlarmPriority.value()){
                typeIds.add(alarmType1.getId());
            }
        }

        if (deviceAlarmPriority!=null){
            predicate = ((BooleanExpression) predicate).and(deviceAlarm.deviceAlarmType.in(typeIds));
        }
        // 查询告警列表，并循环内部信息，补充写入告警类型对象。分页查询后的结果，记录有限，因此性能不至于太差
        Page<DeviceAlarm> deviceAlarms = deviceAlarmService.queryAlarmPagable(tenantId,predicate,pageable);
        List<DeviceAlarm> deviceAlarmList = deviceAlarms.getContent();
        for (int i=0; i<deviceAlarmList.size();i++){
            DeviceAlarm temp = deviceAlarmList.get(i);
            temp.setAlarmType(map.get(temp.getDeviceAlarmType()));
        }
        return deviceAlarms;
    }

}
