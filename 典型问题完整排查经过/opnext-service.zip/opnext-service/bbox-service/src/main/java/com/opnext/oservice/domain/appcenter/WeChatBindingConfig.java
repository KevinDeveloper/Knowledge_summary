package com.opnext.oservice.domain.appcenter;

import jdk.nashorn.internal.ir.annotations.Ignore;
import lombok.Data;
import javax.persistence.*;

/**
 * @author wanglu
 */
@Data
@Table(name = "init_config")
@Entity
public class WeChatBindingConfig {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Ignore
    private int id;
    @Column(name="config_key")
    private String configKey;
    /**
     * 此处的value值表示是否选中，1表示选中，0表示不必须选中
     */
    @Column(name="config_value")
    private String configValue;
    private int sequence;
    private String type;
    @Column(name="need_flag")
    private NeedFlag needFlag;

    public enum NeedFlag{
        /**
         * 可选参数
         */
        DEFAULT((byte) 0),
        /**
         * 必选参数
         */
        REQUIRED((byte)1),
        /**
         * 按规则设置必选项（当前情况，由此标志的项中至少有一项必填）
         */
        PATTERN((byte) 2);

        private byte value;

        NeedFlag(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }
}
