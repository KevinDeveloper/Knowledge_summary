package com.opnext.oservice.controller.rule;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.beebox.push.event.Event;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.rule.QRule;
import com.opnext.oservice.domain.rule.Rule;
import com.opnext.oservice.service.base.BaseRedisService;
import com.opnext.oservice.service.rule.RuleApplyService;
import com.opnext.oservice.service.rule.RuleDeviceService;
import com.opnext.oservice.service.rule.RuleService;
import com.opnext.oservice.validator.IsRuleValidator;
import com.querydsl.core.types.Predicate;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/25 13:10
 */
@Slf4j
@RestController
@RequestMapping("/api/rule")
@Api(value="规则接口",tags={"规则接口"})
public class RuleController {
    @Autowired
    private RuleService ruleService;
    @Autowired
    private RuleApplyService ruleApplyService;
    @Autowired
    private RuleDeviceService ruleDeviceService;
    @Autowired
    private BaseRedisService redisService;

    @ApiOperation(value = "获取规则列表", notes = "获取规则列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "offset", value = "偏移量"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "pageNumber", value = "页数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "pageSize", value = "每页大小"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，name,desc表示在按name倒序排列，不填默认按照updateTime倒序排列")
    })
    @GetMapping("/")
    public CommonResponse<Page<Rule>> getRules(@PageableDefault(sort = "updateTime", direction = Sort.Direction.DESC) Pageable pageable) {
        log.debug("进入到'获取规则列表'接口");
        log.debug(Messages.get("org.tenantId.orgId"));
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Long tenantId = oserviceOperator.getTenantId();
        QRule qRule = QRule.rule;
        Predicate predicate = qRule.tenantId.eq(tenantId).and(qRule.appId.eq(oserviceOperator.getAppId()));
        Page<Rule> rules = ruleService.findAll(predicate, pageable);
        if (rules == null) {
            return null;
        }
        List<Integer> ruleIdList = new ArrayList<>();
        rules.forEach(rule -> ruleIdList.add(rule.getId()));
        Map<Integer, Long> deviceCountMap = ruleDeviceService.getDeviceCountMap(ruleIdList);
        Map<Integer, Long> personCountMap = ruleApplyService.getPersonCountMap(ruleIdList);
        for (Rule rule : rules) {
            rule.setDeviceCount(deviceCountMap.getOrDefault(rule.getId(), 0L).intValue());
            rule.setPersonCount(personCountMap.getOrDefault(rule.getId(), 0L).intValue());
        }
        return CommonResponse.ok(rules);
    }

    @ApiImplicitParam(paramType = "path", dataType = "int", name = "ruleId", value = "规则id")
    @ApiOperation(value = "根据ID获取规则详情", notes = "根据ID获取规则详情")
    @GetMapping("/{ruleId}")
    public CommonResponse<Rule> getRule(@PathVariable("ruleId") int ruleId) throws Exception {
        log.debug("进入到'根据ID获取规则详'接口");
        Long tenantId = OperatorContext.getOperator().getTenantId();
        Rule rule = ruleService.findRuleByIdAndTenantId(ruleId, tenantId);
        if (rule == null) {
            log.debug("参数为空");
            throw new CommonException("DataNotFound");
        }
        if (rule.getType() == Rule.RuleType.PERSON.ordinal()) {
            rule.setPersonIds(ruleApplyService.getPersonIdByRuleId(ruleId, tenantId));
        } else if (rule.getType() == Rule.RuleType.ORGNIZATION.ordinal()) {
            rule.setOrganizationIds(ruleApplyService.getOrganizationIdByRuleId(ruleId, tenantId));
        }
        if (rule.getValidTill() == null) {
            rule.setValidTill(new Date(0));
        }
        rule.setStatus(new Date().before(rule.getValidTill()) ? Rule.Status.NORMAL : Rule.Status.FINISH);
        return CommonResponse.ok(rule);
    }

    @ApiOperation(value = "添加规则", notes = "添加规则")
    @PostMapping("/")
    @Transactional(rollbackFor = Exception.class, noRollbackFor = CommonException.class)
    public CommonResponse<Rule> addRule(@RequestBody Rule rule) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        log.debug("进入到'添加规则'接口,userId:{}", oserviceOperator.getUserId());
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(rule, new IsRuleValidator("rule", oserviceOperator.getOrganizations(), oserviceOperator.getUserType()))
                .doValidate()
                .result(toComplex());
        if (!ret.isSuccess()) {
            log.debug("参数错误");
            throw new CommonException(400, "parameter.incorrect", ret);
        }
        Rule returnRule = ruleService.findRuleByNameAndTenantId(rule.getName(), oserviceOperator.getTenantId());
        if (returnRule != null) {
            log.debug("名称已存在");
            throw new CommonException("NameRepeat");
        }
        if (redisService.hasKey(oserviceOperator.getUserId() + "_ADD_LOCK")) {
            log.info("添加规则频繁操作");
            throw new CommonException("not.operate frequently");
        } else {
            redisService.set(oserviceOperator.getUserId() + "_ADD_LOCK", true, 1L, TimeUnit.MINUTES);
        }
        rule = ruleService.addRule(rule, oserviceOperator);
        //消息推送
        ruleService.pushRule(rule, oserviceOperator.getTenantId(), Event.EventType.RULE_ADD);
        redisService.deleteKey(oserviceOperator.getUserId() + "_ADD_LOCK");
        return CommonResponse.ok(rule);
    }

    @ApiOperation(value = "更新规则", notes = "更新规则")
    @ApiImplicitParam(paramType = "path", dataType = "int", name = "ruleId", value = "规则id")
    @PutMapping("/{ruleId}")
    public void updateRule(@PathVariable("ruleId") int ruleId, @RequestBody Rule rule) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        log.debug("进入到'更新规则'接口,userId:{}", oserviceOperator.getUserId());
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(rule, new IsRuleValidator("rule", oserviceOperator.getOrganizations(), oserviceOperator.getUserType()))
                .doValidate()
                .result(toComplex());
        if (!ret.isSuccess()) {
            log.debug("参数错误");
            throw new CommonException(400, "parameter.incorrect", ret);
        }
        rule.setId(ruleId);
        Rule oldRule = ruleService.findRuleByIdAndTenantId(ruleId, oserviceOperator.getTenantId());
        if (oldRule == null) {
            log.debug("规则不存在");
            throw new CommonException("DataNotFound");
        }
        if (oldRule.getType() != rule.getType()) {
            log.debug("规则类型错误");
            throw new CommonException("DataNotFound");
        }
        if (oldRule.getValidTill().before(new Date())) {
            //消息推送
            ruleService.pushRule(oldRule, oserviceOperator.getTenantId(), Event.EventType.RULE_UPDATE);
            ruleService.modifyOverdueRule(rule, oserviceOperator);
            return;
        }
        Rule returnRule = ruleService.findRuleByNameAndTenantId(rule.getName(), oserviceOperator.getTenantId());
        if (returnRule != null && !returnRule.getId().equals(rule.getId())) {
            log.debug("名称已存在");
            throw new CommonException("NameRepeat");
        }
        if (redisService.hasKey(oserviceOperator.getUserId() + "_UPDATE_LOCK")) {
            log.info("修改规则频繁操作");
            throw new CommonException("not.operate frequently");
        } else {
            redisService.set(oserviceOperator.getUserId() + "_UPDATE_LOCK", true, 1L, TimeUnit.MINUTES);
        }
        oldRule.setName(rule.getName());
        oldRule.setDescription(rule.getDescription());
        oldRule.setTimeRule(rule.getTimeRule());
        oldRule.setPassMode(rule.getPassMode());
        oldRule.setPassTip(rule.getPassTip());
        oldRule.setUpdateTime(new Date());
        oldRule.setValidTill(rule.getValidTill());
        oldRule.setPersonIds(rule.getPersonIds());
        oldRule.setOrganizationIds(rule.getOrganizationIds());
        ruleService.updateRuleAsync(oldRule, (OserviceOperator) oserviceOperator.cloneBean());
    }

    @ApiIgnore
    @ApiOperation(value = "强制更新规则", notes = "强制更新规则")
    @ApiImplicitParam(paramType = "path", dataType = "int", name = "ruleId", value = "规则id")
    @PostMapping("/compulsory/{ruleId}")
    public void compulsoryUpdate(@PathVariable("ruleId") int ruleId, @RequestBody Rule rule) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        log.debug("进入到'强制更新规则'接口,userId:{}", oserviceOperator.getUserId());
        ComplexResult ret = FluentValidator.checkAll()
                .failFast()
                .on(rule, new IsRuleValidator("rule", oserviceOperator.getOrganizations(), oserviceOperator.getUserType()))
                .doValidate()
                .result(toComplex());
        if (!ret.isSuccess()) {
            log.debug("参数错误");
            throw new CommonException(400, "parameter.incorrect", ret);
        }
        rule.setId(ruleId);
        Rule oldRule = ruleService.findRuleByIdAndTenantId(ruleId, oserviceOperator.getTenantId());
        if (oldRule == null) {
            log.debug("规则不存在");
            throw new CommonException("DataNotFound");
        }
        if (oldRule.getType() != rule.getType()) {
            log.debug("规则类型错误");
            throw new CommonException("DataNotFound");
        }
        Rule returnRule = ruleService.findRuleByNameAndTenantId(rule.getName(), oserviceOperator.getTenantId());
        if (returnRule != null && !returnRule.getId().equals(rule.getId())) {
            log.debug("名称已存在");
            throw new CommonException("NameRepeat");
        }
        if (redisService.hasKey(oserviceOperator.getUserId() + "_UPDATE_LOCK")) {
            log.info("修改规则频繁操作");
            throw new CommonException("not.operate frequently");
        } else {
            redisService.set(oserviceOperator.getUserId() + "_UPDATE_LOCK", true, 1L, TimeUnit.MINUTES);
        }
        oldRule.setName(rule.getName());
        oldRule.setDescription(rule.getDescription());
        oldRule.setTimeRule(rule.getTimeRule());
        oldRule.setPassMode(rule.getPassMode());
        oldRule.setPassTip(rule.getPassTip());
        oldRule.setUpdateTime(new Date());
        oldRule.setValidTill(rule.getValidTill());
        oldRule.setPersonIds(rule.getPersonIds());
        oldRule.setOrganizationIds(rule.getOrganizationIds());
        ruleService.compulsoryUpdateAsync(oldRule, (OserviceOperator) oserviceOperator.cloneBean());
    }

    @Transactional(rollbackFor = Exception.class)
    @ApiOperation(value = "删除规则", notes = "删除规则")
    @DeleteMapping("/{ruleId}")
    @ApiImplicitParam(paramType = "path", dataType = "int", name = "ruleId", value = "规则id")
    public void deleteRule(@PathVariable("ruleId") int ruleId) throws Exception {
        log.debug("进入到'删除规则'接口");
        List<Integer> ruleIds = new ArrayList<>();
        ruleIds.add(ruleId);
        ruleService.delRules(ruleIds, OperatorContext.getOperator());
    }

    @ApiIgnore
    @Transactional(rollbackFor = Exception.class)
    @ApiOperation(value = "删除人员规则和规则下的访客", notes = "提供给访客APP使用")
    @DeleteMapping("/person/{ruleId}")
    public void deleteRuleAndPerson(@PathVariable("ruleId") int ruleId) throws Exception {
        log.debug("进入到'删除人员规则和规则下的访客'接口");
        ruleService.delRuleAndPerson(ruleId, OperatorContext.getOperator());
    }

    @ApiIgnore
    @Transactional(rollbackFor = Exception.class)
    @ApiOperation(value = "批量删除规则", notes = "批量删除规则")
    @ApiImplicitParam(dataType = "String", name = "ruleIds", value = "规则id数组")
    @PostMapping("/batchDeleteRule")
    public void batchDeleteRule(@RequestBody List<Integer> ruleIds) throws Exception {
        log.debug("进入到'批量删除规则'接口");
        if (ruleIds == null || ruleIds.size() == 0) {
            log.debug("参数为空");
            throw new CommonException("string.notEmpty");
        }
        ruleService.delRules(ruleIds, OperatorContext.getOperator());
    }
}
