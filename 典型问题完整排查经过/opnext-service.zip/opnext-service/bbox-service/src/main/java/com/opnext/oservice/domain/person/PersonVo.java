package com.opnext.oservice.domain.person;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.opnext.domain.PersonType;
import com.opnext.domain.ResourceType;
import com.opnext.domain.Sex;
import com.opnext.oservice.domain.converter.PersonAvatarsConverter;
import com.opnext.oservice.domain.converter.PersonVariableConverter;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import springfox.documentation.annotations.ApiIgnore;

import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author tianzc
 */
@Data
@Entity
@ApiModel(description="人员Vo实体")
public class PersonVo implements Serializable {
    private static final long serialVersionUID = 3624988207631812342L;
    @Id
    @ApiModelProperty(value="id")
    private String id;

    @ApiModelProperty(value="姓名")
    private String name;

    @ApiModelProperty(value="编号")
    private String no;

    @ApiModelProperty(value="性别")
    private Sex sex;

    @ApiModelProperty(value="类型")
    private PersonType type;

    @ApiModelProperty(value="身份证号")
    private String idCard;

    @ApiModelProperty(value="手机号")
    private String phone;

    @ApiModelProperty(value="职位")
    private String position;

    @ApiModelProperty(value="邮箱")
    private String mail;

    @ApiModelProperty(value="ic卡号")
    private String icNumber;

    @ApiModelProperty(value="韦根号")
    private String wgNumber;

    @ApiModelProperty(value="组织id")
    private Integer organizationId;

    @ApiModelProperty(value="规则id")
    private Integer ruleId;

    @ApiModelProperty(value="同步状态")
    private SyncStatus syncStatus;
    @ApiModelProperty(value="同步版本")
    private Long syncVersion;
    @ApiModelProperty(value="入职时间")
    private Date hiredate;

    @ApiModelProperty(value="参数库id")
    private String groupId;

    @ApiModelProperty(value="备注")
    private String remark;
    @ApiModelProperty(value="创建时间")
    private Date createTime;
    @ApiModelProperty(value="更新时间")
    private Date updateTime;
    @ApiModelProperty(value="租户id")
    private Long tenantId;
    @ApiModelProperty(value="管理员id")
    private Long operatorId;
    @ApiModelProperty(value="管理员")
    private String operatorName;
    @ApiModelProperty(value="应用id")
    private String appId;

    @Convert(converter = PersonVariableConverter.class)
    @ApiModelProperty(value="可选字段")
    private Map<String, String> variable;
    @Convert(converter = PersonAvatarsConverter.class)
    @ApiModelProperty(value="照片")
    private Map<ResourceType, List<String>> avatars;
    private String organization;


    //------------------------------- 批量新增


    private String avatarName;

    private String batchAddResult ="";

    private boolean importResult = true;

    private String sexTitle;

    private String hireDateTitle;

    private String groupName;

    private String password;

}
