package com.opnext.oservice.controller.appcenter;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.appcenter.Application;
import com.opnext.oservice.service.appcenter.ApplicationService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Objects;


/**
 * @author wanglu
 */
@Slf4j
@RestController
@RequestMapping("/api")
public class ApplicationController {
    @Autowired
    private ApplicationService applicationService;

    @ApiOperation(value = "应用列表", notes = "获取应用租户的应用列表")
    @RequestMapping(value = "/apps", method = RequestMethod.GET)
    public CommonResponse<Application> getAppList(){
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        List<Application> applications = applicationService.getApplications(tenantId);
        return CommonResponse.ok(applications);
    }

    @ApiOperation(value = "添加应用", notes = "添加一个应用")
    @RequestMapping(value = "/app", method = RequestMethod.POST)
    public void saveApplication(@Valid @RequestBody Application application, BindingResult bindingResult)throws Exception{
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        if (bindingResult.hasErrors()){
            log.error("添加应用失败,{}",bindingResult);
            throw new CommonException(400,"parameter.incorrect",bindingResult);
        }
        long tenantId = oserviceOperator.getTenantId();
        List<Application> applicationList = applicationService.getApplicationsByAppId(application.getAppId(),tenantId);

        if (!CollectionUtils.isEmpty(applicationList)){
            log.error("添加应用失败,appId已存在,appId={}",application.getAppId());
            throw new CommonException(400,"app.param.appId.exist");
        }
        if(application.getExpiredDateType() == Application.ExpiredDateType.TIME_LIMITED){
            if (Objects.isNull(application.getExpiredDate())){
                log.error("添加应用失败,有效期类型为TIME_LIMITED，但expiredDate为空");
                throw new CommonException(400,"app.param.expire.error");
            }
        }
        application.setTenantId(tenantId);
        application.setCreateTime(new Date());
        applicationService.saveApplication(application);
    }

    @ApiOperation(value = "修改应用", notes = "添加一个应用")
    @RequestMapping(value = "/app/{id}", method = RequestMethod.POST)
    public void modifyApplication(@PathVariable int id, @Valid @RequestBody Application application, BindingResult bindingResult)throws Exception{
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        if (bindingResult.hasErrors()){
            log.error("修改应用失败,{}",bindingResult);
            throw new CommonException(400,"parameter.incorrect",bindingResult);
        }
        long tenantId = oserviceOperator.getTenantId();
        Application srcApplication = applicationService.getApplicationById(id,tenantId);
        if (Objects.isNull(srcApplication)){
            throw new CommonException(400,"app.not.exist");
        }
        if(application.getExpiredDateType() == Application.ExpiredDateType.TIME_LIMITED){
            if (Objects.isNull(application.getExpiredDate())){
                log.error("添加应用失败,有效期类型为TIME_LIMITED，但expiredDate为空");
                throw new CommonException(400,"app.param.expire.error");
            }
        }
        BeanUtils.copyProperties(application,srcApplication);
        srcApplication.setId(id);
        srcApplication.setTenantId(tenantId);
        applicationService.modifyApplication(srcApplication);
    }

}
