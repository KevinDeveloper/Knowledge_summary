package com.opnext.oservice.controller.device.api;

import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.bboxdomain.context.CommonContext;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.domain.PersonInfo;
import com.opnext.domain.config.OConfigGroup;
import com.opnext.domain.message.Command;
import com.opnext.domain.request.CallBackRequest;
import com.opnext.domain.request.FeedBackRequest;
import com.opnext.domain.response.AdminResp;
import com.opnext.domain.response.PersonResp;
import com.opnext.oservice.conf.Constant;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.accessrecord.AccessRecordInfo;
import com.opnext.oservice.domain.command.BusinessType;
import com.opnext.oservice.domain.device.DeviceConfig;
import com.opnext.oservice.domain.device.alarm.DeviceAlarm;
import com.opnext.oservice.domain.device.alarm.DeviceAlarmType;
import com.opnext.oservice.domain.person.OperationType;
import com.opnext.oservice.service.accessrecord.AccessRecordService;
import com.opnext.oservice.service.device.DeviceAlarmService;
import com.opnext.oservice.service.device.DeviceConfigService;
import com.opnext.oservice.service.device.api.DeviceApiService;
import com.opnext.oservice.util.JsonConvertor;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;


/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午4:50 18/5/7
 */
@Slf4j
@RestController
@RequestMapping("/api/devapi")
public class DeviceApiController {

    @Autowired
    DeviceApiService deviceApiService;
    @Autowired
    DeviceConfigService deviceConfigService;
    @Autowired
    AccessRecordService accessRecordService;
    @Autowired
    DeviceAlarmService deviceAlarmService;
    @ApiOperation(value = "获取设备租户信息", notes = "")
    @RequestMapping(value = "/sn/operator", method = RequestMethod.GET)
    public CommonResponse getOperator() throws Exception{
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        return CommonResponse.ok(oserviceDevApiOperator);
    }

    @ApiOperation(value = "终端处理指令错误回调", notes = "")
    @RequestMapping(value = "/callback/{workflowId}/{commandId}/{requestId}/{businessType}",method = RequestMethod.POST)
    public CommonResponse errorCallback (@PathVariable("workflowId") String workflowId,
                                         @PathVariable("commandId") String commandId,
                                         @PathVariable("requestId") String requestId,
                                         @PathVariable("businessType") BusinessType businessType, @RequestBody CallBackRequest callBackRequest) throws Exception {
        log.info("终端错误回调workflowId：{}，commandId：{}，requestId：{}", workflowId, commandId, requestId);
        log.info("终端错误回调callBackRequest：{}", JsonConvertor.beanToJson(callBackRequest));
        Command command = new Command();
        command.setWorkflowId(workflowId);
        command.setCommandId(commandId);
        command.setRequestId(requestId);
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        deviceApiService.errorCallback(command, oserviceDevApiOperator,businessType,callBackRequest);
        return CommonResponse.ok(new HashMap<>());
    }

    @ApiOperation(value = "终端指令处理反馈", notes = "")
    @RequestMapping(value = "/feedback/{workflowId}/{commandId}/{requestId}/{businessType}",method = RequestMethod.POST)
    public CommonResponse feedback (@PathVariable("workflowId") String workflowId,
                                    @PathVariable("commandId") String commandId,
                                    @PathVariable("requestId") String requestId,
                                    @PathVariable("businessType") BusinessType businessType,
                                    @RequestBody FeedBackRequest feedBackRequest) throws Exception {
        log.info("终端处理反馈workflowId：{}，commandId：{}，requestId：{}", workflowId, commandId, requestId);
        log.info("终端处理反馈feedBackRequest：{}", JsonConvertor.beanToJson(feedBackRequest));
        Command command = new Command();
        command.setWorkflowId(workflowId);
        command.setCommandId(commandId);
        command.setRequestId(requestId);
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        deviceApiService.feedback(command, oserviceDevApiOperator,businessType, feedBackRequest);
        return CommonResponse.ok(new HashMap<>());
    }

    @ApiOperation(value = "识别记录保存", notes = "")
    @RequestMapping(value = "/recognitionRecords",method = RequestMethod.POST)
    public CommonResponse saveRecord (@RequestBody List<AccessRecordInfo> accessRecordInfoList) throws Exception{
        log.debug("终端上传识别记录accessRecordInfoList：{}", JsonConvertor.listToJson(accessRecordInfoList));
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        CommonResponse commonResponse = accessRecordService.batchSaveOfcollection(accessRecordInfoList, oserviceDevApiOperator,urlPrefix);
        return commonResponse;
    }

    @ApiOperation(value = "激活后上传设备配置", notes = "终端接受指令上传设置回调方法")
    @RequestMapping(value = "/callback/config/{workflowId}/{commandId}/{requestId}",method = RequestMethod.POST)
    public void configCallback(@PathVariable("workflowId") String workflowId, @PathVariable("commandId") String commandId,
                               @PathVariable("requestId") String requestId, @RequestBody OConfigGroup oConfigGroup) throws Exception {
        log.debug("激活后终端上传配置oConfigGroup：{}", JsonConvertor.beanToJson(oConfigGroup));
        Command command = new Command();
        command.setWorkflowId(workflowId);
        command.setCommandId(commandId);
        command.setRequestId(requestId);
        deviceConfigService.configCallback(command,oConfigGroup);
    }

    @ApiOperation(value = "缓存设备配置", notes = "web下发指令，终端上传配置")
    @RequestMapping(value = "/callback/config/cache/{workflowId}/{commandId}/{requestId}",method = RequestMethod.POST)
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", required = true, dataType = "String", name = "redisKey", value = "缓存key")
    })
    public void configCacheCallback(@PathVariable("workflowId") String workflowId, @PathVariable("commandId") String commandId,
                                    @PathVariable("requestId") String requestId, @RequestParam String redisKey, @RequestBody OConfigGroup oConfigGroup) throws Exception {
        log.debug("终端上传配置oConfigGroup：{}", JsonConvertor.beanToJson(commandId));
        log.info("缓存设备配置-终端上传oConfigGroup对应redisKey：{}", redisKey);
        Command command = new Command();
        command.setWorkflowId(workflowId);
        command.setCommandId(commandId);
        command.setRequestId(requestId);
        deviceConfigService.configCacheCallback(command,redisKey, oConfigGroup);

    }

    @ApiOperation(value = "获取单个设置", notes = "")
    @RequestMapping(value = "/config/{serviceType}/{id}",method = RequestMethod.GET)
    public CommonResponse getConfig(@PathVariable String serviceType, @PathVariable String id) throws Exception {
        log.info("api获取设置参数-serviceType：{}，id：{}", serviceType, id);
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        long tenantId = oserviceDevApiOperator.getTenantId();
        DeviceConfig qDeviceConfig = deviceConfigService.getConfig(serviceType, id, tenantId);
        Object obj = new Object();
        if (null != qDeviceConfig) {
            obj = qDeviceConfig.getObjConfig();
        } else {
            log.info("----------根据id没有查询到有效设置数据----------");
        }
        return CommonResponse.ok(obj);
    }

    @ApiOperation(value = "获取设置", notes = "根据sn获取设备配置")
    @RequestMapping(value = "/config/sn/{serviceType}",method = RequestMethod.GET)
    public CommonResponse getSNConfig(@PathVariable String serviceType) throws Exception {
        log.info("根据sn，api获取设置参数-serviceType：{}", serviceType);
        DeviceConfig qDeviceConfig = deviceConfigService.getSNConfig(serviceType);
        Object obj = new Object();
        if (null != qDeviceConfig) {
            obj = qDeviceConfig.getObjConfig();
        } else {
            log.info("----------根据sn没有查询到有效设置数据----------");
        }
        return CommonResponse.ok(obj);
    }

    @ApiOperation(value = "新增配置", notes = "新增设备配置，可用平台下发指令终端上报设备设置")
    @RequestMapping(value = "/config/{serviceType}",method = RequestMethod.POST)
    public CommonResponse saveConfig(@PathVariable String serviceType, @RequestBody DeviceConfig deviceConfig) throws Exception {
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();

        DeviceConfig qDeviceConfig = deviceConfigService.saveConfig(serviceType, deviceConfig, oserviceDevApiOperator.getTenantId(), oserviceDevApiOperator.getSn());
        Object obj = new Object();
        if (null != qDeviceConfig) {
            obj = qDeviceConfig.getObjConfig();
        }
        return CommonResponse.ok(obj);
    }



    @ApiOperation(value = "获取服务端的服务地址和API列表", notes = "")
    @RequestMapping(value = "/server", method = RequestMethod.GET)
    public CommonResponse getServer(String sn) throws Exception{
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        return CommonResponse.ok(deviceApiService.getServer(sn,urlPrefix));
    }

    @ApiOperation(value = "恢复出厂设置", notes = "")
    @RequestMapping(value = "/server/{sn}", method = RequestMethod.DELETE)
    public CommonResponse restoreFactorySettings(@PathVariable String sn) throws Exception{
        log.info("------恢复出厂设置参数sn：{}", sn);
        deviceApiService.restoreFactorySettings(sn, "reset");
        return CommonResponse.ok(new HashMap<>());
    }

    @ApiOperation(value = "上传终端告警", notes = "告警上传")
    @RequestMapping(value = "/device/{sn}/alarm",method = RequestMethod.POST)
    public void uploadAlarm(@PathVariable(name="sn") String sn, @RequestBody @Valid DeviceAlarmSaveRequest deviceAlarmSaveRequest,
                                      BindingResult bindingResult)throws Exception{
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        //参数校验
        if(bindingResult.hasErrors()){
            log.error("终端告警上传失败，参数错误");
            throw new CommonException(400,"device.alarm.upload.param.error",bindingResult);
        }
        if(StringUtils.isBlank(sn)){
            log.error("终端告警上传失败,sn号为空");
            throw new CommonException("device.alarm.upload.sn.error");
        }
        DeviceAlarmType deviceAlarmType =
                deviceAlarmService.findDeviceAlarmTypeByName(deviceAlarmSaveRequest.getAlarmType());
        if(Objects.isNull(deviceAlarmType)){
            log.error("终端告警上传失败,通过告警类型参数没有找到对应的告警类型实体");
            throw new CommonException("device.alarm.upload.alarmType.error");
        }
        //准备入库参数
        Date occurTime = new java.util.Date(deviceAlarmSaveRequest.getOccurTime());
        DeviceAlarm deviceAlarm =new DeviceAlarm();
        deviceAlarm.setDescription(deviceAlarmType.getName());
        deviceAlarm.setOccurTime(occurTime);
        deviceAlarm.setDeviceAlarmType(deviceAlarmType.getId());
        deviceAlarm.setDeviceSn(sn);
        deviceAlarm.setTenantId(oserviceDevApiOperator.getTenantId());
        deviceAlarm.setReadStatus(false);
        deviceAlarm.setCreateTime(new Date());
        log.info("准备保存终端告警，参数为:{}",deviceAlarm.toString());
        deviceAlarmService.saveDeviceAlarm(deviceAlarm);
    }

    @ApiOperation(value = "终端获取人员信息", notes = "")
    @RequestMapping(value = "/callback/person/{workflowId}/{commandId}/{requestId}",method = RequestMethod.GET)
    public CommonResponse getPerson (@PageableDefault(size = Constant.PERSON_PAGEABLE_SIZE) Pageable pageable,
                                                    @PathVariable("workflowId") String workflowId,
                                                    @PathVariable("commandId") String commandId,
                                                    @PathVariable("requestId") String requestId,
                                                    @RequestParam Long syncVersion,
                                                    @RequestParam OperationType operationType) throws Exception {
        log.info("------终端同步人员参数syncVersion：{}，操作类型operationType：{}", syncVersion, operationType);
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        PersonResp personResp =deviceApiService.getPerson(pageable, operationType, syncVersion, workflowId, commandId, requestId,urlPrefix);
        return CommonResponse.ok(personResp);
    }

    @ApiOperation(value = "终端获取设备管理员信息", notes = "")
    @RequestMapping(value = "/callback/admin/{workflowId}/{commandId}/{requestId}",method = RequestMethod.GET)
    public CommonResponse getAdmin (@PageableDefault() Pageable pageable,
                                     @PathVariable("workflowId") String workflowId,
                                     @PathVariable("commandId") String commandId,
                                     @PathVariable("requestId") String requestId) throws Exception {
        log.info("------终端同步管理员回调参数workflowId：{}，commandId：{}，requestId：{}", workflowId, commandId,requestId);
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        Command command = new Command();
        command.setWorkflowId(workflowId);
        command.setCommandId(commandId);
        command.setRequestId(requestId);
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        AdminResp adminResp =deviceApiService.getAdmin(pageable, oserviceDevApiOperator, command,urlPrefix);
        return CommonResponse.ok(adminResp);
    }

    @ApiOperation(value = "根据人员ID获取人员最新信息", notes = "")
    @RequestMapping(value = "/person",method = RequestMethod.GET)
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "ids", value = "人员ID，逗号分隔。最多可传20个"),
            @ApiImplicitParam(paramType = "query", required = true, dataType = "String", name = "nos", value = "人员编号，逗号分隔。最多可传20个")
    })
    public CommonResponse getPersonOne (String ids, String nos) throws Exception {
        log.info("获取人员信息参数ids：{}，nos：{}", ids, nos);
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        List<PersonInfo> list = deviceApiService.getPersonList(ids, nos, oserviceDevApiOperator,urlPrefix);
        return CommonResponse.ok(list);
    }

    @Data
    static class DeviceAlarmSaveRequest{
        @NotEmpty
        @Length(max=50, message = "长度不能超过50位")
        private String description;
        @NotNull
        private Long occurTime;
        @NotEmpty
        private String alarmType;
    }

    @Data
    public static class DeviceActiveRequest{
        @NotEmpty(message="device.sn.notEmpty")
        private String sn;

        @NotEmpty(message="device.type.notEmpty")
        private String deviceType;

        @NotEmpty(message="device.activeCode.notEmpty")
        private String activeCode;

        @NotEmpty(message="device.version.notEmpty")
        private String deviceVersion;
    }

}
