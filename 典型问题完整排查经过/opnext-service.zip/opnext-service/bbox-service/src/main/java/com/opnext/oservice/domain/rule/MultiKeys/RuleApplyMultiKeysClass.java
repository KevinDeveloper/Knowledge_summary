package com.opnext.oservice.domain.rule.MultiKeys;

import lombok.Data;

import java.io.Serializable;

/**
 * @Author: lixiuwen
 * @Date: 2018/6/21 17:49
 * @Param personId
 * @Param ruleId
 * 由这两个共同组成复合主键
 */
@Data
public class RuleApplyMultiKeysClass implements Serializable {

    /**
     * 应用于人员ID
     */
    private String personId;

    /**
     * 规则ID
     */
    private Integer ruleId;

    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((personId == null) ? 0 : personId.hashCode());
        result = PRIME * result + ((ruleId == null) ? 0 : ruleId.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }

        final RuleApplyMultiKeysClass other = (RuleApplyMultiKeysClass) obj;
        if (personId == null) {
            if (other.personId != null) {
                return false;
            }
        } else if (!personId.equals(other.personId)) {
            return false;
        }
        if (ruleId == null) {
            if (other.ruleId != null) {
                return false;
            }
        } else if (!ruleId.equals(other.ruleId)) {
            return false;
        }

        return true;
    }
}
