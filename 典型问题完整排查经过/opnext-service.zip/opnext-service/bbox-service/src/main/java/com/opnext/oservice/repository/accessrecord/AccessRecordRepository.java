package com.opnext.oservice.repository.accessrecord;

import com.opnext.oservice.domain.accessrecord.AccessRecordInfo;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;

/**
 * @author tianzc
 */
public interface AccessRecordRepository extends MongoRepository<AccessRecordInfo, String>,
        QueryDslPredicateExecutor<AccessRecordInfo> {
}
