package com.opnext.oservice.dto;

import lombok.AllArgsConstructor;

/**
 * @author tianzc
 */
@AllArgsConstructor
public enum TerminalFailCode {
    ACTIVATION_CODE_INCORRECT(104801, "activation.code.incorrect"),
    DEVICE_SN_INCORRECT(104802, "device.sn.incorrect"),
    DEVICE_TYPE_INCORRECT(104803, "device.type.incorrect");
    private Integer value;
    private String message;
    public Integer getValue(){
        return this.value;
    }
    public String getMessage(){
        return this.message;
    }
}
