package com.opnext.oservice.repository.device;

import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.domain.device.DeviceStatus;
import com.opnext.oservice.domain.device.DeviceType;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:02 18/5/7
 */
public interface DeviceRepository extends PagingAndSortingRepository<Device, Integer>,
        QueryDslPredicateExecutor<Device> {
    /**
     * 通过设备SN号查询设备对象
     * @param sn
     * @return
     *
     */
    Device findBySn(String sn);

    @Modifying
    @Query(value = "insert ignore into device(sn,type,version,status,tenant_id) values(?1,?2,?3,?4,?5)",nativeQuery = true)
    int insertDevice(String sn, String type, String version, Integer deviceStatus, Long tenantId);

    /**
     * 根据设备ID和租户ID查询设备
     * @param id
     * @param tenant
     * @return
     */
    Device findDeviceByIdAndTenantId(int id, long tenant);

    /**
     * 根据设备SN和租户ID查询设备
     * @param sn 设备SN号
     * @param tenantId 租户ID
     * @return 查询结果
     */
    Device findDeviceBySnAndTenantId(String sn,long tenantId);
}
