package com.opnext.oservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author tianzc
 */
@AllArgsConstructor
public enum CommonFailedStatus {
    DATABASE_EXCEPTION(104002, "service.database.exception"),
    DATABASE_LOCK_EXCEPTION(104003, "service.database.lock.exception"),
    DATABASE_INSERT_DUPLICATE_EXCEPTION(104004, "service.database.insert.duplicate.exception"),
    DATABASE_UNIQUE_EXCEPTION(104005, "service.database.unique.exception");
    private Integer value;
    private String message;
    public Integer getValue(){
        return this.value;
    }
    public String getMessage(){
        return this.message;
    }
}
