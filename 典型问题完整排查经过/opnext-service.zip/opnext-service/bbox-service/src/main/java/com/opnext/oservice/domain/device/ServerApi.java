package com.opnext.oservice.domain.device;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:06 18/5/7
 */
@Data
@Entity
@Table(name = "server_api")
public class ServerApi implements Cloneable {
    @Id
    @GeneratedValue
    private Integer id;
    private String name;
    private String description;
    private String method;
    private String uri;
    private String version;
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
