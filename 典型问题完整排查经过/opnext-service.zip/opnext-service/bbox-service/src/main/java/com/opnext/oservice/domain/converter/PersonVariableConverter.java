package com.opnext.oservice.domain.converter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.type.MapType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.util.CollectionUtils;

import javax.persistence.AttributeConverter;
import java.util.HashMap;
import java.util.Map;

/**
 * @author tianzc
 */
@Slf4j
public class PersonVariableConverter implements AttributeConverter<Map<String, String>, String> {
    /**
     * Converts the value stored in the entity attribute into the
     * data representation to be stored in the database.
     *
     * @param attribute the entity attribute value to be converted
     * @return the converted data to be stored in the database column
     */
    @Override
    public String convertToDatabaseColumn(Map<String, String> attribute) {
        ObjectMapper mapper = new ObjectMapper();
        String str = null;
        try {
            if (!CollectionUtils.isEmpty(attribute)) {
                str = mapper.writeValueAsString(attribute);
            }
        } catch (Exception e) {
            log.error("--------PersonVariable attribute jackson转换异常，参数：{}", attribute);
            log.error("jackson转换异常：{}", e.getMessage());
        }
        return str;
    }

    /**
     * Converts the data stored in the database column into the
     * value to be stored in the entity attribute.
     * Note that it is the responsibility of the converter writer to
     * specify the correct dbData type for the corresponding column
     * for use by the JDBC driver: i.e., persistence providers are
     * not expected to do such type conversion.
     *
     * @param dbData the data from the database column to be converted
     * @return the converted value to be stored in the entity attribute
     */
    @Override
    public Map<String, String> convertToEntityAttribute(String dbData) {
        ObjectMapper mapper = new ObjectMapper();
        Map<String, String> map = new HashMap<>();
        try {
            if (StringUtils.isNoneBlank(dbData)) {
                MapType mapType = mapper.getTypeFactory().constructMapType(HashMap.class, String.class, String.class);
                map = mapper.readValue(dbData, mapType);
            } else {
                return map;
            }
        } catch (Exception e) {
            log.error("--------PersonVariable dbData jackson转换异常数据，参数：{}", dbData);
            log.error("jackson转换异常：{}", e.getMessage());
        }
        return map;
    }
}
