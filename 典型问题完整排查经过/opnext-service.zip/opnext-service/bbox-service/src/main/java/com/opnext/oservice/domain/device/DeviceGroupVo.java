package com.opnext.oservice.domain.device;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午1:40 18/5/8
 */
@Data
@Entity
public class DeviceGroupVo {
    @Id
    private Integer id;
    private String groupName;
    private Date updateTime;
    private Long deviceCount;
    private String remark;
    private Long tenantId;
}
