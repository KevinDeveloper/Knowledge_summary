package com.opnext.oservice.domain.device;

import lombok.Data;

/**
 * @author tianzc
 */
@Data
public class DeviceAdminIdRel {
    private Integer[] deviceIds;
    private Integer[] adminIds;
}
