package com.opnext.oservice.dto.person;

import lombok.Data;

/**
 * @author tianzc
 */
@Data
public class PersonDTO {
    /**
     * 人员id
     */
    private String id;
    /**
     * 人员名称
     */
    private String name;
    /**
     * 组织id
     */
    private Integer organizationId;

}
