package com.opnext.oservice.repository.tenant;

import com.opnext.oservice.domain.tenant.TenantWechat;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @author lixiuwen
 */
public interface TenantWechatRepository extends PagingAndSortingRepository<TenantWechat, Long>, QueryDslPredicateExecutor<TenantWechat> {
    /**
     * 根据AppId删除数据
     * @param appId appId
     */
    void deleteByAppId(String appId);

    /**
     * 根据AppId删除不是当前租户ID的数据
     * @param appId appId
     * @param tenantId 租户ID
     */
    void deleteByAppIdAndTenantIdIsNot(String appId,Long tenantId);
}
