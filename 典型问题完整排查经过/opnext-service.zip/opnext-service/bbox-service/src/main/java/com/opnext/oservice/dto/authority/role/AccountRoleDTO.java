package com.opnext.oservice.dto.authority.role;

import com.opnext.oservice.domain.authority.role.Role;
import lombok.Data;

import java.util.Date;

/**
 * @author wanglu
 */
@Data
public class AccountRoleDTO{
    private Long id;
    private String name;
    private String description;
    private Role.Type type;
    private Long createdBy;
    private Date createTime;
    private Date updateTime;
    private Long accountId;
    private Long tenantId;
}
