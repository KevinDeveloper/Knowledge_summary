package com.opnext.oservice.domain.authority.role;

import jdk.nashorn.internal.ir.annotations.Ignore;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

import javax.persistence.*;

/**
 * @author wanglu
 */
@Entity
@Table(name = "module")
@Data
@Builder
public class Module {
    @Id
    @GeneratedValue
    private Integer id;
    private String name;
    private Scope scope;
    private String appid;

    @Ignore
    @Column(name = "is_main_function")
    private IsMainFunction isMainFunction;

    @Column(name="pid")
    private Integer pid;

    public enum Scope{
        /**
         * 超级管理员（表示不能角色授权）
         */
        SUPER_ADMIN((byte) 0),
        /**
         * 任意管理账号（表示可以角色授权）
         */
        ADMIN((byte)1);
        private byte value;

        Scope(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }

    public enum IsMainFunction{
        /**
         * 不作为接口调用主攻功能
         */
        FALSE((byte) 0),
        /**
         * 作为接口调用主攻功能
         */
        TRUE((byte)1);
        private byte value;

        IsMainFunction(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }

    @Tolerate
    Module(){}
}
