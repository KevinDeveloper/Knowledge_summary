package com.opnext.oservice.domain.device;

import com.alibaba.fastjson.JSONObject;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;

/** 
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午5:02 18/5/7
 */
@Entity
@Data

public class DeviceConfigVo implements Serializable {

    @Id
    private String id;
    private String name;
    private String serviceType;
    private String sn;
    private Long version;
    private String description;
    private String createTime;
    private String updateTime;
    private Long tenantId;

    private JSONObject objConfig;


    /**
     * 配置请求类型
     */
    public enum ServiceType {

        /**
         * 基础类型
         */
        BASE,
        /**
         * 单个设个获取配置
         */
        SN,
        /**
         * 分库识别类型
         */
        GROUP;
    }

}
