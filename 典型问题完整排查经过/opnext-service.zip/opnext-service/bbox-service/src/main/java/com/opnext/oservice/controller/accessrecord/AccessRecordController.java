package com.opnext.oservice.controller.accessrecord;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.context.CommonContext;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.accessrecord.AccessRecordInfo;
import com.opnext.oservice.domain.accessrecord.SearchAccessRecord;
import com.opnext.oservice.domain.accessrecord.SearchAccessRecordOa;
import com.opnext.oservice.service.accessrecord.AccessRecordService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * @author tianzc
 */
@Api(value="识别记录接口",tags={"识别记录接口"})
@Slf4j
@RestController
@RequestMapping("/api/access-record")
public class AccessRecordController {
    @Autowired
    AccessRecordService accessRecordService;

    @ApiIgnore
    @ApiOperation(value = "验证结果", notes = "")
    @RequestMapping(value = "/result", method = RequestMethod.GET)
    public CommonResponse deviceStatusList() throws Exception{
        return CommonResponse.ok(AccessRecordInfo.ResultType.values());
    }

    @ApiOperation(value = "识别记录列表", notes = "获取识别记录列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "offset", value = "偏移量"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "pageNumber", value = "页数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "pageSize", value = "每页大小"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=version,updateTime,asc&sort=name,desc")
    })
    @RequestMapping(value = "", method = RequestMethod.GET)
    public CommonResponse<Page<AccessRecordInfo>> page(@PageableDefault Pageable pageable,SearchAccessRecord searchAccessRecord) throws Exception{
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        Page page = accessRecordService.getPageOfCollection(pageable, searchAccessRecord, oserviceOperator,urlPrefix);
        return CommonResponse.ok(page);
    }

    @ApiOperation(value = "获取识别记录详情", notes = "根据id获取识别记录")
    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public CommonResponse<AccessRecordInfo> get(@PathVariable String id) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        AccessRecordInfo accessRecordInfo = accessRecordService.getOneOfCollection(id, oserviceOperator.getTenantId(),urlPrefix);
        return CommonResponse.ok(accessRecordInfo);
    }
    @ApiIgnore
    @ApiOperation(value = "批量删除", notes = "根据id批量识别记录")
    @RequestMapping(value = "", method = RequestMethod.DELETE)
    public CommonResponse batchDelete(@RequestBody String[] ids) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        CommonResponse commonResponse = accessRecordService.deleteOfCollection(ids, oserviceOperator.getTenantId());
        return commonResponse;
    }
    @ApiIgnore
    @ApiOperation(value = "oa系统调用识别记录列表", notes = "")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数")
    })
    @RequestMapping(value = "/oa", method = RequestMethod.GET)
    public CommonResponse pageOa(@PageableDefault Pageable pageable,SearchAccessRecordOa searchAccessRecordOa) throws Exception{
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        RequestUrlPrefix urlPrefix = CommonContext.getUrlPrefix();
        Page page = accessRecordService.getPageOaOfCollection(pageable, searchAccessRecordOa, oserviceOperator,urlPrefix);
        return CommonResponse.ok(page);
    }
}
