package com.opnext.oservice.domain.converter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JavaType;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.AttributeConverter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * @ClassName: BatchImportRowDataConverter
 * @Description:
 * @Author: Kevin
 * @Date: 2018/7/10 16:31
 */
@Slf4j
public class BatchImportRowDataConverter implements AttributeConverter<Map<Integer, String>, String> {
    /**
     * Converts the value stored in the entity attribute into the
     * data representation to be stored in the database.
     *
     * @param attribute the entity attribute value to be converted
     * @return the converted data to be stored in the database column
     */
    @Override
    public String convertToDatabaseColumn(Map<Integer, String> attribute) {
        ObjectMapper mapper = new ObjectMapper();
        String str = null;
        try {
            if (Objects.isNull(attribute)) {
                attribute = new HashMap<>();
            }
            str = mapper.writeValueAsString(attribute);
        } catch (JsonProcessingException e) {
            log.error("jackson转换异常", e);
        }
        return str;
    }

    /**
     * Converts the data stored in the database column into the
     * value to be stored in the entity attribute.
     * Note that it is the responsibility of the converter writer to
     * specify the correct dbData type for the corresponding column
     * for use by the JDBC driver: i.e., persistence providers are
     * not expected to do such type conversion.
     *
     * @param dbData the data from the database column to be converted
     * @return the converted value to be stored in the entity attribute
     */
    @Override
    public Map<Integer, String> convertToEntityAttribute(String dbData) {
        ObjectMapper mapper = new ObjectMapper();
        Map<Integer, String> map = new HashMap<>();
        if (StringUtils.isBlank(dbData) || "null".equals(dbData) || "NULL".equals(dbData)) {
            return map;
        }
        try {
            JavaType javaType = mapper.getTypeFactory().constructParametricType(HashMap.class, Integer.class, String.class);
            map = mapper.readValue(dbData, javaType);
        } catch (IOException e) {
            log.error("jackson转换异常", e);
            map = new HashMap<>();
        }
        return map;
    }
}
