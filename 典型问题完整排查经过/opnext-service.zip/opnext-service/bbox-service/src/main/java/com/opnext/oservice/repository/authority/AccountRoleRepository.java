package com.opnext.oservice.repository.authority;

import com.opnext.oservice.domain.authority.AccountRole;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @author wanglu
 */
public interface AccountRoleRepository extends PagingAndSortingRepository<AccountRole, Long>,
        QueryDslPredicateExecutor<AccountRole> {
    /**
     * 通过账号获取账号角色对象
     * @param accountId
     * @return
     */
    AccountRole findByAccountId(long accountId);

    /**
     * 通过角色id获得账号角色列表
     * @param roleId
     * @return
     */
    List<AccountRole> findAllByRoleId(long roleId);
}