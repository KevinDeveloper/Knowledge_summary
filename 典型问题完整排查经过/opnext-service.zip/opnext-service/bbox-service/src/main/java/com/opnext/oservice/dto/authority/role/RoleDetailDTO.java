package com.opnext.oservice.dto.authority.role;

import com.opnext.oservice.domain.authority.role.Role;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import java.util.List;

/**
 * @author wanglu
 */
@Data
@Builder
public class RoleDetailDTO {
    private Long id;
    @NotEmpty(message="tenant.parameter.notEmpty")
    @Length(min=1, max=64, message = "string.length.incorrect")
    private String name;
    @Length(max=100, message = "string.length.incorrect")
    private String description;
    private Role.Type type;
    private List<Integer> moduleIds;
    private List<Integer> organizationIds;
    private List<Integer> deviceGroupIds;
    @Tolerate
    public RoleDetailDTO(){}
}
