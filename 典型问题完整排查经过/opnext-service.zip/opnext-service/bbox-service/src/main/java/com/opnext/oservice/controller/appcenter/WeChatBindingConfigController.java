package com.opnext.oservice.controller.appcenter;

import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.RedisLifeTimeUtil;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.conf.WeChatProperties;
import com.opnext.oservice.domain.ServerConfig;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.appcenter.WeChatBindingConfig;
import com.opnext.oservice.domain.tenant.TenantWechat;
import com.opnext.oservice.service.appcenter.WeChatAuthorizationService;
import com.opnext.oservice.service.base.BaseRedisService;
import com.opnext.oservice.service.person.PersonService;
import com.opnext.oservice.service.tenant.TenantWechatService;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Objects;

/**
 * @author wanglu
 */
@Slf4j
@RestController
@RequestMapping("/api/wechat/user")
public class WeChatBindingConfigController {
    public static final String WECHAT_BINDING_CONFIG_KEY = "visitor-manager_wechat_binding";
    public static final String WECHAT_BINDING_PERIOD = "visitor-manager_wechat_binding_period";

    @Autowired
    private BaseRedisService redisService;
    @Autowired
    PersonService personService;
    @Autowired
    TenantWechatService tenantWechatService;
    @Autowired
    WeChatAuthorizationService wechatAuthorizationService;
    @Autowired
    WeChatProperties wechatProperties;

    @ApiOperation(value = "获取微信绑定选项", notes = "获取微信绑定选项")
    @RequestMapping(value = "/binding-config", method = RequestMethod.GET)
    public List<WeChatBindingConfig> getBindingConfig() {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        List<WeChatBindingConfig> weChatBindingConfigDTOList = wechatAuthorizationService.getBindingConfig(oserviceOperator.getTenantId(), WECHAT_BINDING_CONFIG_KEY);
        List<WeChatBindingConfig> weChatBindingPeriodList = wechatAuthorizationService.getBindingConfig(oserviceOperator.getTenantId(), WECHAT_BINDING_PERIOD);
        weChatBindingConfigDTOList.addAll(weChatBindingPeriodList);
        return weChatBindingConfigDTOList;
    }

    @ApiOperation(value = "设置微信绑定选项", notes = "设置微信绑定选项")
    @RequestMapping(value = "/binding-config", method = RequestMethod.POST)
    public void setBindingConfig(@RequestBody List<ServerConfig> serverConfigList) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        wechatAuthorizationService.setBindingConfig(oserviceOperator.getTenantId(), serverConfigList);
    }

    @ApiOperation("获取微信公众号登录入口地址")
    @RequestMapping(value = "/login_url", method = RequestMethod.GET)
    public String getWechatLoginUrl() {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        log.info("进入“获取微信公众号登录入口地址”接口,tenantId;{}", oserviceOperator.getTenantId());
        TenantWechat tenantWechat = tenantWechatService.findByTenantId(oserviceOperator.getTenantId());
        if (Objects.isNull(tenantWechat)) {
            return "";
        }
        return String.format("%s?appId=%s", wechatProperties.getWechatLoginUrl(), tenantWechat.getAppId());
    }

    @ApiOperation(value = "跳转到授权界面")
    @RequestMapping(value = "/auth_url", method = RequestMethod.GET)
    public void openAuthJsp(HttpServletResponse response,
                            @RequestParam("callback") String callback) throws IOException, CommonException {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        log.info("进入“跳转到授权界面”接口,tenantId;{},界面回调地址:{}", oserviceOperator.getTenantId(), callback);
        if (StringUtils.isBlank(wechatProperties.getHost())) {
            log.info("微信域名配置为空,tenantId:{}", oserviceOperator.getTenantId());
            throw new CommonException("wechat.module.not.install");
        }

        //临时存储，授权完成后跳转到前端界面
        redisService.set(oserviceOperator.getTenantId() + "_authCallBackUrl", callback, RedisLifeTimeUtil.weChatAuthLinkTime());
        String url = String.format("%s%s?callback=%s",
                wechatProperties.getHost(),
                wechatProperties.getWechatAuthCodeUrl(),
                wechatProperties.getSaasHost() + "/wechat/callback/authcode?tenantId=" + oserviceOperator.getTenantId());
        response.sendRedirect(url);
    }
}
