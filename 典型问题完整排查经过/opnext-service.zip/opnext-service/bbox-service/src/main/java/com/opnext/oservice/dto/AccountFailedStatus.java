package com.opnext.oservice.dto;

/**
 * @author wanglu
 */
public enum  AccountFailedStatus {

    /**
     * 账号不存在
     */
    ACCOUNT_NOT_FOUND(104101,"Account not found, or the User-Center service is disabled"),
    /**
     * 账号禁用状态
     */
    ACCOUNT_DISABLED(104102,"This account is Disabled"),
    /**
     * 请求缺少param头部
     */
    HEADER_MISS(104103,"Request miss header [param]");


    public String message;
    public int value;

    AccountFailedStatus(int value,String message) {
        this.value = value;
        this.message = message;

    }

    public static String getMessage(int value) {
        for (AccountFailedStatus c : AccountFailedStatus.values()) {
            if (c.getValue() == value) {
                return c.message;
            }
        }
        return null;
    }

    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public int getValue() {
        return value;
    }
    public void setValue(int value) {
        this.value = value;
    }
}
