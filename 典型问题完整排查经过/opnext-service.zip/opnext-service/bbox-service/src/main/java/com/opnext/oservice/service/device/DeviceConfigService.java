package com.opnext.oservice.service.device;

import com.opnext.domain.config.OConfigGroup;
import com.opnext.domain.message.Command;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.device.DeviceConfig;
import com.opnext.oservice.domain.device.DeviceSync;
import com.opnext.oservice.domain.device.SearchDeviceConfig;

import java.util.List;

/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午5:03 18/5/7
 */ 
public interface DeviceConfigService {


    void configCallback(Command command,OConfigGroup oConfigGroup) throws Exception;

    void configCacheCallback(Command command, String redisKey, OConfigGroup oConfigGroup) throws Exception;
    /**
     * 新增配置
     * @param serviceType
     * @param deviceConfig
     * @return
     * @throws Exception
     */
    DeviceConfig saveConfig(String serviceType, DeviceConfig deviceConfig, Long tenantId) throws Exception;

    /**
     * 新增配置
     * @param serviceType
     * @param deviceConfig
     * @return
     * @throws Exception
     */
    DeviceConfig saveConfig(String serviceType, DeviceConfig deviceConfig, Long tenantId, String sn) throws Exception;

    /**
     * 更新配置
     * @param deviceConfig
     * @return
     * @throws Exception
     */
    DeviceConfig updateConfig(DeviceConfig deviceConfig) throws Exception;

    /**
     * 更新配置
     * @param deviceConfig
     * @return
     * @throws Exception
     */
    DeviceConfig updateConfigName(DeviceConfig deviceConfig) throws Exception;

    /**
     * 删除配置
     * @param id
     * @param serviceType
     * @throws Exception
     */
    void delete(String serviceType, String id) throws Exception;

    /**
     * 根据id获取单个配置
     * @param serviceType
     * @param id
     * @return
     * @throws Exception
     */
    DeviceConfig getConfig(String serviceType, String id, Long tenantId) throws Exception;

    /**
     * 根据分库名称获取分库信息
     * @param tenantId
     * @param name
     * @return
     * @throws Exception
     */
    DeviceConfig getConfig(String name, Long tenantId) throws Exception;

    /**
     * 根据id获取单个配置
     * @param tenantId
     * @param id
     * @return
     * @throws Exception
     */
    DeviceConfig getConfigById(String id, Long tenantId) throws Exception;

    DeviceConfig getConfigByParamKey(String paramKey, Long tenantId) throws Exception;

    /**
     * 根据sn获取单个配置
     * @param serviceType
     * @return
     * @throws Exception
     */
    DeviceConfig getSNConfig(String serviceType) throws Exception;

    /**
     * 根据传入条件查询设备配置或
     * @param type
     * @return
     */
    List<DeviceConfig> findList(String type);

    /**
     * 根据条件获取设备配置列表
     * @param sDeviceConfig
     * @return
     * @throws Exception
     */
    List<DeviceConfig> listConfig(SearchDeviceConfig sDeviceConfig) throws Exception;

    /**
     * 根据租户id获取参数库
     * @param tenantId
     * @return
     * @throws Exception
     */
    List<DeviceConfig> getGroupListByTenantId(Long tenantId) throws Exception;

    /**
     * 同步基础设置
     * @param deviceSync
     * @throws Exception
     */
    void syncConfig(DeviceSync deviceSync) throws Exception;

    void sendConfigToMessage(OserviceOperator oserviceOperator, List<String> snList, OConfigGroup oConfigGroup) throws Exception;
}
