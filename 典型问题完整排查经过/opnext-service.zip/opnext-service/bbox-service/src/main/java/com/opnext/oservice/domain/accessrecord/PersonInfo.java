package com.opnext.oservice.domain.accessrecord;

import com.opnext.domain.PersonType;
import com.opnext.domain.ResourceType;
import com.opnext.domain.Sex;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
@ApiModel(description="人员信息详情")
public class PersonInfo implements Serializable {
    /**
     * 服务端数据库ID
     */
    @ApiModelProperty(value="id")
    private String id;
    /**
     * 人员编号
     */
    @ApiModelProperty(value="编号")
    private String no;
    /**
     * 人员姓名
     */
    @ApiModelProperty(value="姓名")
    private String name;
    /**
     * 人员年龄
     */
    @ApiModelProperty(value="年龄")
    private Integer age;
    /**
     * 租户ID
     */
    @ApiModelProperty(value="租户id")
    private long tenantId;
    /**
     * 组织ID
     */
    @ApiModelProperty(value="组织id")
    private int organizationId;
    /**
     * 手机号
     */
    @ApiModelProperty(value="手机号")
    private String phone;
    /**
     * 人脸图像
     */
    @ApiModelProperty(value="照片")
    private Map<ResourceType, List<String>> avatars;
    /**
     * 参数库ID
     */
    @ApiModelProperty(value="参数库")
    private String groupId;
    /**
     * 参数库名称
     */
    @ApiModelProperty(value="参数库名称")
    private String groupName;
    /**
     * 规则ID
     */
    @ApiModelProperty(value="规则id")
    private String ruleId;
    /**
     * 规则名称
     */
    @ApiModelProperty(value="规则名称")
    private String ruleName;
    /**
     * 动态字段
     */
    @ApiModelProperty(value="动态字段")
    private Map<String, String> variable;
    /**
     * IC卡号
     */
    @ApiModelProperty(value="ic卡号")
    private String icNumber;
    /**
     * 韦根号码
     */
    @ApiModelProperty(value="韦根编号")
    private String wgNumber;
    /**
     * 性别
     */
    @ApiModelProperty(value="性别")
    private Sex sex;
    /**
     * 人员类型
     */
    @ApiModelProperty(value="人员类型")
    private PersonType type;
    /**
     * 身份证号
     */
    @ApiModelProperty(value="身份证号")
    private String idCard;
    /**
     * 应用ID
     */
    @ApiModelProperty(value="应用id")
    private String appId;
}

