package com.opnext.oservice.domain.organization;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Transient;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @ClassName: OrgVo
 * @Description:
 * @Author: Kevin
 * @Date: 2018/5/30 18:44
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Entity
public class OrgVo implements Serializable{

    @Id
    private Integer id;
    private String name;
    private Integer parentId;
    private String remark;
    private Organization.OrgType orgType;

    /**
     * 当前组织下人数
     */
    //private Long hasPersons;

    /**
     * 用于是否可用， false可用， true禁用
     */
    private boolean disabled = false;

    private Date createTime;
    private Date updateTime;

    @Transient
    private List<OrgVo> childNodes = new ArrayList<>();



}
