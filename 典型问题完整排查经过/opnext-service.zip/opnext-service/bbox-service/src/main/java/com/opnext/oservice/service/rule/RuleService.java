package com.opnext.oservice.service.rule;

import com.beebox.push.event.Event;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.domain.response.IDRuleResp;
import com.opnext.oservice.domain.rule.Rule;
import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;

import java.util.List;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 15:56
 */
public interface RuleService {

    /**
     * 组织ID转换成人员ID
     *
     * @param organizationIdList 组织ID集合
     * @param tenantId           租户ID
     * @return 人员ID集合
     */
    List<String> orgIdToPersonId(List<Integer> organizationIdList, long tenantId);

    /**
     * 删除规则
     *
     * @param ruleIds          规则ID集合
     * @param oserviceOperator 当前操作人信息
     * @throws CommonException
     */
    void delRules(List<Integer> ruleIds, OserviceOperator oserviceOperator) throws CommonException;

    /**
     * 删除规则和规则下的访客
     *
     * @param ruleId           规则ID
     * @param oserviceOperator 当前操作人信息
     * @throws CommonException
     */
    void delRuleAndPerson(Integer ruleId, OserviceOperator oserviceOperator) throws CommonException;

    /**
     * 删除规则时调用此接口
     *
     * @param ruleIdList 人员ID集合
     * @param tenantId   租户ID
     */
    void whenDelRule(List<Integer> ruleIdList, long tenantId);

    /**
     * 添加规则
     *
     * @param rule             规则
     * @param oserviceOperator 当前操作人信息
     * @return 添加后的规则信息
     * @throws Exception
     */
    Rule addRule(Rule rule, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 添加规则
     *
     * @param rule             规则
     * @param oserviceOperator 当前操作人信息
     * @return 添加后的规则信息
     * @throws Exception
     */
    void addRuleAsync(Rule rule, OserviceOperator oserviceOperator);

    /**
     * 更新规则（异步方法）
     *
     * @param rule             规则
     * @param oserviceOperator 当前操作人信息
     */
    void updateRuleAsync(Rule rule, OserviceOperator oserviceOperator);

    /**
     * 强制更新规则（异步方法）
     *
     * @param rule             规则
     * @param oserviceOperator 当前操作人
     */
    void compulsoryUpdateAsync(Rule rule, OserviceOperator oserviceOperator);

    /**
     * 修改过期的规则
     *
     * @param rule             过期规则
     * @param oserviceOperator 当前操作人信息
     * @throws Exception
     */
    void modifyOverdueRule(Rule rule, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 根据id和租户id获取规则
     *
     * @param id
     * @param tenantId
     * @return
     */
    Rule findRuleByIdAndTenantId(int id, long tenantId);

    /**
     * 根据姓名查询规则
     *
     * @param name
     * @param tenantId
     * @return
     */
    Rule findRuleByNameAndTenantId(String name, long tenantId);

    /**
     * 查询列表
     *
     * @param predicate 查询条件
     * @param pageable  分页信息
     * @return
     */
    Page<Rule> findAll(Predicate predicate, Pageable pageable);

    /**
     * 保存规则
     *
     * @param rule 规则内容
     * @return
     */
    Rule save(Rule rule);

    /**
     * 推送规则
     *
     * @param obj       推送内容
     * @param tenantId  租户ID
     * @param eventType 事件类型
     */
    void pushRule(Object obj, long tenantId, Event.EventType eventType);
}
