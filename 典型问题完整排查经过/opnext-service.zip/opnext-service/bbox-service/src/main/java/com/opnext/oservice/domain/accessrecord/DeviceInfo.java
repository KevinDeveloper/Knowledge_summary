package com.opnext.oservice.domain.accessrecord;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author tianzc
 */
@Data
@ApiModel(description="设备信息")
public class DeviceInfo implements Serializable {
    /**
     * 设备名称
     */
    @ApiModelProperty(value="设备名称")
    private String name;
    /**
     * 设备sn
     */
    @ApiModelProperty(value="设备sn")
    private String sn;
    /**
     * 设备组
     */
    @ApiModelProperty(value="设备组id")
    private Integer groupId;
    /**
     * 设备进出方向
     */
    @ApiModelProperty(value="设备进出方向")
    private Byte direction;
    /**
     * 区域ID
     */
    @ApiModelProperty(value="区域id")
    private Integer areaId;
    /**
     * 区域名称
     */
    @ApiModelProperty(value="区域名称")
    private String areaName;
}
