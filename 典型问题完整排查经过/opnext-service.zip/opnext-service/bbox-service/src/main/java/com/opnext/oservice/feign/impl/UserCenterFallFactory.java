package com.opnext.oservice.feign.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.oservice.controller.authority.AuthorizationController;
import com.opnext.oservice.domain.account.Account;
import com.opnext.oservice.domain.tenant.Tenant;
import com.opnext.oservice.dto.PageFeign;
import com.opnext.oservice.dto.authority.AuthorityDTO;
import com.opnext.oservice.feign.UserCenterFeign;
import feign.FeignException;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 异常处理：当返回400-499时，向前端排除异常；否则仅打印log不抛出异常，返回空对象
 * @author wanglu
 */
@Component(value = "userCenterFailService")
@Slf4j
public class UserCenterFallFactory implements FallbackFactory<UserCenterFeign> {
    private ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public UserCenterFeign create(Throwable throwable) {
        log.info("fallback; reason was: {}",throwable.getMessage());
        return new UserCenterFeign(){
            @Override
            public CommonResponse<PageFeign<Account>> getAccountPage(Object... urlVariables)throws Exception {
                return innerHandlerException(throwable,new PageImpl(new ArrayList(), null, 0));
            }

            @Override
            public CommonResponse<PageFeign<AuthorityDTO>> getAuthorityAccountPage(Object... urlVariables)throws Exception {
                return innerHandlerException(throwable,new PageImpl(new ArrayList(), null, 0));
            }

            @Override
            public CommonResponse<Boolean> verifyPassword(Account account)throws Exception{
                return innerHandlerException(throwable,new Object());
            }

            @Override
            public CommonResponse modifyAccount(Account account)throws Exception{
                return innerHandlerException(throwable);
            }

            @Override
            public CommonResponse<List<Long>> changeAccountStatus(AuthorizationController.ChangeAccountStatusParam changeAccountStatusParam)throws Exception{
                return innerHandlerException(throwable,new Object());
            }

            @Override
            public CommonResponse<Account> addAccount(Account account) throws Exception{
                return innerHandlerException(throwable,new Object());
            }

            @Override
            public CommonResponse deleteAccount(Map paramMap)throws Exception{
                return innerHandlerException(throwable,new Object());
            }

            @Override
            public CommonResponse<Tenant> getTenantById(Long id)throws Exception{
                return innerHandlerException(throwable,new Object());
            }

            public CommonResponse innerHandlerException(Throwable throwable,Object object) throws Exception{
                if (StringUtils.isBlank(throwable.getMessage())){
                    throw (Exception) throwable;
                }

                String errorMessage = throwable.getMessage().substring(throwable.getMessage().indexOf("\n")+1);
                CommonResponse.ErrorResponse errorResponse = objectMapper.readValue(errorMessage,CommonResponse.ErrorResponse.class);
                if (errorResponse.getStatus()>= HttpStatus.BAD_REQUEST.value() && errorResponse.getStatus()<HttpStatus.INTERNAL_SERVER_ERROR.value()) {

                    if (throwable instanceof FeignException){
                        throw (FeignException) throwable;
                    }else{
                        throw (Exception) throwable;
                    }
                }
                return CommonResponse.ok(object);
            }

            public CommonResponse innerHandlerException(Throwable throwable) throws Exception{
                if (throwable instanceof FeignException){
                    throw (FeignException) throwable;
                }else{
                    throw (Exception) throwable;
                }
            }
        };
    }
}
