package com.opnext.oservice.domain.device;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午5:03 18/5/7
 */ 
@Entity
@Data
@Table(name = "device_group")
@EntityListeners(AuditingEntityListener.class)
public class DeviceGroup {

    @Id
    @GeneratedValue
    private Integer id;
    /**
     * 设备组名称
     */
    @Column(name = "group_name")
    private String groupName;
    /**
     * 备注
     */
    private String remark;
    @Column(name = "create_time")
    @CreatedDate
    private Date createTime;

    @Column(name = "update_time")
    @LastModifiedDate
    private Date updateTime;
    /**
     * 操作者id
     */
    @Column(name = "operator_id")
    private Long operatorId;
    /**
     * 关联租户id
     */
    @Column(name = "tenant_id")
    private Long tenantId;

    @Transient
    private Integer[] deviceIds;
}
