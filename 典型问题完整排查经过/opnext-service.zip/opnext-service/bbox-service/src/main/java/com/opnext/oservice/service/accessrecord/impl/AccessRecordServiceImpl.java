package com.opnext.oservice.service.accessrecord.impl;


import com.alibaba.fastjson.JSONObject;
import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.beebox.push.common.amqp.PushClient;
import com.beebox.push.event.Event;
import com.beebox.push.event.EventBuilder;
import com.mongodb.WriteResult;
import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.validator.IsIntegerStringValidator;
import com.opnext.domain.OPNextConstant;
import com.opnext.domain.PersonType;
import com.opnext.domain.ResourceType;
import com.opnext.oservice.conf.Constant;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.accessrecord.AccessRecordInfo;
import com.opnext.oservice.domain.accessrecord.IdentifyCard;
import com.opnext.oservice.domain.accessrecord.PersonInfo;
import com.opnext.oservice.domain.accessrecord.QAccessRecordInfo;
import com.opnext.oservice.domain.accessrecord.SearchAccessRecord;
import com.opnext.oservice.domain.accessrecord.SearchAccessRecordOa;
import com.opnext.oservice.domain.accessrecord.SendAccessRecord;
import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.domain.device.QDevice;
import com.opnext.oservice.domain.person.HistoryPerson;
import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.domain.person.QHistoryPerson;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.domain.rule.QRule;
import com.opnext.oservice.domain.visitor.QArea;
import com.opnext.oservice.domain.visitor.QAreaDevice;
import com.opnext.oservice.dto.accessrecord.AccessRecordOaDTO;
import com.opnext.oservice.repository.accessrecord.AccessRecordDao;
import com.opnext.oservice.repository.accessrecord.AccessRecordRepository;
import com.opnext.oservice.repository.device.DeviceRepository;
import com.opnext.oservice.repository.person.HistoryPersonRepository;
import com.opnext.oservice.repository.person.PersonRepository;
import com.opnext.oservice.repository.rule.RuleRepository;
import com.opnext.oservice.service.accessrecord.AccessRecordService;
import com.opnext.oservice.util.FileUrlPathHandle;
import com.opnext.oservice.util.JsonConvertor;
import com.opnext.oservice.util.UUIDUtil;
import com.querydsl.core.Tuple;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.support.CorrelationData;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @author tianzc
 */
@Slf4j
@Service
public class AccessRecordServiceImpl implements AccessRecordService {

    @Autowired
    AccessRecordRepository recordRepository;
    @Autowired
    AccessRecordDao accessRecordDao;

    @Autowired
    DeviceRepository deviceRepository;

    @Autowired
    PersonRepository personRepository;
    @Autowired
    HistoryPersonRepository historyPersonRepository;

    @Autowired
    RuleRepository ruleRepository;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;

    @Resource
    private RabbitTemplate rabbitTemplate;
    @Resource
    protected MongoTemplate mongoTemplate;

    @Resource
    private PushClient pushClient;

    /**
     * 获取识别记录列表
     *
     * @param pageable
     * @param searchAccessRecord
     * @return
     */
    @Override
    public Page getPage(Pageable pageable, SearchAccessRecord searchAccessRecord) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("tenantId").is(tenantId);
        // 识别记录条件
//        if (StringUtils.isNoneBlank(searchAccessRecord.getId())) {
//            criteria.and("id").is(searchAccessRecord.getId());
//        }
        if (StringUtils.isNoneBlank(searchAccessRecord.getName())) {
//            criteria.and("name").is(searchAccessRecord.getName());
            criteria.and("name").regex("^.*?" + searchAccessRecord.getName() + ".*$", "i");
        }
        if (StringUtils.isNoneBlank(searchAccessRecord.getPersonNo())) {
            criteria.and("personInfo.no").is(searchAccessRecord.getPersonNo());
        }
        if (StringUtils.isNoneBlank(searchAccessRecord.getRuleId())) {
            criteria.and("personInfo.ruleId").is(searchAccessRecord.getRuleId());
        }
        if (Objects.nonNull(searchAccessRecord.getOrganizationId())) {
            criteria.and("personInfo.organizationId").is(searchAccessRecord.getOrganizationId());
        }
        // 验证结果查询
        if (Objects.nonNull(searchAccessRecord.getResultType())) {
            criteria.and("resultType").is(searchAccessRecord.getResultType());
        }
        // 时间区间
        if (Objects.nonNull(searchAccessRecord.getStartTime()) && Objects.nonNull(searchAccessRecord.getEndTime())) {
            criteria.and("syncTime").gte(searchAccessRecord.getStartTime()).lte(searchAccessRecord.getEndTime());
        } else if (Objects.nonNull(searchAccessRecord.getStartTime()) && Objects.isNull(searchAccessRecord.getEndTime())) {
            criteria.and("syncTime").gte(searchAccessRecord.getStartTime());
        } else if (Objects.isNull(searchAccessRecord.getStartTime()) && Objects.nonNull(searchAccessRecord.getEndTime())) {
            criteria.and("syncTime").lte(searchAccessRecord.getEndTime());
        }

        if (Objects.nonNull(searchAccessRecord.getDeviceGroupId())) {
            if (-1 == searchAccessRecord.getDeviceGroupId()) {
                criteria.and("deviceInfo.groupId").exists(false);
            } else {
                criteria.and("deviceInfo.groupId").is(searchAccessRecord.getDeviceGroupId());
            }
        }
        query.with(new Sort(Sort.Direction.DESC, "syncTime"));
        query.addCriteria(criteria);
        Page<AccessRecordInfo> page = accessRecordDao.findPage(pageable, query);
        return page;
    }

    /**
     * 获取识别记录列表
     * 根据租户分不同集合查询
     *
     * @param pageable
     * @param searchAccessRecord
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public Page getPageOfCollection(Pageable pageable, SearchAccessRecord searchAccessRecord, OserviceOperator oserviceOperator,RequestUrlPrefix urlPrefix) throws Exception {
        long tenantId = oserviceOperator.getTenantId();
        // 查询mongo集合名
        String collectionName = Constant.ACCESS_RECORD_PREFIX + tenantId;
        Query query = new Query();
        Criteria criteria = new Criteria();
        // 时间区间
        if (Objects.nonNull(searchAccessRecord.getStartTime()) && Objects.nonNull(searchAccessRecord.getEndTime())) {
            criteria.and("syncTime").gte(searchAccessRecord.getStartTime()).lte(searchAccessRecord.getEndTime());
        } else if (Objects.nonNull(searchAccessRecord.getStartTime()) && Objects.isNull(searchAccessRecord.getEndTime())) {
            criteria.and("syncTime").gte(searchAccessRecord.getStartTime());
        } else if (Objects.nonNull(searchAccessRecord.getEndTime()) && Objects.isNull(searchAccessRecord.getStartTime())) {
            criteria.and("syncTime").lte(searchAccessRecord.getEndTime());
        }
        // 识别记录条件
        if (StringUtils.isNoneBlank(searchAccessRecord.getName())) {
            if (searchAccessRecord.isRegexName()) {
                criteria.and("name").regex("^.*" + searchAccessRecord.getName() + ".*$", "i");
            } else {
                criteria.and("name").is(searchAccessRecord.getName());
            }
        }
        if (StringUtils.isNoneBlank(searchAccessRecord.getPersonNo())) {
            criteria.and("personInfo.no").is(searchAccessRecord.getPersonNo());
        }
        // 设备sn查询
        if (StringUtils.isNoneBlank(searchAccessRecord.getSn())) {
            criteria.and("deviceInfo.sn").is(searchAccessRecord.getSn());
        }
        // 验证结果查询
        if (Objects.nonNull(searchAccessRecord.getResultType())) {
            criteria.and("resultType").is(searchAccessRecord.getResultType());
        }
        if (StringUtils.isNoneBlank(searchAccessRecord.getRuleId())) {
            criteria.and("personInfo.ruleId").is(searchAccessRecord.getRuleId());
        }
        if (Objects.nonNull(searchAccessRecord.getOrganizationId())) {
            criteria.and("personInfo.organizationId").is(searchAccessRecord.getOrganizationId());
        }
        if (Objects.nonNull(searchAccessRecord.getDeviceGroupId())) {
            if (-1 == searchAccessRecord.getDeviceGroupId()) {
                criteria.and("deviceInfo.groupId").exists(false);
            } else {
                criteria.and("deviceInfo.groupId").is(searchAccessRecord.getDeviceGroupId());
            }
        }
        query.with(new Sort(Sort.Direction.DESC, "syncTime"));
        query.addCriteria(criteria);
        Page<AccessRecordInfo> page = accessRecordDao.findPage(pageable, query, collectionName);
        if (page.getNumberOfElements() > 0) {
            List<AccessRecordInfo> accessRecordInfoList = page.getContent();
            accessRecordInfoList.forEach(accessRecordInfo -> getAccessRecordURL(accessRecordInfo,urlPrefix));
        }
        return page;
    }

    /**
     * 获取识别记录列表
     *
     * @param pageable
     * @param searchAccessRecordOa
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public Page getPageOaOfCollection(Pageable pageable, SearchAccessRecordOa searchAccessRecordOa, OserviceOperator oserviceOperator,RequestUrlPrefix urlPrefix) throws Exception {
        // 请求数据对象转化
        SearchAccessRecord searchAccessRecord = new SearchAccessRecord();
        searchAccessRecord.setName(searchAccessRecordOa.getName());
        searchAccessRecord.setPersonNo(searchAccessRecordOa.getPersonNo());
        searchAccessRecord.setSn(searchAccessRecordOa.getSn());
        searchAccessRecord.setStartTime(searchAccessRecordOa.getStartTime());
        searchAccessRecord.setEndTime(searchAccessRecordOa.getEndTime());
        if (Objects.nonNull(searchAccessRecordOa.getResultType())) {
            AccessRecordInfo.ResultType resultType = null;
            try {
                resultType = AccessRecordInfo.ResultType.indexOfVal(searchAccessRecordOa.getResultType());
            } catch (Exception e) {
                throw new CommonException("accessRecord.resultType.incorrect");
            }
            searchAccessRecord.setResultType(resultType);
        }
        Page<AccessRecordInfo> page = getPageOfCollection(pageable, searchAccessRecord, oserviceOperator,urlPrefix);
        List<AccessRecordOaDTO> recordOaDTOList = new ArrayList<>();
        if (!CollectionUtils.isEmpty(page.getContent())) {
            List<AccessRecordInfo> accessRecordInfoList = page.getContent();
            AccessRecordOaDTO accessRecordOaDTO;
            for (AccessRecordInfo accessRecordInfo : accessRecordInfoList) {
                accessRecordOaDTO = new AccessRecordOaDTO();
                accessRecordOaDTO.setId(accessRecordInfo.getId());
                accessRecordOaDTO.setName(accessRecordInfo.getName());
                // 校验人员信息是否为空
                if (Objects.nonNull(accessRecordInfo.getPersonInfo())) {
                    accessRecordOaDTO.setNo(accessRecordInfo.getPersonInfo().getNo());
                }
                accessRecordOaDTO.setSyncTime(accessRecordInfo.getSyncTime());
                accessRecordOaDTO.setCreateTime(accessRecordInfo.getCreateTime());
                accessRecordOaDTO.setSn(accessRecordInfo.getDeviceInfo().getSn());
                accessRecordOaDTO.setResultType(AccessRecordOaDTO.ResultType.indexOfVal(accessRecordInfo.getResultType().name()));
                recordOaDTOList.add(accessRecordOaDTO);
            }
        }
        Page<AccessRecordOaDTO> oaDTOPage = new PageImpl<>(recordOaDTOList, pageable, page.getTotalElements());
        return oaDTOPage;
    }

    /**
     * 获取识别记录列表
     *
     * @param id
     * @return
     */
    @Override
    public AccessRecordInfo getOne(String id) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("tenantId").is(tenantId);
        criteria.and("id").is(id);
        query.addCriteria(criteria);
        return accessRecordDao.findOne(query);
    }

    /**
     * 获取识别记录列表
     *
     * @param id
     * @param tenantId
     * @return
     * @throws Exception
     */
    @Override
    public AccessRecordInfo getOneOfCollection(String id, Long tenantId, RequestUrlPrefix urlPrefix) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        // 查询mongo集合名
        String collectionName = Constant.ACCESS_RECORD_PREFIX + tenantId;
        AccessRecordInfo accessRecordInfo =accessRecordDao.findById(id, collectionName);
        // 修改识别记录图片地址
        getAccessRecordURL(accessRecordInfo,urlPrefix);
        return accessRecordInfo;
    }

    /**
     * 保存识别记录
     * <p>
     * 处理过程：1、判断识别记录是否上传，2、保存识别记录
     *
     * @param accessRecordInfo
     * @param oserviceDevApiOperator
     * @return
     */
    @Override
    public CommonResponse save(AccessRecordInfo accessRecordInfo, OserviceDevApiOperator oserviceDevApiOperator) throws Exception {
        long tenantId = oserviceDevApiOperator.getTenantId();
        Predicate predicate = QAccessRecordInfo.accessRecordInfo.id.eq(accessRecordInfo.getId());
        predicate = ((BooleanExpression) predicate).and(QAccessRecordInfo.accessRecordInfo.tenantId.eq(tenantId));
        AccessRecordInfo fRecordInfo = recordRepository.findOne(predicate);
        AccessRecordInfo saveInfo = null;
        // 判断是否已存在
        if (Objects.nonNull(fRecordInfo)) {
            // 识别记录已存在，提示数据已保存
            log.info("识别记录已存在！通知终端不必再次上传");
            CommonResponse.ok(HttpStatus.OK.value());
        } else {
            // 识别记录不存在，数据保存
            accessRecordInfo.setTenantId(oserviceDevApiOperator.getTenantId());
            if (!oserviceDevApiOperator.getSn().equals(accessRecordInfo.getDeviceInfo().getSn())) {
                throw new CommonException("data.wrong");
            }
            // 获取人员字段
            PersonInfo personInfo = accessRecordInfo.getPersonInfo();
            if (Objects.nonNull(personInfo)) {
                QPerson qPerson = QPerson.person;
                predicate = qPerson.tenantId.eq(oserviceDevApiOperator.getTenantId());
                predicate = ((BooleanExpression) predicate).and(qPerson.id.eq(personInfo.getId()));
                Person person = personRepository.findOne(predicate);
                if (Objects.isNull(person)) {
                    log.info("人员信息上传失败，没有找到相关信心");
                    throw new CommonException("DataNotFound");
                }
                // 设置人员图片
                personInfo.setAvatars(person.getAvatars());
            }

            // 获取设备关联设备组
            QDevice qDevice = QDevice.device;
            predicate = qDevice.sn.eq(accessRecordInfo.getDeviceInfo().getSn());
            predicate = ((BooleanExpression) predicate).and(qDevice.tenantId.eq(oserviceDevApiOperator.getTenantId()));
            Device device = deviceRepository.findOne(predicate);
            // 设备组id赋值
            accessRecordInfo.getDeviceInfo().setGroupId(device.getGroupId());
            QArea qArea = QArea.area;
            QAreaDevice qAreaDevice = QAreaDevice.areaDevice;
            predicate = qAreaDevice.areaId.eq(qArea.id)
                    .and(qAreaDevice.tenantId.eq(tenantId))
                    .and(qAreaDevice.deviceSn.eq(oserviceDevApiOperator.getSn()));
            Tuple deviceTuple = jpaQueryFactory.select(qArea.id, qArea.name, qAreaDevice.deviceDirection)
                    .from(qAreaDevice, qArea)
                    .where(predicate).fetchFirst();
            if (deviceTuple != null) {
                accessRecordInfo.getDeviceInfo().setAreaId(deviceTuple.get(qArea.id));
                accessRecordInfo.getDeviceInfo().setAreaName(deviceTuple.get(qArea.name));
                accessRecordInfo.getDeviceInfo().setDirection(deviceTuple.get(qAreaDevice.deviceDirection));
            }
            saveInfo = recordRepository.save(accessRecordInfo);
        }
        return CommonResponse.ok(saveInfo);
    }

    @Override
    public CommonResponse batchSave(List<AccessRecordInfo> accessRecordInfoList, OserviceDevApiOperator oserviceDevApiOperator) throws Exception {
        long tenantId = oserviceDevApiOperator.getTenantId();
        QArea qArea = QArea.area;
        QAreaDevice qAreaDevice = QAreaDevice.areaDevice;
        Predicate predicateDevice = qAreaDevice.areaId.eq(qArea.id)
                .and(qAreaDevice.tenantId.eq(tenantId))
                .and(qAreaDevice.deviceSn.eq(oserviceDevApiOperator.getSn()));
        Tuple deviceTuple = jpaQueryFactory.select(qArea.id, qArea.name, qAreaDevice.deviceDirection)
                .from(qAreaDevice, qArea)
                .where(predicateDevice).fetchFirst();
        // 保存人员列表
        List<AccessRecordInfo> recordInfo = new ArrayList<>();
        // 人员信息map
        Map<String, Person> personMap = new HashMap<>();
        // 人员规则name map
        Map<String, String> ruleMap = new HashMap<>();
        int i = 0;
        for (AccessRecordInfo accessRecordInfo : accessRecordInfoList) {
            if (StringUtils.isBlank(accessRecordInfo.getId())) {
                log.error("识别记录id不能为空");
                throw new CommonException("data.wrong");
            }
            Predicate predicate = QAccessRecordInfo.accessRecordInfo.id.eq(accessRecordInfo.getId());
            predicate = ((BooleanExpression) predicate).and(QAccessRecordInfo.accessRecordInfo.tenantId.eq(tenantId));
            AccessRecordInfo fRecordInfo = recordRepository.findOne(predicate);
            // 判断是否已存在
            if (Objects.nonNull(fRecordInfo)) {
                // 识别记录已存在，提示数据已保存
                log.info("识别记录已存在！通知终端不必再次上传");
                return CommonResponse.ok(HttpStatus.OK.value());
            } else {
                PersonType personType = null;
                // 识别记录不存在，数据保存
                accessRecordInfo.setTenantId(oserviceDevApiOperator.getTenantId());
                if (!oserviceDevApiOperator.getSn().equals(accessRecordInfo.getDeviceInfo().getSn())) {
                    log.info("header中sn和数据中的sn号不一致");
                    throw new CommonException("data.wrong");
                }

                IdentifyCard identifyCard = accessRecordInfo.getIdentifyCard();
                PersonInfo personInfo = accessRecordInfo.getPersonInfo();
                if (AccessRecordInfo.PassMode.FACE_AND_ID.equals(accessRecordInfo.getPassMode()) || AccessRecordInfo.PassMode.FACE_AND_PASSPORT.equals(accessRecordInfo.getPassMode())) {
                    if (Objects.nonNull(identifyCard)) {
                        if (StringUtils.isBlank(accessRecordInfo.getIdNumber())) {
                            accessRecordInfo.setIdNumber(identifyCard.getIdCard());
                        }
                        accessRecordInfo.setName(identifyCard.getName());
                    } else {
                        log.error("身份证或护照验证，上传验证信息不能为空");
                        throw new CommonException("data.wrong");
                    }
                } else if (AccessRecordInfo.PassMode.FACE_AND_IC.equals(accessRecordInfo.getPassMode())) {
                    if (Objects.nonNull(personInfo)) {
                        if (StringUtils.isBlank(accessRecordInfo.getIdNumber())) {
                            accessRecordInfo.setIdNumber(personInfo.getIcNumber());
                        }
                        accessRecordInfo.setName(personInfo.getName());
                    } else {
                        log.error("人脸+IC卡验证，人员信息不能为空");
                        throw new CommonException("data.wrong");
                    }
                } else if (AccessRecordInfo.PassMode.FACE_AND_GUARD.equals(accessRecordInfo.getPassMode())) {
                    if (Objects.nonNull(personInfo)) {
                        if (StringUtils.isBlank(accessRecordInfo.getIdNumber())) {
                            accessRecordInfo.setIdNumber(personInfo.getWgNumber());
                        }
                        accessRecordInfo.setName(personInfo.getName());
                    } else {
                        log.error("人脸+门禁卡验证，人脸信息不能为空");
                        throw new CommonException("data.wrong");
                    }
                } else {
                    if (Objects.nonNull(personInfo)) {
                        accessRecordInfo.setName(personInfo.getName());
                    }
                    accessRecordInfo.setIdNumber(null);
                }
                // 获取人员字段
                if (Objects.nonNull(personInfo)) {
                    personType = personInfo.getType();
                    Person person;
                    if (personMap.containsKey(personInfo.getId())) {
                        person = personMap.get(personInfo.getId());
                    } else {
                        person = getPerson(personInfo, oserviceDevApiOperator);
                        personMap.put(person.getId(), person);
                    }
                    // 设置人员图片和手机号
                    if (Objects.nonNull(person)) {
                        personInfo.setAvatars(person.getAvatars());
                        personInfo.setPhone(person.getPhone());
                        personInfo.setAppId(person.getAppId());
                        personInfo.setType(person.getType());
                    }
                    if (StringUtils.isNoneBlank(personInfo.getRuleId())) {
                        // 查看map中是否存在
                        if (ruleMap.containsKey(personInfo.getRuleId())) {
                            personInfo.setRuleName(ruleMap.get(personInfo.getRuleId()));
                        } else {
                            ComplexResult ret = FluentValidator.checkAll()
                                    .failFast()
                                    .on(personInfo.getRuleId(), new IsIntegerStringValidator("personInfo.ruleId"))
                                    .doValidate()
                                    .result(toComplex());
                            if (!ret.isSuccess()) {
                                log.error("personInfo.ruleId参数异常{}", ret);
                                throw new CommonException(400, "parameter.incorrect", ret);
                            }
                            QRule qRule = QRule.rule;
                            predicate = qRule.tenantId.eq(oserviceDevApiOperator.getTenantId());
                            predicate = ((BooleanExpression) predicate).and(qRule.id.eq(Integer.parseInt(personInfo.getRuleId())));
                            String name = jpaQueryFactory.select(qRule.name)
                                    .from(qRule).where(predicate).fetchOne();
                            ruleMap.put(personInfo.getRuleId(), name);
                            personInfo.setRuleName(name);
                        }
                    }
                }
                accessRecordInfo.getDeviceInfo().setGroupId(oserviceDevApiOperator.getGroupId());
                accessRecordInfo.getDeviceInfo().setName(oserviceDevApiOperator.getName());
                if (deviceTuple != null) {
                    accessRecordInfo.getDeviceInfo().setAreaId(deviceTuple.get(qArea.id));
                    accessRecordInfo.getDeviceInfo().setAreaName(deviceTuple.get(qArea.name));
                    accessRecordInfo.getDeviceInfo().setDirection(deviceTuple.get(qAreaDevice.deviceDirection));
                }
                recordInfo.add(accessRecordInfo);
                SendAccessRecord sendAccessRecord = new SendAccessRecord();
                sendAccessRecord.setId(accessRecordInfo.getId());
                sendAccessRecord.setResultType(accessRecordInfo.getResultType());
                sendAccessRecord.setPersonType(personType);
                rabbitTemplate.convertAndSend(OPNextConstant.PERSON_ACCESS_RECORD_EXCHANGE_NAME,
                        Constant.OSERVICE_PERSON_ACCESS_RECORD_ROUTINGKEY,
                        JSONObject.toJSONString(sendAccessRecord), new CorrelationData(UUIDUtil.uuid()));
            }
            if ((i + 1) % 500 == 0) {
                recordRepository.save(recordInfo);
                recordInfo = new ArrayList<>();
            }
            i++;
        }
        if (recordInfo.size() > 0) {
            recordRepository.save(recordInfo);
        }
        return CommonResponse.ok("");
    }

    /**
     * 根据租户分集合存储
     *
     * @param accessRecordInfoList
     * @param oserviceDevApiOperator
     * @return
     * @throws Exception
     */
    @Override
    public CommonResponse batchSaveOfcollection(List<AccessRecordInfo> accessRecordInfoList, OserviceDevApiOperator oserviceDevApiOperator, RequestUrlPrefix urlPrefix) throws Exception {
        long tenantId = oserviceDevApiOperator.getTenantId();
        QArea qArea = QArea.area;
        QAreaDevice qAreaDevice = QAreaDevice.areaDevice;
        Predicate predicateDevice = qAreaDevice.areaId.eq(qArea.id)
                .and(qAreaDevice.tenantId.eq(tenantId))
                .and(qAreaDevice.deviceSn.eq(oserviceDevApiOperator.getSn()));
        Tuple deviceTuple = jpaQueryFactory.select(qArea.id, qArea.name, qAreaDevice.deviceDirection)
                .from(qAreaDevice, qArea)
                .where(predicateDevice).fetchFirst();
        // 保存人员列表
        List<AccessRecordInfo> recordInfo = new ArrayList<>();
        // 人员信息map
        Map<String, Person> personMap = new HashMap<>();
        // 人员规则name map
        Map<String, String> ruleMap = new HashMap<>();
        int i = 0;
        String collectionName = Constant.ACCESS_RECORD_PREFIX + tenantId;
        for (AccessRecordInfo accessRecordInfo : accessRecordInfoList) {
            if (StringUtils.isBlank(accessRecordInfo.getId())) {
                log.error("========识别记录id为空");
                throw new CommonException("data.wrong");
            } else {
                AccessRecordInfo fRecordInfo = accessRecordDao.findById(accessRecordInfo.getId(), collectionName);
                if (Objects.nonNull(fRecordInfo)) {
                    // 识别记录已存在，提示数据已保存
                    log.info("识别记录已存在！返回成功。id：{}", accessRecordInfo.getId());
                    continue;
                }
            }
            // 识别记录不存在，识别数据保存
            accessRecordInfo.setTenantId(oserviceDevApiOperator.getTenantId());
            IdentifyCard identifyCard = accessRecordInfo.getIdentifyCard();
            PersonInfo personInfo = accessRecordInfo.getPersonInfo();
            if (AccessRecordInfo.PassMode.FACE_AND_ID.equals(accessRecordInfo.getPassMode()) || AccessRecordInfo.PassMode.FACE_AND_PASSPORT.equals(accessRecordInfo.getPassMode())) {
                if (Objects.nonNull(identifyCard)) {
                    if (StringUtils.isBlank(accessRecordInfo.getIdNumber())) {
                        accessRecordInfo.setIdNumber(identifyCard.getIdCard());
                    }
                    accessRecordInfo.setName(identifyCard.getName());
                } else {
                    log.error("======身份证或护照验证，上传验证信息为空");
//                        throw new CommonException("data.wrong");
                }
            } else if (AccessRecordInfo.PassMode.FACE_AND_IC.equals(accessRecordInfo.getPassMode())) {
                if (Objects.nonNull(personInfo)) {
                    if (StringUtils.isBlank(accessRecordInfo.getIdNumber())) {
                        accessRecordInfo.setIdNumber(personInfo.getIcNumber());
                    }
                    accessRecordInfo.setName(personInfo.getName());
                } else {
                    log.error("======人脸+IC卡验证，人员信息为空");
//                        throw new CommonException("data.wrong");
                }
            } else if (AccessRecordInfo.PassMode.FACE_AND_GUARD.equals(accessRecordInfo.getPassMode())) {
                if (Objects.nonNull(personInfo)) {
                    if (StringUtils.isBlank(accessRecordInfo.getIdNumber())) {
                        accessRecordInfo.setIdNumber(personInfo.getWgNumber());
                    }
                    accessRecordInfo.setName(personInfo.getName());
                } else {
                    log.error("======人脸+门禁卡验证，人脸信息为空");
//                        throw new CommonException("data.wrong");
                }
            } else {
                if (Objects.nonNull(personInfo)) {
                    accessRecordInfo.setName(personInfo.getName());
                }
            }
            // 获取人员字段
            if (Objects.nonNull(personInfo)) {
                Person person;
                if (personMap.containsKey(personInfo.getId())) {
                    person = personMap.get(personInfo.getId());
                } else {
                    person = getPerson(personInfo, oserviceDevApiOperator);
                    if (Objects.nonNull(person)) {
                        personMap.put(person.getId(), person);
                    }
                }
                // 设置人员图片和手机号
                if (Objects.nonNull(person)) {
                    personInfo.setName(person.getName());
                    // 修改图片地址
                    personInfo.setType(person.getType());
                    personInfo.setAppId(person.getAppId());
                    personInfo.setPhone(person.getPhone());
                    personInfo.setIdCard(person.getIdCard());
                }
                if (StringUtils.isNoneBlank(personInfo.getRuleId())) {
                    // 查看map中是否存在
                    if (ruleMap.containsKey(personInfo.getRuleId())) {
                        personInfo.setRuleName(ruleMap.get(personInfo.getRuleId()));
                    } else {
                        ComplexResult ret = FluentValidator.checkAll().failFast()
                                .on(personInfo.getRuleId(), new IsIntegerStringValidator("personInfo.ruleId"))
                                .doValidate().result(toComplex());
                        if (!ret.isSuccess()) {
                            log.error("======personInfo.ruleId参数异常，参数：{}", ret);
//                                throw new CommonException(400, "parameter.incorrect", ret);
                        } else {
                            QRule qRule = QRule.rule;
                            Predicate predicate = qRule.tenantId.eq(oserviceDevApiOperator.getTenantId());
                            predicate = ((BooleanExpression) predicate).and(qRule.id.eq(Integer.parseInt(personInfo.getRuleId())));
                            String name = jpaQueryFactory.select(qRule.name)
                                    .from(qRule).where(predicate).fetchOne();
                            ruleMap.put(personInfo.getRuleId(), name);
                            personInfo.setRuleName(name);
                        }
                    }
                }
            }
            accessRecordInfo.getDeviceInfo().setGroupId(oserviceDevApiOperator.getGroupId());
            accessRecordInfo.getDeviceInfo().setName(oserviceDevApiOperator.getName());
            if (Objects.nonNull(deviceTuple)) {
                accessRecordInfo.getDeviceInfo().setAreaId(deviceTuple.get(qArea.id));
                accessRecordInfo.getDeviceInfo().setAreaName(deviceTuple.get(qArea.name));
                accessRecordInfo.getDeviceInfo().setDirection(deviceTuple.get(qAreaDevice.deviceDirection));
            }
            accessRecordInfo.setCreateTime(System.currentTimeMillis());
            // 获取完整地址
            getAccessRecordURL(accessRecordInfo,urlPrefix);
            Event event = EventBuilder.newBuilder()
                    .entity(JsonConvertor.beanToJson(accessRecordInfo))
                    .timestamp(System.currentTimeMillis())
                    .tenantId(String.valueOf(oserviceDevApiOperator.getGroupId()))
                    .type(Event.EventType.ACCESS_RECORD_ADD).build();
            pushClient.send(event);
            // 地址转换
            getStoreAccessRecordURL(accessRecordInfo, urlPrefix);
            recordInfo.add(accessRecordInfo);

            if ((i + 1) % 500 == 0) {
                mongoTemplate.insert(recordInfo, collectionName);
                recordInfo = new ArrayList<>();
            }
            i++;
        }
        if (recordInfo.size() > 0) {
            mongoTemplate.insert(recordInfo, collectionName);
        }
        return CommonResponse.ok("");
    }

    private Person getPerson(PersonInfo personInfo, OserviceDevApiOperator oserviceDevApiOperator) throws Exception{
        QPerson qPerson = QPerson.person;
        Predicate predicate = qPerson.tenantId.eq(oserviceDevApiOperator.getTenantId());
        if (StringUtils.isNoneBlank(personInfo.getId())) {
            predicate = ((BooleanExpression) predicate).and(qPerson.id.eq(personInfo.getId()));
        } else if (StringUtils.isNoneBlank(personInfo.getNo())) {
            predicate = ((BooleanExpression) predicate).and(qPerson.no.eq(personInfo.getNo()));
        } else {
            log.error("人员信息参数id或no不能为空");
            return null;
        }
        Person person = personRepository.findOne(predicate);
        if (Objects.isNull(person)) {
            log.info("当前人员库没有找到相关信息，去历史记录查询");
            QHistoryPerson qHistoryPerson = QHistoryPerson.historyPerson;
            predicate = qHistoryPerson.tenantId.eq(oserviceDevApiOperator.getTenantId());
            // 校验人员id、人员编号，二者其一为必填
            if (StringUtils.isNoneBlank(personInfo.getId())) {
                predicate = ((BooleanExpression) predicate).and(qHistoryPerson.id.eq(personInfo.getId()));
            } else if (StringUtils.isNoneBlank(personInfo.getNo())) {
                predicate = ((BooleanExpression) predicate).and(qHistoryPerson.no.eq(personInfo.getNo()));
            }

            Pageable pageable = new PageRequest(0,1, new Sort(Sort.Direction.DESC, "updateTime"));
            Page<HistoryPerson> page = historyPersonRepository.findAll(predicate,pageable);
            List<HistoryPerson> historyPersonList = page.getContent();
            if (CollectionUtils.isEmpty(historyPersonList)) {
                log.error("======历史人员信息库没有找到对应关系");
            } else {
                // person target 不能为空
                person = new Person();
                BeanUtils.copyProperties(historyPersonList.get(0),person);
            }
        }
        return person;
    }

    /**
     * 删除人员id
     *
     * @param ids
     * @return
     */
    @Override
    public CommonResponse delete(String[] ids) {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("tenantId").is(tenantId);
        criteria.and("id").in(ids);
        query.addCriteria(criteria);
        WriteResult writeResult = accessRecordDao.remove(query);
        if (writeResult.getN() == 0) {
            log.info("请求无效，不存在符合条件的数据");
        }
        return CommonResponse.ok(new HashMap<>());
    }

    /**
     * 删除人员id
     *
     * @param ids
     * @param tenantId
     * @return
     */
    @Override
    public CommonResponse deleteOfCollection(String[] ids, Long tenantId) {
        String collectionName = Constant.ACCESS_RECORD_PREFIX + tenantId;
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.and("_id").in(ids);
        query.addCriteria(criteria);
        WriteResult writeResult = accessRecordDao.remove(query, collectionName);
        if (writeResult.getN() == 0) {
            log.info("请求无效，不存在符合条件的数据");
        }
        return CommonResponse.ok(new HashMap<>());
    }

    public void getAccessRecordURL(AccessRecordInfo accessRecordInfo,RequestUrlPrefix urlPrefix) {
        // 修改识别记录抓拍地址
        Map<ResourceType, List<String>> resultMap = FileUrlPathHandle.getShowAvatarsMap(accessRecordInfo.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()));
        accessRecordInfo.setAvatars((HashMap<ResourceType, List<String>>) resultMap);
        if (Objects.nonNull(accessRecordInfo.getPersonInfo())) {
            resultMap = FileUrlPathHandle.getShowAvatarsMap(accessRecordInfo.getPersonInfo().getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()));
            accessRecordInfo.getPersonInfo().setAvatars(resultMap);
        }

    }

    public void getStoreAccessRecordURL(AccessRecordInfo accessRecordInfo,RequestUrlPrefix urlPrefix) {
        // 修改识别记录抓拍地址
        Map<ResourceType, List<String>> resultMap = FileUrlPathHandle.getStoreAvatarsMap(accessRecordInfo.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()),GlobleConfig.ServerConfig.urlStoreRelative);
        accessRecordInfo.setAvatars((HashMap<ResourceType, List<String>>) resultMap);
        if (Objects.nonNull(accessRecordInfo.getPersonInfo())) {
            resultMap = FileUrlPathHandle.getStoreAvatarsMap(accessRecordInfo.getPersonInfo().getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()),GlobleConfig.ServerConfig.urlStoreRelative);
            accessRecordInfo.getPersonInfo().setAvatars(resultMap);
        }

    }

}
