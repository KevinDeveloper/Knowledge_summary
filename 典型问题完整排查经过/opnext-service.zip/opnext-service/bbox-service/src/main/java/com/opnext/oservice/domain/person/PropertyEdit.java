package com.opnext.oservice.domain.person;

import lombok.AllArgsConstructor;

/**
 * @ClassName: PropertyShow
 * @Description:是否可编辑：0不可编辑， 1可编辑
 * @Author: Kevin
 * @Date: 2018/6/5 11:00
 */
@AllArgsConstructor
public enum PropertyEdit {
    /**
     * 0不可编辑
     */
    nonEditable(false),
    /**
     * 1可编辑
     */
    editable(true);
    private boolean value;

    public boolean value() {
        return this.value;
    }

    /**
     * 通过 val 值索引 PropertyType
     *
     * @param val val
     * @return PropertyType
     */
    public static PropertyEdit indexOfVal(boolean val) {
        for (PropertyEdit propertyEdit : values()) {
            if (propertyEdit.value == val) {
                return propertyEdit;
            }
        }

        throw new IllegalArgumentException("param value " + val);
    }
}
