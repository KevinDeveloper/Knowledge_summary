package com.opnext.oservice.dto.person;

/**
 * @Author: lixiuwen
 * @Date: 2018/8/14 10:41
 */
public interface PersonProjection {
    /**
     * 人员ID
     * @return
     */
    String getId();

    /**
     * 姓名
     * @return
     */
    String getName();

    /**
     * 组织ID
     * @return
     */
    Integer getOrganizationId();
}
