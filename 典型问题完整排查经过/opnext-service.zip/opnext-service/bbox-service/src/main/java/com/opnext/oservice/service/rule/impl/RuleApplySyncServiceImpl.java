package com.opnext.oservice.service.rule.impl;

import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.domain.ResourceType;
import com.opnext.domain.access.RulePerson;
import com.opnext.domain.message.Command;
import com.opnext.domain.response.IDRuleResp;
import com.opnext.domain.response.RulePersonResp;
import com.opnext.omessage.support.CallBackBuilder;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.domain.command.BusinessType;
import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.domain.rule.QRuleApplySync;
import com.opnext.oservice.domain.rule.RuleApplySync;
import com.opnext.oservice.repository.ComplicateQueryDao;
import com.opnext.oservice.repository.rule.RuleApplySyncRepository;
import com.opnext.oservice.service.rule.RuleApplySyncService;
import com.opnext.oservice.util.FileUrlPathHandle;
import com.opnext.oservice.util.UUIDUtil;
import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 15:57
 */
@Service
@Slf4j
public class RuleApplySyncServiceImpl implements RuleApplySyncService {
    @Value("${server.context-path}")
    private String serverPath;
    @Autowired
    private JPAQueryFactory jpaQueryFactory;
    @Autowired
    private ComplicateQueryDao complicateQueryDao;
    @Autowired
    private RuleApplySyncRepository ruleApplySyncRepository;
    @PersistenceContext
    private EntityManager entityManager;

    /**
     * 获取要下发的人员信息
     *
     * @param batchId
     * @param workflowId
     * @param commandId
     * @param requestId
     * @param pageable
     * @return
     */
    @Override
    public RulePersonResp getRulePerson(String batchId, String workflowId, String commandId, String requestId, Pageable pageable, RequestUrlPrefix urlPrefix) throws CommonException {
        RuleApplySync ruleApplySyncResult = ruleApplySyncRepository.findFirstByCommandId(batchId);
        if (ruleApplySyncResult == null) {
            log.debug("未查询到人员");
            throw new CommonException("DataNotFound");
        }
        int ruleId = ruleApplySyncResult.getRuleId();
        boolean isBind = ruleApplySyncResult.getOperationType() == IDRuleResp.OperationType.BIND;
        String nextPage = null;
        QPerson qPerson = QPerson.person;
        QRuleApplySync qRuleApplySync = QRuleApplySync.ruleApplySync;
        List<Person> personList = jpaQueryFactory
                .select(qPerson)
                .from(qPerson, qRuleApplySync)
                .where(qPerson.id.eq(qRuleApplySync.personId)
                        .and(qRuleApplySync.commandId.eq(batchId)))
                .offset(pageable.getOffset())
                .limit(pageable.getPageSize())
                .fetch();
        if (CollectionUtils.isEmpty(personList)) {
            return new RulePersonResp();
        }
        String terminalGatewayHost = GlobleConfig.ServerUrl.getTerminalGatewayHost(urlPrefix.getScheme());
        if (personList.size() == pageable.getPageSize()) {
            nextPage = String.format("%s%s/api/devapi/getRulePersonIds/%s/%s/%s/%s?page=%d"
                    , terminalGatewayHost
                    , serverPath
                    , workflowId
                    , commandId
                    , requestId
                    , batchId
                    , pageable.getPageNumber() + 1);
        }
        List<RulePerson> rulePersonList = new ArrayList<>();
        for (Person person : personList) {
            RulePerson rulePerson = new RulePerson();
            rulePerson.setPersonId(person.getNo());
            rulePerson.setVersion(person.getUpdateTime() == null ? 0 : person.getUpdateTime().getTime());
            if (isBind) {
                Map<ResourceType, List<String>> map = FileUrlPathHandle.getShowAvatarsMap(person.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()));
                person.setAvatars(map);
                rulePerson.setInfo(person.toPersonInfo());
            }
            rulePersonList.add(rulePerson);
        }
        String errorCallback = String.format("%s%s/api/devapi/callback/%s/%s/%s/%s"
                , terminalGatewayHost
                , serverPath
                , workflowId
                , commandId
                , requestId
                , BusinessType.PERSON);
        RulePersonResp rulePersonResp = new RulePersonResp();
        rulePersonResp.setRuleId(ruleId);
        rulePersonResp.setRulePersonList(rulePersonList);
        rulePersonResp.setOperationType(isBind ? IDRuleResp.OperationType.BIND : IDRuleResp.OperationType.UNBIND);
        rulePersonResp.setNextPage(nextPage);
        rulePersonResp.setErrorCallback(CallBackBuilder.ready().url(errorCallback).method(Command.Method.POST).build());
        return rulePersonResp;
    }

    /**
     * 获取绑定人员信息
     *
     * @param ruleId
     * @param batchId
     * @param workflowId
     * @param commandId
     * @param requestId
     * @param pageable
     * @return
     */
    @Override
    public RulePersonResp getBindPerson(int ruleId, String batchId, String workflowId, String commandId, String requestId, Pageable pageable,RequestUrlPrefix urlPrefix) {
        String nextPage = null;
        QPerson qPerson = QPerson.person;
        QRuleApplySync qRuleApplySync = QRuleApplySync.ruleApplySync;
        Page<Person> page = complicateQueryDao.find(jpaQueryFactory
                .select(qPerson)
                .from(qPerson, qRuleApplySync)
                .where(qPerson.id.eq(qRuleApplySync.personId).and(qRuleApplySync.commandId.eq(batchId))), pageable);
        List<Person> personList = page.getContent();
        if (personList == null) {
            return new RulePersonResp();
        }
        String terminalGatewayHost = GlobleConfig.ServerUrl.getTerminalGatewayHost(urlPrefix.getScheme());
        if (page.hasNext()) {
            nextPage = String.format("%s%s/api/devapi/getRulePersonIds/%s/%s/%s/%s?page=%d"
                    , terminalGatewayHost
                    , serverPath
                    , workflowId
                    , commandId
                    , requestId
                    , batchId
                    , pageable.getPageNumber() + 1);
        }
        List<RulePerson> rulePersonList = new ArrayList<>();
        for (Person person : personList) {
            RulePerson rulePerson = new RulePerson();
            rulePerson.setPersonId(person.getNo());
            rulePerson.setVersion(person.getUpdateTime() == null ? 0 : person.getUpdateTime().getTime());
            Map<ResourceType, List<String>> map = FileUrlPathHandle.getShowAvatarsMap(person.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()));
            person.setAvatars(map);
            rulePerson.setInfo(person.toPersonInfo());
            rulePersonList.add(rulePerson);
        }
        String errorCallback = String.format("%s%s/api/devapi/callback/%s/%s/%s/%s"
                , terminalGatewayHost
                , serverPath
                , workflowId
                , commandId
                , requestId
                , BusinessType.PERSON);
        RulePersonResp rulePersonResp = new RulePersonResp();
        rulePersonResp.setRuleId(ruleId);
        rulePersonResp.setRulePersonList(rulePersonList);
        rulePersonResp.setOperationType(IDRuleResp.OperationType.BIND);
        rulePersonResp.setNextPage(nextPage);
        rulePersonResp.setErrorCallback(CallBackBuilder.ready().url(errorCallback).method(Command.Method.POST).build());
        return rulePersonResp;
    }

    /**
     * 获取解绑人员信息
     *
     * @param ruleId
     * @param batchId
     * @param workflowId
     * @param commandId
     * @param requestId
     * @param pageable
     * @return
     */
    @Override
    public RulePersonResp getUnBindPerson(int ruleId, String batchId, String workflowId, String commandId, String requestId, Pageable pageable,RequestUrlPrefix urlPrefix) {
        String nextPage = null;
        QRuleApplySync qRuleApplySync = QRuleApplySync.ruleApplySync;
        Predicate predicate = qRuleApplySync.commandId.eq(batchId);
        Page<RuleApplySync> page = ruleApplySyncRepository.findAll(predicate, pageable);
        List<RuleApplySync> ruleApplySyncList = page.getContent();
        if (ruleApplySyncList == null) {
            return new RulePersonResp();
        }
        String terminalGatewayHost = GlobleConfig.ServerUrl.getTerminalGatewayHost(urlPrefix.getScheme());
        if (page.hasNext()) {
            nextPage = String.format("%s%s/api/devapi/getRulePersonIds/%s/%s/%s/%s?page=%d"
                    , terminalGatewayHost
                    , serverPath
                    , workflowId
                    , commandId
                    , requestId
                    , batchId
                    , pageable.getPageNumber() + 1);
        }
        List<RulePerson> rulePersonList = new ArrayList<>();
        for (RuleApplySync ruleApplySync : ruleApplySyncList) {
            RulePerson rulePerson = new RulePerson();
            rulePerson.setPersonId(ruleApplySync.getPersonId());
            rulePersonList.add(rulePerson);
        }
        String errorCallback = String.format("%s%s/api/devapi/callback/%s/%s/%s/%s"
                , terminalGatewayHost
                , serverPath
                , workflowId
                , commandId
                , requestId
                , BusinessType.PERSON);
        RulePersonResp rulePersonResp = new RulePersonResp();
        rulePersonResp.setRuleId(ruleId);
        rulePersonResp.setRulePersonList(rulePersonList);
        rulePersonResp.setOperationType(IDRuleResp.OperationType.UNBIND);
        rulePersonResp.setNextPage(nextPage);
        rulePersonResp.setErrorCallback(CallBackBuilder.ready().url(errorCallback).method(Command.Method.POST).build());
        return rulePersonResp;
    }


    /**
     * 根据人员ID列表添加人员解绑信息到规则应用同步表中
     *
     * @param ruleId        规则ID
     * @param operationType 操作类型（BIND;绑定、UNBIND:解绑）
     * @param personIdList  人员ID列表
     * @return 本次添加的批次ID
     */
    @Override
    public String insertApplySync(int ruleId, IDRuleResp.OperationType operationType, List<String> personIdList) {
        if (CollectionUtils.isEmpty(personIdList)) {
            return null;
        }
        String commandId = UUIDUtil.uuid();
        StringBuilder sbSQLValue = new StringBuilder();
        String strInsertSQL = "insert into rule_apply_sync (person_id, rule_id, operation_type, command_id) values ";
        if (personIdList.size() > 0) {
            for (int i = 0; i < personIdList.size(); i++) {
                sbSQLValue.append(String.format(",('%s', %d, %d, '%s')",
                        personIdList.get(i),
                        ruleId,
                        operationType.ordinal(),
                        commandId));
                if (i > 0 && i % 100 == 0) {
                    entityManager.createNativeQuery(strInsertSQL + sbSQLValue.toString().substring(1)).executeUpdate();
                    sbSQLValue = new StringBuilder();
                }
            }
            if (StringUtils.isNotBlank(sbSQLValue.toString())) {
                entityManager.createNativeQuery(strInsertSQL + sbSQLValue.toString().substring(1)).executeUpdate();
            }
        }
        return commandId;
    }
}
