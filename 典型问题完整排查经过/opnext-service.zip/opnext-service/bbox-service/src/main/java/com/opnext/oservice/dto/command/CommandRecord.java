package com.opnext.oservice.dto.command;

import com.opnext.domain.message.CommandMessage;
import com.opnext.domain.request.FeedBackRequest;
import lombok.Data;

import java.util.List;

/**
 * @author wanglu
 */
@Data
public class CommandRecord extends CommandMessage {
    private String id;
    /** 处理结果 */
    private List<FeedBackRequest.FeedBackError> result;
}
