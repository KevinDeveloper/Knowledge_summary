package com.opnext.oservice.interceptor;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.util.RedisCommonKeyUtil;
import com.opnext.bboxsupport.util.RequestAnalysisUtil;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.authority.role.*;
import com.opnext.oservice.service.authority.PermissionService;
import com.opnext.oservice.service.base.BaseRedisService;
import com.opnext.oservice.service.log.LogAsyncTask;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author wanglu
 */
@Slf4j
public class PermissionHandlerInterceptor  implements HandlerInterceptor {
    @Autowired
    BaseRedisService redisService;
    @Autowired
    PermissionService permissionService;
    @Autowired
    LogAsyncTask logAsyncTask;
    @Autowired
    static final String SU_ROLE = "0";
    static final String NO_ROLE = "-1";

    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        if (!HandlerMethod.class.equals(o.getClass())){
            log.debug("请求的是静态资源，直接通过");
            return true;
        }
        String methodMappingStr = RequestAnalysisUtil.methodUrlPatten((HandlerMethod) o);
        String servletPath = httpServletRequest.getServletPath();
        log.info(">>>在请求处理之前进行调用（Controller方法调用之前）,{},{}",methodMappingStr,servletPath);

        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        if (oserviceOperator.getUserType().value() == OserviceOperator.UserType.GLOBAL.value() || oserviceOperator.getUserType().value() == OserviceOperator.UserType.API.value()){
            log.debug("应用商店调用的接口，或者第三方接口调用，不拦截，直接通过");
            return printLogResult(true,servletPath,methodMappingStr, oserviceOperator);
        }
        //步骤1：判断redis中是否有该账号对应的角色，如果没有，则从DB中查询角色并放入redis中
        String roleIdStr = permissionService.getRoleStrByOperator(oserviceOperator);
        if (StringUtils.isNotBlank(roleIdStr) && SU_ROLE.equals(roleIdStr)){
            log.info("超级管理员角色，直接通过");
            return printLogResult(true,servletPath,methodMappingStr, oserviceOperator);
        }
            //当角色为"无角色",查询访问的是否为公共资源，如果不是则抛403异常
        if (StringUtils.isNotBlank(roleIdStr) && NO_ROLE.equals(roleIdStr)){
            permissionService.initPubResource();
            String pubUrl = redisService.getMapValue(RedisCommonKeyUtil.PUB_RESOURCES,methodMappingStr);
            if (StringUtils.isBlank(pubUrl)){
                log.error("无角色的用户，没有权限访问此接口的权限，返回403");
                throw new CommonException(403,"has.no.permission");
            }
            return printLogResult(true,servletPath,methodMappingStr, oserviceOperator);

        }

        // 步骤2：通过角色查询资源，如果没有资源，则从DB中查询放入redis中
        List<Resource> resources = permissionService.getResourcesByRoleId(Long.parseLong(roleIdStr));
        if (resources.size()<1){
            log.error("用户没有访问任何接口的权利，返回403");
            throw new CommonException(403,"has.no.permission");
        }
            //判断当前访问的api是否在权限范围内，如果不在则抛出403异常
        List<Resource> resourceList =resources.stream().filter(resource ->
                methodMappingStr.equals(resource.getUrl()) && httpServletRequest.getMethod().equalsIgnoreCase(resource.getMethod().name())
            ).collect(Collectors.toList());
        if (Objects.isNull(resourceList) || resourceList.size()==0){
            log.error("用户没有访问此接口的权限，返回403");
            throw new CommonException(403,"has.no.permission");
        }

        //步骤3：查询orgIds，deviceGroupIds并放到operator中，方便后续接口对这两个参数的使用和校验
        List<Integer> orgIdList = permissionService.getOrgIdListByRoleId(Long.parseLong(roleIdStr));
        List<Integer> deviceGroupIdList = permissionService.getDeviceGroupIdListByRoleId(Long.parseLong(roleIdStr));
        oserviceOperator.setUserType(OserviceOperator.UserType.COMMON);
        oserviceOperator.setOrganizations(orgIdList);
        oserviceOperator.setDeviceGroups(deviceGroupIdList);
        OperatorContext.setOperator(oserviceOperator);
        return printLogResult(true,servletPath,methodMappingStr, oserviceOperator);
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {
    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {
        log.info("{}方法调用结束",httpServletRequest.getServletPath());
        String methodMappingStr = RequestAnalysisUtil.methodUrlPatten((HandlerMethod) o);
        String methodName = httpServletRequest.getMethod().toUpperCase();
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        int status = httpServletResponse.getStatus();
        logAsyncTask.saveOperateLog(methodMappingStr,methodName, oserviceOperator.getUserId(), oserviceOperator.getLoginName(), oserviceOperator.getTenantId(),status);
        OperatorContext.remove();
    }

    public boolean printLogResult(boolean bool,String servletPath,String methodAnnotPath,OserviceOperator oserviceOperator){
        log.info("拦截器预处理结束,{},{},{}",methodAnnotPath,servletPath, oserviceOperator);
        return bool;
    }
}
