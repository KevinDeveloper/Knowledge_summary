package com.opnext.oservice.domain.device;

import com.opnext.oservice.domain.converter.DeviceAdminAvatarsConverter;
import lombok.Data;

import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.Id;
import java.util.Date;
import java.util.List;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午5:29 18/5/8
 */
@Data
@Entity
public class DeviceAdminVo
{

    @Id
    private Integer id;
    private String name;
    private String password;
    private String phone;
    private String remark;
    @Convert(converter = DeviceAdminAvatarsConverter.class)
    private List<String> avatars;
    private Long operatorId;
    private String operatorName;
    private Long tenantId;
    private Date createTime;
    private Date updateTime;
    private Long deviceCount;
}
