package com.opnext.oservice.dto.accessrecord;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * @author tianzc
 */
@Data
public class AccessRecordOaDTO {
    private String id;
    /**
     * 人员姓名
     */
    private String name;
    /**
     * 人员编号
     */
    private String no;
    /**
     * 通行证
     */
    private String idNumber;
    /**
     * 设备sn
     */
    private String sn;
    /**
     * 验证时间
     */
    private Long syncTime;
    /**
     * 创建时间
     */
    private Long createTime;

    /**
     * 通行结果
     */
    private ResultType resultType;

    @Slf4j
    @AllArgsConstructor
    public enum ResultType {
        /**
         * 通过
         */
        SUCCESS("TERMINAL_VALIDATION_PASS"),
        /**
         * 验证不通过
         */
        FAIL("TERMINAL_VALIDATION_FAILURE");
        private String value;

        private static Map<String, ResultType> valMap = new HashMap<>();

        public String value(){
            return this.value;
        }

        static {
            for (ResultType result : values()) {
                valMap.put(result.value, result);
            }
        }
        public static ResultType indexOfVal(String value) {
            ResultType resultType = valMap.get(value);
            if(null == resultType){
                log.error("ResultType中没有找到匹配的 " + value);
                throw new IllegalArgumentException("No element matches " + value);
            }
            return resultType;
        }
    }
}
