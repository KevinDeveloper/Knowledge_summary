package com.opnext.oservice.conf;

import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.bboxdomain.OserviceOperator;

/**
 * @author wanglu
 */
public class OperatorContext {
    private static ThreadLocal threadLocal = new ThreadLocal();

    public OperatorContext() {
    }

    public static OserviceOperator getOperator() {
        return (OserviceOperator)threadLocal.get();
    }

    public static void setOperator(OserviceOperator oserviceOperator) {
        threadLocal.set(oserviceOperator);
    }

    public static OserviceDevApiOperator getApiOperator() {
        return (OserviceDevApiOperator)threadLocal.get();
    }

    public static void setApiOperator(OserviceDevApiOperator oserviceDevApiOperator) {
        threadLocal.set(oserviceDevApiOperator);
    }

    public static void remove() {
        threadLocal.remove();
    }
}
