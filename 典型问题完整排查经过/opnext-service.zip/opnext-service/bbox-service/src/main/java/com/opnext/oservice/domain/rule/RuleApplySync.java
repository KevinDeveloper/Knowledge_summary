package com.opnext.oservice.domain.rule;

import com.opnext.domain.response.IDRuleResp;
import lombok.Data;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/31 16:44
 */
@Entity
@Table(name = "rule_apply_sync")
@Data
@EntityListeners(AuditingEntityListener.class)
public class RuleApplySync {
    @Id
    @GeneratedValue
    private Integer id;

    /**
     * 人员ID
     */
    @Column(name="person_id")
    private String personId;

    /**
     * 规则ID
     */
    @Column(name = "rule_id")
    private Integer ruleId;

    /**
     * 同步操作类型
     */
    @Column(name = "operation_type")
    private IDRuleResp.OperationType operationType;

    /**
     * 批次ID
     */
    @Column(name = "command_id")
    private String commandId;
}
