package com.opnext.oservice.service.device;

import com.opnext.oservice.domain.device.alarm.DeviceAlarm;
import com.opnext.oservice.domain.device.alarm.DeviceAlarmType;
import com.querydsl.core.types.Predicate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @author wanglu
 */
public interface DeviceAlarmService {

    /**
     * 获取告警类型
     * @return
     */
    List<DeviceAlarmType> getAlarmTypeList();

    /**
     * 获取未读的终端预警总数
     * @param status
     * @param tenantId
     * @return
     */
    int countByReadStatusAndTenantId(boolean status,long tenantId);

    /**
     * 将未读预警数量清0
     * @param tenantId
     * @return
     */
    void clearUnReadAlarm(long tenantId);

    /**
     * 前端：分页查询终端告警并将未读总数清0
     * @param tenantId
     * @param predicate
     * @param pageable
     * @return
     */
    Page<DeviceAlarm> queryAlarmPagable(long tenantId,Predicate predicate, Pageable pageable);

    /**
     * 通过名称获取告警类型对象
     * @param alarmType
     * @return
     */
    DeviceAlarmType findDeviceAlarmTypeByName(String alarmType);

    /**
     * 保存终端告警
     * @param deviceAlarm
     */
    void saveDeviceAlarm(DeviceAlarm deviceAlarm);
}
