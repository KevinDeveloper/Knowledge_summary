package com.opnext.oservice.domain.rule;

import lombok.Data;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/25 13:10
 */
@Data
public class Range<T> {
    private T start;
    private T end;

    @Data
    public class Day {
        private int year;
        private int mm;
        private int day;
    }

    @Data
    public class Time {
        private int hour;
        private int minute;
        private int second;
    }
}

