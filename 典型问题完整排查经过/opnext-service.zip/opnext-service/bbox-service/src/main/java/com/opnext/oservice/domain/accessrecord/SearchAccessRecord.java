package com.opnext.oservice.domain.accessrecord;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @author tianzc
 */
@Data
@ApiModel(description="搜索识别记录对象")
public class SearchAccessRecord {
    @ApiModelProperty(value="姓名是否模糊搜索")
    private boolean regexName = false;
    @ApiModelProperty(value="姓名")
    private String name;
    @ApiModelProperty(value="人员编号是否模糊搜索")
    private boolean regexPersonNo = false;
    @ApiModelProperty(value="人员编号")
    private String personNo;
    @ApiModelProperty(value="组织id")
    private Integer organizationId;
    @ApiModelProperty(value="开始时间")
    private Long startTime;
    @ApiModelProperty(value="结束时间")
    private Long endTime;
    @ApiModelProperty(value="规则id")
    private String ruleId;
    @ApiModelProperty(value="设备sn号")
    private String sn;
    @ApiModelProperty(value="设备组id")
    private Integer deviceGroupId;
    @ApiModelProperty(value="通行结果")
    private AccessRecordInfo.ResultType resultType;


}
