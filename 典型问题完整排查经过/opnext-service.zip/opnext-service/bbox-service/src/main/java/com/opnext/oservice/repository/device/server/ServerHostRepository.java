package com.opnext.oservice.repository.device.server;

import com.opnext.oservice.domain.device.ServerHost;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @Title: 
 * @Description: 
 * @author tianzc
 * @Date 下午5:08 18/5/7
 */ 
public interface ServerHostRepository extends PagingAndSortingRepository<ServerHost, String>, QueryDslPredicateExecutor<ServerHost> {
}
