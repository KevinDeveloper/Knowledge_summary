package com.opnext.oservice.controller.log;

import com.opnext.bboxdomain.log.LogReq;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.oservice.domain.authority.role.Module;
import com.opnext.oservice.domain.authority.role.QResource;
import com.opnext.oservice.domain.authority.role.Resource;
import com.opnext.oservice.domain.log.OperationLog;
import com.opnext.oservice.domain.log.QOperationLog;
import com.opnext.oservice.dto.authority.role.ResourceDTO;
import com.opnext.oservice.service.account.AccountService;
import com.opnext.oservice.service.authority.ResourceService;
import com.opnext.oservice.service.log.OperationLogService;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.Objects;

/**
 * @author wanglu
 */
@Slf4j
@RestController
public class OperationLogController {
    @Autowired
    private OperationLogService operationLogService;
    @Autowired
    private ResourceService resourceService;

    @ApiOperation(value = "获取操作日志列表", notes = "获取操作日志列表")
    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "query", dataType = "long", name = "startTime", value = "开始时间"),
            @ApiImplicitParam(paramType = "query", dataType = "long", name = "endTime", value = "结束时间"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "loginName", value = "管理员账号"),
            @ApiImplicitParam(paramType = "query", dataType = "Integer", name = "module", value = "主功能Id"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "page", value = "分页页码"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "size", value = "分页条数"),
            @ApiImplicitParam(paramType = "query", dataType = "String", name = "sort", value = "排序规则，例如?sort=occurTime,desc表示根据occurTime字段倒叙排序")
    })
    @RequestMapping(value = "/api/log/operation",method = RequestMethod.GET)
    public Page<OperationLog> getLogPage( @RequestParam(required = false) Long startTime,
                                          @RequestParam(required = false) Long endTime,
                                          @RequestParam(required = false) String loginName,
                                          @RequestParam(required = false) Module module,
                                          @PageableDefault Pageable pageable){
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        Long tenantId = oserviceOperator.getTenantId();
        QOperationLog qOperationLog = QOperationLog.operationLog;
        Predicate predicate=qOperationLog.tenantId.eq(tenantId);
        if (startTime != null){
            Date date = new Date(startTime);
            predicate=((BooleanExpression) predicate).and(qOperationLog.occurTime.goe(date));
        }
        if (endTime !=null){
            Date date = new Date(endTime);
            predicate=((BooleanExpression) predicate).and(qOperationLog.occurTime.loe(date));
        }
        if (StringUtils.isNotBlank(loginName)){
            predicate=((BooleanExpression) predicate).and(qOperationLog.loginName.contains(loginName));
        }
        if (Objects.nonNull(module)){
            predicate=((BooleanExpression) predicate).and(qOperationLog.moduleId.eq(module.getId()));
        }
        Page<OperationLog> operationLogPage = operationLogService.findAll(predicate,pageable);
        return operationLogPage;
    }

    @RequestMapping(value = "/log/operation",method = RequestMethod.POST)
    public void saveLog(@Valid @RequestBody LogReq logReq, BindingResult bindingResult) throws Exception{
        if (bindingResult.hasErrors()){
            throw new CommonException(400,"parameter.incorrect",bindingResult);
        }
        Long accountId = logReq.getUserId();
        Long tenantId = logReq.getTenantId();
        String loginName = logReq.getLoginName();
        String methodMappingStr = logReq.getApiPath();

        if(logReq.getMethod().name().equals(Resource.Method.GET.name()) ){
            log.debug("不是PUT POST DELETE接口，不记录日志");
            return;
        }

        if (Objects.isNull(logReq.getUserId()) || logReq.getUserId()==0){
            log.info("第三方的接口调用，不记录操作记录");
            return;
        }

        QResource qresource =QResource.resource;
        Predicate predicate =qresource.url.eq(methodMappingStr).and(qresource.method.eq(Resource.Method.valueOf(logReq.getMethod().name())));
        ResourceDTO resourceDTO = resourceService.findApiResource(predicate);

        if (Objects.isNull(resourceDTO)){
            log.error("该接口不存在,{}",methodMappingStr);
            return;
        }

        try {
            operationLogService.save(
                    OperationLog.builder()
                            .accountId(accountId)
                            .loginName(loginName)
                            .moduleId(resourceDTO.getModuleId())
                            .moduleName(resourceDTO.getModuleName())
                            .resourceId(resourceDTO.getResourceId())
                            .resourceName(resourceDTO.getResourceName())
                            .tenantId(tenantId)
                            .occurTime(new Date())
                            .resultStatus(OperationLog.ResultStatus.valueOf(logReq.getResultStatus().name()))
                            .build()
            );
        }catch (Exception e1){
            log.error("保存操作记录失败,{}",e1);
        }
    }
}
