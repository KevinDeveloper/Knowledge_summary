package com.opnext.oservice.service;

import com.opnext.oservice.domain.ServerConfig;

/**
 * @author tianzc
 */
public interface ServerConfigService {

    /**
     * 更新信息
     *
     * @param serverConfig
     * @throws Exception
     */
    void update(ServerConfig serverConfig) throws Exception;

    /**
     * 获取配置
     * @param key
     * @param type
     * @param tenantId
     * @return
     * @throws Exception
     */
    ServerConfig getConfig(String key, String type, Long tenantId) throws Exception;

    /**
     * 获取人员密码配置
     * @param tenantId
     * @return
     * @throws Exception
     */
    ServerConfig getPersonPwdConfig(Long tenantId) throws Exception;


}
