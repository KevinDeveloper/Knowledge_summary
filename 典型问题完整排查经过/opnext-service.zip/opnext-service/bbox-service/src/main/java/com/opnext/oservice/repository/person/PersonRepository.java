package com.opnext.oservice.repository.person;

import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.dto.person.PersonProjection;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;
import java.util.Optional;

public interface PersonRepository extends PagingAndSortingRepository<Person, String>, QueryDslPredicateExecutor<Person> {

    /**
     * 通过openId查询人员
     *
     * @param openId
     * @param tenantId
     * @return
     */
    Optional<Person> findByOpenIdAndTenantId(String openId, long tenantId);

    /**
     * 通过人员编号查询人员详情
     *
     * @param no
     * @param tenantId
     * @return
     */
    Person findByNoAndTenantId(String no, long tenantId);

    /**
     * 获取组织下人员列表
     *
     * @param type           人员类型
     * @param organizationId 组织ID
     * @param tenantId       租户ID
     * @param from           查询起始位置
     * @param size           查询数量
     * @return
     */
    @Query(value = "SELECT id,name,organization_id as organizationId" +
            "  FROM person " +
            "  WHERE type=?1 AND organization_id = ?2 AND tenant_id=?3 " +
            "  ORDER BY CONVERT(name USING gbk),id " +
            "  LIMIT ?4,?5", nativeQuery = true)
    List<PersonProjection> findByOrganizationId(int type, int organizationId, long tenantId, int from, int size);
}