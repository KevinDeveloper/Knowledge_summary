package com.opnext.oservice.service;

import com.opnext.domain.OPNextConstant;
import com.opnext.domain.message.Report;
import com.opnext.oservice.conf.DeviceRabbitConfig;
import com.opnext.oservice.service.device.message.DeviceMessageService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.Set;

/**
 * @author wanglu
 */
@Slf4j
@Component
public class MessageHandler {
    @Autowired
    DeviceMessageService deviceMessageService;

    @RabbitListener(queues ={DeviceRabbitConfig.DEVICE_STATUS_REPORT}, containerFactory="rabbitListenerContainerFactory")
    public void process(@Payload Report report) {
        try {
            switch(report.getData()){
                case OPNextConstant.REPORT_TYPE.ALERT.OFF_LINE:
                    deviceMessageService.updateStaus(report);
                    deviceMessageService.uploadAlarm(report);
                    break;
                case OPNextConstant.REPORT_TYPE.ALERT.NO_HEARTBEAT:
                    deviceMessageService.updateStaus(report);
                    deviceMessageService.uploadAlarm(report);
                    break;
                case OPNextConstant.REPORT_TYPE.ALERT.RECOVERY:
                    deviceMessageService.updateStaus(report);
                    break;
                default :
                    break;
            }
        }catch (Exception e){
            log.error("消息处理失败,{},{}",report,e.getMessage());
        }
    }

    @RabbitListener(queues ={DeviceRabbitConfig.DEVICE_STATUS_ONLINE}, containerFactory="rabbitListenerContainerFactory")
    public void processOnline(@Payload Set<String> onlineSet) {
        try {
            deviceMessageService.updateOnlineStatus(onlineSet);
        }catch (Exception e){
            log.error("在线设备补偿-消息处理失败", e);
        }
    }
}
