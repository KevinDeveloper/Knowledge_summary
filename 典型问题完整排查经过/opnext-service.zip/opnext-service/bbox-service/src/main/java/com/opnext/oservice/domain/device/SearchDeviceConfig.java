package com.opnext.oservice.domain.device;

import lombok.Data;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:06 18/5/7
 */
@Data
public class SearchDeviceConfig {

    private String id;
    private String serviceType;
    private Long version;
}
