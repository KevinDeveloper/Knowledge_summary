package com.opnext.oservice.domain;

import lombok.AllArgsConstructor;

/**
 * @author tianzc
 */
@AllArgsConstructor
public enum DeleteFlag {
    /**
     * 数据正常可见
     */
    DATA_VISIBLE((byte)0),
    /**
     * 数据已删除
     */
    DATA_DELETE((byte)1);
    private Byte value;
    public Byte value(){
        return this.value;
    }
}
