package com.opnext.oservice.repository.authority;

import com.opnext.oservice.domain.authority.role.Module;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @author wanglu
 */
public interface ModuleRepository extends PagingAndSortingRepository<Module, Integer>,
        QueryDslPredicateExecutor<Module> {
    /**
     * 通过是否为主菜单，返回菜单列表（菜单==>权限）
     * @param isMainFunction
     * @return
     */
    List<Module> findAllByIsMainFunction(Module.IsMainFunction isMainFunction);

    /**
     * 查询所有pid为空的菜单
     * @return
     */
    List<Module> findAllByPidNull();

    /**
     * 查询所有pid不为空的菜单
     * @return
     */
    List<Module> findAllByPidNotNull();

    /**
     * 根据给出的模块id条件查询所有pid为空的菜单
     * @param ids
     * @return
     */
    List<Module> findAllByIdInAndPidNull(List<Integer> ids);

    /**
     * 根据给出的模块id条件查询所有pid不为空的菜单
     * @param ids
     * @return
     */
    List<Module> findAllByIdInAndPidNotNull(List<Integer> ids);
}