package com.opnext.oservice.domain.rule;

import com.opnext.oservice.domain.rule.MultiKeys.RuleApplyMultiKeysClass;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * @Author: lixiuwen
 * @Date: 2018/5/30 14:03
 */
@Entity
@Table(name = "rule_apply")
@Data
@EntityListeners(AuditingEntityListener.class)
public class RuleApply{
    @Id
    @GeneratedValue
    private Integer id;
    /**
     * 应用于人员ID
     */
    @Column(name = "person_id")
    private String personId;

    /**
     * 应用于组织ID
     */

    @Column(name = "organization_id")
    private Integer organizationId;

    /**
     * 规则ID
     */
    @Column(name = "rule_id")
    private Integer ruleId;

    /**
     * 应用ID
     */
    @Column(name = "app_id")
    private String appId;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    @CreatedDate
    private Date createTime;

    /**
     * 创建人ID
     */
    @Column(name = "create_by")
    private Long createBy;

    /**
     * 租户ID
     */
    @Column(name = "tenant_id")
    private Long tenantId;

    public RuleApply() {

    }

    public RuleApply(int ruleId, String personId) {
        this.ruleId = ruleId;
        this.personId = personId;
    }
}
