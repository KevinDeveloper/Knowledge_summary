package com.opnext.oservice.repository.person;

import com.opnext.oservice.domain.person.HistoryPerson;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface HistoryPersonRepository extends PagingAndSortingRepository<HistoryPerson, String>,QueryDslPredicateExecutor<HistoryPerson> {

}