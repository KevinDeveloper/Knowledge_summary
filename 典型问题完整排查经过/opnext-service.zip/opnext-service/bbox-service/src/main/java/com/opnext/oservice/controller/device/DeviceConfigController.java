package com.opnext.oservice.controller.device;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.validator.IsCollectionEmptyValidator;
import com.opnext.bboxsupport.validator.IsEmptyValidator;
import com.opnext.bboxsupport.validator.IsStringWithinLengthRangeValidator;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.device.DeviceConfig;
import com.opnext.oservice.domain.device.DeviceSync;
import com.opnext.oservice.domain.device.SearchDeviceConfig;
import com.opnext.oservice.service.device.DeviceConfigService;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 * @Title: --
 * @Description: --
 * @author tianzc
 * @Date 下午4:49 18/5/7
 */
@Slf4j
@RestController
@RequestMapping("/api/device/config")
public class DeviceConfigController {

    @Autowired
    DeviceConfigService deviceConfigService;

    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", dataType = "String", required = true, name = "serviceType",  value = "BASE:基础配置，GROUP:分库，其他")
    })
    @ApiOperation(value = "获取配置列表", notes = "通过不同类型查询配置列表")
    @RequestMapping(value = "/{serviceType}",method = RequestMethod.GET)
    public CommonResponse listConfig(@PathVariable String serviceType, SearchDeviceConfig sDeviceConfig) throws Exception {
        sDeviceConfig.setServiceType(serviceType);
        List<DeviceConfig> list = deviceConfigService.listConfig(sDeviceConfig);
        return CommonResponse.ok(list);
    }

    @ApiOperation(value = "单个配置", notes = "获取单个配置")
    @RequestMapping(value = "/{serviceType}/{id}",method = RequestMethod.GET)
    public CommonResponse getConfig(@PathVariable String serviceType, @PathVariable String id) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        DeviceConfig qDeviceConfig = deviceConfigService.getConfig(serviceType, id, tenantId);
        return CommonResponse.ok(qDeviceConfig);
    }

    @ApiImplicitParams({
            @ApiImplicitParam(paramType = "path", dataType = "String", required = true, name = "serviceType", value = "BASE:基础配置，GROUP:分库，其他")
    })
    @ApiOperation(value = "新增配置", notes = "")
    @RequestMapping(value = "/{serviceType}",method = RequestMethod.POST)
    public CommonResponse saveConfig(@PathVariable String serviceType, @RequestBody DeviceConfig deviceConfig) throws Exception {
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        // 数据校验
        ComplexResult ret  = FluentValidator.checkAll()
                .failOver()
                .on(deviceConfig.getName(), new IsEmptyValidator("name"))
                .on(deviceConfig.getName(), new IsStringWithinLengthRangeValidator("name", 1,64,true))
                .on(deviceConfig.getDescription(), new IsStringWithinLengthRangeValidator("description", 0,64,true))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("新增设置参数异常{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        DeviceConfig qDeviceConfig = deviceConfigService.saveConfig(serviceType, deviceConfig, tenantId);
        return CommonResponse.ok(qDeviceConfig);
    }

    @ApiOperation(value = "更新配置/更新名称", notes = "")
    @RequestMapping(value = "/{serviceType}/{id}",method = RequestMethod.POST)
    public CommonResponse updateConfig(@PathVariable String serviceType, @PathVariable String id,
                             @RequestBody DeviceConfig deviceConfig) throws Exception{
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        // 赋值
        deviceConfig.setId(id);
        deviceConfig.setServiceType(serviceType);
        deviceConfig.setTenantId(oserviceOperator.getTenantId());
        DeviceConfig qDeviceConfig = deviceConfigService.updateConfig(deviceConfig);
        return CommonResponse.ok(qDeviceConfig);
    }



    @ApiOperation(value = "删除设置", notes = "通过设备id删除")
    @RequestMapping(value = "/{serviceType}/{id}",method = RequestMethod.DELETE)
    public void delete(@PathVariable String serviceType , @PathVariable String id) throws Exception {
        deviceConfigService.delete(serviceType,id);
    }

    @ApiOperation(value = "同步基础配置", notes = "")
    @RequestMapping(value = "/sync",method = RequestMethod.POST)
    public void syncConfig(@RequestBody DeviceSync deviceSync) throws Exception {
        log.info("同步设备设置参数sn：{}",deviceSync.getSnList());
        log.debug("同步设备设置参数deviceSync：{}",deviceSync);
        ComplexResult ret  = FluentValidator.checkAll()
                .failOver()
                .on(deviceSync.getDeviceIds(), new IsCollectionEmptyValidator<>("deviceIds"))
                .on(deviceSync.getSnList(), new IsCollectionEmptyValidator<>("snList"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("设备配置参数异常{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        // 待完善tianzc
        deviceConfigService.syncConfig(deviceSync);
    }
}
