package com.opnext.oservice.domain.authority.role;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

import javax.persistence.*;

/**
 * @author wanglu
 */
@Entity
@Data
@Table(name = "role_device_group")
@Builder
public class RoleDeviceGroup {
    @Tolerate
    public RoleDeviceGroup(){}
    @Id
    @GeneratedValue
    private Long id;
    @Column(name="role_id")
    private Long roleId;

    @Column(name="device_group_id")
    private Integer deviceGroupId;
}
