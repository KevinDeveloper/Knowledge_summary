package com.opnext.oservice.repository.person;

import com.opnext.oservice.domain.person.PersonConfig;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @ClassName: PersonConfigRepository
 * @Description:
 * @Author: Kevin
 * @Date: 2018/5/18 15:33
 */
public interface PersonConfigRepository extends PagingAndSortingRepository<PersonConfig, Integer>,
        QueryDslPredicateExecutor<PersonConfig> {
}
