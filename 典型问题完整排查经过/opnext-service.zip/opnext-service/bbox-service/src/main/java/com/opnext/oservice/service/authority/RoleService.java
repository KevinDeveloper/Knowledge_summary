package com.opnext.oservice.service.authority;

import com.opnext.oservice.domain.authority.AccountRole;
import com.opnext.oservice.domain.authority.role.Role;
import com.opnext.oservice.dto.authority.role.RoleDetailDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

/**
 * @author wanglu
 */
public interface RoleService {
    /**
     * 获取角色列表（所有租户下）
     * @return
     */
    List<Role> getRolesInAllTenant();

    /**
     * 通过账号id获取账号角色对象
     * @param accountId
     * @return
     */
    AccountRole getAccountRoleByAccountId(long accountId);

    /**
     * 分页查询角色列表
     * @param pageable
     * @param tenantId
     * @return
     */
    Page<Role> findRolePage(Pageable pageable, long tenantId);

    /**
     * 获取角色列表（非分页，用于角色下拉列表的展示，并且不能查询出超管角色）
     * @param tenantId
     * @return
     */
    List<Role> findAllRole(long tenantId);

    /**
     * 通过角色id获取账号id列表
     * @param roleId
     * @return
     */
    List<Long> getAccountIdsByRoleId(long roleId);

    /**
     * 获取角色详情
     * @param roleId
     * @param tenantId
     * @return
     * @throws Exception
     */
    RoleDetailDTO getRoleDetail(long roleId, long tenantId) throws Exception;

    /**
     * 通过角色名称和租户id查询角色列表
     * @param name
     * @param tenantId
     * @return
     */
    List<Role> findAllByNameAndTenantId(String name,long tenantId);

    /**
     * 新增角色
     * @param roleDetailDTO
     * @param accountId
     * @param tenantId
     */
    void addRole(RoleDetailDTO roleDetailDTO,long accountId,long tenantId);

    /**
     * 角色修改
     * @param roleId
     * @param roleDetailDTO
     * @param tenantId
     * @throws Exception
     */
    void modifyRole(long roleId,RoleDetailDTO roleDetailDTO,long tenantId) throws Exception;

    /**
     * 删除角色
     * @param roleId
     * @param tenantId
     * @throws Exception
     */
    void deleteRole(long roleId,long tenantId) throws Exception;
}
