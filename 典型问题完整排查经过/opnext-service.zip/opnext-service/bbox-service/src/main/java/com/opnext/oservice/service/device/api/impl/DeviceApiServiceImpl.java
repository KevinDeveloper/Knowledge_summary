package com.opnext.oservice.service.device.api.impl;

import com.beebox.push.common.amqp.PushClient;
import com.beebox.push.event.Event;
import com.beebox.push.event.EventBuilder;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.util.Messages;
import com.opnext.domain.I18n;
import com.opnext.domain.PersonInfo;
import com.opnext.domain.ResourceType;
import com.opnext.domain.SerializableMap;
import com.opnext.domain.TerminalAdmin;
import com.opnext.domain.descriptor.KeyNameDescriptor;
import com.opnext.domain.message.Command;
import com.opnext.domain.message.CommandType;
import com.opnext.domain.message.Feature;
import com.opnext.domain.request.CallBackRequest;
import com.opnext.domain.request.FeedBackRequest;
import com.opnext.domain.response.AdminResp;
import com.opnext.domain.response.PersonResp;
import com.opnext.omessage.support.CallBackBuilder;
import com.opnext.omessage.support.MessageContext;
import com.opnext.omessage.support.SimpleMessageTemplate;
import com.opnext.oservice.conf.Constant;
import com.opnext.oservice.conf.GlobleConfig;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.controller.device.api.DeviceApiController;
import com.opnext.oservice.domain.command.BusinessType;
import com.opnext.oservice.domain.command.CommandErrorInfo;
import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.domain.device.DeviceAdmin;
import com.opnext.oservice.domain.device.DeviceStatus;
import com.opnext.oservice.domain.device.DeviceType;
import com.opnext.oservice.domain.device.HistoryDevice;
import com.opnext.oservice.domain.device.License;
import com.opnext.oservice.domain.device.QDevice;
import com.opnext.oservice.domain.device.QDeviceAdmin;
import com.opnext.oservice.domain.device.QDeviceAdminRel;
import com.opnext.oservice.domain.device.QTenantActiveCode;
import com.opnext.oservice.domain.device.ServerApi;
import com.opnext.oservice.domain.device.ServerEntity;
import com.opnext.oservice.domain.device.ServerHost;
import com.opnext.oservice.domain.device.ServerUri;
import com.opnext.oservice.domain.device.TenantActiveCode;
import com.opnext.oservice.domain.person.OperationType;
import com.opnext.oservice.domain.person.Person;
import com.opnext.oservice.domain.person.PersonConfigVo;
import com.opnext.oservice.domain.person.PersonSync;
import com.opnext.oservice.domain.person.PersonSyncError;
import com.opnext.oservice.domain.person.QPerson;
import com.opnext.oservice.domain.person.QPersonSync;
import com.opnext.oservice.dto.CommonFailedStatus;
import com.opnext.oservice.dto.TerminalFailCode;
import com.opnext.oservice.feign.DoorKeeperFeign;
import com.opnext.oservice.feign.OMessageFeign;
import com.opnext.oservice.feign.OStreamFeign;
import com.opnext.oservice.feign.StoreApiFeign;
import com.opnext.oservice.repository.ComplicateQueryDao;
import com.opnext.oservice.repository.command.CommandErrorInfoDao;
import com.opnext.oservice.repository.command.CommandErrorInfoRepository;
import com.opnext.oservice.repository.device.DeviceRepository;
import com.opnext.oservice.repository.device.HistoryDeviceRepository;
import com.opnext.oservice.repository.device.TenantActiveCodeRepository;
import com.opnext.oservice.repository.device.server.ServerApiRepository;
import com.opnext.oservice.service.AsyncService;
import com.opnext.oservice.service.device.api.DeviceApiService;
import com.opnext.oservice.service.person.PersonConfigService;
import com.opnext.oservice.service.rule.RuleDeviceService;
import com.opnext.oservice.util.FileUrlPathHandle;
import com.opnext.oservice.util.JsonConvertor;
import com.opnext.oservice.util.MD5Utils;
import com.querydsl.core.types.Predicate;
import com.querydsl.core.types.dsl.BooleanExpression;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import opnext.server.support.util.UrlUtil;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.exception.LockAcquisitionException;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * @author tianzc
 * @date 下午4:53 18/5/7
 */
@Slf4j
@Service
public class DeviceApiServiceImpl implements DeviceApiService {
    @Value("${server.context-path}")
    private String serverPath;

    @Resource
    private TenantActiveCodeRepository activeCodeRepository;
    @Resource
    private DeviceRepository deviceRepository;
    @Resource
    private HistoryDeviceRepository historyDeviceRepository;
    @Resource
    private ServerApiRepository apiRepository;
    @Resource
    private ComplicateQueryDao complicateQueryDao;
    @Resource
    private JPAQueryFactory jpaQueryFactory;

    @Resource
    @Lazy
    private PersonConfigService personConfigService;
    @Resource
    private CommandErrorInfoDao commandErrorInfoDao;
    @Resource
    private CommandErrorInfoRepository commandErrorInfoRepository;
    @Resource
    private AsyncService asyncService;
    @Resource
    private RuleDeviceService ruleDeviceService;

    @Resource
    private StoreApiFeign storeApiFeign;
    @Resource
    private DoorKeeperFeign doorKeeperFeign;
    @Resource
    private OMessageFeign oMessageFeign;
    @Resource
    private OStreamFeign oStreamFeign;
    @Resource
    private GlobleConfig.ServerMessages serverMessages;

    @Resource
    private GlobleConfig.TerminalServer terminalServer;
    @Resource
    private PushClient pushClient;


    /**
     * 数据处理返回错误信息
     *
     * @param command
     * @param oserviceDevApiOperator
     * @param businessType
     * @return
     * @throws Exception
     */
    @Override
    public void errorCallback(Command command, OserviceDevApiOperator oserviceDevApiOperator, BusinessType businessType, CallBackRequest callBackRequest) throws Exception {
        if (!CollectionUtils.isEmpty(callBackRequest.getErrorDataList())) {
            // 人员信息同步错误
            if (BusinessType.PERSON.equals(businessType)) {
                List<Map> personErrorlist = callBackRequest.getErrorDataList();
                if (CollectionUtils.isEmpty(personErrorlist)) {
                    log.info("------处理失败回调数据为空");
                } else {
                    List<String> personNoList = new ArrayList<>();
                    for (Map map : personErrorlist) {
                        PersonSyncError error = JsonConvertor.jsonToBean(JsonConvertor.mapToJson(map), PersonSyncError.class);
                        if (StringUtils.isNoneBlank(error.getNo())) {
                            personNoList.add(error.getNo());
                        }
                    }
                    // 删除上次提交的数据
                    Query query = new Query();
                    Criteria criteria = new Criteria();
                    criteria.and("tenantId").is(oserviceDevApiOperator.getTenantId());
                    criteria.and("requestId").is(command.getRequestId());
                    criteria.and("errorData.no").in(personNoList);
                    query.addCriteria(criteria);
                    commandErrorInfoDao.remove(query);
                    // 数据入库
                    insertErrorInfo(command, oserviceDevApiOperator, businessType, callBackRequest);
                }
            } else if (BusinessType.ADMIN.equals(businessType)) {
                // 数据入库
                insertErrorInfo(command, oserviceDevApiOperator, businessType, callBackRequest);
            } else {
                log.info("暂无其他业务类型同步数据错误处理");
            }
        } else {
            log.info("提交数据为空，不进行业务处理");
        }
    }

    /**
     * 终端错误数据入库
     *
     * @param command
     * @param oserviceDevApiOperator
     * @param businessType
     * @param callBackRequest
     * @throws Exception
     */
    private void insertErrorInfo(Command command, OserviceDevApiOperator oserviceDevApiOperator, BusinessType businessType, CallBackRequest callBackRequest) throws Exception {
        List<SerializableMap> mapList = linkedHashMapToMap(callBackRequest.getErrorDataList());
        List<CommandErrorInfo> list = new ArrayList<>();
        CommandErrorInfo commandErrorInfo;
        int i = 0;
        for (SerializableMap map : mapList) {
            commandErrorInfo = new CommandErrorInfo();
            commandErrorInfo.setCreateTime(System.currentTimeMillis());
            commandErrorInfo.setBusinessType(businessType);
            commandErrorInfo.setCommandId(command.getCommandId());
            commandErrorInfo.setWorkflowId(command.getWorkflowId());
            commandErrorInfo.setRequestId(command.getRequestId());
            commandErrorInfo.setTenantId(oserviceDevApiOperator.getTenantId());
            commandErrorInfo.setDeviceSn(oserviceDevApiOperator.getSn());
            commandErrorInfo.setErrorData(map);
            list.add(commandErrorInfo);
            if ((i + 1) % 100 == 0) {
                commandErrorInfoRepository.save(list);
                list = new ArrayList<>();
            }
            i++;
        }
        if (!CollectionUtils.isEmpty(list)) {
            commandErrorInfoRepository.save(list);
        }
    }

    /**
     * 数据转Map
     *
     * @param linkedHashMapList
     * @return
     */
    private List<SerializableMap> linkedHashMapToMap(List<LinkedHashMap> linkedHashMapList) {
        List<SerializableMap> mapList = new ArrayList<>();
        SerializableMap<String, Object> serializableMap;
        for (LinkedHashMap linkedHashMap : linkedHashMapList) {
            serializableMap = new SerializableMap<>();
            for (Object o : linkedHashMap.entrySet()) {
                Map.Entry entry = (Map.Entry) o;
                serializableMap.put((String) entry.getKey(), entry.getValue());
            }
            mapList.add(serializableMap);
        }
        return mapList;
    }

    /**
     * 指令处理完成反馈
     *
     * @param command
     * @param oserviceDevApiOperator
     * @param businessType
     * @return
     * @throws Exception
     */
    @Override
    public void feedback(Command command, OserviceDevApiOperator oserviceDevApiOperator, BusinessType businessType, FeedBackRequest feedBackRequest) throws Exception {
        asyncService.deviceFeedBack(command, oserviceDevApiOperator, businessType, feedBackRequest);
    }

    /**
     * 获取服务端版本
     *
     * @return
     * @throws Exception
     */
    @Override
    public String getServerVersion() throws Exception {
        String version = GlobleConfig.ServerConfig.version;
        return version;
    }

    /**
     * 终端获取服务端的服务地址和API列表
     *
     * @return
     * @throws Exception
     */
    @Override
    public ServerEntity getServer(String sn,RequestUrlPrefix urlPrefix) throws Exception {
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        // 判断sn
        ServerEntity entity = getEntity(oserviceDevApiOperator.getSn(), false,urlPrefix);
        return entity;
    }

    /**
     * 恢复出厂
     *
     * @param sn
     * @throws Exception
     */
    @Override
    @Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRES_NEW)
    public Device restoreFactorySettings(String sn, String operatorType) throws Exception {
        log.info("重置设备参数sn：{}，operatorType：{}", sn, operatorType);
        Predicate predicate = QDevice.device.sn.eq(sn);
        Device device = deviceRepository.findOne(predicate);
        try {
            if (Objects.nonNull(device)) {
                QDeviceAdminRel qDeviceAdminRel = QDeviceAdminRel.deviceAdminRel;
                predicate = qDeviceAdminRel.deviceId.eq(device.getId());
                predicate = ((BooleanExpression) predicate).and(qDeviceAdminRel.tenantId.eq(device.getTenantId()));
                // 删除管理员绑定设备关系
                jpaQueryFactory.delete(qDeviceAdminRel).where(predicate).execute();
                HistoryDevice historyDevice = new HistoryDevice();
                BeanUtils.copyProperties(device, historyDevice);
                historyDevice.setUpdateTime(new Date());
                historyDevice.setOperatorName("terminal");
                // 设备信息copy到历史表
                historyDeviceRepository.save(historyDevice);
                predicate = QDevice.device.sn.eq(sn);
                // 删除设备
                jpaQueryFactory.delete(QDevice.device).where(predicate).execute();
                log.info("------删除设备参数id：{}，sn：{}", device.getId(), sn);
                try {
                    // 推送设备恢复出厂消息
                    pushDeviceInfo(sn, Event.EventType.DEVICE_RECOVERY, device.getTenantId());
                } catch (Exception e) {
                    log.error("pushServer服务异常",e);
                }
                ruleDeviceService.whenDelDevice(Lists.newArrayList(sn), device.getTenantId());
            } else {
                log.info("------清空设备sn：{}的设备不存在", sn);
            }
            // 清除阻塞指令
            oMessageFeign.deleteCommand(sn);
        } catch (Exception e) {
            if (e.getCause() instanceof LockAcquisitionException) {
                log.error("------设备激活数据锁异常(rest):LockAcquisitionException:{}", e.getMessage());
                throw new CommonException(HttpStatus.BAD_REQUEST.value(), CommonFailedStatus.DATABASE_LOCK_EXCEPTION.getMessage(), null, CommonFailedStatus.DATABASE_LOCK_EXCEPTION.getValue());
            } else {
                log.error("------设备激活数据处理异常(rest): {}", e.getMessage());
                throw new CommonException(HttpStatus.INTERNAL_SERVER_ERROR.value(), CommonFailedStatus.DATABASE_EXCEPTION.getMessage(), null, CommonFailedStatus.DATABASE_EXCEPTION.getValue());
            }
        }
        return device;
    }

    @Override
    @Transactional(rollbackFor = {Exception.class})
    public ServerEntity deviceActive(DeviceApiController.DeviceActiveRequest deviceActiveRequest,RequestUrlPrefix urlPrefix) throws Exception {
        // 根据激活码查询，判断是否可激活
        Predicate predicate = QTenantActiveCode.tenantActiveCode.activeCode.eq(deviceActiveRequest.getActiveCode());
        TenantActiveCode activeCode = activeCodeRepository.findOne(predicate);
        if (null == activeCode) {
            log.info("设备激活码不正确");
            throw new CommonException(HttpStatus.BAD_REQUEST.value(), TerminalFailCode.ACTIVATION_CODE_INCORRECT.getMessage(), null, TerminalFailCode.ACTIVATION_CODE_INCORRECT.getValue());
        }
        Device findDevice = restoreFactorySettings(deviceActiveRequest.getSn(), "active");

        DeviceType deviceType;
        try {
            deviceType = DeviceType.indexOfVal(deviceActiveRequest.getDeviceType());
        } catch (Exception e) {
            throw new CommonException(HttpStatus.BAD_REQUEST.value(), TerminalFailCode.DEVICE_TYPE_INCORRECT.getMessage(), null, TerminalFailCode.DEVICE_TYPE_INCORRECT.getValue());
        }
        // 数据设置
        Device device = new Device();
        device.setSn(deviceActiveRequest.getSn());
        device.setType(deviceType);
        device.setVersion(deviceActiveRequest.getDeviceVersion());
        device.setStatus(DeviceStatus.DEVICE_OFF_LINE);
        device.setTenantId(activeCode.getTenantId());
        device.setCreateTime(new Date());
        device.setUpdateTime(new Date());

        try {
            // 数据入库
//            deviceRepository.insertDevice(device.getSn(),device.getType().value(), device.getVersion(),device.getStatus().value(),device.getTenantId());
            deviceRepository.save(device);

        } catch (DuplicateKeyException e) {
            log.error("------设备激活数据重复异常:DuplicateKeyException：{}", e.getMessage());
            throw new CommonException(HttpStatus.BAD_REQUEST.value(), CommonFailedStatus.DATABASE_INSERT_DUPLICATE_EXCEPTION.getMessage(), null, CommonFailedStatus.DATABASE_INSERT_DUPLICATE_EXCEPTION.getValue());
        } catch (DataIntegrityViolationException e) {
            log.error("------设备激活唯一索引异常:DataIntegrityViolationException:{}", e.getMessage());
            throw new CommonException(HttpStatus.BAD_REQUEST.value(), CommonFailedStatus.DATABASE_UNIQUE_EXCEPTION.getMessage(), null, CommonFailedStatus.DATABASE_UNIQUE_EXCEPTION.getValue());
        } catch (LockAcquisitionException e) {
            log.error("------设备激活数据锁异常:LockAcquisitionException: {}", e.getMessage());
            throw new CommonException(HttpStatus.BAD_REQUEST.value(), CommonFailedStatus.DATABASE_LOCK_EXCEPTION.getMessage(), null, CommonFailedStatus.DATABASE_LOCK_EXCEPTION.getValue());
        } catch (Exception e) {
            log.error("------设备激活数据处理异常: {}", e.getMessage());
            throw new CommonException(HttpStatus.INTERNAL_SERVER_ERROR.value(), CommonFailedStatus.DATABASE_EXCEPTION.getMessage(), null, CommonFailedStatus.DATABASE_EXCEPTION.getValue());
        }
        try {
            pushDeviceInfo(deviceActiveRequest, Event.EventType.DEVICE_REGISTRY, activeCode.getTenantId());
        } catch (Exception e) {
            log.error("pushServer服务异常",e);
        }
        log.info("--------激活设备，数据入库完成，待下发指令");
        // 获取激活返回entity
        ServerEntity entity = getEntity(deviceActiveRequest.getSn(), true,urlPrefix);
        // 下发终端上传配置指令
        String terminalGatewayHost = "";
        String strUrl = String.format("%s%s/api/devapi/callback/config/{workflowId}/{commandId}/{requestId}",
                terminalGatewayHost, serverPath);
        MessageContext context = SimpleMessageTemplate
                .operator(String.valueOf(activeCode.getTenantId()), Constant.TERMINAL_DEFAULT_ADMIN)
                .scope(Sets.newHashSet(deviceActiveRequest.getSn())).postConfig(strUrl);
        // 设置命令类型，阻塞
        Feature feature = new Feature();
        feature.setType(CommandType.BLOCK_COMMAND);
        context.setFeature(feature);
        oMessageFeign.send(context);
        log.info("--------激活设备完成，指令已下发");
        return entity;
    }


    /**
     * 终端分页获取人员列表
     *
     * @param pageable
     * @param operationType
     * @param syncVersion
     * @return
     */
    @Override
    public PersonResp getPerson(Pageable pageable, OperationType operationType, Long syncVersion, String workflowId, String commandId, String requestId,RequestUrlPrefix urlPrefix) throws Exception {
        //personResp nextPage为回调地址-http://xxxx/api/o-service/{}/{}?page=0
        OserviceDevApiOperator oserviceDevApiOperator = OperatorContext.getApiOperator();
        long tenantId = oserviceDevApiOperator.getTenantId();
        Predicate predicate = QPersonSync.personSync.tenantId.eq(tenantId);
        predicate = ((BooleanExpression) predicate).and(QPersonSync.personSync.syncVersion.eq(syncVersion));
        Page<Person> page = new PageImpl(new ArrayList<>());
        // 数据转换 String转URL
        List<PersonInfo> personInfoList = new ArrayList<>();
        // 删除人员
        if (OperationType.DELETE.equals(operationType)) {
            predicate = ((BooleanExpression) predicate).and(QPersonSync.personSync.operationType.eq(operationType));
            Page<PersonSync> pageSync = complicateQueryDao.find(jpaQueryFactory.select(QPersonSync.personSync, QPersonSync.personSync.personId)
                    .from(QPersonSync.personSync)
                    .where(predicate), pageable, PersonSync.class);
            List<PersonSync> personSyncList = pageSync.getContent();
            PersonInfo personInfo;
            for (PersonSync personSync : personSyncList) {
                personInfo = new PersonInfo();
                personInfo.setId(personSync.getPersonId());
                personInfo.setNo(personSync.getNo());
                personInfoList.add(personInfo);
            }
        } else {
            List<OperationType> list = Lists.newArrayList(OperationType.INSERT, OperationType.UPDATE);
            predicate = ((BooleanExpression) predicate).and(QPersonSync.personSync.operationType.in(list));
            predicate = ((BooleanExpression) predicate).and(QPerson.person.id.isNotNull());
            page = complicateQueryDao.find(jpaQueryFactory.select(QPerson.person, QPerson.person.id)
                    .from(QPerson.person)
                    .rightJoin(QPersonSync.personSync)
                    .on(QPersonSync.personSync.personId.eq(QPerson.person.id))
                    .where(predicate), pageable, Person.class);
            List<Person> personList = page.getContent();
            for (Person person : personList) {
                Map<ResourceType, List<String>> map = FileUrlPathHandle.getShowAvatarsMap(person.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()));
                person.setAvatars(map);
                personInfoList.add(person.toPersonInfo());
            }
        }
        PersonResp resp = new PersonResp();
        String terminalGatewayHost = GlobleConfig.ServerUrl.getTerminalGatewayHost(urlPrefix.getScheme());
        String errorCallback = String.format("%s%s/api/devapi/callback/%s/%s/%s/%s",
                terminalGatewayHost, serverPath,
                workflowId, commandId, requestId, BusinessType.PERSON);
        resp.setErrorCallback(CallBackBuilder.ready().url(errorCallback).method(Command.Method.POST).build());
        resp.setPersonInfoList(personInfoList);
        if (!OperationType.DELETE.equals(operationType)) {
            // 获取字段描述
            I18n<String, List<KeyNameDescriptor>> configI18n = getPersonConfigDesc(tenantId);
            resp.setDescriptor(configI18n);
        }
        boolean pageLast = page.isLast();
        // 是否为最后一页
        if (pageLast) {
            // 获取数据回调地址
            resp.setNextPage(null);
        } else {
            String relativeUrl = "%s%s/api/devapi/callback/person/{workflowId}/{commandId}/{requestId}?page=%s&operationType=%s&syncVersion=%s";
            Integer currPage = pageable.getPageNumber() + 1;
            String strUrl = String.format(relativeUrl, terminalGatewayHost, serverPath, currPage, operationType, syncVersion);
            resp.setNextPage(strUrl);
        }
        log.info("终端获取人员信息时间：{}，是否为最后一页：{}", System.currentTimeMillis(), page.isLast());
        log.debug("获取人员信息personInfoList： {}", resp.getPersonInfoList());
        if (pageable.getPageNumber() == 0) {
            //业务处理Callback数据的同时，需要调用消息中心的rest接口，来告诉消息中心此消息已回调成功
            oMessageFeign.callback(workflowId, commandId, requestId);
        }
        return resp;
    }

    /**
     * 根据id获取人员信息
     *
     * @param ids
     * @param oserviceDevApiOperator
     * @return
     * @throws Exception
     */
    @Override
    public List<PersonInfo> getPersonList(String ids, String nos, OserviceDevApiOperator oserviceDevApiOperator,RequestUrlPrefix urlPrefix) throws Exception {
        QPerson qPerson = QPerson.person;
        Predicate predicate = qPerson.tenantId.eq(oserviceDevApiOperator.getTenantId());
        if (StringUtils.isNoneBlank(ids)) {
            String[] idsArr = ids.split(",");
            if (idsArr.length > 20) {
                throw new CommonException("personId.count.limit");
            }
            predicate = ((BooleanExpression) predicate).and(qPerson.id.in(idsArr));

        } else if (StringUtils.isNoneBlank(nos)) {
            String[] nosArr = nos.split(",");
            if (nosArr.length > 20) {
                throw new CommonException("personNo.count.limit");
            }
            predicate = ((BooleanExpression) predicate).and(qPerson.no.in(nosArr));
        } else {
            throw new CommonException("string.notEmpty");
        }
        List<Person> personList = jpaQueryFactory.select(qPerson).from(qPerson)
                .where(predicate).fetch();
        List<PersonInfo> personInfoList = new ArrayList<>();
        if (Objects.nonNull(personList)) {
            for (Person person : personList) {
                Map<ResourceType, List<String>> map = FileUrlPathHandle.getShowAvatarsMap(person.getAvatars(), GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()));
                person.setAvatars(map);
                personInfoList.add(person.toPersonInfo());
            }
            log.info("终端根据id或no获取人员信息完成");
        }
        return personInfoList;
    }

    /**
     * 终端分页获取管理员列表
     *
     * @param pageable
     * @param command
     * @return
     * @throws Exception
     */
    @Override
    public AdminResp getAdmin(Pageable pageable, OserviceDevApiOperator oserviceDevApiOperator, Command command,RequestUrlPrefix urlPrefix) throws Exception {
        Predicate predicate = QDeviceAdmin.deviceAdmin.tenantId.eq(oserviceDevApiOperator.getTenantId());
        predicate = ((BooleanExpression) predicate).and(QDevice.device.sn.eq(oserviceDevApiOperator.getSn()));

        List<DeviceAdmin> deviceAdminList = jpaQueryFactory.selectFrom(QDeviceAdmin.deviceAdmin)
                .leftJoin(QDeviceAdminRel.deviceAdminRel)
                .on(QDeviceAdmin.deviceAdmin.id.eq(QDeviceAdminRel.deviceAdminRel.deviceAdminId))
                .leftJoin(QDevice.device)
                .on(QDeviceAdminRel.deviceAdminRel.deviceId.eq(QDevice.device.id))
                .where(predicate).fetch();
        List<TerminalAdmin> adminList = new ArrayList<>();
        TerminalAdmin terminalAdmin;
        // 管理员列表转换
        if (!CollectionUtils.isEmpty(deviceAdminList)) {
            for (DeviceAdmin deviceAdmin : deviceAdminList) {
                if (Objects.nonNull(deviceAdmin)) {
                    deviceAdminShowPath(deviceAdmin.getAvatars(),urlPrefix);
                    terminalAdmin = new TerminalAdmin();
                    BeanUtils.copyProperties(deviceAdmin, terminalAdmin);
                    // 终端密码加密
                    terminalAdmin.setPassword(MD5Utils.encrypt(terminalAdmin.getPassword()));
                    adminList.add(terminalAdmin);
                }
            }
        }
        AdminResp adminResp = new AdminResp();
        adminResp.setAdminList(adminList);
        String terminalGatewayHost = GlobleConfig.ServerUrl.getTerminalGatewayHost(urlPrefix.getScheme());
        String errorCallback = String.format("%s%s/api/devapi/callback/%s/%s/%s/%s",
                terminalGatewayHost, serverPath,
                command.getWorkflowId(), command.getCommandId(), command.getRequestId(), BusinessType.ADMIN);
        adminResp.setErrorCallback(CallBackBuilder.ready().url(errorCallback).method(Command.Method.POST).build());
        if (pageable.getPageNumber() == 0) {
            //业务处理Callback数据的同时，需要调用消息中心的rest接口，来告诉消息中心此消息已回调成功
            oMessageFeign.callback(command.getWorkflowId(), command.getCommandId(), command.getRequestId());
        }
        return adminResp;
    }

    public List<String> deviceAdminShowPath(List<String> avatars, RequestUrlPrefix urlPrefix) {
        if (!CollectionUtils.isEmpty(avatars)) {
            avatars.replaceAll(urlPath -> {
                Optional<String> optional = UrlUtil.getShowPath(GlobleConfig.ServerUrl.getFastdfsGatewayHost(urlPrefix.getScheme()), urlPath);
                if (optional.isPresent()) {
                    urlPath = optional.get();
                }
                return urlPath;
            });
        }
        return avatars;
    }

    /**
     * 获取设备总条数
     *
     * @param sn
     * @return
     */
    @Override
    public long getCountBySn(String sn) throws Exception {
        Predicate predicate = QDevice.device.sn.eq(sn);
        return deviceRepository.count(predicate);
    }

    /**
     * 推送设备信息
     *
     * @param obj       信息
     * @param eventType 事件类型
     */
    @Override
    public void pushDeviceInfo(Object obj, Event.EventType eventType,Long tenantId) throws Exception {
        //消息推送
        Event event = EventBuilder.newBuilder()
                .entity(JsonConvertor.beanToJson(obj))
                .timestamp(System.currentTimeMillis())
                .tenantId(String.valueOf(tenantId))
                .type(eventType).build();
        pushClient.send(event);
    }

    /**
     * 获取人员配置字段描述
     *
     * @param tenantId
     * @return
     * @throws Exception
     */
    public I18n getPersonConfigDesc(long tenantId) throws Exception {
        I18n<String, List<KeyNameDescriptor>> configI18n = new I18n<>();
        List<String> langList = serverMessages.getLanguage();
        List<PersonConfigVo> personConfigs;
        List<KeyNameDescriptor> keyNameDescriptors;
        for (String lang : langList) {
            keyNameDescriptors = new ArrayList<>();
            // 设置语言
            Locale locale;
            String[] pairs = lang.split("_");
            if (pairs.length > 1) {
                locale = new Locale(pairs[0], pairs[1]);
            } else {
                locale = new Locale(pairs[0]);
            }
            Messages.setLocale(locale);
            personConfigs = personConfigService.personConfigList(tenantId);
            KeyNameDescriptor keyNameDescriptor;
            // 数据转换
            for (PersonConfigVo personConfig : personConfigs) {
                keyNameDescriptor = new KeyNameDescriptor();
                keyNameDescriptor.setKeyName(personConfig.getPropertyName());
                keyNameDescriptor.setExplain(personConfig.getPropertyTitle());
                keyNameDescriptors.add(keyNameDescriptor);
            }
            configI18n.set(lang, keyNameDescriptors);
        }
        return configI18n;
    }

    /**
     * 获取服务api返回体
     *
     * @param sn
     * @param activeFlag 是否激活标志，true激活，反之false
     * @return
     * @throws Exception
     */
    public ServerEntity getEntity(String sn, boolean activeFlag,RequestUrlPrefix urlPrefix) throws Exception {
        ServerEntity entity = new ServerEntity();
        // 获取服务端的服务地址和API列表，设置Server
        entity.setServer(getServerConfig(urlPrefix));

        entity.setVersion(GlobleConfig.ServerConfig.version);
        try {
            if (GlobleConfig.ServerConfig.publicPlatform) {
                // 获取license
                CommonResponse<License> commonResponse = storeApiFeign.getLicense(sn);
                if (0 == commonResponse.getCode() && Objects.nonNull(commonResponse.getEntity())) {
                    License license = commonResponse.getEntity();
                    entity.setLicenseFile(license.getUrlPath());
                } else {
                    log.error("获取licenseFile异常");
                    entity.setLicenseFile("");
                }
            } else {
                log.info("私网环境licenseFile为空字符串");
                entity.setLicenseFile("");
            }
        } catch (Exception e) {
            entity.setLicenseFile("");
            log.error("storeApi-licenseFile异常", e);
        }
        if (activeFlag) {
            // 获取秘钥
            CommonResponse response = doorKeeperFeign.getSecureKey(sn);
            if (0 == response.getCode() && Objects.nonNull(response.getEntity())) {
                Map<String, String> map = (Map<String, String>) response.getEntity();
                String secureKey = map.get(sn);
                entity.setSecureKey(secureKey);
            } else {
                log.error("获取秘钥异常");
                throw new CommonException("config.getSecureKey.exception");
            }
        }

        return entity;
    }

    /**
     * 获取服务端的服务地址和API列表
     *
     * @return
     * @throws Exception
     */
    public ServerUri getServerConfig(RequestUrlPrefix urlPrefix) throws Exception {
        List<ServerHost> hostList = terminalServer.getHosts();
        if (CollectionUtils.isEmpty(hostList)) {
            log.info("host配置信息为空");
            throw new CommonException("config.isEmpty");
        }
        List<ServerHost> serverHostList = Lists.newArrayList(hostList);
        CommonResponse<ServerHost> nettyResponse = oStreamFeign.getNettyHost();
        if (Objects.nonNull(nettyResponse)) {
            ServerHost nettyHost = nettyResponse.getEntity();
            nettyHost.setName(Constant.NETTY_HOST_NAME);
            serverHostList.add(nettyHost);
        } else {
            log.info("获取netty地址失败");
            throw new CommonException("config.getNetty.exception");
        }

        // 获取服务api
        List<ServerApi> apiList = (List<ServerApi>) apiRepository.findAll();
        List<ServerApi> apiListClone = new ArrayList<>();
        if (null == apiList || apiList.size() == 0) {
            log.info("api配置信息为空");
            throw new CommonException("config.isEmpty");
        } else {
            for (ServerApi api : apiList) {
                ServerApi apiClone = (ServerApi) api.clone();
                // 处理请求地址
                String terminalGatewayHost = GlobleConfig.ServerUrl.getTerminalGatewayHost(urlPrefix.getScheme());
                if ("UPLOAD_IMAGE".equals(apiClone.getName())) {
                    apiClone.setUri(terminalGatewayHost + api.getUri());
                } else {
                    apiClone.setUri(terminalGatewayHost + serverPath + api.getUri());
                }
                apiListClone.add(apiClone);
            }
        }
        ServerUri serverURI = new ServerUri();
        serverURI.setApis(apiListClone);
        serverURI.setHosts(serverHostList);
        serverURI.setIsSecurity(GlobleConfig.ServerConfig.isSecurity);
        return serverURI;
    }
}
