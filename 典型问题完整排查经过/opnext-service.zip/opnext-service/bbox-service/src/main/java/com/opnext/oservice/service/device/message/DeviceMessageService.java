package com.opnext.oservice.service.device.message;

import com.opnext.domain.message.Report;

import java.util.Set;

/**
 * @author wanglu
 */
public interface DeviceMessageService {
    /**
     * 上传终端日志
     * @param report
     * @throws Exception
     */
    public void uploadAlarm(Report report) throws Exception;

    /**
     * 修改设备状态
     * @param report
     * @throws Exception
     */
    void updateStaus(Report report) throws Exception;

    /**
     * 补偿处理，更新断网设备
     * @param onlineSet
     * @throws Exception
     */
    void updateOnlineStatus(Set<String> onlineSet) throws Exception;
}
