package com.opnext.oservice.service.authority.impl;

import com.opnext.oservice.domain.authority.role.Module;
import com.opnext.oservice.domain.authority.role.RoleModule;
import com.opnext.oservice.dto.authority.role.ModuleDTO;
import com.opnext.oservice.repository.authority.ModuleRepository;
import com.opnext.oservice.repository.authority.RoleModuleRepository;
import com.opnext.oservice.service.authority.ModuleService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author wanglu
 */
@Service
public class ModuleServiceImpl implements ModuleService {
    @Autowired
    private ModuleRepository moduleRepository;
    @Autowired
    private RoleModuleRepository roleModuleRepository;

    @Override
    public List<ModuleDTO> getAllModule(){
        List<Module> pModules = moduleRepository.findAllByPidNull();
        List<Module> sModules = moduleRepository.findAllByPidNotNull();
        return getModuleList(pModules,sModules);
    }

    @Override
    public List<Module> getMainFunction() throws Exception {
        List<Module> modules = moduleRepository.findAllByIsMainFunction(Module.IsMainFunction.TRUE);
        return modules;
    }

    public List<ModuleDTO> getModuleList(List<Module> parentModules,List<Module> subModules){
        int pSize = parentModules.size();
        int cSize = subModules.size();
        //初始化返回的list，设置容量为上述好两个查询结果之和
        List<ModuleDTO> moduleList = new ArrayList<>(pSize+cSize);
        Map<Integer,ModuleDTO> moduleMap = new HashMap<>(pSize);

        for (int i=0; i<pSize; i++) {
            Module tempModule = parentModules.get(i);

            ModuleDTO pModule = new ModuleDTO();
            BeanUtils.copyProperties(tempModule,pModule,"pid");

            moduleMap.put(tempModule.getId(),pModule);
            moduleList.add(pModule);
        }

        for (int j=0; j<cSize; j++){
            Module tempModule = subModules.get(j);
            int pid = tempModule.getPid();

            ModuleDTO sModule = new ModuleDTO();
            BeanUtils.copyProperties(tempModule,sModule,"pid");

            sModule.setPid(moduleMap.get(pid));
            moduleList.add(sModule);
        }

        return moduleList;
    }

    @Override
    public List<ModuleDTO> findModuleListByRoleId(long roleId){
        //通过角色返回能够访问的model列表
        List<RoleModule> roleModules = roleModuleRepository.findAllByRoleId(roleId);
        List<Integer> moduleIds = roleModules.stream().map(roleModule -> {
            return roleModule.getModuleId();
        }).collect(Collectors.toList());

        List<Module> pModules = moduleRepository.findAllByIdInAndPidNull(moduleIds);
        List<Module> sModules = moduleRepository.findAllByIdInAndPidNotNull(moduleIds);
        return getModuleList(pModules,sModules);
    }
}
