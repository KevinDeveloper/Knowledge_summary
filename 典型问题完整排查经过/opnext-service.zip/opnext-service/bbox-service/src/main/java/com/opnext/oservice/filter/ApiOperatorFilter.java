package com.opnext.oservice.filter;

import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.oservice.conf.OperatorContext;
import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.service.device.DeviceService;
import com.opnext.oservice.util.AntPathRequestMatcher;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/**
 * @author tianzc
 */
@Slf4j
public class ApiOperatorFilter implements Filter{

    private DeviceService deviceService;
    private List<AntPathRequestMatcher> matchers = new ArrayList<>();

    /**
     * Called by the web container to indicate to a filter that it is being
     * placed into service. The servlet container calls the init method exactly
     * once after instantiating the filter. The init method must complete
     * successfully before the filter is asked to do any filtering work.
     * <p>
     * The web container cannot place the filter into service if the init method
     * either:
     * <ul>
     * <li>Throws a ServletException</li>
     * <li>Does not return within a time period defined by the web
     * container</li>
     * </ul>
     *
     * @param filterConfig The configuration information associated with the
     *                     filter instance being initialised
     * @throws ServletException if the initialisation fails
     */
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        String excludePath = this.getParameter(filterConfig, "excludes");
        if (StringUtils.isNotBlank(excludePath)) {
            String[] paths = excludePath.split(",");
            String[] var4 = paths;
            int var5 = paths.length;

            for(int i = 0; i < var5; ++i) {
                String path = var4[i];
                this.matchers.add(new AntPathRequestMatcher(path));
            }
        }
    }

    /**
     * The <code>doFilter</code> method of the Filter is called by the container
     * each time a request/response pair is passed through the chain due to a
     * client request for a resource at the end of the chain. The FilterChain
     * passed in to this method allows the Filter to pass on the request and
     * response to the next entity in the chain.
     * <p>
     * A typical implementation of this method would follow the following
     * pattern:- <br>
     * 1. Examine the request<br>
     * 2. Optionally wrap the request object with a custom implementation to
     * filter content or headers for input filtering <br>
     * 3. Optionally wrap the response object with a custom implementation to
     * filter content or headers for output filtering <br>
     * 4. a) <strong>Either</strong> invoke the next entity in the chain using
     * the FilterChain object (<code>chain.doFilter()</code>), <br>
     * 4. b) <strong>or</strong> not pass on the request/response pair to the
     * next entity in the filter chain to block the request processing<br>
     * 5. Directly set headers on the response after invocation of the next
     * entity in the filter chain.
     *
     * @param request  The request to process
     * @param response The response associated with the request
     * @param chain    Provides access to the next filter in the chain for this
     *                 filter to pass the request and response to for further
     *                 processing
     * @throws IOException      if an I/O error occurs during this filter's
     *                          processing of the request
     * @throws ServletException if the processing fails for any other reason
     */
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest servletRequest = (HttpServletRequest) request;
        log.info("apiFilter------>>{}，调用开始", servletRequest.getServletPath());
        this.doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
        OperatorContext.remove();
        log.info("apiFilter------>>{}，调用结束", servletRequest.getServletPath());
    }

    public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {

        boolean ignore = this.isExcludePath(request);
        if (ignore){
            chain.doFilter(request, response);
        }else {
            boolean flag;
            try {
                flag = this.checkHeader(request);
            } catch (Exception e) {
                log.error("权限校验失败：{}", e);
                response.sendError(HttpStatus.INTERNAL_SERVER_ERROR.value());
                OperatorContext.remove();
                return;
            }
            if (flag) {
                try {
                    chain.doFilter(request, response);
                } catch (Exception var10) {
                    response.sendError(HttpStatus.FORBIDDEN.value());
                    OperatorContext.remove();
                    log.error("权限校验失败：{}", var10);
                }
            } else {
                response.sendError(HttpStatus.FORBIDDEN.value());
                OperatorContext.remove();
                log.error("权限校验失败：{}", "没有找到终端所属关系");
            }
        }
    }

    private boolean checkHeader(HttpServletRequest request) throws Exception{
        String jsonStr = request.getHeader("sn");
        OserviceDevApiOperator oserviceDevApiOperator = new OserviceDevApiOperator();
        oserviceDevApiOperator.setSn(jsonStr);
        log.info("api请求从header中取出参数 sn：{}",jsonStr);
        if (Objects.isNull(deviceService)) {
            BeanFactory factory = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getServletContext());
            deviceService = (DeviceService) factory.getBean(DeviceService.class);
        }
        if (StringUtils.isNoneBlank(oserviceDevApiOperator.getSn())) {
            Device device = deviceService.getDevice(oserviceDevApiOperator.getSn());
            if (Objects.isNull(device)) {
                log.error("通过sn没有查询到设备所属租户");
                return false;
            }
            oserviceDevApiOperator.setTenantId(device.getTenantId());
            oserviceDevApiOperator.setName(device.getName());
            oserviceDevApiOperator.setGroupId(device.getGroupId());
        } else {
            log.error("该终端请求缺少sn");
            return false;
        }
        OperatorContext.setApiOperator(oserviceDevApiOperator);
        return true;
    }

    /**
     * Called by the web container to indicate to a filter that it is being
     * taken out of service. This method is only called once all threads within
     * the filter's doFilter method have exited or after a timeout period has
     * passed. After the web container calls this method, it will not call the
     * doFilter method again on this instance of the filter. <br>
     * <br>
     * <p>
     * This method gives the filter an opportunity to clean up any resources
     * that are being held (for example, memory, file handles, threads) and make
     * sure that any persistent state is synchronized with the filter's current
     * state in memory.
     */
    @Override
    public void destroy() {

    }

    private boolean isExcludePath(HttpServletRequest request) {
        Iterator var2 = this.matchers.iterator();

        AntPathRequestMatcher matcher;
        do {
            if (!var2.hasNext()) {
                return false;
            }

            matcher = (AntPathRequestMatcher)var2.next();
        } while(!matcher.matches(request));

        return true;
    }

    private String getParameter(FilterConfig config, String param) {
        String value = config.getInitParameter(param);
        return value;
    }
}
