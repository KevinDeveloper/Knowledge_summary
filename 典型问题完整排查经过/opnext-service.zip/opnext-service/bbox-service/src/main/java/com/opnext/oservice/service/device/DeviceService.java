package com.opnext.oservice.service.device;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.domain.config.OConfigGroup;
import com.opnext.oservice.domain.device.Device;
import com.opnext.oservice.domain.device.DeviceSync;
import com.opnext.oservice.domain.device.SearchDevice;
import com.opnext.oservice.domain.device.TenantActiveCode;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Set;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:04 18/5/7
 */
public interface DeviceService {

    /**
     * 根据sn获取设备所属租户
     * @param sn
     * @return
     */
    Device getDevice(String sn);

    /**
     * 根据sn获取设备所属租户
     * @param sn
     * @return
     */
    Long getTenantId(String sn);

    /**
     * 获取设备列表
     * @param pageable
     * @param sDevice
     * @return
     * @throws Exception
     */
    Page getDevicePage(Pageable pageable, SearchDevice sDevice) throws Exception;

    /**
     * 根据是否有设备组获取设备列表
     * @param groupId
     * @return
     * @throws Exception
     */
    List listByGroupFlag(Integer groupId) throws Exception;

    /**
     * 根据租户获取设备激活码
     * @return
     * @throws Exception
     */
    TenantActiveCode getActiveCode() throws Exception;

    /**
     * 设备单次开门
     * @param sn
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    CommonResponse doorSingleOpen(String sn, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 重启设备
     * @param snSet
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    CommonResponse rebootDevice(Set<String> snSet, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 设备常开
     * @param snSet
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    CommonResponse doorOpenAlways(Set<String> snSet, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 设备取消常开
     * @param snSet
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    CommonResponse doorOpenCancel(Set<String> snSet, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 根据租户刷新设备激活码
     * @return
     * @throws Exception
     */
    TenantActiveCode refreshActiveCode(Integer id) throws Exception;


    /**
     * 关联设备管理员
     * @param deviceIds
     * @throws Exception
     */
    void bindDeviceAdmin(Integer[] deviceIds, Integer[] adminIds) throws Exception;


    /**
     * 移除设备组
     * @throws Exception
     */
    void deleteDeviceGroup(Integer[] deviceIds) throws Exception;

    /**
     * 获取设备设置
     * @param sn
     * @throws Exception
     */
    OConfigGroup getDeviceConfig(String sn) throws Exception;

    /**
     * 更新设备
     * @param sn
     * @throws Exception
     */
    void updateDeviceConfig(String sn, DeviceSync deviceSync) throws Exception;
}
