package com.opnext.oservice.domain.person;

import lombok.AllArgsConstructor;

/**
 * @ClassName: PropertyRequire
 * @Description: 是否必填：0不必填，1必填
 * @Author: Kevin
 * @Date: 2018/5/18 19:11
 */
@AllArgsConstructor
public enum PropertyRequire {
    /**
     * 不必填
     */
    unRequire(false),
    /**
     * 必填
     */
    require(true);
    private boolean value;

    public boolean value() {
        return this.value;
    }

    /**
     * 通过 val 值索引 PropertyType
     * @param val val
     * @return PropertyType
     */
    public static PropertyRequire indexOfVal(boolean  val) {
        for (PropertyRequire propertyRequire : values()) {
            if (propertyRequire.value == val) {
                return propertyRequire;
            }
        }

        throw new IllegalArgumentException("param value " + val);
    }
}
