package com.opnext.oservice.repository.device.alarm;

import com.opnext.oservice.domain.device.alarm.DeviceAlarmPriority;
import com.opnext.oservice.domain.device.alarm.DeviceAlarmType;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

import java.util.List;

/**
 * @author wanglu
 */
public interface DeviceAlarmTypeRepository extends PagingAndSortingRepository<DeviceAlarmType, Integer>,
        QueryDslPredicateExecutor<DeviceAlarmType> {
    /**
     * 通过告警类型名称获取告警类型对象
     * @param name
     * @return
     */
    DeviceAlarmType findDeviceAlarmTypeByName(String name);

    /**
     * 通过告警级别获取告警类型对象
     * @param priority
     * @return
     */
    List<DeviceAlarmType> findByPriority(DeviceAlarmPriority priority);

}
