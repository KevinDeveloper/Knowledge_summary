package com.opnext.oservice.domain.command;

import com.opnext.domain.SerializableMap;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.BeanUtils;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import javax.persistence.Entity;
import javax.persistence.Id;
import java.io.Serializable;

/**
 * @author tianzc
 */
@Slf4j
@Entity
@Data
@Document(collection = "commandErrorInfo")
@CompoundIndexes({
        @CompoundIndex(unique = true, dropDups = true, name = "unique_requestId_no_tenantId", def = "{'requestId': -1,'errorData.no': -1,'tenantId': -1}"),
        @CompoundIndex(name = "idx_tenantId_createTime_commandId_deviceSn", def = "{'tenantId': -1,'createTime': -1,'commandId': -1,'deviceSn': -1}"),
        @CompoundIndex(name = "idx_tenantId_requestId", def = "{'tenantId': -1,'requestId': -1}"),
        @CompoundIndex(name = "idx_deviceSn", def = "{'deviceSn': -1}"),
        @CompoundIndex(name = "idx_requestId", def = "{'requestId': -1}"),
        @CompoundIndex(name = "idx_commandId", def = "{'commandId': -1}")
})
public class CommandErrorInfo implements Serializable {
    @Id
    private String id;
    private String workflowId;
    private String commandId;
    private String requestId;
    private String deviceName;
    private String deviceSn;
    private BusinessType businessType;
    private SerializableMap errorData;
    private Long createTime;
    private Long tenantId;

    public <T> T mapToBean(Class<T> clazz) {
        T bean = null;
        try {
            bean =  clazz.newInstance();
            BeanUtils.populate(bean, errorData);
        } catch (Exception e) {
            log.error("map2Bean格式转化异常：{}", e);
        }
        return bean;
    }
}
