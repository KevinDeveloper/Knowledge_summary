package com.opnext.oservice.domain.device.alarm;

import lombok.Data;
import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.annotation.CreatedDate;

import javax.persistence.*;
import java.util.Date;

/**
 * @author wanglu
 */
@Entity
@Table(name = "device_alarm")
@Data
public class DeviceAlarm {
    @Id
    @GenericGenerator(name="systemUUID",strategy="uuid")
    @GeneratedValue(generator="systemUUID")
    private String id;
    private String description;

    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    @Column(name="occur_time")
    private Date occurTime;

    @Temporal(TemporalType.TIMESTAMP)
    @CreatedDate
    @Column(name="create_time")
    private Date createTime;

    @Column(name="device_sn")
    private String deviceSn;

    @Column(name="alarm_type")
    private int deviceAlarmType;

    /**
     * 数据库忽略字段alarmType
     */
    @Transient
    private DeviceAlarmType alarmType;

    @Column(name="tenant_id")
    private Long tenantId;

    /**
     * 是否已读，true1已读 false0未读
     */
    @Column(name="read_status")
    private Boolean readStatus;
}
