package com.opnext.oservice.dto;

import lombok.Data;

/**
 * @author wanglu
 */
@Data
public class PageParam {
    int page;
    int size;
    String sort;
}
