package com.opnext.oservice.conf;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午6:38 18/5/10
 */
@Configuration
public class RestConfig {
    @Bean
    @ConfigurationProperties(prefix = "remote-rest.config")
    public HttpComponentsClientHttpRequestFactory httpRequestFactory() {
        return new HttpComponentsClientHttpRequestFactory();
    }

    @Bean
    public RestTemplate restTemplate(){

        RestTemplate restTemplate = new RestTemplate(httpRequestFactory());
        return restTemplate;
    }
}
