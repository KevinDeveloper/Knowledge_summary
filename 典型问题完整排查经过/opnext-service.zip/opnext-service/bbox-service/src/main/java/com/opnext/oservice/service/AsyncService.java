package com.opnext.oservice.service;

import com.opnext.bboxdomain.OserviceDevApiOperator;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.context.RequestUrlPrefix;
import com.opnext.domain.message.Command;
import com.opnext.domain.request.FeedBackRequest;
import com.opnext.oservice.domain.command.BusinessType;
import com.opnext.oservice.domain.person.OperationType;
import com.opnext.oservice.domain.person.Person;

import java.util.List;

/**
 * @author tianzc
 */
public interface AsyncService {

    /**
     * 通过syncVersion 获取人员列表
     *
     * @param syncVersion
     * @param operationType
     */
    void syncPerson(long syncVersion, OperationType operationType);

    /**
     * @param person
     * @param operationType
     */
    void syncPerson(Person person, OperationType operationType, OserviceOperator oserviceOperator);

    /**
     * @param personList    人员列表
     * @param operationType
     */
    void syncPerson(List<Person> personList, OperationType operationType, OserviceOperator oserviceOperator);

    /**
     * 异步处理终端指令反馈
     *
     * @param command
     * @param businessType
     * @param feedBackRequest
     */
    void deviceFeedBack(Command command, OserviceDevApiOperator oserviceDevApiOperator, BusinessType businessType, FeedBackRequest feedBackRequest);

    /**
     * 删除指定文件，删除两天前文件夹
     *
     * @param imgFilePath
     */
    void clearImgEmptyFile(String imgFilePath);

    /**
     * 异步处理导出人员
     */
    void exportPerson(OserviceOperator oserviceOperator, String name, String no, Integer organizationId, String fileExcelPath, String avatarsDirPath, String allAvatarsZipPath, String exportDirPath, String allFilesZipPath, String allFilesZip, RequestUrlPrefix urlPrefix);

    /**
     * 异步处理人员入库
     */
    void insertBatchPersons(OserviceOperator oserviceOperator , RequestUrlPrefix urlPrefix);


}
