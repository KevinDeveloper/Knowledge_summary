package com.opnext.batch.feign;

import com.alibaba.fastjson.JSONObject;
import com.opnext.batch.domain.algorithm.FaceDetectionResp;
import com.opnext.batch.feign.impl.AlgorithmHystrixFallBackFactory;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author tianzc
 */
@FeignClient(value = "faceAlgorithm-server",
//        fallback = AlgorithmHystrixFallBack.class,
        fallbackFactory = AlgorithmHystrixFallBackFactory.class)
public interface AlgorithmFeign {
    /**
     * 图片比对检测图片，返回人脸坐标
     * @param object
     * @return
     */
    @RequestMapping(value = "/face/detect", method = RequestMethod.POST)
    FaceDetectionResp detect(JSONObject object);
}
