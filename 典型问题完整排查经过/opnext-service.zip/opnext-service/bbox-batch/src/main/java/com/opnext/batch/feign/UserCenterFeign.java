package com.opnext.batch.feign;

import com.opnext.batch.domain.account.Account;
import com.opnext.batch.dto.PageFeign;
import com.opnext.batch.feign.impl.UserCenterFailFactory;
import com.opnext.bboxsupport.advise.CommonResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author wanglu
 */
@FeignClient(value = "user-center", fallbackFactory = UserCenterFailFactory.class)
public interface UserCenterFeign {

    /**
     * 查询管理员列表（分页）
     *
     * @param urlVariables
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET, value = "/user-center/api/users")
    CommonResponse<PageFeign<Account>> getAccountPage(Object... urlVariables) throws Exception;
}

