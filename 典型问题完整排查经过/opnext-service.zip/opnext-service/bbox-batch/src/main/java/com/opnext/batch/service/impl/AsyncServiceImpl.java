package com.opnext.batch.service.impl;

import com.opnext.batch.service.AsyncService;
import com.opnext.batch.util.DateUtil;
import com.opnext.batch.util.FileUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.ApplicationHome;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.Date;

/**
 * @author tianzc
 */
@Slf4j
@Service
public class AsyncServiceImpl implements AsyncService {

    /**
     * 删除指定文件
     * 删除7天前文件夹
     *
     * @param imgFilePath
     */
    @Override
    @Async
    public void clearImgEmptyFile(String imgFilePath) {
        try {
            if (StringUtils.isNotBlank(imgFilePath)) {
                File file = new File(imgFilePath);
                file.delete();
            }
        } catch (Exception e) {
            log.error("--临时文件删除失败：", e);
        }
        try {
            // 删除两天前的文件夹以及文件
            ApplicationHome home = new ApplicationHome(getClass());
            String basePath = home.getDir().getAbsolutePath() + File.separator + "imgFiles";
            File baseFile = new File(basePath);
            if (baseFile.isDirectory()) {
                File[] tempList = baseFile.listFiles();
                if (null != tempList && tempList.length > 0) {
                    for (File tmpfile : tempList) {
                        if (tmpfile.isDirectory()) {
                            String tmpFileName = tmpfile.getName();
                            Date fileDate = null;
                            try {
                                fileDate = DateUtil.parseStrToDate(tmpFileName, "yyyy-MM-dd");
                            } catch (Exception e) {
                                log.error("上传文件夹下未知文件夹：" + tmpFileName);
                            }
                            if (fileDate != null) {
                                // 两个时间差
                                long m = DateUtil.getCurrDistanceDays(fileDate, DateUtil.getDayBeginTime(new Date()));
                                if (m > 7) {
                                    log.info("删除文件夹" + tmpfile.getPath());
                                    FileUtil.deleteDir(tmpfile);
                                }
                            }
                        }
                    }
                } else {
                    log.debug("上传路径下没有文件和文件夹");
                }
            } else {
                log.debug("上传路径不存在");
            }
        } catch (Exception e) {
            log.error("删除7天前的临时文件任务异常：{}", e);
        }
    }

}
