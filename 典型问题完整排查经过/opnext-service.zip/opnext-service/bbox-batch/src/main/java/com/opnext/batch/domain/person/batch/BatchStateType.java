package com.opnext.batch.domain.person.batch;

import lombok.AllArgsConstructor;

/**
 * @ClassName: BatchStateType
 * @Description: 上传状态
 * @Author: Kevin
 * @Date: 2018/7/4 14:19
 */
@AllArgsConstructor
public enum BatchStateType {
    /**
     * 无租户上传
     */
    STATE_EMPTY(-1),

    /**
     * 可上传
     */
    STATE_UPLOADABLE(0),
    /**
     * 解析中
     */
    STATE_PARSING(1),
    /**
     * 可预览
     */
    STATE_PREVIEWING(2),
    /**
     * 导入中
     */
    STATE_IMPORTING(3),
    /**
     * 已导入
     */
    STATE_IMPORTED(4),

    /**
     * 解析失败
     */
    STATE_PARSE_FAIL(5),

    /**
     * 导入失败
     */
    STATE_IMPORTE_FAIL(6);

    private int value;

    public int value() {
        return this.value;
    }

    /**
     * 通过 val 值索引 BatchStateType
     *
     * @param val val
     * @return BatchStateType
     */
    public static BatchStateType indexOfVal(int val) {
        for (BatchStateType batchStateType : values()) {
            if (batchStateType.value == val) {
                return batchStateType;
            }
        }
        throw new IllegalArgumentException("param value " + val);
    }
}
