package com.opnext.batch.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.opnext.batch.conf.Constant;
import com.opnext.batch.conf.GlobleConfig;
import com.opnext.batch.domain.person.batch.BatchStateType;
import com.opnext.batch.feign.BatchOperatorLogFeign;
import com.opnext.batch.service.AsyncTaskService;
import com.opnext.batch.service.person.BatchStateManageService;
import com.opnext.batch.service.person.PersonService;
import com.opnext.batch.task.ExcelXlsToPersonTask;
import com.opnext.batch.task.ExcelXlsxToPersonTask;
import com.opnext.batch.util.FileUtil;
import com.opnext.batch.util.excel.ExcelReadUtil;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.log.LogReq;
import com.opnext.bboxsupport.advise.CommonException;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * @ClassName: AsyncTaskServiceImpl
 * @Description:
 * @Author: Kevin
 * @Date: 2018/7/4 13:58
 */
@Slf4j
@Service
public class AsyncTaskServiceImpl implements AsyncTaskService {

    @Autowired
    private PersonService personService;

    @Autowired
    private BatchStateManageService batchStateManageService;

    @Autowired
    BatchOperatorLogFeign batchOperatorLogFeign;


    @Async
    @Override
    public void asyncUnZipAndParingBatchAddPersonForImageFile(OserviceOperator oserviceOperator, File excelFile, List<File> imgFiles, File imgFileZip, String uploadType, String userRootPath) {
        log.info("异步解析人员批量导入文件 - 开始");
        long startTime = System.currentTimeMillis();

        ScheduledExecutorService scheduledExecutor = new ScheduledThreadPoolExecutor(1);
        scheduledExecutor.scheduleAtFixedRate(() -> {
            try {
                //更新异步任务存活时间
                batchStateManageService.setUnderWay(oserviceOperator.getTenantId(), BatchStateManageService.BATCH_PERSON_KEY_UNDERWAY);
                log.info("更新异步任务存活时间,  异步解析人员");
            } catch (Exception e) {
                log.error("异步任务定时管理器异常，e={}", e);
            }
        }, 0, 1, TimeUnit.MINUTES);
        try {
            if (Constant.UPLOAD_TYPE_ZIP.equals(uploadType)) {
                imgFiles = getUnZipImages(oserviceOperator, imgFileZip, userRootPath);
            }
            //处理图片文件
            ConcurrentMap<String, File> avatarFileMap = new ConcurrentHashMap<>();
            if (!CollectionUtils.isEmpty(imgFiles)) {
                for (File file : imgFiles) {
                    avatarFileMap.put(file.getName(), file);
                }
            }
            //清空之间导入的文件
            personService.deleteBatchImportData(oserviceOperator);
            //获取文件的后缀
            String suffix = excelFile.getName().substring(excelFile.getName().lastIndexOf(".")).toLowerCase();
            if (ExcelReadUtil.EXCEL_SUFFIX_XLS.equals(suffix)) {
                readFromXlsForMapToPerson(oserviceOperator, excelFile, avatarFileMap);
            } else if (ExcelReadUtil.EXCEL_SUFFIX_XLSX.equals(suffix)) {
                readFromXlsxForMapToPerson(oserviceOperator, excelFile, avatarFileMap);
            }
            log.info("异步解析人员批量导入文件 - 耗时={} (ms)", (System.currentTimeMillis() - startTime));
            //设置状态可预览状态
            batchStateManageService.setBatchState(oserviceOperator.getTenantId(), BatchStateType.STATE_PREVIEWING);
        } catch (Exception e) {
            log.error("异步解析人员批量导入文件 - 异常，e={}", e);
            //设置状态 - 解析失败
            batchStateManageService.setBatchState(oserviceOperator.getTenantId(), BatchStateType.STATE_PARSE_FAIL);
            //清空当前租户内的批量导入临时数据
            try {
                personService.deleteBatchImportData(oserviceOperator);
            } catch (Exception e1) {
                log.error("解析失败, 清空临时数据, 异常e={}", e1);
            }
        } finally {
            //删除临时文件
            FileUtil.deleteTempZipFile(userRootPath, oserviceOperator);

            scheduledExecutor.shutdown();
        }
        log.info("异步解析人员批量导入文件 - 结束");
    }


    /**
     * 解压照片压缩包
     *
     * @param oserviceOperator
     * @param imgFileZip
     * @param userRootPath
     * @return
     * @throws Exception
     */
    private List<File> getUnZipImages(OserviceOperator oserviceOperator, File imgFileZip, String userRootPath) throws Exception {
        StopWatch stopWatch = new StopWatch("保存照片文件");
        List<File> imgFiles = new ArrayList<>();
        if (Objects.isNull(imgFileZip)) {
            log.info("照片文件获取为空， 不解压");
        } else {
            stopWatch.start("照片zip解压");
            imgFiles = FileUtil.getUnZipFiles(userRootPath, imgFileZip, oserviceOperator);
            stopWatch.stop();
            log.info("照片文件解压完成");
        }
        log.info("照片文件解压完成， 上传的图片文件数量为，imgSize={}, 耗时统计={}", imgFiles.size(), stopWatch.prettyPrint());
        return imgFiles;
    }

    /**
     * xlx 格式处理
     *
     * @param excelFile
     * @throws Exception
     */
    private void readFromXlsForMapToPerson(OserviceOperator oserviceOperator, File excelFile, ConcurrentMap<String, File> avatarFileMap) throws Exception {
        //int threadNum = GlobleConfig.ServiceBatch.threadNum;
        //int avableCount = Runtime.getRuntime().availableProcessors();
        //threadNum = threadNum > avableCount ? avableCount : threadNum;
        ForkJoinPool forkJoinPool = new ForkJoinPool(2);
        try (InputStream inputStream = new FileInputStream(excelFile)) {

            POIFSFileSystem fs = new POIFSFileSystem(inputStream);
            Workbook book = new HSSFWorkbook(fs);
            HSSFSheet sheet = (HSSFSheet) book.getSheetAt(0);
            // 遍历行获得每行信息
            Map<Integer, String> rowdatasMap = null;
            XSSFRow xSSFRow = null;
            int rowsSize = sheet.getLastRowNum();
            //第一行作为表头，不作数据处理
            if (rowsSize < 1) {
                return;
            }
            //更新解析导入文件的进度
            batchStateManageService.setBatchTotal(oserviceOperator.getTenantId(), rowsSize);
            ExcelXlsToPersonTask personTask = new ExcelXlsToPersonTask(oserviceOperator, personService, batchStateManageService, avatarFileMap, sheet, 1, rowsSize);
            Future<Integer> result = forkJoinPool.submit(personTask);
            Integer count = result.get();
            log.info("解析导入文件完成 ，文件数量rowsSize=={}, 解析数量count={}", rowsSize, count);
        } catch (Exception e) {
            log.error("异步解析人员批量导入文件 - 异常，e={}", e);
            throw new CommonException(e);
        } finally {
            // 关闭线程池
            forkJoinPool.shutdown();

        }

    }

    /**
     * xlx 格式处理
     *
     * @param excelFile
     * @throws Exception
     */
    private void readFromXlsxForMapToPerson(OserviceOperator oserviceOperator, File excelFile, ConcurrentMap<String, File> avatarFileMap) throws Exception {
       // int threadNum = GlobleConfig.ServiceBatch.threadNum;
       // int avableCount = Runtime.getRuntime().availableProcessors();
       // threadNum = threadNum > avableCount ? avableCount : threadNum;
        ForkJoinPool forkJoinPool = new ForkJoinPool(2);
        try (InputStream inputStream = new FileInputStream(excelFile)) {
            Workbook book = new XSSFWorkbook(inputStream);
            XSSFSheet sheet = (XSSFSheet) book.getSheetAt(0);
            int rowsSize = sheet.getLastRowNum();
            //第一行作为表头，不作数据处理
            if (rowsSize < 1) {
                return;
            }
            //更新解析导入文件的进度
            batchStateManageService.setBatchTotal(oserviceOperator.getTenantId(), rowsSize);
            ExcelXlsxToPersonTask personTask = new ExcelXlsxToPersonTask(oserviceOperator, personService, batchStateManageService, avatarFileMap, sheet, 1, rowsSize);
            Future<Integer> result = forkJoinPool.submit(personTask);
            Integer count = result.get();
            log.info("解析导入文件完成 ，文件数量rowsSize=={}, 解析数量count={}", rowsSize, count);
        } catch (Exception e) {
            log.error("异步解析人员批量导入文件 - 异常，e={}", e);
            throw new CommonException(e);
        } finally {
            // 关闭线程池
            forkJoinPool.shutdown();
        }
    }

    /**
     * 异步发送操作日志
     *
     * @param logReq
     * @throws Exception
     */
    @Async
    @Override
    public void asyncSendOperatorLog(LogReq logReq) {
        log.info("异步发送操作日志， logReq={}", JSONObject.toJSONString(logReq));
        try {
            batchOperatorLogFeign.sendOperatorLog(logReq);
        } catch (Exception e) {
            log.error("异步发送操作日志, 异步， e={}", e);
        }

    }
}
