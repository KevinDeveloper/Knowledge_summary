package com.opnext.batch.interceptor;

import com.alibaba.fastjson.JSONObject;
import com.opnext.batch.conf.OperatorContext;
import com.opnext.batch.feign.BatchAuthorityFeign;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.util.RequestAnalysisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.annotation.Order;
import org.springframework.util.StopWatch;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * @ClassName: OperatorInterceptor
 * @Description: 网关认证，权限验证
 * @Author: Kevin
 * @Date: 2018/8/21 16:01
 */
@Slf4j
@Order(2)
public class OperatorAuthInterceptor implements HandlerInterceptor {

    @Autowired
    private BatchAuthorityFeign batchAuthorityFeign;

    @Value("${remote-rest.authCenter.clientId}")
    private String appId;


    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        log.info("bbox-batch 进入OperatorInterceptor 拦截器");
        if (!HandlerMethod.class.equals(o.getClass())) {
            log.debug("请求的是静态资源，直接通过");
            return true;
        }
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        if (Objects.isNull(oserviceOperator)) {
            return true;
        }
        StopWatch stopWatch = new StopWatch();
        //权限验证接口
        stopWatch.start("权限验证");
        Map<String, Object> paramMap = new HashMap<>();
        paramMap.put("tenantId", oserviceOperator.getTenantId());
        paramMap.put("userId", oserviceOperator.getUserId());
        paramMap.put("appId", appId);
        String param = JSONObject.toJSONString(paramMap);
        log.info("param={}", param);
        String apiPath = RequestAnalysisUtil.methodUrlPatten((HandlerMethod) o);
        String method = httpServletRequest.getMethod();
        log.info("权限验请求参数， param={}， apiPath={}, method={}", param, apiPath, method);
        CommonResponse<OserviceOperator> response = batchAuthorityFeign.checkAuthority(param, apiPath, method);
        if (Objects.isNull(response)) {
            log.info("bbox-batch, 权限认证失败, null");
            throw new CommonException(403, "person.batchAdd.authority.error");
        } else if (response.getStatus() == 403) {
            log.info("bbox-batch, 权限认证失败");
            throw new CommonException(403, "person.batchAdd.authority.error");
        }
        stopWatch.stop();
        log.info("bbox-batch, 权限验证成功 , 耗时={}(ms)", stopWatch.getLastTaskTimeMillis());
        return printLogResult(true, apiPath, method, oserviceOperator);
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {
        log.info("{}方法调用结束", httpServletRequest.getServletPath());
//        String methodMappingStr = RequestAnalysisUtil.methodUrlPatten((HandlerMethod) o);
//        String methodName = httpServletRequest.getMethod().toUpperCase();
        // OserviceOperator oserviceOperator = OperatorContext.getOperator();
//        logAsyncTask.saveOperateLog(methodMappingStr,methodName,oserviceOperator.getUserId(),oserviceOperator.getLoginName(),oserviceOperator.getTenantId(),httpServletResponse,o,e);
        OperatorContext.remove();
    }


    public boolean printLogResult(boolean bool, String servletPath, String methodAnnotPath, OserviceOperator oserviceOperator) {
        log.info("拦截器预处理结束,{},{},{}", methodAnnotPath, servletPath, oserviceOperator);
        return bool;
    }

}
