package com.opnext.batch.repository;

import com.querydsl.core.Tuple;
import com.querydsl.core.types.EntityPath;
import com.querydsl.core.types.Order;
import com.querydsl.core.types.OrderSpecifier;
import com.querydsl.core.types.dsl.PathBuilder;
import com.querydsl.jpa.impl.JPAQuery;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author wanglu
 */
@NoRepositoryBean
public interface ComplicateQueryDao {
    Logger LOGGER = LoggerFactory.getLogger(ComplicateQueryDao.class);

    /**
     * 查询单条
     *
     * @param query
     * @param returnClass
     * @param <T>
     * @return
     */
    default <T> T findOne(JPAQuery<Tuple> query, Class<T> returnClass) {
        //noinspection unchecked
        return (T) findOne(query, new ClassExtractor<T>(returnClass));
    }

    /**
     * 查询单条
     *
     * @param query
     * @param extractor
     * @param <T>
     * @return
     */
    default <T> T findOne(JPAQuery<Tuple> query, Extractor<T> extractor) {
        return extractor.extract(query.fetchOne());
    }

    /**
     * 查询
     *
     * @param query
     * @param pageable
     * @param returnClass
     * @param <T>
     * @return
     */
    default <T> Page<T> find(JPAQuery<Tuple> query, Pageable pageable, Class<T> returnClass) {
        //noinspection unchecked
        return find(query, pageable, new ClassExtractor<T>(returnClass));
    }

    /**
     * 查询
     *
     * @param query
     * @param pageable
     * @param extractor
     * @param <T>
     * @return
     */
    default <T> Page<T> find(JPAQuery<Tuple> query, Pageable pageable, Extractor<T> extractor) {
        long count = query.fetchCount();
        List<Tuple> list = new ArrayList<>();
        if (count > 0) {
            applySorting(pageable.getSort(),query);
            list = query.offset(pageable.getOffset()).limit(pageable.getPageSize()).fetch();
        }
        return new PageImpl<>(list.stream().map(extractor::extract).collect(Collectors.toList())
                , pageable, count);
    }

    default <T> Page<T> find(JPAQuery<T> query, Pageable pageable) {
        long count = query.fetchCount();
        List<T> list = new ArrayList<>();
        if (count > 0) {
            applySorting(pageable.getSort(),query);
            list = query.offset(pageable.getOffset()).limit(pageable.getPageSize()).fetch();
        }
        return new PageImpl<>(list.stream().collect(Collectors.toList()), pageable, count);
    }

    default <T> JPAQuery<T> applySorting(Sort sort, JPAQuery<T> query) {
        if (sort == null) {
            return query;
        }
        EntityPath entity = (EntityPath) query.getMetadata().getJoins().get(0).getTarget();
        for (Sort.Order o : sort) {
            PathBuilder orderByExpression = new PathBuilder(entity.getType(), entity.getMetadata());
            query.orderBy(new OrderSpecifier(o.isAscending() ? Order.ASC : Order.DESC, orderByExpression.get(o.getProperty())));
        }
        return query;
    }

    interface Extractor<T> {
        /**
         * 查询
         *
         * @param tuple
         * @return
         */
        T extract(Tuple tuple);
    }

    class ClassExtractor<T> implements Extractor {
        private Class<T> clazz;

        ClassExtractor(Class<T> clazz) {
            this.clazz = clazz;
        }

        @Override
        @SneakyThrows(Exception.class)
        public T extract(Tuple tuple) {
            T t = clazz.newInstance();
            Object[] objects = tuple.toArray();
            for (int i = objects.length - 1; i >= 0; i--) {
                if (null != objects[i]) {
                    BeanUtils.copyProperties(objects[i], t);
                }
            }
            return t;
        }
    }
}
