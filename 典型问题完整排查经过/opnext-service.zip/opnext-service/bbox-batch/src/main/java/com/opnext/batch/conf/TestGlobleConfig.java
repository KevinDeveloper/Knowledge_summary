package com.opnext.batch.conf;

import lombok.Data;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.List;
import java.util.Map;

/**
 * @ClassName: TestClobleConfig
 * @Description:
 * @Author: Kevin
 * @Date: 2018/9/21 10:33
 */
@Slf4j
@Configuration
//@PropertySource(value={"classpath:test.properties"})
public class TestGlobleConfig {

    @Configuration
    @ConfigurationProperties(prefix = "test.test0")
    @Data
    public static class Test0 {
        @Setter
        public static String bean;

    }


//    @Configuration
//    @ConfigurationProperties(prefix = "test.test1")
//    @Data
//    public static class Test1 {
//        @Setter
//        public static List<T1> bean;
//        @Data
//        class T1{
//            String t1;
//        }
//    }

    @Configuration
    @ConfigurationProperties(prefix = "test.test2")
    @Data
    public static class Test2 {
        @Setter
        public static List<String> bean;
    }

    @Configuration
    @ConfigurationProperties(prefix = "test.test3")
    @Data
    public static class Test3 {
        @Setter
        public static List<Bean> bean;

        @Data
        class Bean{
            String host;
            String ip;
            String port;
        }
    }

    @Configuration
    @ConfigurationProperties(prefix = "test.test4")
    @Data
    public static class Test4 {
        @Setter
        public static Map<String, String> bean;
    }




}
