package com.opnext.batch.interceptor;

import com.opnext.batch.conf.OperatorContext;
import com.opnext.batch.service.AsyncTaskService;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.log.LogReq;
import com.opnext.bboxsupport.util.RequestAnalysisUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.annotation.Order;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Objects;

/**
 * @ClassName: OperatorInterceptor
 * @Description: 网关认证，权限验证
 * @Author: Kevin
 * @Date: 2018/8/21 16:01
 */
@Slf4j
@Order(5)
public class OperatorLogsInterceptor implements HandlerInterceptor {

    @Autowired
    AsyncTaskService asyncTaskService;


    @Override
    public boolean preHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o) throws Exception {
        log.info("bbox-batch OperatorLogsInterceptor 拦截器");
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }

    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {
        log.info("{}方法调用结束, 异步保存日志", httpServletRequest.getServletPath());
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        if (Objects.isNull(oserviceOperator)) {
            log.info("操作用户为空，网关或权限认证不通过， 不保存操作日志");
            return;
        }
        String methodMappingStr = RequestAnalysisUtil.methodUrlPatten((HandlerMethod) o);
        String methodName = httpServletRequest.getMethod().toUpperCase();
        LogReq logReq = new LogReq();
        logReq.setApiPath(methodMappingStr);
        logReq.setMethod(LogReq.Method.valueOf(methodName));
        logReq.setAppId(oserviceOperator.getAppId());
        logReq.setLoginName(oserviceOperator.getLoginName());
        logReq.setTenantId(oserviceOperator.getTenantId());
        logReq.setUserId(oserviceOperator.getUserId());
        logReq.setResultStatus(httpServletResponse.getStatus() >= 400 ? LogReq.ResultStatus.FAILED : LogReq.ResultStatus.SUCCESS);
        asyncTaskService.asyncSendOperatorLog(logReq);
        OperatorContext.remove();
    }


}
