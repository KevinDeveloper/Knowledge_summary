package com.opnext.batch.service.person.impl;

import com.opnext.batch.domain.MultipartFileResp;
import com.opnext.batch.domain.person.batchimport.BatchImportData;
import com.opnext.batch.domain.person.batchimport.QBatchImportData;
import com.opnext.batch.repository.person.BatchImportRepository;
import com.opnext.batch.service.UploadServiceV2;
import com.opnext.batch.service.person.PersonService;
import com.opnext.bboxdomain.OserviceOperator;
import com.querydsl.core.types.Predicate;
import com.querydsl.jpa.impl.JPAQueryFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentMap;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午5:05 18/5/7
 */
@Slf4j
@Service
public class PersonServiceImpl implements PersonService {


    @Autowired
    private JPAQueryFactory jpaQueryFactory;

    @Autowired
    private UploadServiceV2 uploadService;


    //---------------------------------------------------------


    @Override
    public Map<String, MultipartFileResp> checkImportDataPic(String picName, ConcurrentMap<String, File> avatarFileMap, OserviceOperator oserviceOperator) throws Exception {
        Map<String, MultipartFileResp> imgFileResultMap = new HashMap<>();
        log.info("checkImportDataPic, picName={}", picName);
        if (StringUtils.isNotBlank(picName)) {
            if (!CollectionUtils.isEmpty(avatarFileMap) &&
                    avatarFileMap.containsKey(picName)) {
                File avatarFile = avatarFileMap.get(picName);
                List<File> imgFilesList = new ArrayList<>();
                imgFilesList.add(avatarFile);
                imgFileResultMap = imgRespListToMap(uploadService.batchUploadImageForFile(imgFilesList, oserviceOperator));
//                //处理图片地址为相对地址
//                MultipartFileResp resp = imgFileResultMap.get(picName);
//                imgFileResultMap.put(picName, resp);
                avatarFileMap.remove(picName);
            }
        }
        return imgFileResultMap;
    }

    private Map<String, MultipartFileResp> imgRespListToMap(List<MultipartFileResp> fileResps) {
        Map<String, MultipartFileResp> imgFileResultMap = new HashMap<>();
        if (!CollectionUtils.isEmpty(fileResps)) {
            fileResps.forEach(multipartFileResp -> {
                if (Objects.nonNull(multipartFileResp)) {
                    imgFileResultMap.put(multipartFileResp.getFileName(), multipartFileResp);
                }
            });
        }
        return imgFileResultMap;
    }


    @Autowired
    private BatchImportRepository batchImportRepository;

    @Override
    public void saveBatchImportData(BatchImportData batchImportData) throws Exception {
        batchImportRepository.save(batchImportData);
    }

    @Transactional(rollbackFor = Exception.class)
    @Override
    public void deleteBatchImportData(OserviceOperator oserviceOperator) throws Exception {
        Predicate predicate = QBatchImportData.batchImportData.tenantId.eq(oserviceOperator.getTenantId());
        jpaQueryFactory.delete(QBatchImportData.batchImportData).where(predicate).execute();
    }


}
