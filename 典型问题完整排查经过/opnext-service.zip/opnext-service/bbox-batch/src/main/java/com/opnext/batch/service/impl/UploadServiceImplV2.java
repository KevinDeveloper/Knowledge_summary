package com.opnext.batch.service.impl;

import com.opnext.batch.domain.MultipartFileResp;
import com.opnext.batch.service.ImageHandlerV2;
import com.opnext.batch.service.UploadServiceV2;
import com.opnext.bboxdomain.OserviceOperator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.util.List;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午3:18 18/5/9
 */
@Slf4j
@Service
public class UploadServiceImplV2 implements UploadServiceV2 {

    @Resource
    private ImageHandlerV2 imageHandlerV2;


    /**
     * 批量上传人物正面照片
     * 注：非异步调用
     * @param multipartFileList
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public List<MultipartFileResp> batchUploadImage(List<MultipartFile> multipartFileList, OserviceOperator oserviceOperator) throws Exception {
        List<MultipartFileResp> multipartFileRespList = imageHandlerV2.checkAndCutAndUploadImage(multipartFileList,oserviceOperator);
        return multipartFileRespList;
    }

    /**
     * 批量上传文件照片
     *
     * @param fileList
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    @Override
    public List<MultipartFileResp> batchUploadImageForFile(List<File> fileList, OserviceOperator oserviceOperator) throws Exception {
        List<MultipartFileResp> multipartFileRespList = imageHandlerV2.checkAndCutAndUploadImageForList(fileList,oserviceOperator);
        return multipartFileRespList;
    }

}
