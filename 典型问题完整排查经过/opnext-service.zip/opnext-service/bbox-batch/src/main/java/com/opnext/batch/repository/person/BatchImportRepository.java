package com.opnext.batch.repository.person;

import com.opnext.batch.domain.person.batchimport.BatchImportData;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface BatchImportRepository extends PagingAndSortingRepository<BatchImportData, Long>, QueryDslPredicateExecutor<BatchImportData> {

}