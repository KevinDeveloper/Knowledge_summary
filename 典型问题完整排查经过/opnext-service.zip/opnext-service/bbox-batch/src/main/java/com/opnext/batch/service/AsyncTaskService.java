package com.opnext.batch.service;

import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxdomain.log.LogReq;

import java.io.File;
import java.util.List;

/**
 * @ClassName: AsyncService
 * @Description: 异步任务
 * @Author: Kevin
 * @Date: 2018/5/18 15:06
 */
public interface AsyncTaskService {


    /**
     * 异步解析人员文件
     *
     * @param oserviceOperator
     * @param excelFile
     * @param imgFiles
     * @param imgFileZip
     * @param uploadType
     * @param userRootPath
     * @throws Exception
     */
    void asyncUnZipAndParingBatchAddPersonForImageFile(OserviceOperator oserviceOperator, File excelFile, List<File> imgFiles, File imgFileZip, String uploadType, String userRootPath) throws Exception;


    /**
     * 异步发送操作日志
     *
     * @param logReq
     * @throws Exception
     */
    void asyncSendOperatorLog(LogReq logReq) throws Exception;

}
