package com.opnext.batch.service;

import com.opnext.batch.domain.MultipartFileResp;
import com.opnext.bboxdomain.OserviceOperator;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午3:18 18/5/9
 */
public interface UploadServiceV2 {

    /**
     * 批量上传文件照片
     *
     * @param multipartFileList
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    List<MultipartFileResp> batchUploadImage(List<MultipartFile> multipartFileList, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 批量上传文件照片
     *
     * @param fileList
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    List<MultipartFileResp> batchUploadImageForFile(List<File> fileList, OserviceOperator oserviceOperator) throws Exception;
}
