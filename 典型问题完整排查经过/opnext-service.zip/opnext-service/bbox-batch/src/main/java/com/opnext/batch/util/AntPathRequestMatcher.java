package com.opnext.batch.util;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.util.AntPathMatcher;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;

/**
 * @author wanglu
 */
public class AntPathRequestMatcher {
    private static final Logger logger = LoggerFactory.getLogger(AntPathRequestMatcher.class);
    private static final String MATCH_ALL = "/**";
    private final AntPathRequestMatcher.Matcher matcher;
    private final String pattern;
    private final HttpMethod httpMethod;

    public AntPathRequestMatcher(String pattern) {
        this(pattern, (String)null);
    }

    public AntPathRequestMatcher(String pattern, String httpMethod) {
        Assert.hasText(pattern, "Pattern cannot be null or empty");
        String allPath="/**";
        String allReq="**";
        String onStar="*";
        if (!allPath.equals(pattern) && !allReq.equals(pattern)) {
            pattern = pattern.toLowerCase();
            if (pattern.endsWith(allPath) && pattern.indexOf(63) == -1 && pattern.indexOf(onStar) == pattern.length() - 2) {
                this.matcher = new AntPathRequestMatcher.SubpathMatcher(pattern.substring(0, pattern.length() - 3));
            } else {
                this.matcher = new AntPathRequestMatcher.SpringAntMatcher(pattern);
            }
        } else {
            pattern = "/**";
            this.matcher = null;
        }

        this.pattern = pattern;
        this.httpMethod = StringUtils.hasText(httpMethod) ? HttpMethod.valueOf(httpMethod) : null;
    }

    public boolean matches(HttpServletRequest request) {
        String allPath="/**";
        if (this.httpMethod != null && this.httpMethod != HttpMethod.valueOf(request.getMethod())) {
            if (logger.isDebugEnabled()) {
                logger.debug("Request '" + request.getMethod() + " " + this.getRequestPath(request) + "' doesn't match '" + this.httpMethod + " " + this.pattern);
            }

            return false;
        } else if (allPath.equals(this.pattern)) {
            if (logger.isDebugEnabled()) {
                logger.debug("Request '" + this.getRequestPath(request) + "' matched by universal pattern '/**'");
            }

            return true;
        } else {
            String url = this.getRequestPath(request);
            if (logger.isDebugEnabled()) {
                logger.debug("Checking match of request : '" + url + "'; against '" + this.pattern + "'");
            }

            return this.matcher.matches(url);
        }
    }

    private String getRequestPath(HttpServletRequest request) {
        String url = request.getServletPath();
        if (request.getPathInfo() != null) {
            url = url + request.getPathInfo();
        }

        url = url.toLowerCase();
        return url;
    }

    public String getPattern() {
        return this.pattern;
    }

    private static class SubpathMatcher implements AntPathRequestMatcher.Matcher {
        private final String subpath;
        private final int length;

        private SubpathMatcher(String subpath) {
            assert !subpath.contains("*");

            this.subpath = subpath;
            this.length = subpath.length();
        }
        @Override
        public boolean matches(String path) {
            return path.startsWith(this.subpath) && (path.length() == this.length || path.charAt(this.length) == '/');
        }
    }

    private static class SpringAntMatcher implements AntPathRequestMatcher.Matcher {
        private static final AntPathMatcher ANTMATCHER = new AntPathMatcher();
        private final String pattern;

        private SpringAntMatcher(String pattern) {
            this.pattern = pattern;
        }
        @Override
        public boolean matches(String path) {
            return ANTMATCHER.match(this.pattern, path);
        }
    }

    private interface Matcher {
        /**
         * api rest 拦截规则处理
         * @param var1
         * @return
         */
        boolean matches(String var1);
    }
}
