package com.opnext.batch.domain.person.batch;

import lombok.Data;

/**
 * @ClassName: BatchResult
 * @Description: 批量导入结果统计
 * @Author: Kevin
 * @Date: 2018/7/6 17:09
 */
@Data
public class BatchResult {
    long total;
    long numFail;
    long numSuccess;
}
