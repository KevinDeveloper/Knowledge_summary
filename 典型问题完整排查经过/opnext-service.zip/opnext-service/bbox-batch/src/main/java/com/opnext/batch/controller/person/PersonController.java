package com.opnext.batch.controller.person;

import com.opnext.batch.conf.Constant;
import com.opnext.batch.conf.OperatorContext;
import com.opnext.batch.domain.person.batch.BatchStateBean;
import com.opnext.batch.domain.person.batch.BatchStateType;
import com.opnext.batch.redis.RedisCacheUtil;
import com.opnext.batch.service.AsyncTaskService;
import com.opnext.batch.service.person.BatchStateManageService;
import com.opnext.batch.service.person.PersonService;
import com.opnext.batch.util.FileUtil;
import com.opnext.batch.util.UUIDUtil;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationHome;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午5:05 18/5/7
 */
@Slf4j
@RestController
@RequestMapping("/api/person")
public class PersonController {

    @Autowired
    private PersonService personService;

    @Autowired
    private BatchStateManageService batchStateManageService;

    @Autowired
    private AsyncTaskService asyncTaskService;

    @Autowired
    private RedisCacheUtil redisCacheUtil;


    @ApiOperation(value = "获取批量导入requestId", notes = "")
    @RequestMapping(value = "/batch/requestId", method = RequestMethod.GET)
    public CommonResponse getBatchUploadRequestId() throws Exception {
        log.info("获取批量导入requestId - 开始");
        OserviceOperator operator = OperatorContext.getOperator();
        StopWatch stopWatch = new StopWatch();

        //判断批量导入状态
        BatchStateBean curState = batchStateManageService.getBatchStateBean(operator.getTenantId());
        if (Objects.isNull(curState)) {
            log.error("获取导入状态为空，处理异常, batchlog - 1");
            throw new CommonException("person.batchAdd.batchstate.get.error");
        }
        log.info("获取租户当前批量导入状态 ,batchStateBean={}", curState.toString());
        //1、判断当前导入状态 - 可导入状态
        if (BatchStateType.STATE_UPLOADABLE.value() != curState.getBatchStateType()) {
            log.error("当前处于非可导入状态, batchlog - 2,  stateType ={}", curState.getBatchStateType());
            throw new CommonException(416, "person.batchAdd.hashother");

        }
        //2、查询用户占用状态  -
        if (BatchStateManageService.BATCH_PERSON_USER_EMPTY.longValue() != curState.getUserId()) {
            log.info("当前处于用户占用状态, batchlog - 3, 占用用户 userId={}", curState.getUserId());
            throw new CommonException(416, "person.batchAdd.hashother");
        }

        //设置requestid
        String requestId = operator.getTenantId() + "_" + operator.getUserId() + "_" + UUIDUtil.uuid();
        String requestKey = "batch_requestId_" + operator.getTenantId() + "_" + operator.getUserId();
        stopWatch.start("设置批量导入接口请求id");
        batchStateManageService.setBatchRequestId(requestKey, requestId);

        log.info("获取批量导入requestId - 结束，requestId = {}, 耗时={}", requestId, stopWatch.prettyPrint());
        return CommonResponse.ok(requestId);
    }


    @ApiOperation(value = "上传批量导入文件", notes = "上传批量导入文件,uploadType为上传文件类型,zip照片压缩包,files照片文件夹")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "uploadType", value = "上传图片类型", required = true),
            @ApiImplicitParam(name = "requestId", value = "上传文件接口的requestId", required = true)
    })
    @RequestMapping(value = "/batchAddPreview", method = RequestMethod.POST)
    public void batchAddPreview(HttpServletRequest request, @RequestParam String uploadType, @RequestParam String requestId) throws Exception {
        log.info("上传批量导入文件 - 开始, uploadType ={}", uploadType);
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        StopWatch stopWatch = new StopWatch("上传批量导入文件");
        //判断requestId
        stopWatch.start("判断requestId");
        String requestKey = "batch_requestId_" + oserviceOperator.getTenantId() + "_" + oserviceOperator.getUserId();
        String curRequestId = batchStateManageService.getBatchRequestId(requestKey);
        if (StringUtils.isBlank(requestId)) {
            log.error("上传requestId 为空错误");
            throw new CommonException(416, "person.batchAdd.parameter.incorrect");
        }
        if (StringUtils.isBlank(curRequestId)) {
            log.error("上传requestId 为空错误， 获取redis 中requestId为空");
            throw new CommonException(416, "person.batchAdd.parameter.incorrect");
        } else if (!curRequestId.equals(requestId)) {
            log.error("上传requestId 为空错误, requestId不相等");
            throw new CommonException(416, "person.batchAdd.hashother");
        }

        stopWatch.stop();

        stopWatch.start("判断导入状态");
        //判断批量导入状态
        BatchStateBean curState = batchStateManageService.getBatchStateBean(oserviceOperator.getTenantId());
        if (Objects.isNull(curState)) {
            log.error("获取导入状态为空，处理异常, batchlog - 1");
            throw new CommonException("person.batchAdd.batchstate.get.error");
        }
        log.info("获取租户当前批量导入状态 ,batchStateBean={}", curState.toString());
        //1、判断当前导入状态 - 可导入状态
        if (BatchStateType.STATE_UPLOADABLE.value() != curState.getBatchStateType()) {
            log.error("当前处于非可导入状态, batchlog - 2,  stateType ={}", curState.getBatchStateType());
            throw new CommonException(416, "person.batchAdd.hashother");

        }
        //2、查询用户占用状态  -
        if (BatchStateManageService.BATCH_PERSON_USER_EMPTY.longValue() != curState.getUserId()) {
            log.info("当前处于用户占用状态, batchlog - 3, 占用用户 userId={}", curState.getUserId());
            throw new CommonException(416, "person.batchAdd.hashother");
        }
        stopWatch.stop();
        //状态合法，开始导入操作
        if (StringUtils.isBlank(uploadType) ||
                (!Constant.UPLOAD_TYPE_ZIP.equals(uploadType)
                        && !Constant.UPLOAD_TYPE_FILES.equals(uploadType))) {
            log.error("上传类型错误，uploadtype={}, batchlog - 4", uploadType);
            throw new CommonException(416, "person.batchAdd.parameter.incorrect");
        }
        //防止同一个用户并发调用
        String saveFileKey = "batch_async_" + oserviceOperator.getTenantId() + "_" + oserviceOperator.getUserId();
        long curTime = System.currentTimeMillis();
        try {
            //判断当前 批量导入状态 , 开始加锁
            boolean keyResult = redisCacheUtil.getDistributedLock(saveFileKey, curTime, 20000L, TimeUnit.MILLISECONDS);
            if (!keyResult) {
                log.error("未获取到分布式锁，当前时段本用户正在操作,batchlog - 5");
                throw new CommonException(416, "person.batchAdd.hashother");
            }
        } catch (Exception e) {
            log.error("未获取到分布式锁，当前时段本用户正在操作, batchlog - 6");
            throw new CommonException(416, "person.batchAdd.hashother");
        } finally {
//            Long cacheTime = redisCacheUtil.getCacheObject(saveFileKey);
//            if (Objects.nonNull(cacheTime) && curTime == cacheTime) {
//                redisCacheUtil.delete(saveFileKey);
//            }
        }
        //保存文件
        ApplicationHome home = new ApplicationHome(getClass());
        String userRootPath = home.getDir().getAbsolutePath() + File.separator + batchStateManageService.getBatchUserRotPath(oserviceOperator);
//        String userRootPath = request.getServletContext().getRealPath("/") + getBatchUserRotPath(oserviceOperator);
        FileUtil.createDirByPathName(userRootPath);

        log.info("上传批量导入文件 - userRootPath={}", userRootPath);
        stopWatch.start("获取并保存上传的导入文件");
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        MultipartFile multipartFileExcel = multipartRequest.getFile("excelFile");
        if (null == multipartFileExcel || multipartFileExcel.getSize() == 0) {
            log.info("批量导入excel文件为空, batchlog - 7");
            throw new CommonException(416, "person.batchAdd.excel");
        }
        File excelFile = FileUtil.saveMultipartFileExcel(oserviceOperator, userRootPath, multipartFileExcel);
        if (Objects.isNull(excelFile)) {
            log.info("保存excel文件失败, batchlog - 8");
            throw new CommonException(416, "person.batchAdd.file.error");
        }
        log.info("保存excel文件成功，filename={}, path={}", excelFile.getName(), excelFile.getAbsolutePath());
        //-----------------------------
        List<File> imgFilesList = new ArrayList<>();
        File imgFileZip = null;
        if (Constant.UPLOAD_TYPE_ZIP.equals(uploadType)) {
            MultipartFile filePicsZip = multipartRequest.getFile("allImage");
            if (Objects.isNull(filePicsZip)) {
                log.info("照片文件获取为空， 不解压");
            } else {
                imgFileZip = FileUtil.saveMultipartFileZipImgFile(userRootPath, filePicsZip, oserviceOperator);
            }
        } else if (Constant.UPLOAD_TYPE_FILES.equals(uploadType)) {
            List<MultipartFile> imgMultipartFiles = multipartRequest.getFiles("allImage");
            if (CollectionUtils.isEmpty(imgMultipartFiles)) {
                log.info("批量导入图片文件为空");
            } else {
                //保存imgMultipartFiles 到本地为file
                imgFilesList = FileUtil.saveMultipartFileImage(oserviceOperator, userRootPath, imgMultipartFiles);
            }
        }
        stopWatch.stop();
        log.info("获取并保存上传文件成功");
        //-------------------------------------
        //异步处理，给前端返回
        log.info("后台接收到上传文件，开始异步处理");
        stopWatch.start("开启异步解析任务，并设置导入状态");
        curTime = System.currentTimeMillis();
        String distributedKey = "batch_async_" + oserviceOperator.getTenantId();
        try {
            //判断当前 批量导入状态 , 开始加锁
            boolean keyResult = redisCacheUtil.getDistributedLock(distributedKey, curTime, 2000L, TimeUnit.MILLISECONDS);
            if (!keyResult) {
                log.error("未获取到分布式锁，当前时段在有其他用户操作, batchlog - 9");
                throw new CommonException(416, "person.batchAdd.hashother");
            }
            log.info("获取到分布式锁，当前时段在没有其他用户操作， 耗时={}(ms)", (System.currentTimeMillis() - curTime));

            boolean uploadable = batchStateManageService.isUploadable(oserviceOperator.getTenantId());
            if (!uploadable) {
                log.info("当前时段处于非可导入状态，不能操作, batchlog - 10");
                throw new CommonException(416, "person.batchAdd.hashother");
            }
            //更新导入状态
            BatchStateBean batchStateBean = new BatchStateBean();
            batchStateBean.setBatchStateType(BatchStateType.STATE_PARSING.value());
            batchStateBean.setUserId(oserviceOperator.getUserId());
            batchStateBean.setIndex(0);
            batchStateManageService.startAndReleaseBatchStateBean(oserviceOperator.getTenantId(), batchStateBean);
            asyncTaskService.asyncUnZipAndParingBatchAddPersonForImageFile(oserviceOperator, excelFile, imgFilesList, imgFileZip, uploadType, userRootPath);
        } catch (Exception e) {
            log.info("异步解析批量文件异常，batchlog - 11", e);
            //设置状态 - 解析失败
            BatchStateBean batchStateBean = new BatchStateBean();
            batchStateBean.setBatchStateType(BatchStateType.STATE_PARSE_FAIL.value());
            batchStateBean.setUserId(oserviceOperator.getUserId());
            batchStateManageService.startAndReleaseBatchStateBean(oserviceOperator.getTenantId(), batchStateBean);
            //清空当前租户内的批量导入临时数据
            personService.deleteBatchImportData(oserviceOperator);
            //删除临时文件
            FileUtil.deleteTempZipFile(userRootPath, oserviceOperator);
        } finally {
            Long cacheTime = redisCacheUtil.getCacheObject(distributedKey);
            if (Objects.nonNull(cacheTime) && curTime == cacheTime) {
                redisCacheUtil.delete(distributedKey);
            }
        }
        stopWatch.stop();
        log.info("上传批量导入文件 - 结束，uploadType={},  耗时={}", uploadType, stopWatch.prettyPrint());
    }


    @ApiOperation(value = "清空批量导入缓存数据", notes = "清空批量导入缓存数据")
    @RequestMapping(value = "/batchAddClear", method = RequestMethod.DELETE)
    public void batchAddClear() throws Exception {
        log.info("清空批量导入缓存数据 - 开始");
        long startTime = System.currentTimeMillis();
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        //判断批量导入状态
        BatchStateBean curState = batchStateManageService.getBatchStateBean(oserviceOperator.getTenantId());
        if (Objects.isNull(curState)) {
            log.error("获取导入状态为空，处理异常, batchlog - 1");
            throw new CommonException("person.batchAdd.batchstate.get.error");
        }
        //不等于中间状态值的时候才执行清空操作， 解析中 和 导入中 状态不清空
        if (BatchStateType.STATE_PARSING.value() != curState.getBatchStateType() &&
                BatchStateType.STATE_IMPORTING.value() != curState.getBatchStateType()) {
            ApplicationHome home = new ApplicationHome(getClass());
            String userRootPath = home.getDir().getAbsolutePath() + File.separator + batchStateManageService.getBatchUserRotPath(oserviceOperator);
//        String userRootPath = request.getServletContext().getRealPath("/") + getBatchUserRotPath(oserviceOperator);
            log.info("清空批量导入缓存数据, userRootPath={}", userRootPath);
            //删除临时文件
            FileUtil.deleteTempZipFile(userRootPath, oserviceOperator);
            //重置批量导入状态
            batchStateManageService.startAndReleaseBatchStateBean(oserviceOperator.getTenantId(), new BatchStateBean());
            personService.deleteBatchImportData(oserviceOperator);
        }

        log.info("清空批量导入缓存数据 - 结束 ,耗时={}", (System.currentTimeMillis() - startTime));
    }


    //=========================================================


}
