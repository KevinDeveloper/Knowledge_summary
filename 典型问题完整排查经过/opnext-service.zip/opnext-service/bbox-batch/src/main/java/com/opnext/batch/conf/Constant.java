package com.opnext.batch.conf;

/**
 * @author tianzc
 * @Title: 常量类
 * @Description:
 * @Date 下午4:45 18/5/7
 */
public interface Constant {

    String TERMINAL_DEFAULT_ADMIN = "terminal-admin";

    /**
     * 文件上传统一资源标志符
     */
    String FASTDFS_SERVER_UPLOAD_URI = "/api/ocfs/file/upload";

    /**
     * 文件下载统一资源标志符
     */
    String FASTDFS_SERVER_DOWNLOAD_URI = "/ocfs/file/download";

    /**
     * 图片类型名
     */
    String IMAGE_FORMAT_NAME = "jpg";

    /**
     * 返回终端的host中的netty的名称值
     */
    String NETTY_HOST_NAME = "netty";
    /**
     * 人员size
     */
    int PERSON_PAGEABLE_SIZE = 1000;
    int BATCH_INSERT_SIZE = 500;

    String CONFIG_REDIS_PATTERN_KEY = "config_redis_";

    //--------------------- 批量处理-----开始
    String UPLOAD_TYPE_ZIP = "zip";
    String UPLOAD_TYPE_FILES = "files";
    //----------------------批量处理-----结束

    /**
     * 异步解析任务失败key
     */
    String ASYNC_TASK_PARSE_KEY = "asyncTaskParseKey";

    /**
     * 异步导入任务失败key
     */
    String ASYNC_TASK_IMPORT_KEY = "asyncTaskImportKey";


    /**
     * 异步导出任务失败key
     */
    String ASYNC_TASK_EXPORT_KEY = "asyncTaskExportKey";


}
