package com.opnext.batch.repository.fastdfs;

import com.opnext.batch.domain.fastdfs.FastdfsTmpFile;
import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

/**
 * @ClassName: fastdfs
 * @Description:
 * @Author: Kevin
 * @Date: 2018/8/28 16:05
 */
public interface FastdfsTmpFileRepository extends PagingAndSortingRepository<FastdfsTmpFile, Long>, QueryDslPredicateExecutor<FastdfsTmpFile> {
}
