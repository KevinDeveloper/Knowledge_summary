package com.opnext.batch.task;

import com.opnext.batch.conf.GlobleConfig;
import com.opnext.batch.domain.person.batchimport.BatchImportData;
import com.opnext.batch.service.person.BatchStateManageService;
import com.opnext.batch.service.person.PersonService;
import com.opnext.batch.util.excel.ExcelReadUtil;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.util.Messages;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.RecursiveTask;

/**
 * @ClassName: ExcelXlsxToPersonTask
 * @Description: 针对Office2007 以上版本，做Excel解析
 * @Author: Kevin
 * @Date: 2018/7/3 19:33
 */
@Slf4j
public class ExcelXlsxToPersonTask extends RecursiveTask<Integer> {


    private int startIndex;
    private int endIndex;

    private OserviceOperator oserviceOperator;
    private XSSFSheet xssfSheet;
    private PersonService personService;
    private BatchStateManageService batchStateManageService;

    private ConcurrentMap<String, File> avatarFileMap;

    public ExcelXlsxToPersonTask(OserviceOperator oserviceOperator, PersonService personService, BatchStateManageService batchStateManageService, ConcurrentMap<String, File> avatarFileMap, XSSFSheet xssfSheet, int startIndex, int endIndex) {
        this.oserviceOperator = oserviceOperator;
        this.personService = personService;
        this.batchStateManageService = batchStateManageService;

        this.avatarFileMap = avatarFileMap;

        this.xssfSheet = xssfSheet;
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        if (Objects.nonNull(oserviceOperator.getCurLocale())) {
            Messages.setLocale(oserviceOperator.getCurLocale());
        }
    }

    @Override
    protected Integer compute() {
        int sum = 0;
        log.info("startIndex={}, endIndex={}, --{}", startIndex, endIndex, Thread.currentThread());
        Integer threshold = GlobleConfig.ServiceBatch.batchThreshold;
        if (Objects.isNull(threshold) || threshold < 1) {
            threshold = BatchStateManageService.THRESHOLD;
        }
        if ((endIndex - startIndex) < threshold.intValue()) {
            XSSFRow xSSFRow = null;
            Map<Integer, String> rowdatasMap = null;
            for (int rows = startIndex; rows <= endIndex; rows++) {
                try {
                    // 取得某一行 对象
                    xSSFRow = xssfSheet.getRow(rows);
                    rowdatasMap = ExcelReadUtil.getRowDatesForSheetForXlsx(xSSFRow);
                    if (CollectionUtils.isEmpty(rowdatasMap)) {
                        continue;
                    }
                    //--------处理BatchImportData
                    BatchImportData importData = new BatchImportData();
                    importData.setTenantId(oserviceOperator.getTenantId());
                    importData.setUserId(oserviceOperator.getUserId());
                    importData.setOrder(rows);
                    importData.setRowdata(rowdatasMap);
                    String picName = rowdatasMap.get(2);
                    importData.setPicResp(personService.checkImportDataPic(picName, avatarFileMap, oserviceOperator));
                    //---------------- 保存BatchImportData到数据库
                    personService.saveBatchImportData(importData);

                } catch (Exception e) {
                    log.error("导入人员异常，e={}", e);
                }
            }
            //更新状态 - 解析进度更新
            sum = endIndex - startIndex + 1;
            batchStateManageService.updateBatchIndex(oserviceOperator.getTenantId(), sum);

        } else {
            int midle = (startIndex + endIndex) >> 1;
            ExcelXlsxToPersonTask left = new ExcelXlsxToPersonTask(oserviceOperator, personService, batchStateManageService, avatarFileMap, xssfSheet, startIndex, midle);
            ExcelXlsxToPersonTask right = new ExcelXlsxToPersonTask(oserviceOperator, personService, batchStateManageService, avatarFileMap, xssfSheet, midle + 1, endIndex);
            left.fork();
            right.fork();
            sum = left.join() + right.join();
        }
        return sum;
    }


}
