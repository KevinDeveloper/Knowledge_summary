package com.opnext.batch.domain.account;

import lombok.Data;

/**
 * @author tianzc
 */
@Data
public class ApiOperator {
    /**
     * 设备sn
     */
    String sn;
    /**
     * 设备名称
     */
    String name;
    /**
     * 设备组
     */
    Integer groupId;
    Long tenantId;
}
