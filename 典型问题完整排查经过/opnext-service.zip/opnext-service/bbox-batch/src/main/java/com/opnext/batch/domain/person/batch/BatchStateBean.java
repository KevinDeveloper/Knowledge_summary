package com.opnext.batch.domain.person.batch;

import com.opnext.batch.service.person.BatchStateManageService;
import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName: BatchStateBean
 * @Description: 批量导入状态
 * @Author: Kevin
 * @Date: 2018/7/4 19:10
 */
@Data
public class BatchStateBean implements Serializable {


    Integer batchStateType;
    Integer total;
    Integer index;
    Long userId;
    /**
     * 判断是否当前用户在操作导入
     */
    boolean curUserBatch;


    public BatchStateBean() {
        batchStateType = BatchStateType.STATE_UPLOADABLE.value();
        total = 0;
        index = 0;
        userId = BatchStateManageService.BATCH_PERSON_USER_EMPTY;
        curUserBatch = false;
    }

    public BatchStateBean(BatchStateType batchStateType, Integer total, Integer index, Long userId) {
        this.batchStateType = batchStateType.value();
        this.total = total;
        this.index = index;
        this.userId = userId;
    }


    @Override
    public String toString() {
        return "BatchStateBean{" +
                "batchStateType=" + batchStateType +
                ", total=" + total +
                ", index=" + index +
                ", userId=" + userId +
                ", curUserBatch=" + curUserBatch +
                '}';
    }
}
