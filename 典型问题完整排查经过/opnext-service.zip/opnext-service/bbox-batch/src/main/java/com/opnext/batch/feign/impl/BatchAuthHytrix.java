package com.opnext.batch.feign.impl;

import com.opnext.batch.domain.DispatchAuthResp;
import com.opnext.batch.feign.BatchAuthFeign;
import com.opnext.bboxsupport.advise.CommonResponse;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @ClassName: BatchAuthHytrix
 * @Description:
 * @Author: Kevin
 * @Date: 2018/7/30 17:20
 */
@Slf4j
@Component(value = "batchAuthHytrix")
public class BatchAuthHytrix implements FallbackFactory<BatchAuthFeign> {

    @Override
    public BatchAuthFeign create(Throwable throwable) {
        log.info("batchAuthHytrix   -------");
        return new BatchAuthFeign() {
            @Override
            public CommonResponse<DispatchAuthResp> dispathAuth(String token) throws Exception {
                log.error("bbox-batch， 网关认证失败, throwable={}", throwable);
                return null;
            }
        };
    }
}
