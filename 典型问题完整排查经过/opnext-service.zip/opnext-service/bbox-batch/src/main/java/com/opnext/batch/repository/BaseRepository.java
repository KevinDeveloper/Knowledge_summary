package com.opnext.batch.repository;

import org.springframework.data.querydsl.QueryDslPredicateExecutor;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface BaseRepository<T> extends PagingAndSortingRepository<T, Integer>,QueryDslPredicateExecutor<T>{

}
