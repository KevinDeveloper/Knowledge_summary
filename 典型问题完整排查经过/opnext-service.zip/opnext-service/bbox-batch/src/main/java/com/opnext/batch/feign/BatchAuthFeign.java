package com.opnext.batch.feign;

import com.opnext.batch.domain.DispatchAuthResp;
import com.opnext.batch.feign.impl.BatchAuthHytrix;
import com.opnext.bboxsupport.advise.CommonResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @ClassName: BatchAuthFeign
 * @Description: 网关认证
 * @Author: Kevin
 * @Date: 2018/7/30 17:18
 */
@FeignClient(value = "door-keeper", fallbackFactory = BatchAuthHytrix.class)
public interface BatchAuthFeign {

    @RequestMapping(value = "/dispatch/auth", method = RequestMethod.GET)
    CommonResponse<DispatchAuthResp> dispathAuth(@RequestParam(value = "token") String token) throws Exception;
}
