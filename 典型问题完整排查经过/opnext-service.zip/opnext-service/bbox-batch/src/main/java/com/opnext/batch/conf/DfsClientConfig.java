package com.opnext.batch.conf;

import com.op.server.dfs.client.DfsClient;
import lombok.Data;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationHome;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.File;

/**
 * @author tianzc
 */
@Slf4j
@Configuration
public class DfsClientConfig {

    @Configuration
    @ConfigurationProperties(prefix = "fastdfs.config")
    @Data
    public  class FastdfsConfig {
        public  String fileName;
        public  String fileDir;
    }
    @Bean
    DfsClient createDfsClient(FastdfsConfig fastdfsConfig){
        ApplicationHome home = new ApplicationHome(getClass());
        String path = home.getDir().getAbsolutePath() + File.separator + fastdfsConfig.getFileDir() + File.separator + fastdfsConfig.getFileName();
        log.info("--------文件地址path：{}",path);
        File configFile = new File(path);
        if(configFile.exists() && configFile.isFile()){
            return new DfsClient(path);
        }
        return new DfsClient();
    }
}
