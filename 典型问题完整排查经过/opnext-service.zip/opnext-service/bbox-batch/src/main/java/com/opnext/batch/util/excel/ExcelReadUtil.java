package com.opnext.batch.util.excel;

import com.opnext.batch.util.DateUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;


/**
 * @author Kevin
 * @Title:PersonConfigController
 * @Description: 读取Excel数据
 * @Date 下午5:05 18/5/7
 */
public class ExcelReadUtil {

    private static Logger LOGGER = LoggerFactory.getLogger(ExcelReadUtil.class);
    /**
     * 初始化map大小
     */
    private static int INIT_MAP_SIZE = 32;
    /**
     * 针对Office2007 以上版本，做Excel解析
     */
    public static String EXCEL_SUFFIX_XLSX = ".xlsx";
    /**
     * 针对Office2007 以前版本，做Excel解析
     */
    public static String EXCEL_SUFFIX_XLS = ".xls";


    public static List<List<String>> readExcel(MultipartFile multipartFile) throws Exception {

        List<List<String>> excelData = new ArrayList<>();
        InputStream inputStream = null;
        try {
            inputStream = multipartFile.getInputStream();
            /** 获取文件的后缀 **/
            String suffix = multipartFile.getOriginalFilename().substring(multipartFile.getOriginalFilename().lastIndexOf(".")).toLowerCase();
            if (EXCEL_SUFFIX_XLSX.equals(suffix)) {
                excelData = ExcelReadUtil.readFromXlsx(inputStream);
            } else if (EXCEL_SUFFIX_XLS.equals(suffix)) {
                excelData = ExcelReadUtil.readFromXls(inputStream);
            }
        } catch (Exception e) {
            LOGGER.error("exception readExcel, {}", e);
        } finally {
            if (Objects.nonNull(inputStream)) {
                inputStream.close();
            }
        }
        return excelData;
    }

    public static List<Map<Integer, String>> readExcelForMap(MultipartFile multipartFile) throws Exception {

        List<Map<Integer, String>> excelData = new ArrayList<>();
        InputStream inputStream = null;
        try {
            inputStream = multipartFile.getInputStream();
            /** 获取文件的后缀 **/
            String suffix = multipartFile.getOriginalFilename().substring(multipartFile.getOriginalFilename().lastIndexOf(".")).toLowerCase();
            if (EXCEL_SUFFIX_XLSX.equals(suffix)) {
                excelData = ExcelReadUtil.readFromXlsxForMap(inputStream, suffix);
            } else if (EXCEL_SUFFIX_XLS.equals(suffix)) {
                excelData = ExcelReadUtil.readFromXlsForMap(inputStream, suffix);
            }
        } catch (Exception e) {
            LOGGER.error("exception readExcelForMap, {}", e);
        } finally {
            if (Objects.nonNull(inputStream)) {
                inputStream.close();
            }
        }
        return excelData;
    }

    public static List<List<String>> readFromXls(InputStream excelStream) {
        List<List<String>> data = new ArrayList<>();
        try {
            POIFSFileSystem fs = new POIFSFileSystem(excelStream);
            Workbook book = new HSSFWorkbook(fs);
            HSSFSheet sheet = (HSSFSheet) book.getSheetAt(0);
            HSSFRow hSSFRow = null;
            List<String> rowdatas = null;
            for (int rows = 0; rows <= sheet.getLastRowNum(); rows++) {
                // 取得某一行 对象
                hSSFRow = sheet.getRow(rows);
                if (hSSFRow == null) {
                    continue;
                }
                int columncount = hSSFRow.getLastCellNum();
                rowdatas = new ArrayList<>();
                boolean isEmpty = true;
                for (int i = 0; i < columncount; i++) {
                    String cellValue = getStringCellValue(hSSFRow.getCell(i));
                    rowdatas.add(cellValue);
                    if (isEmpty && StringUtils.isNotBlank(cellValue)) {
                        isEmpty = false;
                    }
                }
                if (!isEmpty) {
                    data.add(rowdatas);
                }
            }
        } catch (Exception e) {
            LOGGER.error("readFromXls error:{}", e);
            data = null;
        }
        return data;
    }

    public static List<List<String>> readFromXlsx(InputStream excelStream) {
        List<List<String>> data = new ArrayList<>();
        try {
            Workbook book = new XSSFWorkbook(excelStream);
            XSSFSheet sheet = (XSSFSheet) book.getSheetAt(0);
            // 遍历行获得每行信息
            List<String> rowdatas = null;
            XSSFRow xSSFRow = null;
            for (int rows = 0; rows <= sheet.getLastRowNum(); rows++) {
                xSSFRow = sheet.getRow(rows);
                if (xSSFRow == null) {
                    continue;
                }
                int columncount = xSSFRow.getLastCellNum();
                rowdatas = new ArrayList<>();
                boolean isEmpty = true;
                for (int i = 0; i < columncount; i++) {
                    String cellValue = getStringXSSFCellValue(xSSFRow.getCell(i));
                    rowdatas.add(cellValue);
                    if (isEmpty && StringUtils.isNotBlank(cellValue)) {
                        isEmpty = false;
                    }
                }
                if (!isEmpty) {
                    data.add(rowdatas);
                }
            }

        } catch (Exception e) {
            LOGGER.error("readFromXlsx error:{}", e);
            data = null;
        }
        return data;
    }


    public static String getStringCellValue(HSSFCell cell) {
        if (cell == null) {
            return "";
        }
        String strCell = "";
        switch (cell.getCellType()) {
            case HSSFCell.CELL_TYPE_STRING:
                strCell = cell.getStringCellValue();
                break;
            case HSSFCell.CELL_TYPE_NUMERIC:
                // 处理日期格式、时间格式
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    Date date = cell.getDateCellValue();
                    strCell = DateUtil.parseDateToStr(date, DateUtil.DATE_TIME_FORMAT_YYYY_MM_DD_HH_MI);
                } else {
                    double value = cell.getNumericCellValue();
                    strCell = String.valueOf((new Double(value)).longValue());
                }
                break;
            case HSSFCell.CELL_TYPE_BOOLEAN:
                strCell = String.valueOf(cell.getBooleanCellValue());
                break;
            case HSSFCell.CELL_TYPE_BLANK:
                strCell = "";
                break;
            default:
                strCell = "";
                break;
        }
        if (StringUtils.isBlank(strCell)) {
            return "";
        }
        if (StringUtils.isNoneBlank(strCell)) {
            strCell = strCell.trim();
        }
        return strCell;
    }

    public static String getStringXSSFCellValue(XSSFCell cell) {
        if (cell == null) {
            return "";
        }
        String strCell = "";
        switch (cell.getCellType()) {
            case XSSFCell.CELL_TYPE_STRING:
                strCell = cell.getStringCellValue();

                break;
            case XSSFCell.CELL_TYPE_NUMERIC:
                // 处理日期格式、时间格式
                if (HSSFDateUtil.isCellDateFormatted(cell)) {
                    Date date = cell.getDateCellValue();
                    strCell = DateUtil.parseDateToStr(date, DateUtil.DATE_TIME_FORMAT_YYYY_MM_DD_HH_MI);
                } else {
                    double value = cell.getNumericCellValue();
                    strCell = String.valueOf((new Double(value)).longValue());
                }
                // strCell = String.valueOf(cell.getNumericCellValue());
                break;
            case XSSFCell.CELL_TYPE_BOOLEAN:
                strCell = String.valueOf(cell.getBooleanCellValue());
                break;
            case XSSFCell.CELL_TYPE_BLANK:
                strCell = "";
                break;
            default:
                strCell = "";
                break;
        }
        if (StringUtils.isBlank(strCell)) {
            return "";
        }
        if (StringUtils.isNoneBlank(strCell)) {
            strCell = strCell.trim();
        }
        return strCell;
    }

    //-------------------------------------------------------------------------- 以map形式返回数据


    public static List<Map<Integer, String>> readFromXlsForMap(InputStream excelStream, final String suffix) {
        List<Map<Integer, String>> data = new ArrayList<>();
        try {
            POIFSFileSystem fs = new POIFSFileSystem(excelStream);
            Workbook book = new HSSFWorkbook(fs);
            HSSFSheet sheet = (HSSFSheet) book.getSheetAt(0);
            HSSFRow hSSFRow = null;
            Map<Integer, String> rowdatasMap = null;
            int rowsSize = sheet.getLastRowNum();
            for (int rows = 0; rows <= rowsSize; rows++) {
                // 取得某一行 对象
                hSSFRow = sheet.getRow(rows);
                if (hSSFRow == null) {
                    continue;
                }
                rowdatasMap = getRowDatesForSheetForXls(hSSFRow);
                if (!CollectionUtils.isEmpty(rowdatasMap)) {
                    data.add(rowdatasMap);
                }
            }
        } catch (Exception e) {
            LOGGER.error("readFromXls error:{}", e);
            data = null;
        }
        return data;
    }

    public static List<Map<Integer, String>> readFromXlsxForMap(InputStream excelStream, final String suffix) {
        List<Map<Integer, String>> data = new ArrayList<>();
        try {
            Workbook book = new XSSFWorkbook(excelStream);
            XSSFSheet sheet = (XSSFSheet) book.getSheetAt(0);
            // 遍历行获得每行信息
            Map<Integer, String> rowdatasMap = null;
            XSSFRow xSSFRow = null;
            int rowsSize = sheet.getLastRowNum();
            for (int rows = 0; rows <= rowsSize; rows++) {
                xSSFRow = sheet.getRow(rows);
                if (xSSFRow == null) {
                    continue;
                }
                rowdatasMap = getRowDatesForSheetForXlsx(xSSFRow);
                if (!CollectionUtils.isEmpty(rowdatasMap)) {
                    data.add(rowdatasMap);
                }
            }

        } catch (Exception e) {
            LOGGER.error("readFromXlsx error:{}", e);
            data = null;
        }
        return data;
    }

    //-----------------------------------------------将得到的excel行数据直接转换为 person 对象

    public static Map<Integer, String> getRowDatesForSheetForXls(HSSFRow hSSFRow) {
        if(Objects.isNull(hSSFRow)){
            return null;
        }
        Map<Integer, String> rowdatasMap = new HashMap<>(INIT_MAP_SIZE);
        boolean isEmpty = true;
        int columncount = hSSFRow.getLastCellNum();
        for (int i = 0; i < columncount; i++) {
            String cellValue = getStringCellValue(hSSFRow.getCell(i));
            rowdatasMap.put(i, cellValue);
            if (isEmpty && StringUtils.isNotBlank(cellValue)) {
                isEmpty = false;
            }
        }
        if (isEmpty) {
            rowdatasMap = null;
        }
        return rowdatasMap;
    }

    public static Map<Integer, String> getRowDatesForSheetForXlsx(XSSFRow xSSFRow) {
        Map<Integer, String> rowdatasMap = new HashMap<>(INIT_MAP_SIZE);
        if(Objects.isNull(xSSFRow)){
            return null;
        }
        boolean isEmpty = true;
        int columncount = xSSFRow.getLastCellNum();
        for (int i = 0; i < columncount; i++) {
            String cellValue = getStringXSSFCellValue(xSSFRow.getCell(i));
            rowdatasMap.put(i, cellValue);
            if (isEmpty && StringUtils.isNotBlank(cellValue)) {
                isEmpty = false;
            }
        }
        if (isEmpty) {
            rowdatasMap = null;
        }
        return rowdatasMap;
    }

}
