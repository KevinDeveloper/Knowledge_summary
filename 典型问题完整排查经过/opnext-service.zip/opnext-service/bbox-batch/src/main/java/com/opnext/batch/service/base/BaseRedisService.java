package com.opnext.batch.service.base;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @author wanglu
 */

@Repository
public class BaseRedisService {
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private RedisTemplate redisTemplate;

    /**
     * 保存数据，value数据为字符串
     * @param key
     * @param value
     */
    public  void setKey(String key,String value){
        ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
        ops.set(key,value);
    }

    public String getValue(String key){
        ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
        return ops.get(key);
    }

    /**
     * redis对list的操作
     * @param key
     * @param <T>
     * @return
     */
    public <T> List<T> getListValue(String key){
        ListOperations lops = this.redisTemplate.opsForList();
        return lops.range(key,0,lops.size(key)-1);
    }

    public long getListSize(String key){
        ListOperations lops = this.redisTemplate.opsForList();
        return lops.size(key);
    }

    public void setListValue(String key,List list){
        ListOperations lops = this.redisTemplate.opsForList();
        lops.leftPushAll(key,list);
    }

    /**
     * redis对Map的操作
     * @param key
     * @return
     */
    public Map<String,String> getAllMapValue(String key){
        return redisTemplate.opsForHash().entries(key);
    }

    public String getMapValue(String key,String hashKey){
        return (String)redisTemplate.opsForHash().get(key,hashKey);
    }

    public void setAllMapValue(String key,Map<String,String> map){
        redisTemplate.opsForHash().putAll(key,map);
    }

    public void setMapValue(String key,String hashKey,String value){
        redisTemplate.opsForHash().put(key,hashKey,value);
    }
    public void deleteMapHashKey(String key,String hashKey){
        redisTemplate.opsForHash().delete(key,hashKey);
    }

    /** -------------------分割线，以下为对象操作------------------- */
    /**
     * 保存对象值
     * @param key
     * @param value
     */
    public void set(String key, Object value){
        if (value == null) {
            return;
        }
        redisTemplate.opsForValue().set(key, value);
    }

    /**
     * 保存对象值，包含设置数据失效时间，时间单位
     * @param key
     * @param value
     * @param timeout
     */
    public void set(String key, Object value, Long timeout){
        if (value == null) {
            return;
        }
        redisTemplate.opsForValue().set(key, value, timeout);
    }

    /**
     * 保存对象值，包含设置数据失效时间，时间单位
     * @param key
     * @param value
     * @param timeout
     * @param unit
     */
    public void set(String key, Object value, Long timeout, TimeUnit unit){
        if (value == null) {
            return;
        }
        redisTemplate.opsForValue().set(key, value, timeout, unit);
    }

    /**
     * 根据key获取对象值
     * @param key
     * @return
     */
    public Object get(String key){
        return redisTemplate.opsForValue().get(key);
    }

    /** -------------------分割线，以下为通用操作------------------- */

    public void deleteKey(String key){
        redisTemplate.delete(key);
    }

}
