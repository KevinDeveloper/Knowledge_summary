package com.opnext.batch.service.person;

import com.opnext.batch.domain.MultipartFileResp;
import com.opnext.batch.domain.person.batchimport.BatchImportData;
import com.opnext.bboxdomain.OserviceOperator;

import java.io.File;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午5:05 18/5/7
 */
public interface PersonService {

    //-------------------------------------------------------

    /**
     * 检测某行数据对应的图片数据
     *
     * @param picName
     * @param avatarFileMap
     * @return
     * @throws Exception
     */
    Map<String, MultipartFileResp> checkImportDataPic(String picName, ConcurrentMap<String, File> avatarFileMap, OserviceOperator oserviceOperator) throws Exception;

    /**
     * 保存导入文件后的解析数据
     *
     * @param batchImportData
     * @throws Exception
     */
    void saveBatchImportData(BatchImportData batchImportData) throws Exception;

    /**
     * 清空之前的数据
     *
     * @param oserviceOperator
     * @throws Exception
     */
    void deleteBatchImportData(OserviceOperator oserviceOperator) throws Exception;


}

