package com.opnext.batch.util;

import java.util.UUID;

/**
 * @Title: 
 * @Description: 
 * @author tianzc
 * @Date 下午5:12 18/5/7
 */ 
public class UUIDUtil {

    public static String uuid(){
        return UUID.randomUUID().toString().replaceAll("-", "");
    }
}
