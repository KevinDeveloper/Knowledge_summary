package com.opnext.batch.service.person;

import com.opnext.batch.conf.GlobleConfig;
import com.opnext.batch.domain.person.batch.BatchStateBean;
import com.opnext.batch.domain.person.batch.BatchStateType;
import com.opnext.batch.redis.RedisCacheUtil;
import com.opnext.bboxdomain.OserviceOperator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

/**
 * @ClassName: BatchStateManageService
 * @Description: 人员批量导入管理类
 * @Author: Kevin
 * @Date: 2018/7/4 13:29
 */
@Slf4j
@Service
public class BatchStateManageService {

    /**
     * 数据缓存的时间(h)
     */
    public static final int BATCH_PERSON_CACHE_TIME = 24;
    /**
     * -1表示当前无租户批量导入
     */
    public static final Long BATCH_PERSON_USER_EMPTY = -1L;

    /**
     * 单个线程处理的数量
     */
    public static final Integer THRESHOLD = 50;

    /**
     * 批量导入状态值的key前缀
     */
    public static final String BATCH_PERSON_KEY_STATE = "batch_person_key_state";
    public static final String BATCH_PERSON_KEY_TOTAL = "batch_person_key_total";
    public static final String BATCH_PERSON_KEY_INDEX = "batch_person_key_index";
    public static final String BATCH_PERSON_KEY_USERID = "batch_person_key_userId";


    /**
     * 进行中时间，超过这个时间认为任务失败（分钟）
     */
    public static int BATCH_PERSON_UNDERWAR_TIME = 5;

    /**
     * 进行中的状态值key
     */
    public static final String BATCH_PERSON_KEY_UNDERWAY = "batch_person_key_underway";

    /**
     * 租户内key值唯一
     *
     * @param tenantId
     * @return
     */
    public static String getBatchPersonKey(long tenantId, String key) {
        return key + "_" + tenantId;
    }

    @Autowired
    private RedisCacheUtil redisCacheUtil;

    /**
     * 是否可以导入
     *
     * @param tenantId
     * @return
     */
    public boolean isUploadable(long tenantId) {
        boolean isUploadable = true;
        String key = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_STATE);
        if (redisCacheUtil.exists(key)) {
            Integer stateValue = redisCacheUtil.getCacheObject(key);
            if (Objects.nonNull(stateValue) && BatchStateType.STATE_UPLOADABLE.value() != stateValue) {
                isUploadable = false;
            }
        }
        return isUploadable;
    }


    /**
     * 设置状态值
     *
     * @param tenantId
     * @param batchStateVal
     */
    public void setBatchState(long tenantId, BatchStateType batchStateVal) {
        String key = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_STATE);
        redisCacheUtil.setCacheObject(key, batchStateVal.value(), GlobleConfig.ServiceBatch.cacheTime, TimeUnit.HOURS);
    }

    /**
     * 设置导入数据的总量
     *
     * @param tenantId
     * @param total
     */
    public void setBatchTotal(long tenantId, int total) {
        String key = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_TOTAL);
        redisCacheUtil.setCacheObject(key, total, GlobleConfig.ServiceBatch.cacheTime, TimeUnit.HOURS);
    }

    /**
     * 更新当前进度
     *
     * @param tenantId
     * @param index    )
     */
    public void updateBatchIndex(long tenantId, int index) {
        String key = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_INDEX);
        redisCacheUtil.incrementCacheObject(key, index, GlobleConfig.ServiceBatch.cacheTime, TimeUnit.HOURS);
    }

    /**
     * 设置当前批量导入 总状态，  开始加锁
     *
     * @param tenantId
     * @param batchStateBean
     */
    public void startAndReleaseBatchStateBean(long tenantId, BatchStateBean batchStateBean) {
        String keyState = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_STATE);
        String keyTotal = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_TOTAL);
        String keyIndex = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_INDEX);
        String keyUserId = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_USERID);
        Map<String, Object> map = new HashMap<>();
        map.put(keyState, batchStateBean.getBatchStateType());
        map.put(keyTotal, batchStateBean.getTotal());
        map.put(keyIndex, batchStateBean.getIndex());
        map.put(keyUserId, batchStateBean.getUserId());
        redisCacheUtil.multiSetCacheObject(map, GlobleConfig.ServiceBatch.cacheTime, TimeUnit.HOURS);
    }

    /**
     * 获取当前批量导入状态 总状态
     *
     * @param tenantId
     * @return
     */
    public BatchStateBean getBatchStateBean(long tenantId) {
        BatchStateBean stateBean = new BatchStateBean();
        String keyState = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_STATE);
        String keyTotal = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_TOTAL);
        String keyIndex = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_INDEX);
        String keyUserId = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_USERID);

        if (!redisCacheUtil.exists(keyState) ||
                !redisCacheUtil.exists(keyTotal) ||
                !redisCacheUtil.exists(keyIndex) ||
                !redisCacheUtil.exists(keyUserId)) {
            return stateBean;
        }
        List<String> keyList = new ArrayList<>();
        keyList.add(keyState);
        keyList.add(keyTotal);
        keyList.add(keyIndex);
        keyList.add(keyUserId);
        List<Object> valList = redisCacheUtil.multiGetCacheObject(keyList);
        if (!CollectionUtils.isEmpty(valList)) {
            switch (valList.size()) {
                case 4:
                    stateBean.setUserId((Long.valueOf(String.valueOf(valList.get(3)))));
                case 3:
                    stateBean.setIndex((Integer) valList.get(2));
                case 2:
                    stateBean.setTotal((Integer) valList.get(1));
                case 1:
                    stateBean.setBatchStateType((Integer) valList.get(0));
                default:

            }
        }
        return stateBean;
    }


    /**
     * 判断任务是否超过5分钟，用于判断异步任务是否已经挂了
     *
     * @param tenantId
     * @return
     */
    public boolean isExistUnderWayKey(long tenantId, String keyType) {
        boolean result = false;
        String underWayKey = getBatchPersonKey(tenantId, keyType);
        if (redisCacheUtil.exists(underWayKey)) {
            result = true;
        }
        return result;

    }

    /**
     * 更新存活时间
     *
     * @param tenantId
     */
    public void setUnderWay(long tenantId, String keyType) {
        String underWayKey = getBatchPersonKey(tenantId, keyType);
        redisCacheUtil.setCacheObject(underWayKey, underWayKey + "_" + System.currentTimeMillis(), BATCH_PERSON_UNDERWAR_TIME, TimeUnit.MINUTES);
    }


    /**
     * 获取状态值
     *
     * @param tenantId
     */
    public BatchStateType getBatchStateVal(long tenantId) {
        BatchStateType batchStateVal = null;
        String key = getBatchPersonKey(tenantId, BATCH_PERSON_KEY_STATE);
        if (!redisCacheUtil.exists(key)) {
            return batchStateVal;
        }
        int val = redisCacheUtil.getCacheObject(key);
        try {
            batchStateVal = BatchStateType.indexOfVal(val);
        } catch (IllegalArgumentException e) {
            log.error("获取批量导入状态异常，e={}", e);
            batchStateVal = null;
        }
        return batchStateVal;
    }

    /**
     * 生成批量导入的用户空间
     *
     * @param oserviceOperator
     * @return
     */
    public String getBatchUserRotPath(OserviceOperator oserviceOperator) {
        return "batch_temp" + File.separator + oserviceOperator.getTenantId() + "_" + oserviceOperator.getUserId() + "_batch";
    }

    /**
     * 设置批量导入的上传接口请求id
     * @param requestKey
     * @param requestId
     */
    public void setBatchRequestId(String requestKey, String requestId){
        redisCacheUtil.setCacheObject(requestKey, requestId, 24, TimeUnit.HOURS);
    }


    /**
     * 获取批量导入的上传接口请求id
     * @param requestKey
     * @return
     */
    public String getBatchRequestId(String requestKey){
        String requestId = redisCacheUtil.getCacheObject(requestKey);
        return requestId;
    }

}
