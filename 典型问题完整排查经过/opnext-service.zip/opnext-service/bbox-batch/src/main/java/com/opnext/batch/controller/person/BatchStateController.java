package com.opnext.batch.controller.person;

import com.opnext.batch.conf.OperatorContext;
import com.opnext.batch.domain.person.batch.BatchStateBean;
import com.opnext.batch.domain.person.batch.BatchStateType;
import com.opnext.batch.service.person.BatchStateManageService;
import com.opnext.batch.service.person.PersonService;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Objects;

/**
 * @ClassName: BatchStateController
 * @Description:
 * @Author: Kevin
 * @Date: 2018/7/4 19:56
 */
@Slf4j
@RestController
@RequestMapping("/api/batchState")
public class BatchStateController {

    @Autowired
    private BatchStateManageService batchStateManageService;

    @Autowired
    private PersonService personService;

    @ApiOperation(value = "获取批量导入当前状态和进度", notes = "获取批量导入当前状态和进度。返回值说明：batchStateType(批量上传状态)：可上传-0，解析中-1 ，可预览-2，导入中-3， 已导入-4 ，解析失败-5， 导入失败-6；total(解析的总数)；index(当前已解析数量)；userId(导入状态占有用户,-1表示无用户操作)；curUserBatch(是否当前用户，true 当前批量操作用户，false 非当前操作用户)")
    @RequestMapping(value = "/batchSateAndProgress", method = RequestMethod.GET)
    public CommonResponse getBatchState() throws Exception {
        log.info("获取批量导入当前状态和进度 - 开始");
        long start = System.currentTimeMillis();
        OserviceOperator oserviceOperator = OperatorContext.getOperator();
        long tenantId = oserviceOperator.getTenantId();
        long userId = oserviceOperator.getUserId();
        BatchStateBean batchStateBean = batchStateManageService.getBatchStateBean(tenantId);
        if (Objects.isNull(batchStateBean)) {
            throw new CommonException("person.batchAdd.batchstate.get.error");
        }
        //1、判断是否是当前用户
        if (BatchStateManageService.BATCH_PERSON_USER_EMPTY.longValue() != batchStateBean.getUserId()) {
            if (userId == batchStateBean.getUserId()) {
                batchStateBean.setCurUserBatch(true);
            } else {
                batchStateBean.setCurUserBatch(false);
            }
        }
        log.info("获取租户当前批量导入状态 ,batchStateBean={}", batchStateBean.toString());

        //判断当前状态是否是在 异步解析中
        if (batchStateBean.getBatchStateType() == BatchStateType.STATE_PARSING.value()) {
            log.debug("判断存活流程 - 1、当前状态为解析中");
            if (!batchStateManageService.isExistUnderWayKey(tenantId , BatchStateManageService.BATCH_PERSON_KEY_UNDERWAY)) {
                log.info("判断异步解析任务存活流程 - 存活标志超时未更新，判定异步解析任务异常，更新状态为失败, tenantId={}, userId={}", tenantId, userId);
                //设置状态 - 解析失败
                batchStateManageService.setBatchState(oserviceOperator.getTenantId(), BatchStateType.STATE_PARSE_FAIL);
                //清空当前租户内的批量导入临时数据
                try {
                    personService.deleteBatchImportData(oserviceOperator);
                } catch (Exception e1) {
                    log.error("解析失败, 清空临时数据, 异常e={}", e1);
                }

                batchStateBean.setBatchStateType(BatchStateType.STATE_PARSE_FAIL.value());
            }

        } else if (batchStateBean.getBatchStateType() == BatchStateType.STATE_IMPORTING.value()) {
            //判断当前状态是否是在 异步入库中
            log.debug("判断存活流程 - 1、当前状态为异步入库中");
            if (!batchStateManageService.isExistUnderWayKey(tenantId, BatchStateManageService.BATCH_PERSON_KEY_UNDERWAY)) {
                log.info("判断异步入库任务存活流程 - 存活标志超时未更新，判定异步入库任务异常，更新状态为失败, tenantId={}, userId={}", tenantId, userId);
                //更新导入状态 - 导入失败
                batchStateManageService.setBatchState(tenantId, BatchStateType.STATE_IMPORTE_FAIL);
                batchStateBean.setBatchStateType(BatchStateType.STATE_IMPORTE_FAIL.value());
            }
        }

        log.info("获取批量导入当前状态和进度 - 结束，耗时={}", (System.currentTimeMillis() - start));
        return CommonResponse.ok(batchStateBean);
    }


}
