package com.opnext.batch.feign;

import com.opnext.batch.feign.impl.BatchAuthorityHytrix;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @ClassName: BatchAuthorityFeign
 * @Description: 权限认证
 * @Author: Kevin
 * @Date: 2018/8/21 14:30
 */
@FeignClient(value = "bbox-service", fallbackFactory = BatchAuthorityHytrix.class)
public interface BatchAuthorityFeign {

    @RequestMapping(value = "/bbox-service/api/authority/_check", method = RequestMethod.GET)
    CommonResponse<OserviceOperator> checkAuthority(@RequestHeader(name = "param") String param, @RequestParam(name = "apiPath") String apiPath, @RequestParam(name = "method") String method) throws Exception;

}
