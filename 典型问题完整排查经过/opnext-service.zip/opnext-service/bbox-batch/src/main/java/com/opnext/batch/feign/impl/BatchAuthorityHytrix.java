package com.opnext.batch.feign.impl;

import com.opnext.batch.feign.BatchAuthorityFeign;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.advise.CommonResponse;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @ClassName: BatchAuthorityHytrix
 * @Description:
 * @Author: Kevin
 * @Date: 2018/7/30 17:20
 */
@Slf4j
@Component(value = "batchAuthorityHytrix")
public class BatchAuthorityHytrix implements FallbackFactory<BatchAuthorityFeign> {

    @Override
    public BatchAuthorityFeign create(Throwable throwable) {
        log.info("batchAuthorityHytrix   -------");
        return new BatchAuthorityFeign() {
            @Override
            public CommonResponse<OserviceOperator> checkAuthority(String param, String apiPath, String method) throws Exception {
                log.error("bbox-batch, 权限认证失败, throwable={}", throwable);
                return null;
            }
        };
    }
}
