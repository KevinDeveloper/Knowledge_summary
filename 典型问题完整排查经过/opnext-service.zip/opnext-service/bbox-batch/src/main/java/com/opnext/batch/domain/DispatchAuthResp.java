package com.opnext.batch.domain;

import lombok.Builder;
import lombok.Data;

/**
 * @ClassName: DispatchAuthResp
 * @Description:
 * @Author: Kevin
 * @Date: 2018/7/30 17:23
 */
@Data
@Builder
public class DispatchAuthResp {
    String clientId;
    String tenantId;
    String userId;
}
