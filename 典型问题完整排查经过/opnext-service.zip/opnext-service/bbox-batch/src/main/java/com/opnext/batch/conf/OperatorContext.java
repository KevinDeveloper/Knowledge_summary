package com.opnext.batch.conf;

import com.opnext.batch.domain.account.ApiOperator;
import com.opnext.bboxdomain.OserviceOperator;

/**
 * @author wanglu
 */
public class OperatorContext {
    private static ThreadLocal threadLocal = new ThreadLocal();

    public OperatorContext() {
    }

    public static OserviceOperator getOperator() {
        return (OserviceOperator)threadLocal.get();
    }

    public static void setOperator(OserviceOperator oserviceOperator) {
        threadLocal.set(oserviceOperator);
    }

    public static ApiOperator getApiOperator() {
        return (ApiOperator)threadLocal.get();
    }

    public static void setApiOperator(ApiOperator apiOperator) {
        threadLocal.set(apiOperator);
    }

    public static void remove() {
        threadLocal.remove();
    }
}
