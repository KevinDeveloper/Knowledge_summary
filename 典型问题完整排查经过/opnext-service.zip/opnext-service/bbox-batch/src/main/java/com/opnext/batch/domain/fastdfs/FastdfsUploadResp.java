package com.opnext.batch.domain.fastdfs;

import lombok.Data;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午4:54 18/5/11
 */
@Data
public class FastdfsUploadResp {
    private int code;
    private FastdfsEntity entity;
}
