package com.opnext.batch.conf;

import com.opnext.batch.interceptor.OperatorAuthInterceptor;
import com.opnext.batch.interceptor.OperatorInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * @ClassName: CommonWebConfig
 * @Description:
 * @Author: Kevin
 * @Date: 2018/7/30 17:20
 */
@Configuration
public class CommonWebConfig extends WebMvcConfigurerAdapter {

    @Bean
    public OperatorInterceptor operatorInterceptor() {
        return new OperatorInterceptor();
    }

    @Bean
    public OperatorAuthInterceptor operatorAuthInterceptor() {
        return new OperatorAuthInterceptor();
    }

    /**
     * 注册 拦截器
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(operatorInterceptor())
                .addPathPatterns("/api/person/batchAddPreview");
        registry.addInterceptor(operatorAuthInterceptor())
                .addPathPatterns("/api/*")
                .excludePathPatterns("/api/person/batchAddPreview");
        super.addInterceptors(registry);
    }

}