package com.opnext.batch.service.account;

import com.opnext.batch.domain.account.Account;
import com.opnext.batch.dto.PageFeign;
import com.opnext.batch.feign.UserCenterFeign;
import com.opnext.bboxsupport.advise.CommonResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wanglu
 */
@Service(value = "accountService")
@Slf4j
public class AccountService {
    @Resource
    private UserCenterFeign userCenter;

    public List<Account> getAccountList(Object... urlVariables)throws Exception {
        CommonResponse<PageFeign<Account>> entityResponse =userCenter.getAccountPage(urlVariables);
        return entityResponse.getEntity().getContent();
    }
}
