package com.opnext.batch.service;

import com.alibaba.fastjson.JSONObject;
import com.opnext.batch.conf.Constant;
import com.opnext.batch.conf.GlobleConfig;
import com.opnext.batch.domain.MultipartFileResp;
import com.opnext.batch.domain.algorithm.FaceDetectionResp;
import com.opnext.batch.domain.algorithm.Quality;
import com.opnext.batch.feign.AlgorithmFeign;
import com.opnext.batch.service.fastdfs.FastTmpFileManagerService;
import com.opnext.batch.util.DateUtil;
import com.opnext.batch.util.UUIDUtil;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboximage.OperateImage;
import com.opnext.bboximage.domain.algorithm.FaceLocation;
import com.opnext.bboximage.util.IOUtils;
import com.opnext.bboximage.util.ImageBase64;
import com.opnext.bboxsupport.advise.CommonException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.ApplicationHome;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.File;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * @author tianzc
 */
@Slf4j
@Component
public class ImageHandler {
    /**
     * 比对算法Feign
     */
    @Resource
    private AlgorithmFeign algorithmFeign;
    /**
     * 异步处理
     * 清除文件
     */
    @Resource
    private AsyncService asyncService;
    /**
     * 处理上传临时文件
     */
    @Resource
    private FastTmpFileManagerService fastTmpFileManagerService;
    @Resource
    private OperateImage operateImage;

    /**
     * 根据spring-multipartFile上传文件
     * @param multipartFile
     * @param oserviceOperator
     * @return
     * @throws Exception
     */
    public Map<String, MultipartFileResp> checkAndCutAndUploadImage(MultipartFile multipartFile, OserviceOperator oserviceOperator) throws Exception {
        Map<String, MultipartFileResp> map = new HashMap<>();
        String fileName = multipartFile.getOriginalFilename();
        // 文件格式校验
        checkFormat(multipartFile);
        InputStream inputStream = multipartFile.getInputStream();
        String imgBase64 = ImageBase64.getImageBase64Str(inputStream);
        // 关闭输入流
        IOUtils.closeQuietly(inputStream);
        // 文件检测，裁剪，上传文件服务器，返回文件id
        // 图片检测
        FaceLocation faceLocation = checkImageAlgorithm(imgBase64, GlobleConfig.AlgorithmConfig.qualityDetect);
        // 图片处理
        Optional<byte[]> optionalBytes = operateImage.cropImage(imgBase64, faceLocation);
        if (optionalBytes.isPresent()) {
            String fId = uploadImageSDK(optionalBytes.get(), fileName,oserviceOperator);
            String url = Constant.FASTDFS_SERVER_DOWNLOAD_URI + "/" + fId;
            MultipartFileResp fileResp = MultipartFileResp.builder()
                    .flag(true).fileName(fileName).url(url).build();
            map.put(fileName, fileResp);
        } else {
            MultipartFileResp fileResp = MultipartFileResp.builder()
                    .flag(false).fileName(fileName).message("imageFile.cut.exception").build();
            map.put(fileName, fileResp);
        }
        return map;
    }

    public Map<String, MultipartFileResp> checkAndCutAndUploadImage(File file, OserviceOperator oserviceOperator) throws Exception {
        Map<String, MultipartFileResp> map = new HashMap<>();
        String fileName = file.getName();
        // 文件格式校验
        checkFormat(file);
        String imgBase64 = ImageBase64.getImageBase64Str(file);
        // 图片检测
        FaceLocation faceLocation = checkImageAlgorithm(imgBase64, GlobleConfig.AlgorithmConfig.qualityDetect);
        // 图片处理
        Optional<byte[]> optionalBytes = operateImage.cropImage(imgBase64, faceLocation);
        if (optionalBytes.isPresent()) {
            String fId = uploadImageSDK(optionalBytes.get(), fileName, oserviceOperator);
            String url = Constant.FASTDFS_SERVER_DOWNLOAD_URI + "/" + fId;
            MultipartFileResp fileResp = MultipartFileResp.builder().flag(true).url(url).fileName(fileName).build();
            map.put(fileName, fileResp);
        } else {
            MultipartFileResp fileResp = MultipartFileResp.builder()
                    .flag(false).fileName(fileName).message("imageFile.cut.exception").build();
            map.put(fileName, fileResp);
        }
        return map;
    }

    /**
     * 使用SDK上传文件到文件服务器
     * @param imgData
     * @return
     * @throws Exception
     */
    public String uploadImageSDK(byte[] imgData,String fileName, OserviceOperator oserviceOperator) throws Exception {
        String imgFilePath = null;
        try{
            String dateStr = DateUtil.parseDateToStr(new Date(), "yyyy-MM-dd");
            ApplicationHome home = new ApplicationHome(getClass());
            String path = home.getDir().getAbsolutePath() + File.separator + "imgFiles" + File.separator +dateStr;
            imgFilePath = ImageBase64.generateImage(imgData, UUIDUtil.uuid(), "jpg", path);
            Optional<String> optional = fastTmpFileManagerService.uploadFileWithOriginalName(new File(imgFilePath),fileName, oserviceOperator);
            if (optional.isPresent()) {
                return optional.get();
            } else {
                log.error("==使用SDK上传文件异常fid：null");
                throw new CommonException("imageFile.upload.exception");
            }
        } catch (Exception e) {
            log.error("==使用SDK上传文件异常：{}", e);
            throw new CommonException("imageFile.upload.exception");
        } finally {
            asyncService.clearImgEmptyFile(imgFilePath);
        }
    }

    /**
     * 校验图片
     * @param imgBase64 图片base64
     * @param qualityDetect 是否进行质量检测，
     * @return
     */
    public FaceLocation checkImageAlgorithm(String imgBase64, Boolean qualityDetect) throws Exception {
        JSONObject jsonDetect = new JSONObject();
        jsonDetect.put("faceMaxNums", 8);
        jsonDetect.put("facePic", imgBase64);
        jsonDetect.put("qualityDetect", qualityDetect);
        long startTime = System.currentTimeMillis();
        FaceDetectionResp faceDetectionResp = algorithmFeign.detect(jsonDetect);
        long endTime = System.currentTimeMillis();
        log.info("running start Time : {}", (endTime - startTime));
        if (Objects.nonNull(faceDetectionResp)) {
            if (faceDetectionResp.getFaceNum() > 1) {
                log.info("==存在人脸数：{}", faceDetectionResp.getFaceNum());
                // 照片存在多个人脸
                throw new CommonException("algorithm.exception.more.face");
            } else if (faceDetectionResp.getFaceNum() > 0) {
                // 返回人脸坐标
                if (GlobleConfig.AlgorithmConfig.qualityDetect) {
                    checkQuality(faceDetectionResp.getResult().get(0).getQuality());
                }
                return faceDetectionResp.getResult().get(0).getFaceLocation();
            } else {
                // 无有效人脸
                log.info("==照片中无有效人脸");
                throw new CommonException("algorithm.exception.not.face");
            }
        } else {
            throw new CommonException("algorithm.exception");
        }
    }

    /**
     * 算法校验
     * @param quality
     * @throws Exception
     */
    public void checkQuality(Quality quality) throws Exception {
        if (Objects.isNull(quality)) {
            throw new CommonException("algorithm.exception");
        }
        log.info("==图片质量检测quality：{}", quality);
        // 标识清晰程度校验
        if (quality.getClearLevel() > GlobleConfig.AlgorithmQuality.clearLevel) {
            log.info("--图片质量检测-人脸模糊");
            throw new CommonException("algorithm.quality.clearLevel");
        }
        // 标识遮挡
        if (quality.getVisLevel() > GlobleConfig.AlgorithmQuality.visLevel) {
            log.info("==图片质量检测-人脸遮挡");
            throw new CommonException("algorithm.quality.visLevel");
        }
        // 标识眼镜
        if (GlobleConfig.AlgorithmConfig.qualityGlass) {
            if (quality.getGlassLevel() > GlobleConfig.AlgorithmQuality.glassLevel) {
                log.info("==图片质量检测-人脸戴墨镜");
                throw new CommonException("algorithm.quality.glassLevel");
            }
        }
        // 判断是否进行人脸角度检验
        if (GlobleConfig.AlgorithmConfig.qualityAngle) {
            // 照片检验角度
            if (quality.getYaw() > quality.getRegular() && quality.getYaw() > quality.getPitch()) {
                log.info("图片质量检测-人脸左右旋转的概率过大");
                throw new CommonException("algorithm.quality.yaw");
            } else if (quality.getPitch() > quality.getRegular() && quality.getPitch() > quality.getYaw()) {
                log.info("图片质量检测-人脸上下旋转的概率过大");
                throw new CommonException("algorithm.quality.pitch");
            } else {
                log.debug("人脸角度检测正常");
            }
        }
    }

    /**
     * 校验图片格式，大小，像素
     * 仅支持照片上传，jpg、png、bmp格式，照片尺寸不低于320*320px，照片最大为10MB
     * @param multipartFile
     * @throws Exception
     */
    public void checkFormat(MultipartFile multipartFile) throws Exception{
        boolean flag = operateImage.checkFormatMultipartFile(multipartFile);
        if (!flag) {
            throw new CommonException("imageFile.check.format");
        }
        // 校验图片大小
        flag = operateImage.checkSizeMultipartFile(multipartFile);
        if (!flag) {
            throw new CommonException("imageFile.check.max.size");
        }
        // 校验图片像素
        flag = operateImage.checkImagePixelMultipartFile(multipartFile);
        if (!flag) {
            throw new CommonException("imageFile.check.min.pixel");
        }
    }

    /**
     * 校验图片格式，大小，像素
     * 仅支持照片上传，jpg、png、bmp格式，照片尺寸不低于320*320px，照片最大为10MB
     * @param imgFile
     * @throws Exception
     */
    public void checkFormat(File imgFile) throws Exception{
        boolean flag = operateImage.checkFormatFile(imgFile);
        if (!flag) {
            throw new CommonException("imageFile.check.format");
        }
        // 校验图片大小
        flag = operateImage.checkSizeFile(imgFile);
        if (!flag) {
            throw new CommonException("imageFile.check.max.size");
        }
        // 校验图片像素
        flag = operateImage.checkImagePixelFile(imgFile);
        if (!flag) {
            throw new CommonException("imageFile.check.min.pixel");
        }
    }
}
