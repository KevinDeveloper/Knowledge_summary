package com.opnext.batch.service;

/**
 * @author tianzc
 */
public interface AsyncService {

    /**
     * 删除指定文件，删除两天前文件夹
     *
     * @param imgFilePath
     */
    void clearImgEmptyFile(String imgFilePath);



}
