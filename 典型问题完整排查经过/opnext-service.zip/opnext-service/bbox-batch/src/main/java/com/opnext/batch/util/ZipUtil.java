package com.opnext.batch.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;
import org.apache.tools.zip.ZipOutputStream;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipInputStream;

/**
 * @ClassName: ZipUtil
 * @Description:
 * @Author: Kevin
 * @Date: 2018/6/6 14:21
 */
@Slf4j
public class ZipUtil {
    private static byte[] dateByte = new byte[1024];

    private static final String ENCODE_UTF_8 = "UTF-8";
    private static final String SUFF_NAME =".zip";

    /**
     * 压缩文件或路径
     *
     * @param zip      压缩的目的地址  例如：D://zipTest.zip
     * @param srcFiles 压缩的源文件
     */
    public static void zipFile(String zip, List<File> srcFiles) {
        try {
                //判断是否为压缩后的文件后缀是否为.zip结尾
            if (zip.endsWith(SUFF_NAME) || zip.endsWith(SUFF_NAME)) {
                ZipOutputStream zipOut = new ZipOutputStream(new FileOutputStream(new File(zip)));
                //设置编码
                zipOut.setEncoding(ENCODE_UTF_8);
                for (File tempFile : srcFiles) {
                    zipFile(zip, zipOut, tempFile, "");
                }
                zipOut.close();
            } else {
                log.info("target file[ {} ] is not .zip type file", zip);
            }
        } catch (FileNotFoundException e) {

        } catch (IOException e) {
        }
    }


    /**
     * @param zip     压缩的目的地址  例如：D://zipTest.zip
     * @param zipOut
     * @param srcFile 被压缩的文件
     * @param path    在zip中的相对路径
     * @throws IOException
     */
    private static void zipFile(String zip, ZipOutputStream zipOut, File srcFile, String path) throws IOException {
        log.info(" 开始压缩文件[ {} ]", srcFile.getName());
        if (!"".equals(path) && !path.endsWith(File.separator)) {
            path += File.separator;
        }
        //测试此抽象路径名定义的文件或目录是否存在
        if (!srcFile.exists()) {
            log.info("压缩失败，文件或目录 {} 不存在!", srcFile);
        } else {
            if (!srcFile.getPath().equals(zip)) {
                if (srcFile.isDirectory()) {
                    //listFiles能够获取当前文件夹下的所有文件和文件夹，如果文件夹A下还有文件D，那么D也在childs里。
                    File[] files = srcFile.listFiles();
                    if (files.length == 0) {
                        zipOut.putNextEntry(new ZipEntry(path + srcFile.getName() + File.separator));
                        zipOut.closeEntry();
                    } else {
                        for (File tempFile : files) {
                            zipFile(zip, zipOut, tempFile, path + srcFile.getName());
                        }
                    }
                } else {
                    FileInputStream fileInputStream = new FileInputStream(srcFile);
                    zipOut.putNextEntry(new ZipEntry(path + srcFile.getName()));
                    int len = 0;
                    while ((len = fileInputStream.read(dateByte)) > 0) {
                        zipOut.write(dateByte, 0, len);
                    }
                    fileInputStream.close();
                    zipOut.closeEntry();
                }
            }
        }
    }

    /**
     * 解压缩ZIP文件，将ZIP文件里的内容解压到targetDIR目录下
     *
     * @param zipPath 待解压缩的ZIP文件名
     * @param descDir 目标目录
     */
    public static List<File> upzipFile(String zipPath, String descDir) {
        return upzipFile(new File(zipPath), descDir);
    }

    /**
     * 对.zip文件进行解压缩
     *
     * @param zipFile 解压缩文件
     * @param descDir 压缩的目标地址，如：D:\\测试 或 /mnt/d/测试
     * @return
     */
    @SuppressWarnings("rawtypes")
    public static List<File> upzipFile(File zipFile, String descDir) {
        List<File> fileList = new ArrayList<File>();
        try {
            if (!zipFile.exists()) {
                log.info("解压失败，文件 {} 不存在!", zipFile);
                return fileList;
            }
            ZipFile zipfile = new ZipFile(zipFile, ENCODE_UTF_8);
            for (Enumeration entries = zipfile.getEntries(); entries.hasMoreElements(); ) {
                ZipEntry entry = (ZipEntry) entries.nextElement();
                File file = new File(descDir + File.separator + entry.getName());
                if (entry.isDirectory()) {
                    file.mkdirs();
                } else {
                    File parentFile = file.getParentFile();
                    if (!parentFile.exists()) {
                        parentFile.mkdirs();
                    }
                    InputStream inputStream = zipfile.getInputStream(entry);
                    OutputStream outputStream = new FileOutputStream(file);
                    int len = 0;
                    while ((len = inputStream.read(dateByte)) > 0) {
                        outputStream.write(dateByte, 0, len);
                    }
                    inputStream.close();
                    outputStream.flush();
                    outputStream.close();
                    fileList.add(file);
                }
            }
        } catch (IOException e) {
            log.error("e = {}",e);
        }
        return fileList;
    }

    @SuppressWarnings("rawtypes")
    public static List<File> upzipfileLft(File zipFile, String descDir) {
        List<File> fileList = new ArrayList<File>();
        ZipInputStream zipInputStream = null;
        BufferedInputStream bufferedInputStream = null;
        try {
            if (!zipFile.exists()) {
                log.info("解压失败，文件 {} 不存在!", zipFile);
                return fileList;
            }
            // ZipInputStream读取压缩文件
            zipInputStream = new ZipInputStream(new FileInputStream(zipFile), Charset.forName("GBK"));
            // 写入到缓冲流中
            bufferedInputStream = new BufferedInputStream(zipInputStream);
            // 读取压缩文件中的一个文件
            java.util.zip.ZipEntry zipEntry = null;
            File fileOut = null;
            FileOutputStream fileOutputStream = null;
            BufferedOutputStream bufferedOutputStream = null;
            while ((zipEntry = zipInputStream.getNextEntry()) != null) {
                fileOut = new File(descDir + File.separator + zipEntry.getName());

                // 若当前zipEntry是一个文件夹
                if (zipEntry.isDirectory()) {
                    // 在指定路径下创建文件夹
                    if (!fileOut.exists()) {
                        fileOut.mkdirs();
                    }
                } else {
                    //若是文件
                    // 原文件名与指定路径创建File对象(解压后文件的对象)
                    fileOut = new File(descDir, zipEntry.getName());
                    File parentFile = fileOut.getParentFile();
                    if (!parentFile.exists()) {
                        parentFile.mkdirs();
                    }
                    fileOutputStream = new FileOutputStream(fileOut);
                    bufferedOutputStream = new BufferedOutputStream(fileOutputStream);
                    //将文件写入到指定file中
                    int b = 0;
                    while ((b = bufferedInputStream.read()) != -1) {
                        bufferedOutputStream.write(b);
                    }
                    bufferedOutputStream.close();
                    fileOutputStream.close();
                    fileList.add(fileOut);
                }
            }


        } catch (Exception e) {
            log.error("e={}",e);
        } finally {
            try {
                if (null != bufferedInputStream) {
                    bufferedInputStream.close();
                }
            } catch (IOException e) {
               log.error(" bufferedInputStream.close()，e={}",e);
            }
            if (null != zipInputStream) {
                try {
                    zipInputStream.close();
                } catch (IOException e) {
                    log.error("zipInputStream.close()，e={}",e);
                }
            }
        }
        return fileList;
    }

    /**
     * 对临时生成的文件夹和文件夹下的文件进行删除
     */
    public static void deletefile(String delpath) {
        try {
            File file = new File(delpath);
            if (!file.exists()) {
                return;
            }
            //判断是不是一个目录
            if (!file.isDirectory()) {
                file.delete();
            } else if (file.isDirectory()) {
                String[] filelist = file.list();
                for (int i = 0; i < filelist.length; i++) {
                    File delfile = new File(delpath + File.separator + filelist[i]);
                    if (!delfile.isDirectory()) {
                        delfile.delete();
                    } else if (delfile.isDirectory()) {
                        //递归删除
                        deletefile(delpath + File.separator + filelist[i]);
                    }
                }
                file.delete();
            }
        } catch (Exception e) {
            log.error("e = {}",e);
        }
    }

    /**
     * 将存放在sourceFilePath目录下的源文件，打包成fileName名称的zip文件，并存放到zipFilePath路径下
     *
     * @param sourceFilePath  :待压缩的文件路径
     * @param zipFilePathName :压缩后文件的路径和名称
     * @return
     */
    public static boolean fileToZip(String sourceFilePath, String zipFilePathName) {
        boolean flag = false;
        File sourceFile = new File(sourceFilePath);
        FileInputStream fis = null;
        BufferedInputStream bis = null;
        FileOutputStream fos = null;
        ZipOutputStream zos = null;
        int bufInputSize = 1024 * 10;
        if (!sourceFile.exists()) {
            log.info("待压缩的文件目录：" + sourceFilePath + "不存在.");
        } else {
            try {
                File zipFile = new File(zipFilePathName);
                if (zipFile.exists()) {
                    log.info("目录下存在名字为:" + zipFilePathName + "打包文件.");
                    zipFile.delete();
                    log.info("删除已存在的打包文件");
                }
                File[] sourceFiles = sourceFile.listFiles();
                if (null == sourceFiles || sourceFiles.length < 1) {
                    log.info("待压缩的文件目录：" + sourceFilePath + "里面不存在文件，无需压缩.");
                } else {
                    fos = new FileOutputStream(zipFile);
                    zos = new ZipOutputStream(new BufferedOutputStream(fos));
                    byte[] bufs = new byte[1024 * 10];
                    for (int i = 0; i < sourceFiles.length; i++) {
                        if (sourceFiles[i] == null || sourceFiles[i].mkdir()) {
                            continue;
                        }
                        //创建ZIP实体，并添加进压缩包
                        ZipEntry zipEntry = new ZipEntry(sourceFiles[i].getName());
                        zos.putNextEntry(zipEntry);
                        //读取待压缩的文件并写进压缩包里
                        fis = new FileInputStream(sourceFiles[i]);
                        bis = new BufferedInputStream(fis, bufInputSize);
                        int read = 0;
                        while ((read = bis.read(bufs, 0, bufInputSize)) != -1) {
                            zos.write(bufs, 0, read);
                        }
                        bis.close();
                        fis.close();
                        zos.closeEntry();

                    }
                    flag = true;
                }


            } catch (FileNotFoundException e) {
                log.error("e = {}",e);
                throw new RuntimeException(e);
            } catch (IOException e) {
                log.error("e = {}",e);
                throw new RuntimeException(e);
            } finally {
                //关闭流
                try {
                    if (null != bis) {
                        bis.close();
                    }
                    if (null != fis) {
                        fis.close();
                    }
                    if (null != zos) {
                        zos.close();
                    }
                    if (null != fos) {
                        fos.close();
                    }

                } catch (IOException e) {
                    log.error("e = {}",e);
                    throw new RuntimeException(e);
                }
            }
        }
        return flag;
    }
//    public static void main(String[] args) {
//        String zip = "D://zipTest.zip";
//        List<File> srcFiles = new ArrayList<>();
//        srcFiles.add(new File("D://testZip"));
//        srcFiles.add(new File("D://999"));
//        zipFile(zip, srcFiles);
//
//        List<File> list = upzipFile("D://zipTest.zip", "D://Solin");
//        for(File file : list){
//            System.out.println(file.getName());
//        }
//        //deletefile(zip);
//    }
}
