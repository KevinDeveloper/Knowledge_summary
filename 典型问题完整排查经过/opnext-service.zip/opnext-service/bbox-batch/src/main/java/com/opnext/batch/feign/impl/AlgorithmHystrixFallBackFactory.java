package com.opnext.batch.feign.impl;

import com.alibaba.fastjson.JSONObject;
import com.opnext.batch.domain.algorithm.FaceDetectionResp;
import com.opnext.batch.feign.AlgorithmFeign;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author tianzc
 */
@Slf4j
@Component("algorithmHystrixFallBackFactory")
public class AlgorithmHystrixFallBackFactory implements FallbackFactory<AlgorithmFeign> {
    @Override
    public AlgorithmFeign create(Throwable throwable) {
        log.info("call AlgorithmFeign create error");
        return new AlgorithmFeign(){

            /**
             * 图片比对检测图片，返回人脸坐标
             *
             * @param object
             * @return
             */
            @Override
            public FaceDetectionResp detect(JSONObject object) {
                log.error("call AlgorithmFeign detect error", throwable);
                return null;
            }
        };
    }
}
