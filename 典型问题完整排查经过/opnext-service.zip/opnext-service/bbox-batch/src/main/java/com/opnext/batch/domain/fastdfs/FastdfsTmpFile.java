package com.opnext.batch.domain.fastdfs;

import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

/**
 * @ClassName: fastdfs
 * @Description: fastdfs 临时文件
 * @Author: Kevin
 * @Date: 2018/8/28 15:58
 */
@Entity
@Data
@Table(name = "fastdfs_temp_file")
@EntityListeners(AuditingEntityListener.class)
public class FastdfsTmpFile {

    @Id
    @GeneratedValue
    @Column(name = "id")
    private Long id;

    /**
     * fileId
     */
    @Column(name = "file_id")
    private String fileId;

    /**
     * 创建时间
     */
    @Column(name = "create_time")
    @CreatedDate
    private Date createTime;

    /**
     * 失效时间点
     */
    @Column(name = "expire_time")
    private Date expireTime;


    @Column(name = "tenant_id")
    private Long tenantId;
    @Column(name = "user_id")
    private Long userId;


}
