package com.opnext.batch.conf;

import com.opnext.batch.filter.CommonContextFilter;
import com.opnext.batch.filter.OperatorFilter;
import com.opnext.batch.filter.UrlFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * @author wanglu
 */
@Configuration
public class BboxBatchFilterRegistry {


    @Bean
    public FilterRegistrationBean registerOperator(){

        String excludesPath = "/api/devapi/**,/api/error,/api/person/batchAddPreview";
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(new OperatorFilter());
        registration.setName("operatorFilter");
        registration.addUrlPatterns("/api/*");
        registration.setOrder(100);

        registration.addInitParameter("excludes", excludesPath);

        return registration;
    }

    @Bean
    public FilterRegistrationBean registerUrl(){
        FilterRegistrationBean registration = new FilterRegistrationBean(new UrlFilter());
        registration.addUrlPatterns("/*");
        registration.setOrder(101);
        return registration;
    }

    @Bean
    public FilterRegistrationBean registerContext(){
        FilterRegistrationBean registration = new FilterRegistrationBean(new CommonContextFilter());
        registration.addUrlPatterns("/*");
        registration.setOrder(102);
        return registration;
    }

}
