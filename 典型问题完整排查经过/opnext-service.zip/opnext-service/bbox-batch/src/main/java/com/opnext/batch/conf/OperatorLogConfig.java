package com.opnext.batch.conf;

import com.opnext.batch.interceptor.OperatorLogsInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

/**
 * @ClassName: CommonWebConfig
 * @Description:
 * @Author: Kevin
 * @Date: 2018/7/30 17:20
 */
@Configuration
public class OperatorLogConfig extends WebMvcConfigurerAdapter {

    @Bean
    public OperatorLogsInterceptor operatorLogsInterceptor() {
        return new OperatorLogsInterceptor();
    }

    /**
     * 注册 拦截器
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(operatorLogsInterceptor())
                .addPathPatterns("/api/**");
        super.addInterceptors(registry);
    }


}