package com.opnext.batch.conf;

import lombok.Data;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午6:57 18/5/11
 */
@Slf4j
@Configuration
public class GlobleConfig {

    @Configuration
    @ConfigurationProperties(prefix = "remote-rest.server")
    public static class ServerUrl {
        @Setter
        public static String fastdfsGatewayHost;
        public static String getFastdfsGatewayHost(String scheme) {
            UriComponents uriComponents = UriComponentsBuilder.newInstance().scheme(scheme).host(fastdfsGatewayHost).build();
            try {
                uriComponents.toUri();
            } catch (Exception e) {
                log.error("scheme或host不合法，scheme = {}，fastdfsHost = {}",scheme, fastdfsGatewayHost, e);
            }
            return uriComponents.toUriString();
        }
    }

    @Configuration
    @ConfigurationProperties(prefix = "algorithm.config")
    public static class AlgorithmConfig {
        @Setter
        public static Boolean qualityDetect;
        /**
         * 是否开启遮挡校验标志
         */
        @Setter
        public static Boolean qualityVisible;
        /**
         * 是否开启模糊校验标志
         */
        @Setter
        public static Boolean qualityClear;
        @Setter
        public static Boolean qualityAngle;
        @Setter
        public static Boolean qualityGlass;
    }
    @Configuration
    @ConfigurationProperties(prefix = "algorithm.quality")
    public static class AlgorithmQuality {
        @Setter
        public static Double clearLevel;
        @Setter
        public static Double visLevel;
        @Setter
        public static Double glassLevel;
    }
    @Configuration
    @ConfigurationProperties(prefix = "service.config")
    public static class ServerConfig {
        @Setter
        public static Boolean urlStoreRelative;
        @Setter
        public static String version;
        @Setter
        public static Boolean isSecurity;
    }

    @Configuration
    @ConfigurationProperties(prefix = "service.image")
    public static class ServiceImage {
        @Setter
        public static Integer minWidth;
        @Setter
        public static Integer minHeight;
        @Setter
        public static Integer maxSize;
        @Setter
        public static Integer maxThreadCount;
        @Setter
        public static Integer maxCountLimit;
    }

    @Configuration
    @ConfigurationProperties(prefix = "service.person")
    public static class servicePerson {
        @Setter
        public static String pwdKey;
        @Setter
        public static String type;
        @Setter
        public static String commonPassword;
    }

    @Configuration
    @ConfigurationProperties(prefix = "service.messages")
    @Data
    public class ServerMessages {
        public List<String> language;
    }


    @Configuration
    @ConfigurationProperties(prefix = "service.batch")
    public static class ServiceBatch {
        @Setter
        public static Integer threadNum;
        @Setter
        public static Integer batchThreshold;
        @Setter
        public static Integer cacheTime;
    }

}
