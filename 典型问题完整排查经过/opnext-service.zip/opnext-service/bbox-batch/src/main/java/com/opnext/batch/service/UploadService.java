package com.opnext.batch.service;

import com.opnext.batch.domain.MultipartFileResp;
import com.opnext.bboxdomain.OserviceOperator;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午3:18 18/5/9
 */
public interface UploadService {
    /**
     * 可见光照片上传
     *
     * @param multipartFile
     * @return
     */
    @Deprecated
    Map<String, MultipartFileResp> uploadImage(MultipartFile multipartFile,OserviceOperator oserviceOperator) throws Exception;

    /**
     * 批量上传文件照片
     *
     * @param multipartFiles
     * @return
     * @throws Exception
     */
    @Deprecated
    Map<String, MultipartFileResp> batchUploadImage(List<MultipartFile> multipartFiles,OserviceOperator oserviceOperator) throws Exception;

    /**
     * 批量上传文件照片（用于人员批量上传）
     * @param multipartFiles
     * @return
     * @throws Exception
     */
    Map<String, MultipartFileResp> batchUploadImageForFile(List<File> multipartFiles,OserviceOperator oserviceOperator) throws Exception;
}
