package com.opnext.batch.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opnext.batch.conf.OperatorContext;
import com.opnext.batch.domain.account.Account;
import com.opnext.batch.service.account.AccountService;
import com.opnext.batch.util.AntPathRequestMatcher;
import com.opnext.bboxdomain.OserviceOperator;
import com.opnext.bboxsupport.util.Messages;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/**
 * @author wanglu
 */
@Slf4j
public class OperatorFilter implements Filter{
    private List<AntPathRequestMatcher> matchers = new ArrayList();

    private AccountService accountService;

    @Override
    public void init(FilterConfig config) throws ServletException {
        String excludePath = this.getParameter(config, "excludes");
        if (excludePath != null && excludePath.length() > 0) {
            String[] paths = excludePath.split(",");
            String[] var4 = paths;
            int var5 = paths.length;

            for(int var6 = 0; var6 < var5; ++var6) {
                String path = var4[var6];
                this.matchers.add(new AntPathRequestMatcher(path));
            }
        }
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        this.doFilter((HttpServletRequest)request, (HttpServletResponse)response, chain);
    }

    public void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        boolean ignore = this.isExcludePath(request);
        if (ignore){
            chain.doFilter(request, response);
        }else if (this.checkHeader(request)){
            try {
                chain.doFilter(request, response);
            } catch (Exception var10) {
                response.sendError(401);
                OperatorContext.remove();
            }
        }else{
            response.sendError(401);
            OperatorContext.remove();
        }
    }

    private boolean checkHeader(HttpServletRequest request) throws IOException{
        String jsonStr = request.getHeader("param");
        String appStore = "0";
        log.info("从header中取出参数 param,{}",jsonStr);
        if (StringUtils.isBlank(jsonStr)){
            return false;
        }
        ObjectMapper objectMapper = new ObjectMapper();
        OserviceOperator oserviceOperator = objectMapper.readValue(jsonStr,OserviceOperator.class);
        oserviceOperator.setUserType(OserviceOperator.UserType.COMMON);
        if (appStore.equals(oserviceOperator.getAppId()) && Objects.isNull(oserviceOperator.getUserId())){
            oserviceOperator.setUserType(OserviceOperator.UserType.GLOBAL);
        }
        if (Objects.isNull(oserviceOperator.getUserId())){
            oserviceOperator.setUserType(OserviceOperator.UserType.API);
        }else {
            try {
                if (Objects.isNull(accountService)) {
                    BeanFactory factory = WebApplicationContextUtils.getRequiredWebApplicationContext(request.getServletContext());
                    accountService = (AccountService) factory.getBean("accountService");
                }
                List<Account> accounts = accountService.getAccountList(Account.builder().id(oserviceOperator.getUserId()).tenantId(oserviceOperator.getTenantId()).build());
                Account account = accounts.get(0);
                if (account.getStatus()==0){
                    log.error("当前账号的状态是停用");
                    return false;
                }
                if (account.getIsRoot()){
                    oserviceOperator.setUserType(OserviceOperator.UserType.SUPER);
                }
                oserviceOperator.setLoginName(account.getLoginName());
            }catch (Exception e){
                log.error("判断账号当前状态异常，无法调用用户中心获取账号信息的接口，{}",e);
                return false;
            }
        }
        /**
         * 设置当前用户登录的语言环境
         */
        oserviceOperator.setCurLocale(Messages.getLocale());
        OperatorContext.setOperator(oserviceOperator);
        return true;
    }

    private boolean isExcludePath(HttpServletRequest request) {
        Iterator var2 = this.matchers.iterator();

        AntPathRequestMatcher matcher;
        do {
            if (!var2.hasNext()) {
                return false;
            }

            matcher = (AntPathRequestMatcher)var2.next();
        } while(!matcher.matches(request));

        return true;
    }

    private String getParameter(FilterConfig config, String param) {
        String value = config.getInitParameter(param);
        return value;
    }

    @Override
    public void destroy() {
        // do nothing
    }

}
