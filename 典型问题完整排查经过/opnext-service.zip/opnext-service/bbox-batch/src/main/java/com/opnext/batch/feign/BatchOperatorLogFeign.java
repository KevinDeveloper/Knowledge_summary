package com.opnext.batch.feign;

import com.opnext.batch.feign.impl.BatchAuthorityHytrix;
import com.opnext.batch.feign.impl.BatchOperatorLogHytrix;
import com.opnext.bboxdomain.log.LogReq;
import com.opnext.bboxsupport.advise.CommonResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @ClassName: BatchOperatorLogFeign
 * @Description: 操作日志
 * @Author: Kevin
 * @Date: 2018/8/21 14:30
 */
@FeignClient(value = "bbox-service", fallbackFactory = BatchOperatorLogHytrix.class)
public interface BatchOperatorLogFeign {

    @RequestMapping(value = "/bbox-service/log/operation", method = RequestMethod.POST)
    CommonResponse sendOperatorLog(LogReq logReq) throws Exception;

}
