package com.opnext.batch.domain.fastdfs;

import lombok.Data;

/**
 * @author tianzc
 * @Title:
 * @Description:
 * @Date 下午4:56 18/5/11
 */
@Data
public class FastdfsItem {
    private String param;
    private String fileName;
    private String fid;
    private String md5;
}
