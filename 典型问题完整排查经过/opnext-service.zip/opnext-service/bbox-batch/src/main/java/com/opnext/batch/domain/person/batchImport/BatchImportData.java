package com.opnext.batch.domain.person.batchimport;

import com.opnext.batch.domain.MultipartFileResp;
import com.opnext.batch.domain.converter.BatchImportPicRespConverter;
import com.opnext.batch.domain.converter.BatchImportRowDataConverter;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;
import java.util.Map;

/**
 * @ClassName: BatchImportData
 * @Description: 批量导入的数据
 * @Author: Kevin
 * @Date: 2018/7/10 16:31
 */
@Entity
@Data
@Table(name = "batch_data")
@EntityListeners(AuditingEntityListener.class)
public class BatchImportData {
    @Id
    @GeneratedValue
    @Column(name = "id")
    private Long id;
    @Column(name = "tenant_id")
    private Long tenantId;
    @Column(name = "user_id")
    private Long userId;
    @Column(name = "order_id")
    private Integer order;

    @Column(name = "pic_resp")
    @Convert(converter = BatchImportPicRespConverter.class)
    private Map<String, MultipartFileResp> picResp;

    @Column(name = "row_data")
    @Convert(converter = BatchImportRowDataConverter.class)
    private Map<Integer, String> rowdata;

    @Column(name = "import_result_flag")
    private boolean importResultFlag = true;
    @Column(name = "import_result_text")
    private String importResultText="";

    @Column(name="create_time")
    @CreatedDate
    private Date createTime;
    @Column(name="update_time")
    @LastModifiedDate
    private Date updateTime;

}
