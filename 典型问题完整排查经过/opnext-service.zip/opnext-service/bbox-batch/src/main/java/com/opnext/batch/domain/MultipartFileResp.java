package com.opnext.batch.domain;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * @author tianzc
 */
@Data
@Builder
public class MultipartFileResp implements Serializable {
    /**
     * 上传成功失败标志
     */
    private boolean flag;
    /**
     * 文件访问地址
     */
    private String url;
    /**
     * 消息
     */
    private String message;
    /**
     * 上传文件原名称
     */
    private String fileName;
}
