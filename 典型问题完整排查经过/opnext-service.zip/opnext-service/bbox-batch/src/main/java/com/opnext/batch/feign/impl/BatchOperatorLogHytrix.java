package com.opnext.batch.feign.impl;

import com.opnext.batch.feign.BatchOperatorLogFeign;
import com.opnext.bboxdomain.log.LogReq;
import com.opnext.bboxsupport.advise.CommonResponse;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @ClassName: BatchOperatorLogHytrix
 * @Description:
 * @Author: Kevin
 * @Date: 2018/7/30 17:20
 */
@Slf4j
@Component(value = "batchOperatorLogHytrix")
public class BatchOperatorLogHytrix implements FallbackFactory<BatchOperatorLogFeign> {

    @Override
    public BatchOperatorLogFeign create(Throwable throwable) {
        log.info("batchOperatorLogHytrix   -------");
        return new BatchOperatorLogFeign() {
            @Override
            public CommonResponse sendOperatorLog(LogReq logReq) throws Exception {
                log.error("bbox-batch, 添加操作日志失败, throwable={}", throwable);
                return null;
            }
        };
    }
}
