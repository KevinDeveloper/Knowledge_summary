package com.opnext.batch.util;

/**
 * @ClassName: MyThread
 * @Description:
 * @Author: Kevin
 * @Date: 2018/9/5 16:04
 */
public class MyThread extends Thread {
    @Override
    public void run() {
        try {
            Thread.currentThread().setName("aaaaa");
            int count = 0;
            while (true) {
                System.out.println("aaaaa----: " + count);
                Thread.sleep(2000);
                count++;
            }
        } catch (Exception e) {

        }


    }

    /**
     * Cannot instantiate.
     */

    @Override
    public void finalize() throws Throwable {
        System.out.println("MyThread finalize");
        super.finalize();
    }
}
