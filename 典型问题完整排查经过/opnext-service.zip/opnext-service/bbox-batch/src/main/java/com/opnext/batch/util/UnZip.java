package com.opnext.batch.util;

import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;


/**
 * @ClassName: UnZip
 * @Description:
 * @Author: Kevin
 * @Date: 2018/10/19 14:21
 */

@Slf4j
public class UnZip {

    public static List<File> unzip(String zipFilePath, String destDir) {
        System.setProperty("sun.zip.encoding", System.getProperty("sun.jnu.encoding")); //防止文件名中有中文时出错
        //System.out.println(System.getProperty("sun.zip.encoding")); //ZIP编码方式
        //System.out.println(System.getProperty("sun.jnu.encoding")); //当前文件编码方式
        //System.out.println(System.getProperty("file.encoding")); //这个是当前文件内容编码方式
        List<File> fileList = new ArrayList<File>();
        File dir = new File(destDir);
        // create output directory if it doesn't exist
        if (!dir.exists()) {
            dir.mkdirs();
        }
        // buffer for read and write data to file
        byte[] buffer = new byte[1024];
        try(FileInputStream fis = new FileInputStream(zipFilePath)) {
            ZipInputStream zis = new ZipInputStream(fis);
            ZipEntry ze = zis.getNextEntry();
            while (ze != null) {
                String fileName = ze.getName();
                File newFile = new File(destDir + File.separator + fileName);
                File parentFile = newFile.getParentFile();
                if (!parentFile.exists()) {
                    parentFile.mkdirs();
                }
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fileList.add(newFile);
                fos.close();
                // close this ZipEntry
                zis.closeEntry();
                ze = zis.getNextEntry();
            }
            // close last ZipEntry
            zis.closeEntry();
            zis.close();
            fis.close();
        } catch (IOException e) {
            log.error("e = {}", e);
        }
        return fileList;

    }


}
