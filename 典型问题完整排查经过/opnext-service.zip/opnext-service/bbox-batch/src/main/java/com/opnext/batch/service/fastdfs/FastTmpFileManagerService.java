package com.opnext.batch.service.fastdfs;

import com.opnext.bboxdomain.OserviceOperator;

import java.io.File;
import java.util.Date;
import java.util.Optional;

/**
 * @ClassName: FastTmpFileManagerService
 * @Description:
 * @Author: Kevin
 * @Date: 2018/8/28 16:08
 */
public interface FastTmpFileManagerService {

    /**
     * 上传文件，并标记临时表
     *
     * @param file
     * @param operator
     * @return
     * @throws Exception
     */
    Optional<String> uploadFile(File file, OserviceOperator operator) throws Exception;

    /**
     * 上传文件，并标记临时表 , 带名称
     *
     * @param file
     * @param fileName
     * @param operator
     * @return
     * @throws Exception
     */
    Optional<String> uploadFileWithOriginalName(File file, String fileName, OserviceOperator operator) throws Exception;

    /**
     * 上传文件并保存到临时表
     *
     * @param file       file
     * @param expireDate 过期时间
     * @param operator   操作人
     * @return
     * @throws Exception
     */
    Optional<String> uploadFile(File file, Date expireDate, OserviceOperator operator) throws Exception;

    /**
     * 上传文件，并标记临时表 , 带名称
     *
     * @param file       待上传文件
     * @param fileName   上传文件名
     * @param expireDate 过期时间
     * @param operator   操作人
     * @return
     * @throws Exception
     */
    Optional<String> uploadFileWithOriginalName(File file, String fileName, Date expireDate, OserviceOperator operator) throws Exception;

    /**
     * 更新临时表， 删除临时表文件记录，持久保存文件
     *
     * @param fileId
     * @throws Exception
     */
    boolean updateTempFile(String fileId) throws Exception;

    /**
     * 过期文件记录入库
     *
     * @param fileId
     * @param operator
     * @throws Exception
     */
    boolean insertTempFile(String fileId, OserviceOperator operator) throws Exception;

    /**
     * 过期文件记录入库
     *
     * @param fileId
     * @param expireDate
     * @param operator
     * @throws Exception
     */
    boolean insertTempFile(String fileId, Date expireDate, OserviceOperator operator) throws Exception;


    /**
     * 手动调用 删除文件
     *
     * @param fileId
     * @return
     * @throws Exception
     */
    boolean deleteFile(String fileId) throws Exception;

    /**
     * 定时删除临时表中过期的文件
     *
     * @throws Exception
     */
    void deleteExpireFile();


}
