package com.opnext.bboxregister.controller;

import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.opnext.bboxregister.conf.AuthorizeProperties;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.util.RedirectHttpUtil;
import com.opnext.bboxsupport.validator.IsEmptyValidator;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Base64;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;
/**
 *
 * @author wanglu
 */
@ApiIgnore
@Slf4j
@RestController
@RequestMapping("/")
@Api(value="登陆认证",tags={"账号登陆和刷新"})
public class LoginController {
    @Autowired
    private AuthorizeProperties authorizeProperties;
    @Autowired
    private RestTemplate restTemplate;

    @ApiOperation(value = "登陆", notes = "登陆")
    @ApiImplicitParam(name="callbackUrl", value="回调地址",required = true)
    @RequestMapping(value = "/login",method = RequestMethod.GET)
    public void login(String callbackUrl, HttpServletRequest request,HttpServletResponse response) throws Exception {
        ComplexResult ret  = FluentValidator.checkAll()
                .failFast()
                .on(callbackUrl, new IsEmptyValidator("callbackUrl"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.info("登陆参数错误:{}",ret.toString());
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        //接受到参数：callbackurl=前端的回调地址
        String authUrl =  RedirectHttpUtil.getScheme(request)+"://"+RedirectHttpUtil.getHost(request)+ authorizeProperties.getAuthorizeUrl()
                + "?client_id=" + authorizeProperties.getClientId()
                + "&response_type=code&redirect_uri=" + URLEncoder.encode(callbackUrl, "UTF-8");
        response.sendRedirect(authUrl);
    }

    @ApiOperation(value = "获取token", notes = "获取token")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "code", value = "oauth的code，用以换取token",required = true),
            @ApiImplicitParam(name = "state", value = "重定向地址",required = true)
    })
    @RequestMapping(value = "/check",method = RequestMethod.GET)
    public ResponseEntity<CommonResponse> getToken(@RequestParam String code, @RequestParam String state) throws Exception {
        String tokenUrl = "http://"+authorizeProperties.getHost() + authorizeProperties.getOauthTokenUrl();

        StringBuilder params = new StringBuilder();
        params.append("grant_type=").append("authorization_code")
                .append("&client_id=").append(authorizeProperties.getClientId())
                .append("&redirect_uri=").append(URLDecoder.decode(state,"UTF-8"))
                .append("&code=").append(code);

        log.info("code换token，准备参数:{}",params);
        String authBasicStr = Base64.getEncoder().encodeToString((authorizeProperties.getClientId()+":"+authorizeProperties.getSecretId()).getBytes());

        RequestEntity requestEntity = RequestEntity
                .post(new URI(tokenUrl))
                .header("Authorization","Basic "+authBasicStr)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .body(params.toString());
        ResponseEntity<CommonResponse> responseEntity=restTemplate.exchange(requestEntity, CommonResponse.class);

        log.info("从OAuth获取到换取token的结果:{}",responseEntity);
        return responseEntity;
    }

    @ApiOperation(value = "刷新token", notes = "刷新token")
    @ApiImplicitParam(name="token", value="旧token，用来获取新token",required = true)
    @RequestMapping(value = "/token/_refresh",method = RequestMethod.GET)
    public ResponseEntity<CommonResponse> refreshToken(@RequestParam String token) throws Exception {
        String tokenUrl = "http://"+authorizeProperties.getHost() + authorizeProperties.getOauthTokenUrl();

        StringBuilder params = new StringBuilder();
        params.append("grant_type=").append("refresh_token")
                .append("&client_id=").append(authorizeProperties.getClientId())
                .append("&refresh_token=").append(token);

        log.info("refreshToken，准备参数:{}",params);
        String authBasicStr = Base64.getEncoder().encodeToString((authorizeProperties.getClientId()+":"+authorizeProperties.getSecretId()).getBytes());

        RequestEntity requestEntity = RequestEntity
                .post(new URI(tokenUrl))
                .header("Authorization","Basic "+authBasicStr)
                .contentType(MediaType.APPLICATION_FORM_URLENCODED)
                .body(params.toString());
        ResponseEntity<CommonResponse> responseEntity=restTemplate.exchange(requestEntity, CommonResponse.class);

        log.info("从OAuth获取到换取refresh_token的结果:{}",responseEntity);
        return responseEntity;
    }
}
