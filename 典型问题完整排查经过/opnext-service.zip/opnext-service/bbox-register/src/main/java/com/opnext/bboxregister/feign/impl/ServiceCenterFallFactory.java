package com.opnext.bboxregister.feign.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opnext.bboxregister.feign.ServiceCenterFeign;
import com.opnext.bboxsupport.advise.CommonResponse;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;


/**
 * 异常处理：当返回400-499时，向前端排除异常；否则仅打印log不抛出异常，返回空对象
 * @author wanglu
 */
@Component(value = "oServiceFallBack")
@Slf4j
public class ServiceCenterFallFactory implements FallbackFactory<ServiceCenterFeign> {
    @Override
    public ServiceCenterFeign create(Throwable throwable) {
        log.info("fallback; reason was: {}",throwable.getMessage());
        return new ServiceCenterFeign() {
            @Override
            public CommonResponse init(String param, String orgName) throws Exception{
                log.error("feign调用出现错误，",throwable);

                //由于已经打印了错误堆栈，此处不再处理直接返回null，交给接收者处理
                if (StringUtils.isBlank(throwable.getMessage())){
                    return null;
                }
                String errorMessage = throwable.getMessage().substring(throwable.getMessage().indexOf("\n")+1);
                CommonResponse.ErrorResponse errorResponse = new ObjectMapper().readValue(errorMessage,CommonResponse.ErrorResponse.class);
                return errorResponse;
            }
        };
    }
}
