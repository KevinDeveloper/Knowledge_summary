package com.opnext.bboxregister.feign.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.opnext.bboxregister.domain.Account;
import com.opnext.bboxregister.domain.RegisterParam;
import com.opnext.bboxregister.domain.resp.PageFeign;
import com.opnext.bboxregister.feign.UserCenterFeign;
import com.opnext.bboxsupport.advise.CommonResponse;
import feign.FeignException;
import feign.hystrix.FallbackFactory;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageImpl;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

/**
 * 异常处理：当返回400-499时，向前端排除异常；否则仅打印log不抛出异常，返回空对象
 * @author wanglu
 */
@Component(value = "userCenterFailService")
@Slf4j
public class UserCenterFallFactory implements FallbackFactory<UserCenterFeign> {
    @Override
    public UserCenterFeign create(Throwable throwable) {
        log.info("fallback; reason was: {}",throwable.getMessage());
        return new UserCenterFeign() {
            @Override
            public CommonResponse<Account> registerConfirm(RegisterParam registerParam) throws Exception {
                return innerHandlerException(throwable,new PageImpl(new ArrayList(), null, 0));
            }

            @Override
            public CommonResponse<PageFeign<Account>> getAccountPage(Object... urlVariables) throws Exception {
                return innerHandlerException(throwable,new PageImpl(new ArrayList(), null, 0));
            }

            @Override
            public CommonResponse changePassword(Account account) throws Exception {
                return innerHandlerException(throwable,new PageImpl(new ArrayList(), null, 0));
            }

            @Override
            public CommonResponse deleteTenantById(Long id)throws Exception{
                return innerHandlerException(throwable,new Object());
            }
            public CommonResponse innerHandlerException(Throwable throwable,Object object) throws Exception{
                CommonResponse.ErrorResponse errorResponse = new CommonResponse.ErrorResponse();
                String errorMessage = throwable.getMessage().substring(throwable.getMessage().indexOf("\n")+1);
                errorResponse = new ObjectMapper().readValue(errorMessage,CommonResponse.ErrorResponse.class);
                if (errorResponse.getStatus()>= HttpStatus.BAD_REQUEST.value() && errorResponse.getStatus()<HttpStatus.INTERNAL_SERVER_ERROR.value()) {
                    if (throwable instanceof FeignException){
                        throw (FeignException) throwable;
                    }else{
                        throw (Exception) throwable;
                    }
                }
                return CommonResponse.ok(object);
            }
        };
    }
}
