package com.opnext.bboxregister.domain;

/**
 * @author wanglu
 */
public enum Locus {
    /**
     * 中国
     */
    CHINA((byte) 0),

    /**
     * 海外
     */
    ABROAD((byte)1);

    private byte value;

    Locus(byte value) {
        this.value = value;
    }

    public byte value() {
        return this.value;
    }
}