package com.opnext.bboxregister.domain;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

/**
 * @author wanglu
 */
@ApiModel(description = "账号对象")
@Data
@Builder
public class Account {
    @ApiModelProperty(value = "用户id")
    private Long id;
    @ApiModelProperty(value = "登陆名")
    private String loginName;
    @ApiModelProperty(value = "密码")
    private String password;
    @ApiModelProperty(value = "租户id")
    private Long tenantId;
    @ApiModelProperty(value = "是否是超级管理员")
    private Boolean isRoot;
    /**
     * 0停用，1启用
     */
    @ApiModelProperty(value = "账号状态")
    private Integer status;
    @ApiModelProperty(value = "邮箱")
    private String email;
    @ApiModelProperty(value = "创建者")
    private Long createdBy;
    @ApiModelProperty(value = "电话好吗")
    private String phone;
    @ApiModelProperty(value = "创建时间")
    private Long createTime;
    @Tolerate
    public Account(){}
}