package com.opnext.bboxregister.domain;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.Pattern;

/**
 * @author wanglu
 */

@ApiModel(description = "注册")
@Data
public class Register {

    @ApiModelProperty(value = "登陆名",required = true)
    @NotEmpty(message="tenant.register.loginname.notEmpty")
    @Length(min=6, max=20, message = "tenant.register.loginname.length")
    @Pattern(regexp="[-_A-Za-z0-9]*",message = "tenant.register.loginname.content")
    private String loginName;

    @ApiModelProperty(value = "密码" ,required = true)
    @NotEmpty(message="tenant.register.password.notEmpty")
    @Length(max=20, message = "tenant.register.password.length")
    private String password;

    @ApiModelProperty(value = "邮箱" ,required = true)
    @Email(message = "tenant.register.email.validate")
    private String email;

    @ApiModelProperty(value = "企业名称",required = true)
    @NotEmpty(message = "tenant.register.enterprise.notEmpty")
    @Length( max=20, message = "tenant.register.enterprise.length")
    private String enterprise;

    @ApiModelProperty(value = "所在地")
    private Locus locus;
    @ApiModelProperty(value = "行业")
    private Industry industry;

    @ApiModelProperty(value = "联系人姓名",required = true)
    @NotEmpty(message = "tenant.register.contactName.notEmpty")
    @Length(min=1,max=64, message = "string.length.incorrect")
    private String contactName;

    @ApiModelProperty(value = "电话号码")
    @Pattern(regexp="[0-9]*",message = "tenant.register.contactPhone")
    @Length(max=20, message = "string.length.incorrect")
    private String contactPhone;

    @ApiModelProperty(value = "邮箱验证码",required = true)
    @NotEmpty(message = "tenant.register.emailCode")
    private String emailCode;
}