package com.opnext.bboxregister.domain;

/**
 * @author wanglu
 */

public enum Industry {

    /**
     * 政府/事业单位
     */
    GOVERNMENT_AND_INSTITUTION((byte) 0),

    /**
     * 互联网/信息技术
     */
    INTERNET_AND_INFORMATION_TECHNOLOGY((byte) 1),

    /**
     * 教育行业
     */
    EDUCATION((byte)2),

    /**
     * 房地产业
     */
    REAL_ESTATE((byte)3),

    /**
     * 居民服务
     */
    RESIDENCE_SERVICE((byte)4),

    /**
     * 文体/娱乐/传媒
     */
    STYPE_AND_ENTERTAINMENT_AND_MEDIA((byte)5),

    /**
     * 其他
     */
    OTHERS((byte)6);

    private byte value;

    Industry(byte value) {
        this.value = value;
    }

    public byte value() {
        return this.value;
    }
}
