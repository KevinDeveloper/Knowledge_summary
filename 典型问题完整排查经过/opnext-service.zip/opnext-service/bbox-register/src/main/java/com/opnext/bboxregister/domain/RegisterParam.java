package com.opnext.bboxregister.domain;

import lombok.Builder;
import lombok.Data;

/**
 * @author wanglu
 */
@Data
@Builder
public class RegisterParam{
    private String name;
    private Integer businessType;
    private Integer countryCode;
    private String contact;
    private String contactPhone;
    private String password;
    private String loginName;
    private String email;
    private Long adminId;
    private Long tenantId;
}