package com.opnext.bboxregister.feign;

import com.opnext.bboxregister.domain.Account;
import com.opnext.bboxregister.domain.RegisterParam;
import com.opnext.bboxregister.domain.resp.PageFeign;
import com.opnext.bboxregister.feign.impl.UserCenterFallFactory;
import com.opnext.bboxsupport.advise.CommonResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * @author wanglu
 */
@FeignClient(value = "user-center",fallbackFactory = UserCenterFallFactory.class)
public interface UserCenterFeign {

    /**
     * 注册确认
     * @param registerParam
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.POST, value = "/user-center/api/registry")
    CommonResponse<Account> registerConfirm(RegisterParam registerParam)throws Exception;

    /**
     * 获取账号列表
     * @param urlVariables
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.GET, value = "/user-center/api/users")
    CommonResponse<PageFeign<Account>> getAccountPage(Object... urlVariables)throws Exception;

    /**
     * 修改密码
     * @param account
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.PUT, value = "/user-center/api/user")
    CommonResponse changePassword(Account account)throws Exception;

    /**
     * 租户详情查询
     * @param id
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.DELETE, value = "/user-center/api/tenant/{id}")
    CommonResponse deleteTenantById(@PathVariable("id") Long id)throws Exception;
}

