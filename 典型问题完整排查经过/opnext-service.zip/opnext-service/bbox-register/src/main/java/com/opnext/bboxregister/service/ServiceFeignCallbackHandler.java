package com.opnext.bboxregister.service;

import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import org.springframework.http.HttpStatus;

import java.util.Objects;

/**
 * @author wanglu
 */
public class ServiceFeignCallbackHandler {
    /**
     * 用来处理feign返回结果
     * code<400不处理
     * code>=400，抛出异常
     * 特殊情况，feign调用返回的异常没有errorMessage，则在callback打印堆栈并返回空，在该方法处理中直接抛出Exception server error
     * @param commonResponse
     * @throws Exception
     */
    public static void checkResponseError(CommonResponse commonResponse) throws Exception{
        if (Objects.isNull(commonResponse)) {
            throw new Exception("InternalServerError");
        } else if (commonResponse.getStatus()>= HttpStatus.BAD_REQUEST.value()) {
            if (commonResponse instanceof CommonResponse.ErrorResponse) {
                throw new CommonException(commonResponse.getStatus(), commonResponse.getMessage(),
                        ((CommonResponse.ErrorResponse) commonResponse).getErrors(),commonResponse.getCode());
            }
            throw new CommonException(commonResponse.getStatus(), commonResponse.getMessage(), null,
                    commonResponse.getCode());
        }
    }

}