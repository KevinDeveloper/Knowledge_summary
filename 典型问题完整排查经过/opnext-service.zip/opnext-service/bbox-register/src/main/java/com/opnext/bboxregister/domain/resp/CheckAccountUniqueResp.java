package com.opnext.bboxregister.domain.resp;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;

/**
 * 用于DTO，返回前端判断接口，该账号是否可用
 * @author wanglu
 */
@ApiModel(description = "邮箱是否可用")
@Builder
@Data
public class CheckAccountUniqueResp {
    @ApiModelProperty(value = "是否可用，available可用，unavailable不可用")
    Res res;

    public enum Res{
        /**
         * 可用
         */
        available((byte) 0),
        /**
         * 不可用
         */
        unavailable((byte)1);

        private byte value;

        Res(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }
}
