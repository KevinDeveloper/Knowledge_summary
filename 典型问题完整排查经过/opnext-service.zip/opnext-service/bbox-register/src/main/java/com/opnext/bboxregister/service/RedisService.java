package com.opnext.bboxregister.service;

import com.opnext.bboxsupport.util.RedisLifeTimeUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author wanglu
 */

@Repository
public class RedisService {
    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    @Autowired
    private RedisTemplate redisTemplate;

    public  void setKey(String key,String value){
        ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
        ops.set(key,value);
    }

    public  void setKey(String key,String value,long timeout){
        ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
        ops.set(key,value,timeout);
    }

    public  void setKey(String key, String value, long timeout, TimeUnit timeUnit){
        ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
        ops.set(key,value,timeout,timeUnit);
    }

    public  void setKey(String key, String value, RedisLifeTimeUtil redisLifeTimeUtil){
        ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
        ops.set(key,value,redisLifeTimeUtil.getTime(),redisLifeTimeUtil.getUnit());
    }

    public void deleteKey(String key){
        stringRedisTemplate.delete(key);
    }

    public String getValue(String key){
        ValueOperations<String, String> ops = stringRedisTemplate.opsForValue();
        return ops.get(key);
    }

    public  void setRedisKey(String key,Object value){
        redisTemplate.boundListOps(key).leftPush(value);
        //ValueOperations<String, Object> ops = redisTemplate.opsForValue();
    }

    public Object getRedisValue(String key){
        ValueOperations<String,Object> ops = this.redisTemplate.opsForValue();
        return ops.get(key);
    }

    public <T> List<T> getListValue(String key){
        ListOperations lops = this.redisTemplate.opsForList();
        return lops.range(key,0,lops.size(key)-1);
    }
}
