package com.opnext.bboxregister.domain.resp;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

/**
 * @author wanglu
 * @param <T>
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class PageFeign<T> implements Iterable<T>, Serializable {

    private static final long serialVersionUID = 1L;

    private List<T> content = new ArrayList<>();
    private boolean last;
    private int totalPages;
    private int totalElements;
    private int numberOfElements;
    private int size;
    private int number;
    private Pageable pageable;

    public PageFeign() {
    }

    public List<T> getContent() {
        return content;
    }

    public void setContent(List<T> content) {
        this.content = content;
    }

    public boolean isLast() {
        return last;
    }

    public void setLast(boolean last) {
        this.last = last;
    }

    public int getTotalPages() {
        return totalPages;
    }

    public void setTotalPages(int totalPages) {
        this.totalPages = totalPages;
    }

    public int getTotalElements() {
        return totalElements;
    }

    public void setTotalElements(int totalElements) {
        this.totalElements = totalElements;
    }

    public int getNumberOfElements() {
        return numberOfElements;
    }

    public void setNumberOfElements(int numberOfElements) {
        this.numberOfElements = numberOfElements;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public Pageable getPageable() {

        return new PageRequest(number,size);
    }

    @Override
    public Iterator<T> iterator() {
        return getContent().iterator();
    }

    public static <T> Page<T> localPageToSpringPage(PageFeign<T> page) {
        if (Objects.nonNull(page)){
            return new PageImpl(page.getContent(), page.getPageable(), page.getTotalElements());
        }else{
            return new PageImpl(new ArrayList(), null, 0);
        }
    }
}