package com.opnext.bboxregister.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author wanglu
 */
@Component
@Data
@ConfigurationProperties(prefix = "remote-rest.browserClientCenter")
public class BrowserClientCenter {
    String forgerPasswordUrl;
}
