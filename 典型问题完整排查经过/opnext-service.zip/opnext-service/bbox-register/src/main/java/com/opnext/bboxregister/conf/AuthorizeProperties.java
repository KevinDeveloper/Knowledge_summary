package com.opnext.bboxregister.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author wanglu
 */
@Component
@Data
@ConfigurationProperties(prefix = "remote-rest.authCenter")
public class AuthorizeProperties {
    String scheme;
    String host;
    String callbackTokenUrl;
    String authorizeUrl;
    String clientId;
    String secretId;
    String oauthTokenUrl;
}
