package com.opnext.bboxregister.controller;

import com.alibaba.fastjson.JSONObject;
import com.baidu.unbiz.fluentvalidator.ComplexResult;
import com.baidu.unbiz.fluentvalidator.FluentValidator;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Maps;
import com.opnext.bboxregister.conf.AuthorizeProperties;
import com.opnext.bboxregister.conf.BrowserClientCenter;
import com.opnext.bboxregister.domain.*;
import com.opnext.bboxregister.domain.resp.CheckAccountUniqueResp;
import com.opnext.bboxregister.feign.ServiceCenterFeign;
import com.opnext.bboxregister.service.AccountService;
import com.opnext.bboxregister.service.RedisService;
import com.opnext.bboxregister.service.ServiceFeignCallbackHandler;
import com.opnext.bboxsupport.advise.CommonException;
import com.opnext.bboxsupport.advise.CommonResponse;
import com.opnext.bboxsupport.mail.MailEntity;
import com.opnext.bboxsupport.mail.MailSender;
import com.opnext.bboxsupport.util.*;
import com.opnext.bboxsupport.validator.HasEasySpecialCharValidator;
import com.opnext.bboxsupport.validator.IsEmailValidator;
import com.opnext.bboxsupport.validator.IsEmptyValidator;
import io.swagger.annotations.*;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.validation.constraints.Pattern;
import java.util.*;

import static com.baidu.unbiz.fluentvalidator.ResultCollectors.toComplex;

/**
 *
 * @author wanglu
 */
@Slf4j
@RestController
@RequestMapping("/tenant")
@Api(value="租户管理",tags={"用户注册和账号管理"})
public class TenantController {
    @Autowired
    private RedisService redisService;
    @Autowired
    private AccountService accountService;
    @Autowired
    private BrowserClientCenter browserClientCenter;
    @Resource
    private ServiceCenterFeign oService;
    @Autowired
    private AuthorizeProperties authorizeProperties;

    private ObjectMapper objectMapper = new ObjectMapper();

    @ApiIgnore
    @ApiOperation(value = "获取行业列表", notes = "获取行业列表，返回枚举字符串，需要前端根据字符串搜索国际化文字")
    @RequestMapping(value = "/industry",method = RequestMethod.GET)
    public Industry[] getIndustry(){
        return Industry.values();
    }

    @ApiIgnore
    @ApiOperation(value = "获取所在地列表", notes = "获取所在地列表，返回枚举字符串，需要前端根据字符串搜索国际化文字")
    @RequestMapping(value = "/locus",method = RequestMethod.GET)
    public Locus[] getLocus(){
        return Locus.values();
    }

    @ApiIgnore
    @ApiOperation(value = "注册发送邮箱验证码", notes = "注册发送邮箱验证码")
    @ApiImplicitParams({
            @ApiImplicitParam(
                    name = "email",
                    dataType = "EmailForReq.class")
    })
    @RequestMapping(value = "/register/validateCode",method = RequestMethod.POST)
    public void sendEmailValidatorCode(@RequestBody String email) throws Exception{
        String mailAddress = JSONObject.parseObject(email).getString("email");
        //校验
        ComplexResult ret  = FluentValidator.checkAll()
                .failOver()
                .on(mailAddress, new IsEmptyValidator("email"))
                .on(mailAddress, new IsEmailValidator("email"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        //生成验证码
        int code = (int) ((Math.random() * 9 + 1) * 100000);
        log.info("测试使用验证码："+code);
        //发送邮件
        MailEntity m=MailEntity.builder()
                .title(Messages.get("email.title.verify.email"))
                .content(Messages.get("mail.register.validateCode",new String[]{code+""}))
                .contentType(MailEntity.MailContentTypeEnum.HTML.getValue())
                .target(new ArrayList<String>(){{
                    add(mailAddress);
                }}).build();
        try {
            MailSender.send(m);
        } catch (Exception e) {
            log.error("注册发送验证码失败，原因为：{}",e.getMessage());
            throw new CommonException(e.getMessage());
        }
        //验证码放到redis中
        String keyName = RedisCommonKeyUtil.EMAIL_VALIDATION_CODE + mailAddress;

        redisService.setKey(keyName,code+"", RedisLifeTimeUtil.validateCodeTime());
    }

    @ApiIgnore
    @ApiOperation(value = "验证邮箱验证码", notes = "验证邮箱验证码")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "email", value = "邮箱地址",required = true),
            @ApiImplicitParam(name = "emailCode", value = "邮箱验证码",required = true)
    })
    @RequestMapping(value = "/register/validateCode",method = RequestMethod.GET)
    public CheckAccountUniqueResp checkEmailValidateCode(
            @RequestParam(name = "email") String email,
            @RequestParam(name = "emailCode")  String emailCode)
            throws Exception{
        //校验
        ComplexResult ret  = FluentValidator.checkAll()
                .failOver()
                .on(email, new IsEmptyValidator("email"))
                .on(emailCode, new IsEmptyValidator("emailCode"))
                .on(email, new IsEmailValidator("email"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            throw new CommonException(400,"parameter.incorrect",ret);
        }
        //校验邮箱验证码
        String code = redisService.getValue(RedisCommonKeyUtil.EMAIL_VALIDATION_CODE + email);
        if (StringUtils.isBlank(code) || !emailCode.equals(code)) {
            log.error("验证码校验失败，原因为：通过邮箱查询到code为空");
            return CheckAccountUniqueResp.builder()
                            .res(CheckAccountUniqueResp.Res.unavailable).build();
        }
        return CheckAccountUniqueResp.builder()
                .res(CheckAccountUniqueResp.Res.available).build();
    }

    @ApiIgnore
    @ApiOperation(value = "注册确认", notes = "注册确认")
    @Transactional(rollbackFor=Exception.class)
    @ApiImplicitParam(paramType = "body", dataType = "Register", name = "entity", value = "注册对象")
    @RequestMapping(value = "/register",method = RequestMethod.POST)
    public Account register(@RequestBody @Valid Register entity, BindingResult bindingResult) throws Exception{
        //验证参数是否正确
        if(bindingResult.hasErrors()){
            log.error("注册确认失败，参数存在错误项,{}",bindingResult);
            throw new CommonException(400, "tenant.register.parameter.error", bindingResult);
        }

        ComplexResult ret  = FluentValidator.checkAll()
                .failOver()
                .on(entity.getPassword(), new HasEasySpecialCharValidator("password"))
                .on(entity.getEnterprise(), new HasEasySpecialCharValidator("enterprise"))
                .on(entity.getContactName(), new HasEasySpecialCharValidator("contactName"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("注册失败,参数有误，{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }

        //校验邮箱验证码
        String emailCode = entity.getEmailCode();
        String key = RedisCommonKeyUtil.EMAIL_VALIDATION_CODE + entity.getEmail();
        String code = redisService.getValue(key);

        if(StringUtils.isBlank(code)){
            log.error("注册确认失败，通过邮箱获取的验证码为空");
            throw new CommonException(400, "email.validation.code.timeout");
        }else if (!code.equals(emailCode)){
            log.error("注册确认失败，验证码和通过邮箱查询的结果不一致");
            throw new CommonException("email.validation.code.incorrect");
        }

        Account account = Account.builder().email(entity.getEmail()).build();
        List<Account> accountList = accountService.getAccountList(account);
        if (accountList!=null && accountList.size()>0){
            throw new CommonException(400,"tenant.email.used");
        }
        Account account1 = Account.builder().loginName(entity.getLoginName()).build();
        List<Account> accountList2 = accountService.getAccountList(account1);
        if (accountList2!=null && accountList2.size()>0){
            throw new CommonException(400,"tenant.loginName.used");
        }
        redisService.deleteKey(key);
        //账号保存
        Account result = accountService.registerConfirm(
                RegisterParam.builder()
                        .name(entity.getEnterprise())
                        .email(entity.getEmail())
                        .loginName(entity.getLoginName())
                        .password(entity.getPassword())
                        .businessType((int)entity.getIndustry().value())
                        .countryCode((int)entity.getLocus().value())
                        .contact(entity.getContactName())
                        .contactPhone(entity.getContactPhone())
                        .build());
        //保存 账号-超管的角色关联
        Map<String,Object> acountHeader = Maps.newHashMap();
        acountHeader.put("userId",result.getId());
        acountHeader.put("tenantId",result.getTenantId());
        acountHeader.put("appId",authorizeProperties.getClientId());

        String headerStr = objectMapper.writeValueAsString(acountHeader);

        oService.init(headerStr,entity.getEnterprise());
        return result;
    }

    @ApiOperation(value = "内网注册确认", notes = "注册确认")
    @Transactional(rollbackFor=Exception.class)
    @RequestMapping(value = "/register/internal",method = RequestMethod.POST)
    public Account registerInternal(@RequestBody @Valid RegisterInternal registerInternal, BindingResult bindingResult) throws Exception{
        //验证参数是否正确
        if(bindingResult.hasErrors()){
            log.error("注册确认失败，参数存在错误项,{}",bindingResult);
            throw new CommonException(400, "tenant.register.parameter.error", bindingResult);
        }

        ComplexResult ret  = FluentValidator.checkAll()
                .failOver()
                .on(registerInternal.getPassword(), new HasEasySpecialCharValidator("password"))
                .on(registerInternal.getEnterprise(), new HasEasySpecialCharValidator("enterprise"))
                .on(registerInternal.getContactName(), new HasEasySpecialCharValidator("contactName"))
                .doValidate()
                .result(toComplex());
        if(!ret.isSuccess()){
            log.error("注册失败,参数有误，{}",ret);
            throw new CommonException(400,"parameter.incorrect",ret);
        }

        if (Objects.nonNull(registerInternal.getAdminId())){
            Account account = Account.builder().id(registerInternal.getAdminId()).build();
            List<Account> accountList = accountService.getAccountList(account);
            if (!CollectionUtils.isEmpty(accountList)){
                throw new CommonException(400,"tenant.adminId.used");
            }
        }

        if (Objects.nonNull(registerInternal.getTenantId())){
            Account account = Account.builder().tenantId(registerInternal.getTenantId()).build();
            List<Account> accountList = accountService.getAccountList(account);
            if (!CollectionUtils.isEmpty(accountList)){
                throw new CommonException(400,"tenant.tenantId.used");
            }
        }

        Account account = Account.builder().email(registerInternal.getEmail()).build();
        List<Account> accountList = accountService.getAccountList(account);
        if (!CollectionUtils.isEmpty(accountList)){
            throw new CommonException(400,"tenant.email.used");
        }
        Account account1 = Account.builder().loginName(registerInternal.getLoginName()).build();
        List<Account> accountList2 = accountService.getAccountList(account1);
        if (!CollectionUtils.isEmpty(accountList2)){
            throw new CommonException(400,"tenant.loginName.used");
        }
        //账号保存
        Account result = accountService.registerConfirm(
                RegisterParam.builder()
                        .name(registerInternal.getEnterprise())
                        .email(registerInternal.getEmail())
                        .loginName(registerInternal.getLoginName())
                        .password(registerInternal.getPassword())
                        .businessType((int)registerInternal.getIndustry().value())
                        .countryCode((int)registerInternal.getLocus().value())
                        .contact(registerInternal.getContactName())
                        .contactPhone(registerInternal.getContactPhone())
                        .adminId(registerInternal.getAdminId())
                        .tenantId(registerInternal.getTenantId())
                        .build());

        //账号初始化
        Map<String,Object> accountHeader = new HashMap<>(3);
        accountHeader.put("userId",result.getId());
        accountHeader.put("tenantId",result.getTenantId());
        accountHeader.put("appId",authorizeProperties.getClientId());

        String headerStr = objectMapper.writeValueAsString(accountHeader);
        try {
            CommonResponse initResponse = oService.init(headerStr,registerInternal.getEnterprise());
            ServiceFeignCallbackHandler.checkResponseError(initResponse);
        }catch (Exception ex){
            log.error("租户注册失败：初始化过程出现错误",ex.getMessage());
            accountService.deleteTenant(result.getTenantId());
            throw ex;
        }
        return result;
    }

    @ApiIgnore
    @ApiOperation(value = "忘记密码-验证账号邮箱",notes = "忘记密码：验证账号和邮箱并向邮箱发送修改链接，链接仅十分钟有效")
    @RequestMapping(value = "/account",method = RequestMethod.POST)
    public void validateAccountForForgetPassword(
            @RequestBody @Valid ForgetPasswordRequest forgetPasswordRequest,
            BindingResult bindingResult) throws Exception{
        //验证参数是否正确
        if(bindingResult.hasErrors()){
            log.error("忘记密码-验证账号邮箱 操作失败,{}",bindingResult);
            throw new CommonException(400, "tenant.register.parameter.error", bindingResult);
        }
        List<Account> accountList = accountService.getAccountList(Account.builder().email(forgetPasswordRequest.getEmail()).build());
        if (Objects.isNull(accountList) || accountList.isEmpty() || !(accountList.get(0).getLoginName()).equals(forgetPasswordRequest.getLoginName())){
            log.error("忘记密码-验证账号邮箱 邮箱和账号不匹配");
            throw new CommonException( "tenant.email.loginName.incompatible");
        }
        //发送邮件
        String uuid = UUID.randomUUID().toString();

        String[] args = new String[6];
        args[0]=authorizeProperties.getScheme()+"://"+browserClientCenter.getForgerPasswordUrl();
        args[1]=uuid;
        args[2]=Messages.getLocale().getDisplayLanguage();
        args[3]=authorizeProperties.getScheme()+"://"+browserClientCenter.getForgerPasswordUrl();
        args[4]=uuid;
        args[5]=Messages.getLocale().getDisplayLanguage();

        MailEntity m=MailEntity.builder()
                .title(Messages.get("email.title.password.reset"))
                .content(Messages.get("mail.forgetPassword.link",args))
                .contentType(MailEntity.MailContentTypeEnum.HTML.getValue())
                .target(new ArrayList<String>(){{
                    add(forgetPasswordRequest.getEmail());
                }}).build();
        try {
            MailSender.send(m);
        } catch (Exception e) {
            log.error("忘记密码-验证账号邮箱,邮件发送失败，{}",e.getMessage());
            throw new CommonException(e.getMessage());
        }
        //验证码放到redis中
        String keyName =RedisCommonKeyUtil.FORGET_PASSWORD_LINK +uuid ;
        redisService.setKey(keyName,forgetPasswordRequest.getEmail(),RedisLifeTimeUtil.validateCodeTime());
    }

    @ApiIgnore
    @ApiOperation(value = "忘记密码-重置密码",notes = "忘记密码：重置密码")
    @RequestMapping(value = "/account",method = RequestMethod.PUT)
    public void resetPwd(@RequestBody @Valid ResetPasswordRequest resetPasswordRequest,BindingResult bindingResult) throws Exception{
        //验证参数是否正确
        if(bindingResult.hasErrors()){
            log.error("重置密码失败 操作失败,{}",bindingResult);
            throw new CommonException(400, "tenant.register.parameter.error", bindingResult);
        }

        if (ValidatorUtil.hasEasySpecialChart(resetPasswordRequest.getPassword())){
            bindingResult.addError(new ObjectError("password", "string.include.specialChart") );
            throw new CommonException(400,"string.include.specialChart",bindingResult);
        }

        String keyName = RedisCommonKeyUtil.FORGET_PASSWORD_LINK +resetPasswordRequest.getValidateCode() ;
        String email = redisService.getValue(keyName);
        if (StringUtils.isBlank(email)){
            log.error("修改密码失败：通过validateCode获取邮箱信息失败");
            throw new CommonException(400, "email.validation.link.timeout");
        }
        redisService.deleteKey(keyName);
        List<Account> accounts = accountService.getAccountList(Account.builder().email(email));
        if (Objects.isNull(accounts) || accounts.isEmpty()){
            log.error("重置密码失败 操作失败：参数错误，没有找到这个邮箱关联的账户");
            throw new CommonException(400, "tenant.register.parameter.error");
        }
        //改
        accountService.changePassword(Account.builder().id(accounts.get(0).getId()).password(resetPasswordRequest.getPassword()).build());
    }

    @ApiIgnore
    @ApiOperation(value = "判断邮箱和账号是否已经被注册", notes = "判断邮箱和账号是否已经被注册")
    @RequestMapping(value = "/account",method = RequestMethod.GET)
    public CheckAccountUniqueResp getAdmin(@Valid  CheckEmailOrLoginNameReq checkEmailOrLoginNameReq,BindingResult bindingResult) throws Exception {
        if (StringUtils.isBlank(checkEmailOrLoginNameReq.getEmail()) && StringUtils.isBlank(checkEmailOrLoginNameReq.getLoginName())){
            throw new CommonException(400,"parameter.incorrect");
        }
        if (bindingResult.hasErrors()){
            throw new CommonException(400,"parameter.incorrect",bindingResult);
        }
        List<Account> accountList = accountService.getAccountList(checkEmailOrLoginNameReq);
        if (Objects.isNull(accountList) || accountList.isEmpty()) {
            return CheckAccountUniqueResp.builder()
                            .res(CheckAccountUniqueResp.Res.available)
                            .build();
        }

        return CheckAccountUniqueResp.builder()
                .res(CheckAccountUniqueResp.Res.unavailable)
                .build();
    }

    @ApiModel(description = "忘记密码：密码+邮箱验证码")
    @Data
    static class ResetPasswordRequest{
        @ApiModelProperty(value="验证码",required = true)
        @NotEmpty(message="tenant.parameter.notEmpty")
        private String validateCode;

        @ApiModelProperty(value="密码",required = true)
        @NotEmpty(message="tenant.register.password.notEmpty")
        @Length(max=20, message = "tenant.register.password.length")
        private String password;
    }

    @ApiModel(description = "登陆名邮箱")
    @Data
    static class ForgetPasswordRequest{
        @ApiModelProperty(value="登陆账号",required = true)
        @NotEmpty(message="tenant.register.loginname.notEmpty")
        @Length(min=6, max=20, message = "tenant.register.loginname.length")
        @Pattern(regexp="[-_A-Za-z0-9]*",message = "tenant.register.loginname.content")
        private String loginName;

        @ApiModelProperty(value="邮箱",required = true)
        @Email(message = "tenant.register.email.validate")
        private String email;
    }

    @ApiModel(description = "账号登陆名邮箱")
    @Data
    static class CheckEmailOrLoginNameReq{
        @ApiModelProperty(value="登陆名称")
        @Length(min=6, max=20, message = "tenant.register.loginname.length")
        @Pattern(regexp="[-_A-Za-z0-9]*",message = "tenant.register.loginname.content")
        private String loginName;

        @ApiModelProperty(value="邮箱地址")
        @Email(message = "tenant.register.email.validate")
        private String email;
    }

    @ApiModel(description = "用户内部注册")
    @Data
    static class RegisterInternal {
        @ApiModelProperty(value="管理员id")
        private Long adminId;

        @ApiModelProperty(value="租户id")
        private Long tenantId;

        @ApiModelProperty(value="登陆账号",required = true)
        @NotEmpty(message="tenant.register.loginname.notEmpty")
        @Length(min=6, max=20, message = "tenant.register.loginname.length")
        @Pattern(regexp="[-_A-Za-z0-9]*",message = "tenant.register.loginname.content")
        private String loginName;

        @ApiModelProperty(value="密码",required = true)
        @NotEmpty(message="tenant.register.password.notEmpty")
        @Length(max=20, message = "tenant.register.password.length")
        private String password;

        @ApiModelProperty(value="邮箱地址",required = true)
        @Email(message = "tenant.register.email.validate")
        private String email;

        @ApiModelProperty(value="企业名称",required = true)
        @NotEmpty(message = "tenant.register.enterprise.notEmpty")
        @Length( max=20, message = "tenant.register.enterprise.length")
        private String enterprise;

        @ApiModelProperty(value="所在地")
        private Locus locus;
        @ApiModelProperty(value="行业")
        private Industry industry;

        @ApiModelProperty(value="联系人姓名",required = true)
        @NotEmpty(message = "tenant.register.contactName.notEmpty")
        @Length(min=1,max=64, message = "string.length.incorrect")
        private String contactName;

        @ApiModelProperty(value="联系人电话")
        @Pattern(regexp="[0-9]*",message = "tenant.register.contactPhone")
        @Length(max=20, message = "string.length.incorrect")
        private String contactPhone;
    }

    @Data
    static class EmailForReq{
        private String email;
    }
}


