package com.opnext.bboxregister.feign;

import com.opnext.bboxregister.feign.impl.ServiceCenterFallFactory;
import com.opnext.bboxsupport.advise.CommonResponse;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author wanglu
 */
@FeignClient(value = "bbox-service",fallbackFactory = ServiceCenterFallFactory.class)
public interface ServiceCenterFeign {
    /**
     * 租户注册，初始化组织
     * @param param
     * @param orgName
     * @return
     * @throws Exception
     */
    @RequestMapping(method = RequestMethod.POST, value = "/bbox-service/api/init")
    CommonResponse init(@RequestHeader(name="param")String param, @RequestParam(name = "orgName") String orgName)throws Exception;
}

