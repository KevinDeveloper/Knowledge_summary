package com.opnext.bboxregister.service;

import com.opnext.bboxregister.domain.Account;
import com.opnext.bboxregister.domain.RegisterParam;
import com.opnext.bboxregister.domain.resp.PageFeign;
import com.opnext.bboxregister.feign.UserCenterFeign;
import com.opnext.bboxsupport.advise.CommonResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author wanglu
 */
@Service
@Slf4j
public class AccountService {

    @Resource
    private UserCenterFeign userCenter;
    /**
     * 管理员接口
     * @param registerParam
     * @return
     * @throws Exception
     */
    public Account registerConfirm(RegisterParam registerParam) throws Exception{
        CommonResponse<Account> commonResponse = userCenter.registerConfirm(registerParam);
        return commonResponse.getEntity();
    }
    public List<Account> getAccountList(Object... urlVariables)throws Exception {
        CommonResponse<PageFeign<Account>> commonResponse = userCenter.getAccountPage(urlVariables);
        return commonResponse.getEntity().getContent();
    }
    public ResponseEntity changePassword(Account account)throws Exception{
        CommonResponse commonResponse = userCenter.changePassword(account);
        return ResponseEntity.ok(commonResponse);
    }
    public ResponseEntity deleteTenant(Long tenantId)throws Exception{
        CommonResponse entityResponse =userCenter.deleteTenantById(tenantId);
        return ResponseEntity.ok(entityResponse);
    }

}
