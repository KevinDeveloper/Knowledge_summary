package com.opnext.bboxdomain.batch;

import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName: ExportResult
 * @Description: 导出结果
 * @Author: Kevin
 * @Date: 2018/7/12 15:37
 */
@Data
public class ExportResult implements Serializable {
    Integer exportState;
    String filePath;

    public ExportResult() {
        exportState = ExportStateType.STATE_NORMAL.value();
        filePath = "http";
    }

    public ExportResult(Integer exportState, String filePath) {
        this.exportState = exportState;
        this.filePath = filePath;
    }
}
