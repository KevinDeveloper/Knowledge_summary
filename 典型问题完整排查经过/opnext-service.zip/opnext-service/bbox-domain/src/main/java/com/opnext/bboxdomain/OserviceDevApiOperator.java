package com.opnext.bboxdomain;

import lombok.Data;
import org.springframework.util.StopWatch;

/**
 * @author tianzc
 */
@Data
public class OserviceDevApiOperator {
    /**
     * 设备sn
     */
    String sn;
    /**
     * 设备名称
     */
    String name;
    /**
     * 设备组
     */
    Integer groupId;
    /**
     * 租户id
     */
    Long tenantId;
    /**
     * 时间计时器
     */
    StopWatch stopWatch = new StopWatch();
}
