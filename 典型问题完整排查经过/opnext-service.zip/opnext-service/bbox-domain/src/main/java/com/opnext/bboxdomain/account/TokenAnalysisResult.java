package com.opnext.bboxdomain.account;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

/**
 * @author wanglu
 */
@Data
@Builder
public class TokenAnalysisResult {
    String clientId;
    String tenantId;
    String userId;

    @Tolerate
    public TokenAnalysisResult(){}
}
