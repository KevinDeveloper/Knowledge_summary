package com.opnext.bboxdomain.device;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:04 18/5/7
 */
@Slf4j
@AllArgsConstructor
public enum DeviceStatusEnum {

    /**
     * 设备断网
     */
    DEVICE_OFF_LINE(0),
    /**
     * 设备无心跳
     */
//    DEVICE_NO_HEARTBEAT(1),
    /**
     * 设备正常
     */
    DEVICE_RECOVERY(1);
    private Integer value;
    public Integer value(){
        return this.value;
    }
    private static Map<String, DeviceStatusEnum> valMap = new HashMap<>();

    static {
        for (DeviceStatusEnum deviceStatus : values()) {
            valMap.put(deviceStatus.name(), deviceStatus);
        }
    }

    public static DeviceStatusEnum indexOfVal(String value) {
        DeviceStatusEnum deviceStatus = valMap.get(value);
        if(null == deviceStatus){
            log.error("DeviceType中没有找到匹配的 " + value);
            throw new IllegalArgumentException("No element matches " + value);
        }
        return deviceStatus;
    }
}
