package com.opnext.bboxdomain.organization;

import lombok.AllArgsConstructor;

/**
 * @ClassName: OrgDelType
 * @Description: 组织删除类型
 * @Author: Kevin
 * @Date: 2018/11/12 10:45
 */
@AllArgsConstructor
public enum OrgDelType {
    /**
     * 直接删除
     */
    DEL_DIRECT(0),
    /**
     * 删除移动
     */
    DEL_MOVE(1);

    private int value;

    public int value() {
        return this.value;
    }

    public static OrgDelType indexOfVal(int val) {
        for (OrgDelType type : values()) {
            if (type.value == val) {
                return type;
            }
        }
        throw new IllegalArgumentException("param value " + val);
    }


}
