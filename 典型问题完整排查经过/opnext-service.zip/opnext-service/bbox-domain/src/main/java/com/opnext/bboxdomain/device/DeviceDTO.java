package com.opnext.bboxdomain.device;

import lombok.Data;
import java.util.Date;

/**
 * @Title: 设备类
 * @Description: --
 * @author tianzc
 * @Date 下午4:46 18/5/7
 */
@Data
public class DeviceDTO {
    private Integer id;
    /**
     * 设备名称
     */
    private String name;
    /**
     * 设备SN
     */
    private String sn;
    /**
     * 设备类型
     */
    private DeviceTypeEnum type;

    /**
     * 设备状态
     */
    private DeviceStatusEnum status;
    /**
     * 设备组id
     */

    private Integer groupId;

    private String groupName;

    private String version;
    /**
     * 创建时间
     */
    private Date createTime;
    /**
     * 更新时间
     */
    private Date updateTime;
    /**
     * 表示外建：所属租户
     */
    private Long tenantId;
    /**
     * 操作者id
     */
    private Long operatorId;

    /**
     * 操作者账号
     */
    private String operatorName;

}
