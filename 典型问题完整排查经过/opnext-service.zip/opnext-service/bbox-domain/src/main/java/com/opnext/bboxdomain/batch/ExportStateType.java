package com.opnext.bboxdomain.batch;

import lombok.AllArgsConstructor;

/**
 * @ClassName: ExportStateType
 * @Description: 导出状态类型
 * @Author: Kevin
 * @Date: 2018/7/12 15:33
 */
@AllArgsConstructor
public enum ExportStateType {
    /**
     * 失败
     */
    STATE_FAIL(-1),

    /**
     * 初始状态
     */
    STATE_NORMAL(0),

    /**
     * 正在导出
     */
    STATE_EXPORTING(1),

    /**
     * 导出成功
     */
    STATE_SUCCESS(2);


    private int value;

    public int value() {
        return this.value;
    }

    /**
     * 通过 val 值索引 BatchStateType
     *
     * @param val val
     * @return BatchStateType
     */
    public static ExportStateType indexOfVal(int val) {
        for (ExportStateType exportStateType : values()) {
            if (exportStateType.value == val) {
                return exportStateType;
            }
        }
        throw new IllegalArgumentException("param value " + val);
    }


}
