package com.opnext.bboxdomain.account;

import lombok.Builder;
import lombok.Data;
import lombok.experimental.Tolerate;

/**
 * @author wanglu
 */
@Builder
@Data
public class OserviceAuthHeader {
    private Long tenantId;
    private Long userId;
    private String appId;
    @Tolerate
    public OserviceAuthHeader(){}
}
