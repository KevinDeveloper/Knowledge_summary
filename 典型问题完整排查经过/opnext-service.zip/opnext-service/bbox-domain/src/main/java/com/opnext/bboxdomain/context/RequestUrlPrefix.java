package com.opnext.bboxdomain.context;

import lombok.Data;

/**
 * @author tianzc
 */
@Data
public class RequestUrlPrefix {
    /**
     * 请求协议
     */
    String scheme;
    /**
     * 请求域名或ip
     */
    String host;
    /**
     * 请求端口号
     */
    Integer port;
}
