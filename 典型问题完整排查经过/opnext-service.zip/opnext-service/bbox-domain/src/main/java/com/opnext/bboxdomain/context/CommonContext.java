package com.opnext.bboxdomain.context;

/**
 * @author tianzc
 */
public class CommonContext {
    private static ThreadLocal threadLocal = new ThreadLocal();

    public static RequestUrlPrefix getUrlPrefix() {
        return (RequestUrlPrefix) threadLocal.get();
    }

    public static void setUrlPrefix(RequestUrlPrefix urlPrefix) {
        threadLocal.set(urlPrefix);
    }

    public static void remove(){
        threadLocal.remove();
    }

}
