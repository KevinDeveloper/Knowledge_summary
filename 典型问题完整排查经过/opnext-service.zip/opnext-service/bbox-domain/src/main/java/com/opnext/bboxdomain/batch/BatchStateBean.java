package com.opnext.bboxdomain.batch;

import lombok.Data;

import java.io.Serializable;

/**
 * @ClassName: BatchStateBean
 * @Description: 批量导入状态
 * @Author: Kevin
 * @Date: 2018/7/4 19:10
 */
@Data
public class BatchStateBean implements Serializable {


    Integer batchStateType;
    Integer total;
    Integer index;
    Long userId;
    /**
     * 判断是否当前用户在操作导入
     */
    boolean curUserBatch;


    public BatchStateBean() {
        batchStateType = BatchStateType.STATE_UPLOADABLE.value();
        total = 0;
        index = 0;
        userId = -1L;
        curUserBatch = false;
    }

    public BatchStateBean(BatchStateType batchStateType, Integer total, Integer index, Long userId) {
        this.batchStateType = batchStateType.value();
        this.total = total;
        this.index = index;
        this.userId = userId;
    }


}
