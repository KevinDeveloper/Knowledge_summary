package com.opnext.bboxdomain.log;

import lombok.Data;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;

/**
 * @author wanglu
 */
@Data
public class LogReq {
    @NotEmpty
    String appId;
    @NotNull
    Long userId;
    @NotNull
    Long tenantId;
    @NotEmpty
    String loginName;
    @NotNull
    Method method;
    @NotEmpty
    String apiPath;
    @NotNull
    ResultStatus resultStatus;

    public enum Method{
        /**
         * 向特定的资源发出请求。
         */
        GET((byte) 2),
        /**
         * 向指定资源提交数据进行处理请求（例如提交表单或者上传文件）。数据被包含在请求体中。POST请求可能会导致新的资源的创建和/或已有资源的修改。
         */
        POST((byte) 3),
        /**
         * 向指定资源位置上传其最新内容。
         */
        PUT((byte) 4),
        /**
         * 请求服务器删除Request-URI所标识的资源。
         */
        DELETE((byte) 5);

        private byte value;

        Method(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }
    public enum ResultStatus{
        /**
         * 操作成功
         */
        SUCCESS((byte) 0),
        /**
         * 操作失败
         */
        FAILED((byte)1);

        private byte value;

        ResultStatus(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }
}
