package com.opnext.bboxdomain;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Locale;

/**
 * @author wanglu
 */
@Data
@Slf4j
public class OserviceOperator implements Cloneable {
    String appId;
    Long userId;
    Long tenantId;
    List<Integer> deviceGroups;
    List<Integer> organizations;
    UserType userType;
    String loginName;
    /**
     * 当前用户的多语言环境
     */
    Locale curLocale;

    public Object cloneBean() {
        try {
            //仅浅复制
            return super.clone();
        } catch (CloneNotSupportedException e) {
            log.error("OserviceOperator.clone error:{}", e);
            return new OserviceOperator();
        }
    }

    public enum UserType {
        /**
         * 超管
         */
        SUPER((byte) 0),
        /**
         * 普通
         */
        COMMON((byte) 1),
        /**
         * API调用者
         */
        API((byte) 2),
        /**
         * APPStore调用者
         */
        GLOBAL((byte) 3);
        private byte value;

        UserType(byte value) {
            this.value = value;
        }

        public byte value() {
            return this.value;
        }
    }
}
