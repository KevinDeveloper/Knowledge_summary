package com.opnext.bboxdomain.device;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

/**
 * @Title:
 * @Description:
 * @author tianzc
 * @Date 下午5:04 18/5/7
 */
@Slf4j
@AllArgsConstructor
public enum DeviceTypeEnum {

    /**
     * 单屏
     */
    DEVICE_TYPE_SINGLE_SCREEN("1001"),
    /**
     * 门禁
     */
    DEVICE_TYPE_ACCESS_CONTROL("2001"),
    /**
     *  闸机
     */
    DEVICE_TYPE_GATE_MACHINE("3001"),
    /**
     * 桌面机
     */
    DEVICE_TYPE_DESKTOP_MACHINE("4001");
//    /**
//     * 摄像头
//     */
//    DEVICE_TYPE_CAMERA("5001");

    private String value;

    private static Map<String, DeviceTypeEnum> valMap = new HashMap<>();

    public String value(){
        return this.value;
    }

    static {
        for (DeviceTypeEnum deviceType : values()) {
            valMap.put(deviceType.value, deviceType);
        }
    }

    public static DeviceTypeEnum indexOfVal(String value) {
        DeviceTypeEnum deviceType = valMap.get(value);
        if(null == deviceType){
            log.error("DeviceType中没有找到匹配的 " + value);
            throw new IllegalArgumentException("No element matches " + value);
        }
        return deviceType;
    }
}
