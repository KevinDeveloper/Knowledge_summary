package com.opnext.bboximage.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author tianzc
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "face.data.image")
public class FaceImageProperties {
    private static final String DEFAULT_PERMIT_FORMAT_NAME = "jpg|jpeg|png|bmp";
    /**
     * 默认图片最小宽高
     */
    public static final int DEFAULT_MIN_WIDTH = 295;
    public static final int DEFAULT_MIN_HEIGHT = 413;
    /**
     * 默认文件最大字节
     */
    public static final int DEFAULT_MAX_SIZE_MB = 10;
    /**
     * 文件临时目录
     */
    private String tempPath;
    /**
     * 照片最小宽度
     */
    private Integer minWidth;
    /**
     * 照片最小高度
     */
    private Integer minHeight;
    /**
     * 照片最大大小，单位MB
     */
    private Integer maxSize;
    /**
     * 校验格式
     */
    private String permitFormatName;

    public Integer getMinWidth() {
        return minWidth != null ? minWidth : DEFAULT_MIN_WIDTH;
    }

    public Integer getMinHeight() {
        return minHeight != null ? minHeight : DEFAULT_MIN_HEIGHT;
    }

    public Integer getMaxSize() {
        return maxSize != null ? maxSize : DEFAULT_MAX_SIZE_MB;
    }

    public String getPermitFormatName() {
        return permitFormatName != null ? permitFormatName : DEFAULT_PERMIT_FORMAT_NAME;
    }
}
