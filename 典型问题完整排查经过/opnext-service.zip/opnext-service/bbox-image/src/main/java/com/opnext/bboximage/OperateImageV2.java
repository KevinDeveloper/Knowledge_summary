package com.opnext.bboximage;

import com.opnext.bboximage.conf.FaceAlgorithmProperties;
import com.opnext.bboximage.conf.FaceImageProperties;
import com.opnext.bboximage.domain.algorithm.FaceLocation;
import com.opnext.bboximage.util.IOUtils;
import com.opnext.bboximage.util.ImageBase64;
import com.opnexts.algo.core.domain.Rect;
import lombok.Builder;
import lombok.Data;
import lombok.NonNull;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.CropImageFilter;
import java.awt.image.FilteredImageSource;
import java.awt.image.ImageFilter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author tianzc
 */
@Slf4j
@Component
public class OperateImageV2 {
    @Resource
    private FaceImageProperties faceImageProperties;
    @Resource
    private FaceAlgorithmProperties faceAlgorithmProperties;
    /**
     * 裁剪后默认图片格式
     */
    public static final String DEFAULT_FORMAT_NAME = "JPEG";

    /**
     * 默认文件最大字节
     */
    public static final int DEFAULT_MAX_SIZE_BYTE = 2 * 1024 * 1024;
    /**
     * 默认最大宽高分辨率
     */
    public static final int DEFAULT_MAX_WIDTH_HEIGHT_PIXEL = 1024;
    /**
     * 图片扩展像素倍率
     */
    public static final int FACE_WIDTH_TIMES = 2;
    public static final int FACE_HEIGHT_TIMES = 2;
    /**
     * 图片扩展率
     */
    public static final int WIDTH_EXPAND_RATE = 4;
    public static final int HEIGHT_EXPAND_RATE = 5;

    public Optional<byte[]> cropImage(@NonNull String imgBase64, @NonNull Rect faceLocation) {
        Optional<byte[]> optional = cropImage(imgBase64, faceLocation,faceImageProperties.getMinWidth(),faceImageProperties.getMinWidth());
        return optional;
    }

    public Optional<byte[]> cropImage(@NonNull String imgBase64, @NonNull Rect faceLocation, Integer minWidth, Integer minHeight) {

        byte[] resData = null;
        try {
            try {
                Optional<BufferedImage> optional = ImageBase64.getBufferedImage(imgBase64);
                if (optional.isPresent()) {
                    BufferedImage bi = optional.get();
                    ImagePixel imagePixel = calculatePixel(bi.getWidth(),bi.getHeight(),minWidth,minHeight, faceLocation);
                    resData = cropImage(optional.get(),imgBase64, imagePixel, minWidth, minHeight);
                }
            } catch (Exception e) {
                log.error("--------图片裁剪方法------获取BufferedImage异常:{}", e);
            }
        } catch (Exception e) {
            log.error("OperateImage图片裁剪异常:{}", e);
        }
        return Optional.ofNullable(resData);
    }

    private byte[] cropImage(BufferedImage bi,String imgBase64, ImagePixel imagePixel, Integer minWidth, Integer minHeight) {
        int srcWidth = bi.getWidth();
        int srcHeight = bi.getHeight();
        // 人脸宽度
        int faceWidth = imagePixel.getWidth();
        // 人脸高度
        int faceHeight = imagePixel.getHeight();
        // 图片起始坐标
        int xLeft = imagePixel.getXLeft();
        int yTop = imagePixel.getYTop();

        byte[] resData = null;
        boolean existed = ((Objects.nonNull(minWidth) && Objects.nonNull(minHeight)) && (faceWidth < minWidth || faceHeight < minHeight));
        if (existed) {
            resData = ImageBase64.getByteByImgBase64(imgBase64);
        } else {
            if (srcWidth >= faceWidth && srcHeight >= faceHeight) {
                Image image = bi.getScaledInstance(srcWidth, srcHeight, Image.SCALE_SMOOTH);
                ImageFilter cropFilter = new CropImageFilter(xLeft, yTop, faceWidth, faceHeight);
                Image img = Toolkit.getDefaultToolkit().createImage(new FilteredImageSource(image.getSource(), cropFilter));
                //针对终端处理长度或宽度大于1024的图片
                if (faceWidth > DEFAULT_MAX_WIDTH_HEIGHT_PIXEL) {
                    faceHeight = faceHeight * DEFAULT_MAX_WIDTH_HEIGHT_PIXEL / faceWidth;
                    faceWidth = DEFAULT_MAX_WIDTH_HEIGHT_PIXEL;
                }
                if (faceHeight > DEFAULT_MAX_WIDTH_HEIGHT_PIXEL) {
                    faceWidth = faceWidth * DEFAULT_MAX_WIDTH_HEIGHT_PIXEL / faceHeight;
                    faceHeight = DEFAULT_MAX_WIDTH_HEIGHT_PIXEL;
                }
                log.info("原图片像素：srcWidth = {}，srcHeight = {}，图片裁剪像素：faceWidth = {}，faceHeight = {}", srcWidth, srcHeight, faceWidth, faceHeight);
                BufferedImage tag = new BufferedImage(faceWidth, faceHeight, BufferedImage.TYPE_INT_RGB);
                Graphics2D g = tag.createGraphics();
                g.drawImage(img.getScaledInstance(faceWidth, faceHeight, Image.SCALE_SMOOTH), 0, 0,null);
                g.dispose();
                ByteArrayOutputStream outputStream = null;
                try {
                    outputStream = new ByteArrayOutputStream();
                    ImageIO.write(tag, DEFAULT_FORMAT_NAME, outputStream);
                    resData = outputStream.toByteArray();
                } catch (Exception e) {
                    log.error("--resData = outputStream.toByteArray()处理异常:{}", e);
                } finally {
                    IOUtils.closeQuietly(outputStream);
                }
            } else {
                log.warn("==========图片尺寸出错==========");
            }
        }
        return resData;
    }

    /**
     * 获取图片文件格式，无法解码图片返回null
     * @param imgPath
     * @return
     */
    public Optional<String> getFormatName(String imgPath) {
        String formatName = null;
        File imgFile = new File(imgPath);
        if (imgFile.isFile()) {
            Optional<String> optional = getFormatName(imgFile);
            if (optional.isPresent()) {
                formatName = optional.get();
            }
        }
        return Optional.ofNullable(formatName);
    }

    /**
     * 获取图片文件格式，无法解码图片返回null
     * @param input 为File或InputStream
     * @return
     */
    public Optional<String> getFormatName(Object input) {
        ImageReader reader = null;
        ImageInputStream iis = null;
        String formatName = null;
        try {
            iis = ImageIO.createImageInputStream(input);
            Iterator<ImageReader> iter = ImageIO.getImageReaders(iis);
            if (!iter.hasNext()) {
                return null;
            }
            reader = iter.next();
            formatName =  reader.getFormatName();
        } catch (IOException e) {
            log.error("getFormatName获取图片类型异常：{}", e.getMessage());
        } finally {
            reader.dispose();
            IOUtils.closeQuietly(iis);
        }
        return Optional.ofNullable(formatName);
    }

    /**
     * 根据人脸坐标计算图片裁剪分辨率，起始坐标
     * @param faceLocation
     * @return
     */
    public ImagePixel calculatePixel(FaceLocation faceLocation) {
        // 算法检测人脸坐标
        int left = faceLocation.getLeft();
        int right = faceLocation.getRight();
        int top = faceLocation.getTop();
        int bottom = faceLocation.getBottom();
        // 人脸宽度
        int faceWidth = right -left;
        // 人脸高度
        int faceHeight = bottom - top;
        // 计算扩展像素
        int tmpWidth = faceWidth * WIDTH_EXPAND_RATE / 10;
        int tmpHeight = faceHeight * HEIGHT_EXPAND_RATE / 10;
        int xLeft, yTop;
        if (left > tmpWidth) {
            xLeft = left - tmpWidth;
        } else {
            xLeft = 0;
        }
        if (top > tmpHeight) {
            yTop = top - tmpHeight;
        } else {
            yTop = 0;
        }
        faceWidth += (FACE_WIDTH_TIMES * tmpWidth);
        faceHeight += (FACE_HEIGHT_TIMES * tmpHeight);
        ImagePixel imagePixel = ImagePixel.builder().xLeft(xLeft).yTop(yTop).width(faceWidth).height(faceHeight).build();
        return imagePixel;
    }

    /**
     * 根据人脸坐标计算图片裁剪分辨率，起始坐标
     * @param faceLocation
     * @return
     */
    public ImagePixel calculatePixel(@NonNull Integer srcWidth,@NonNull Integer srcHeight,Integer minWidth, Integer minHeight, Rect faceLocation) {
        // 算法检测人脸坐标
        int left = (int) faceLocation.getLeft();
        int right = (int) faceLocation.getRight();
        int top = (int) faceLocation.getTop();
        int bottom = (int) faceLocation.getBottom();
        // 人脸宽度
        int faceWidth = right - left;
        // 人脸高度
        int faceHeight = bottom - top;
        // 计算扩展像素
        int tmpWidth = faceWidth * WIDTH_EXPAND_RATE / 10;
        int tmpHeight = faceHeight * HEIGHT_EXPAND_RATE / 10;

        faceWidth += (FACE_WIDTH_TIMES * tmpWidth);
        faceHeight += (FACE_HEIGHT_TIMES * tmpHeight);
        // 校验图片像素最小尺寸，不合格计算裁剪合格尺寸
        boolean existed = ((Objects.nonNull(minWidth) && Objects.nonNull(minHeight)));
        if (existed) {
            int addWidth = 0, addHeight = 0;
            if (faceWidth <= faceHeight) {
                if (faceWidth < minWidth) {
                    int minus = minWidth - faceWidth;
                    addWidth = minus / FACE_WIDTH_TIMES + minus % FACE_WIDTH_TIMES;
                    addHeight = addWidth * HEIGHT_EXPAND_RATE / WIDTH_EXPAND_RATE + addWidth * HEIGHT_EXPAND_RATE % WIDTH_EXPAND_RATE;
                }
            } else {
                if (faceHeight < minHeight) {
                    int minus = minHeight - faceHeight;
                    addHeight = minus / FACE_HEIGHT_TIMES + minus % FACE_HEIGHT_TIMES;
                    addWidth += addHeight * WIDTH_EXPAND_RATE / HEIGHT_EXPAND_RATE  + addHeight * WIDTH_EXPAND_RATE % HEIGHT_EXPAND_RATE;
                }
            }
            tmpWidth += addWidth;
            tmpHeight += addHeight;
            faceWidth += (FACE_WIDTH_TIMES * addWidth);
            faceHeight += (FACE_HEIGHT_TIMES * addHeight);
        }
        int xLeft, yTop;
        if (left > tmpWidth) {
            xLeft = left - tmpWidth;
        } else {
            xLeft = 0;
        }
        if (top > tmpHeight) {
            yTop = top - tmpHeight;
        } else {
            yTop = 0;
        }
        if (faceWidth + xLeft > srcWidth) {
            faceWidth = srcWidth - xLeft;
        }
        if (faceHeight + yTop > srcHeight) {
            faceHeight = srcHeight - yTop;
        }
        ImagePixel imagePixel = ImagePixel.builder().xLeft(xLeft).yTop(yTop).width(faceWidth).height(faceHeight).build();
        return imagePixel;
    }

    /**
     * 支持文件格式
     * @param str
     * @return
     */
    public boolean match( String str) {
        // 不区分大小写
        String regex = "(?i)(" + faceImageProperties.getPermitFormatName() + ")";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(str);
        return matcher.find();
    }

    /**
     * 校验图片格式
     * @param multipartFile
     * @return
     */
    public boolean checkFormatMultipartFile(@NonNull MultipartFile multipartFile){
        boolean flag = false;
        InputStream inputStream = null;
        try {
            inputStream = multipartFile.getInputStream();
            flag = checkFormatFile(inputStream, multipartFile.getOriginalFilename());
        } catch (Exception e) {
            log.error("图片处理失败：{}", e);
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
        return flag;
    }

    /**
     * 根据文件 校验图片格式
     * @param file
     * @return
     */
    public boolean checkFormatFile(@NonNull File file){
        boolean flag = false;
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(file);
            flag = checkFormatFile(inputStream, file.getName());
        } catch (Exception e) {
            log.error("图片处理失败：{}", e);
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
        return flag;
    }

    public boolean checkFormatFile(InputStream inputStream, String fileName){
        boolean flag = false;
        try {
            Optional<String> formatName = getFormatName(inputStream);
            if (formatName.isPresent()) {
                // 文件格式校验
                flag = match(formatName.get());
                if (!flag) {
                    log.info("图片格式校验失败，图片格式：{}，图片名称：{}", formatName.get(), fileName);
                }
            }
        } catch (Exception e) {
            log.error("图片处理失败：{}", e);
        }
        return flag;
    }

    /**
     * multipartFile校验文件大小
     * @param multipartFile
     * @return
     */
    public boolean checkSizeMultipartFile(MultipartFile multipartFile){
        boolean flag = false;
        try {
            long limitByte = faceImageProperties.getMaxSize() * 1024 * 1024;
            if (multipartFile.getSize() > limitByte) {
                long fileSize = multipartFile.getSize() / 1024 / 1024;
                log.info("图片大小超出最大限制({}MB)验失败，图片大小：{} MB",faceImageProperties.getMaxSize(), fileSize);
            } else {
                flag = true;
            }
        } catch (Exception e) {
            log.error("图片处理失败：{}", e);
        }
        return flag;
    }

    /**
     * 校验图片文件大小
     * @param file
     * @return
     */
    public boolean checkSizeFile(File file){
        boolean flag = false;
        try {
            long limitByte = faceImageProperties.getMaxSize() * 1024 * 1024;
            if (file.length() > limitByte) {
                long fileSize = file.length() / 1024 / 1024;
                log.info("图片大小超出最大限制({}MB)验失败，图片大小：{} MB",faceImageProperties.getMaxSize(), fileSize);
            } else {
                flag = true;
            }
        } catch (Exception e) {
            log.error("图片处理失败：{}", e);
        }
        return flag;
    }

    /**
     * 校验文件像素大小
     * @param multipartFile
     * @return
     * @throws Exception
     */
    public boolean checkImagePixelMultipartFile(MultipartFile multipartFile) throws Exception{
        boolean flag = false;
        InputStream inputStream = null;
        try {
            inputStream = multipartFile.getInputStream();
            flag = checkImagePixelFile(inputStream);
        } catch (Exception e) {
            log.error("图片处理失败：{}", e);
            throw e;
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
        return flag;
    }

    /**
     * 校验文件像素大小
     * @param file
     * @return
     * @throws Exception
     */
    public boolean checkImagePixelFile(@NonNull File file) throws Exception{
        boolean flag = false;
        InputStream inputStream = null;
        try {
            inputStream = new FileInputStream(file);
            flag = checkImagePixelFile(inputStream);
        } catch (Exception e) {
            log.error("图片处理失败：{}", e);
            throw e;
        } finally {
            IOUtils.closeQuietly(inputStream);
        }
        return flag;
    }

    private boolean checkImagePixelFile(InputStream inputStream){
        boolean flag = false;
        try {
            Optional<BufferedImage> image = ImageBase64.getBufferedImage(inputStream);
            if (image.isPresent()) {
                if (faceImageProperties.getMinWidth() > image.get().getWidth() || faceImageProperties.getMinWidth() > image.get().getWidth()) {
                    log.info("图片最小像素({}x{})校验失败，图片像素 width：{}，height：{}",faceImageProperties.getMinWidth(),faceImageProperties.getMinHeight(), image.get().getWidth(), image.get().getWidth());
                } else {
                    return true;
                }
            }
        } catch (Exception e) {
            log.error("图片处理失败：{}", e);
        }
        return flag;
    }

    @Data
    @Builder
    public static class ImagePixel {
        private Integer width;
        private Integer height;
        /**
         * 图片坐标
         */
        private Integer xLeft;
        private Integer yTop;
    }
}
