package com.opnext.bboximage.conf;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author tianzc
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "face.data.algorithm")
public class FaceAlgorithmProperties {
    /**
     * 默认开启质量校验
     */
    public static final boolean DEFAULT_DETECT = true;
    /**
     * 默认开启人脸角度旋转率校验
     */
    public static final boolean DEFAULT_ANGLE = true;
    /**
     * 默认不开启眼镜校验
     */
    public static final boolean DEFAULT_GLASS = false;
    /**
     *  是否开启质量检测，默认 开启(true)
     */
    private Boolean qualityDetect;

    /**
     * 是否开启角度校验，默认 开启（true）
     */
    private Boolean qualityAngle;

    /**
     * 是否开启佩戴眼镜校验，默认 不开启（false）
     */
    private Boolean qualityGlass;

    /**
     * 标识清晰程度
     */
    private Integer clearLevel;

    /**
     * 标识遮挡
     */
    private Integer visLevel;

    /**
     * 标识眼镜
     */
    private Integer glassLevel;

    public Boolean getQualityDetect() {
        return (this.qualityDetect != null ? this.qualityDetect : DEFAULT_DETECT);
    }

    public Boolean getQualityAngle() {
        return (this.qualityAngle != null ? this.qualityAngle : DEFAULT_ANGLE);
    }

    public Boolean getQualityGlass() {
        return (this.qualityGlass != null ? this.qualityGlass : DEFAULT_GLASS);
    }
}
