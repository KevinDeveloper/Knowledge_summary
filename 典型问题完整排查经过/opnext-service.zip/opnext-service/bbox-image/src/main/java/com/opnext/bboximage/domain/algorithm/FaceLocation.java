package com.opnext.bboximage.domain.algorithm;

import lombok.Data;

/**
 * @author tianzc
 */
@Data
public class FaceLocation {
    private int left;
    private int right;
    private int top;
    private int bottom;
}
